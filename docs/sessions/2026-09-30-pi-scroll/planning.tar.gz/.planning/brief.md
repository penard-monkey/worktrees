# Investigate + fix: the mouse wheel does not scroll a pi pane in the app

## What David sees
In the worktrees app (v0.33.0), a pi lane's terminal (e.g. valleos `todo-first`,
tmux session `valleos-todo-first~agent~pi`) cannot be scrolled — the wheel does nothing
useful, so earlier pi output is unreachable. Claude panes scroll fine.

## Measured before this lane started (2026-09-29, live tmux)
```
valleos-todo-first~agent~pi  alternate_on=0 history_size=525 limit=2000 mouse_any_flag=0 mouse_sgr_flag=0 cmd=node
valleos-(main) (Claude)      alternate_on=1 history_size=0   limit=2000 mouse_any_flag=1 mouse_sgr_flag=1 cmd=2.1.283
tmux global `mouse` = off
```
So Claude runs in the alternate screen with mouse reporting ON and scrolls itself; pi
draws in the MAIN screen with NO mouse reporting, and its history lives in tmux's
scrollback (525 lines). Codex (alt screen?) and a plain shell are the other two cases
the fix must not break. (opencode, per its proposal, is alt-screen with history 0.)

## Task
1. Find how the app turns a wheel event into scrolling today: `TerminalPane` /
   `useTerm` / the xterm setup (xterm attached to a tmux client, which is itself
   alternate-screen from xterm's point of view), any wheel handler, whether the app
   ever enters tmux copy-mode, `mouse` settings the app applies to its tmux server,
   and what xterm sends for a wheel when the app underneath does not request mouse
   (alternate-scroll → arrow keys? nothing?). Say exactly what happens for a pi pane
   today — including whether the wheel is turned into ↑/↓ keys that pi reads as
   editor history (that would be worse than nothing).
2. Design the fix for ALL pane kinds: Claude (app-driven scroll, mouse on), Codex, pi
   (main screen + tmux history), plain shell, and the dock's own shells if they share
   the path. Likely shape: when the pane's program has not asked for the mouse
   (`#{mouse_any_flag}`/`#{alternate_on}`), a wheel scrolls tmux history (copy-mode
   `-e` + scroll, exit at bottom), otherwise it is forwarded as today. Keep keyboard
   input going to the program; make sure a scrolled-back pane returns to live output
   on typing and on new output behaviour you choose deliberately. Check AGENTS.md's
   terminal rules (resize/SIGWINCH coalescing, replay muting, xterm stops propagation
   of handled keys, `useEscape`) before touching TerminalPane.
3. Prove it: a check script in `app/scripts/` evaluating the real source (the
   `termresize-check.mjs` / `termreplay-check.mjs` shape), shown failing first; a real
   tmux probe in a THROWAWAY server (`tmux -L <name>`, killed after) with a main-screen
   program that prints 300 lines (no need to run pi itself — `seq 1 300; cat` is the
   same terminal shape; if you do want pi, only with lm-studio and only if your safety
   check allows it). Do NOT drive David's running app (not by name, AppleScript or
   keys); the mock harness on a port ≠ 1420 is fine; the sandbox app only by PID.
4. Gates per AGENTS.md (grep-reported), CHANGELOG `### Fixed` under `## [Unreleased]`
   with a bold lead — another open PR (#372) also adds `## [Unreleased]` → `### Fixed`;
   after rebasing on whichever lands first there must be exactly ONE `[Unreleased]` and
   ONE `### Fixed` (count them). Open a PR, watch CI with `gh run watch <id>
   --exit-status`, report, STOP. Do not merge.

## Rules
- Codex is out of tokens: no Codex sessions (reason about Codex's pane shape from
  tmux flags on an existing Codex pane if one is up, else from code/fixtures).
- Lane `pi-phase3` is editing mcp.rs, harness.rs, pi.rs and app pi surfaces; lane
  `notallowed-error` touched clipboard code — stay out unless the cause is there.
- Scratch in `~/.cache/worktrees/worktrees/<this worktree>/`. Keep Co-Authored-By; NO
  session URLs or Claude-Session trailers.
