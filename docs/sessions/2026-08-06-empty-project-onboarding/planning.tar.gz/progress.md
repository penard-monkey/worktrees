# Progress

## Session 2026-08-02 — empty-project onboarding
- Read screenshot `_tmp/Screenshot 2026-08-02 at 20.13.12.png`; reproduced in
  `/Users/davidpena/workspace/headshots`. Root cause = unborn HEAD.
- Planning files created. Phase 1 complete.
- Phases 2–5 complete: core guard (`git::has_commits` + `cmd_new` preflight),
  backend `probe_dir` / `init_repo` / `create_initial_commit` + `unborn` on the
  snapshot, `InitRepoPrompt` / `UnbornPrompt` in the nav, mock parity via
  `?empty` / `?unborn` knobs, bats test in `test/new.bats`.
- Gates green: 242 bats ok, lint clean, cargo check core+app, tsc clean.
- Verified headlessly (mock harness :5199): init offer → project added;
  unborn project → first-commit action → form swaps to New worktree.
- Verified against the real repo: `worktrees new` in /Users/davidpena/workspace/headshots
  now refuses with the remedy instead of git's "not a valid object name".
