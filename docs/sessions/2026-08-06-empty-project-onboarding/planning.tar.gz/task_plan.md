# Task plan — empty-project onboarding (git init + first commit)

**Goal**: adding a non-git folder to the app should offer `git init`; a repo with
zero commits (unborn HEAD) must not fail worktree creation with git's raw
`fatal: not a valid object name: 'main'`.

## Root cause (confirmed)
`/Users/davidpena/workspace/headshots` was `git init`ed but has **no commits**.
`git worktree add -b project-config <dir> main` → `fatal: not a valid object
name: 'main'`. Missing remote is NOT the cause.

## Phases
| # | Phase | Status |
|---|-------|--------|
| 1 | Repro + root cause | complete |
| 2 | Core: unborn-HEAD preflight guard in `cmd_new` (+ bats test) | complete |
| 3 | Backend cmds: `probe_dir`, `init_repo`, `create_initial_commit` | complete |
| 4 | Frontend: offer `git init` on add; offer first commit on unborn repo | complete |
| 5 | Mock harness parity (`app/src/mock/install.ts`) | complete |
| 6 | Gates (build, bats, lint, cargo test, tsc/cargo check) + PR | in_progress |

## Key files
- `crates/worktrees-core/src/ops.rs:209` `cmd_new` — worktree create path
- `crates/worktrees-core/src/project.rs:47` `Project::discover` — git guard
- `app/src-tauri/src/lib.rs:220` `add_project`
- `app/src/App.tsx:1381` `addProject`
- `app/src/mock/install.ts:197`

## Errors log
| Error | Attempt | Resolution |
|-------|---------|------------|
| `fatal: not a valid object name: 'main'` | repro | unborn HEAD; needs initial commit |
