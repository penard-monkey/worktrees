# Findings

## Repro (2026-08-02)
```
$ cd /Users/davidpena/workspace/headshots
$ git symbolic-ref HEAD          # refs/heads/main
$ git rev-parse --verify HEAD    # fatal: Needed a single revision  (unborn)
$ git worktree add -b project-config /tmp/wt-test main
Preparing worktree (new branch 'project-config')
fatal: not a valid object name: 'main'
```
`git worktree add` needs a real commit-ish. No remote is irrelevant; a repo with
commits but no remote works (`start` falls back to the local base branch —
ops.rs:349 only prefers `origin/<base>` when that ref exists).

## Code map
- `Project::discover` (project.rs:47) guards only `rev-parse --is-inside-work-tree`
  → a commit-less repo *can* be added as a project (headshots already has
  `.worktrees.places.json`). Failure surfaces later, in `cmd_new`.
- `cmd_new` (ops.rs:209) → create block at ops.rs:345-360: prefers
  `origin/<base>` if present, else bare `<base>`; calls
  `git worktree add -b <branch> <wt> <start>` and prints the two error lines
  seen in the screenshot.
- App add-project: `App.tsx:1381` → `invoke("add_project")` → `lib.rs:220` →
  `Project::discover` → `Err("Not inside a git repository.")` shown via `fail()`.
  No remediation offered.

## Design decisions
- Guard belongs in core `cmd_new` (CLI + app both benefit, bats-testable).
- App gets two remediation affordances: `git init` on add of a non-repo, and
  "create initial commit" when the repo has an unborn HEAD.
- Initial commit = `git commit --allow-empty -m "Initial commit"` (works on an
  empty dir; does not touch user files).
