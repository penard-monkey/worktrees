# Brief: the wheel scrolls a Codex pane

## Symptom
David can't scroll in a Codex lane (mac-utilities `gif-stickers`, codex-cli 0.159.0). The live pane `mac-utilities-gif-stickers~agent~codex:0.0` measured:
- `alternate_on=1`, `pane_mode=` empty;
- all `mouse_*_flag=0`;
- `history_size=0`.

So Codex 0.159 runs its TUI on the ALTERNATE screen and never asks for the mouse. Read `docs/sessions/2026-09-30-pi-scroll/summary.md` first; it is the whole background. The app's `wheel_plan` (`app/src-tauri/src/lib.rs`, `term_wheel`) sends `send-keys Up/Down` for an alt-screen pane with no mouse. Codex reads those as composer history, or nothing, and tmux has no history to scroll.

## Leading fix (measure before committing to it)
`codex --help` offers `--no-alt-screen`: "Runs the TUI in inline mode, preserving terminal scrollback history." Codex's output would then land on the pane's MAIN screen and in tmux history. The existing pi path (main screen → `copy-mode -e` + `scroll-up`) would scroll it with no app change.

1. **MEASURE FIRST, on a throwaway tmux server.** Use **`tmux -L <unique-name>` (or `-S <sock>` with `env -u TMUX`) on EVERY call, including kill-server. NEVER run a bare `tmux kill-server`; `TMUX_TMPDIR` is not isolation inside a lane.** On 2026-10-01 a lane killed David's whole tmux server.
   - Start `codex --no-alt-screen` (a trivial prompt is fine, or none; do not burn quota on a long task) and confirm `alternate_on=0` and that `history_size` grows.
   - Confirm `copy-mode -e` + `scroll-up` shows earlier output.
   - Check how inline mode behaves under a tmux resize: does the redraw duplicate or garble the transcript in history? Check the composer, the approval/question modals and `codex resume`.
   - Compare with alt-screen: does Codex itself scroll its transcript on PageUp/PageDown or some key while in alt-screen? If so, the alternative is to teach `wheel_plan` to send that key for a Codex pane. Report which is cleaner, with evidence.
2. **Build the winner.**
   - If it is `--no-alt-screen`, add it in the Codex harness's launch argv (`crates/worktrees-core/src/harness.rs` and wherever the codex command line is built; the live argv has `-c forced_login_method=…`, `-c developer_instructions=…` and so on).
   - Apply it to fresh launches AND resume. Don't add it twice if the user's own AI command already carries it.
   - NEVER write `~/.codex/config.toml`; per-launch argv only.
   - Check the knock-on effects on Codex's "waiting" detection: `codex_waiting_panes` captures the pane and keys on the modal FOOTER being the bottom line (AGENTS.md, the Codex rollout notes). Inline mode could change what `capture-pane` returns, so verify the amber dot still works, and update the fixtures/tests if the capture shape changes.
   - Also check `send`/paste into a Codex pane (`leave_mode`, `paste_commands`).
3. **Tests.**
   - A unit test that the Codex launch argv carries the flag, on both fresh and resume.
   - Show it fails before the change.
   - Plus whatever the waiting-detection change needs.
   - If it is the app-side alternative, extend `termwheel-check.mjs` or the `wheel_plan` Rust tests, fail-first.
4. **AGENTS.md** gets a short note in the Codex rollout section: Codex 0.15x runs on the alternate screen without the mouse, so the wheel has nothing to scroll; we launch it inline. **`docs/adding-a-harness.md`** gets a "the wheel scrolls it" check, if it doesn't already have one.
5. **CHANGELOG**: under `## [Unreleased]`, add a `### Fixed` entry. Another lane (`cli-no-spare`) is adding `### Changed` there at the same time, so on any rebase keep ONE of each `###` and count them.

## Gates (AGENTS.md; `make -C <place root>`)
1. `git submodule update --init --recursive`, then `cargo build --release -p worktrees-cli` FIRST.
2. `make test`: check the plan line and the not-ok count.
3. `make lint`.
4. `cargo test` for each of `-p worktrees-core`, `-p worktrees-cli` and `-p app --lib`. Report them with a grep, not a tail.
5. Frontend: `nvm use`, then `corepack pnpm install` in app/. Then run tsc and `make -C <root> test-frontend`.
6. `ls --json` byte-identical to `~/.local/bin/worktrees`.

Real-app check: you may NOT drive David's running app. Say in the PR what David should try by hand (scroll a fresh Codex lane, resize, an approval prompt).

## Finish
- Open a PR. Commits keep a Co-Authored-By line, with no Claude-Session trailers or session URLs.
- Watch CI with `gh run watch <id> --exit-status`.
- Report to the orchestrator in (main) with the PR number, the measurements, the gates and the fail-first evidence. Do NOT merge.

## Don't
- Don't touch David's existing tmux sessions, including the gif-stickers Codex lane. It is waiting on a question right now; leave it alone.
- Don't write to `~/.codex`, `~/.claude.json` or `~/.pi`.
- Don't run long Codex tasks; quota matters.
- For scratch repos use a `worktrees new <name> --ai none --no-spare --no-attach` place, or a dir under `~/.cache/worktrees/worktrees/codex-scroll/`. Never use `git worktree add`.
