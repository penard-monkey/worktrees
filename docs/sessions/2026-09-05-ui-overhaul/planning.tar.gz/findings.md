# findings.md — ui-tweaks: metrics, nav states, settings page, release notes, drafts

_Research context. Treat as data._

## Screenshot 2026-09-05 16.55.20 (`_tmp/`)
- Topbar of a RENAMED place: `standup-and-daily-work` (title) then two grey
  chips both reading `random-work`. Source (App.tsx ~4990-5006): `.slug-alias`
  (dir/tmux name, shown whenever `declared.title` is set) + `.branch` chip.
  Branch === slug, so `hi`/`↗` are suppressed and the two chips are identical.
  Fix: when `branch === slug` render ONE chip (alias) — or when both differ,
  keep two. Nav row shows title only, no alias, so nav is fine.
- Left rail: Places / Recent / Attention lens icons at top; bottom: hide-nav
  (PanelLeftClose), add-project, settings gear. Nav bottom: usage widget,
  "Add project" footer.

## Left nav today (App.tsx)
- `settings.nav_collapsed` (bool) + `settings.lens` ("places"|"recent"|"attention").
- `changeLens` (~4482): collapsed → open into lens; active lens click → toggleNav
  (VS Code model). So the top icon ALREADY toggles; the rail-bottom button
  (~4892) is a pure duplicate. ⌘B = toggleNav. ⌘2..N = keyboard lens select
  (always reveals, never collapses).
- `fitLayout` (settings.ts:401) turns `nav_collapsed` into a grid column being
  REMOVED (`gridCols` filter). A hover-reveal nav therefore cannot be the grid
  column — it must be an overlay (`position:absolute`, left = rail width,
  z above `.space`), otherwise every reveal reflows the terminal (SIGWINCH
  + refit, see CLAUDE.md resize rules).
- Nav is kept MOUNTED while collapsed (`.nav.hidden {display:none}`) so drafts/
  scroll survive — an overlay must keep that property.
- Keyboard nav inside the tree: search input (`searchRef`), ⌘K QuickSwitch
  palette (ranks by activity → it IS the "recent" surface). `hasAttention`
  (line 180) = dirty || ahead || (main && behind).
- Existing surfaces that must keep an auto-hidden nav OPEN: ctx menus
  (`.menu-catch` overlay), sort popover, add-project menu, drag (`body.dragging`),
  TitleEditor/rename, InitRepoPrompt, filter input focus.

## Release notes today
- CHANGELOG.md is 1306 lines, ships in the binary (`get_changelog`).
  `parseNotes` (App.tsx ~303) → sections/groups/items; `ReleaseNotes` renders
  every bullet in full. Shown in `.settings-sheet.whatsnew` over the scrim
  (auto on version change, manual from Settings → Version).
- EVERY bullet starts with `**Bold lead sentence.** long paragraph…`. So a
  compact view = lead only, paragraph behind a disclosure — no changelog
  rewrite, GitHub release notes unchanged.
- ROADMAP: links in notes print raw (`[text](url)` unhandled) — unrelated.

## Settings today
- `SettingsSheet.tsx` 583 lines, 14 `<section className="setting">` blocks
  (appearance/zoom, fonts, theme, density, nav, dock/files, AI profiles
  summary, editor/terminal cmds, updates/version, auto-fetch, restore, logs,
  data dir, danger). Rendered as a right-side sheet over a scrim.
  `ProjectSheet`, `StatusSheet`, `whatsnew` are sibling sheets; whatsnew stacks
  ON TOP of Settings.
- Home screen is already a takeover surface inside `.space` (sel === null) —
  precedent for a Settings PAGE that keeps rail + nav usable.
- ROADMAP: app chords (⌘B/⌘J/⌘1-9/⌘±) fire behind whatsnew/ProjectSheet scrims
  — a page-mode Settings sidesteps this for Settings, still open for sheets.
- Persisted UI state = `ui-state.json` written whole-blob by frontend.

## Claude "unsent draft" signal
- Probe `~/.claude/sessions/<pid>.json` has: pid, cwd, status, tmux
  (`"<session>:@<win>.%<pane>"`, e.g. `cdv-random-work:@0.%0`; `null` when not
  under tmux), updatedAt/statusUpdatedAt, parkedJobId. NO draft/prompt field.
  Nothing under ~/.claude persists an unsent prompt (history.jsonl = submitted).
- `tmux capture-pane -p -t %0` on an IDLE claude pane prints:
  ```
  ─────────────── Marisol WhatsApp contract discussion ─
  ❯ ok now let's look at the wilmar group message
  ──────────────────────────────────────────────────
    ⏵⏵ auto mode on (shift+tab to cycle) · ← 2 agents   /rc
  ```
  and an empty prompt is `❯ ` alone. Pane ids (`%N`) are server-global, so
  `-t %N` works without the session name (`session:%N` does NOT — "can't find
  window").
- tmux chains commands in ONE process: `tmux capture-pane -p -t %0 -S -12 \;
  display-message -p '@@' \; capture-pane -p -t %1 -S -12 …` → one spawn for
  all live sessions per tick (CLAUDE.md: count subprocesses; the 3s loop
  already runs `session_fingerprint`). Sample every 5th tick (15s) like
  `save_shell_cwds` — a draft is a slow signal.
- Parse: last line starting with `❯` (also accept `>` at col 0 for older
  claude); draft = text after it + following lines until a `───` rule;
  non-empty after trim → draft. Ignore when status == busy (the prompt line
  is then the queued/next message — arguably also worth showing, as "queued").
- Multi-line drafts wrap inside the box; continuation lines are indented two
  spaces. Copy-mode does not change capture-pane output (captures the pane
  screen, not the scrollback view).
- Live sessions right now: 22 probes, 20 idle, 2 busy; one has tmux=null
  (pid 34099, random-work — launched outside tmux, no signal possible: correct
  degradation = no dot).

## Metrics / heatmap
- No telemetry of any kind exists (grep: none). `applog` (lib.rs:64) writes
  app.log (UTC). Config dir holds ui-state.json (frontend-owned whole blob) and
  shell-cwds.json (backend-owned) — a metrics store must be backend-owned
  like shell-cwds.json, never inside ui-state.json.
- Cheapest full-coverage capture: ONE delegated `click`/`keydown`-chord
  listener on `document` that resolves `closest('[data-track], [title],
  [data-testid], button')` → a stable key (data-track > data-testid > title >
  class path), plus explicit `track()` for chords and for surface DWELL
  (`lastSurface` pointerdown tracking already exists at App.tsx ~2496;
  visibilitychange is reliable per CLAUDE.md).
- Existing patterns to reuse for the view: `UsageWidget` (nav), StatusSheet's
  `.update-log` boxes, `dataviz` skill for the heatmap (rows = control,
  cols = day / hour-of-day).
