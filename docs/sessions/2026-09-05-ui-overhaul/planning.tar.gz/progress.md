# progress.md

## 2026-09-05 session 1 (fable, design)
- Read screenshot; grounded nav/lens/topbar/settings/whatsnew/claude-probe code.
- Confirmed tmux capture-pane exposes the unsent `❯ …` line on idle panes.
- Wrote findings.md + task_plan.md. Next: design canvas + written proposal.
- Authored 6 artboards in ~/.cache/worktrees/worktrees/ui-tweaks/design/ (Main=sidebar states,
  Topbar, ReleaseNotes, Drafts, SettingsPage, Usage) + canvas.json; seeded + checked.
- Published canvas: https://claude.ai/code/artifact/40e61a3a-d944-4788-8e6a-20d44612ffa4
- Next: visual check in Chrome, then written proposal to David.
- Visual check in Chrome: all six boards render; widened Sidebar board (frames overflowed at 1740),
  raised Topbar/Drafts heights (scrollbars). Republished to the same URL.
- Handed the proposal to David. Waiting on: sidebar behaviour picks, Settings page vs modal,
  whether to fold Recent/Attention now or after Usage data.
- David: Settings = centered modal; sidebar default = auto-hide overlay. Settings board rebuilt
  as a modal over the app (nav hidden behind, terminal full width), canvas republished.
- Still open: fold Recent/Attention now vs after usage data. Then PRs A→E per task_plan.
- David: lenses out now. Branched `ui-tweaks-header-chip` off origin/main (v0.20.0 landed since
  the worktree parked). Wrote PR A brief (scratchpad/brief-pr-a-header-chip.md), launched opus agent.
- PR #187 (header chip) reviewed, squash-merged (80a46f9). Branched `ui-tweaks-sidebar` off the
  merged main; brief in scratchpad/brief-pr-b-sidebar.md; launching opus agent.
- PR B agent report reviewed (diff clean; overlay never reflows; 12 harness readings). Committed
  0e9cc10, opened PR #188, CI watching in background. Rough edge noted in PR: Enter in the filter
  picks the first VISIBLE row (collapsed groups hide matches) → ROADMAP candidate.
- Next: PR C brief (Settings modal + compact What's new + chord guard).
- PR #188 merged (squash). Branched `ui-tweaks-settings-modal` off merged main; brief at
  scratchpad/brief-pr-c-settings-modal.md; launching opus agent.
- Wrote briefs D (usage metrics) and E (draft marker) in the scratchpad while PR C's agent runs.
  tmux chaining verified: `;` as its own argv element; display-message eats `%` in its format.
- PR C agent report reviewed: modal + compact notes + DOM-based chord guard good. One revision sent
  back: page zoom (⌘+/⌘−/⌘0) exempt from the guard (view op, moves nothing; old decision stands);
  ⌘⌥ markdown zoom stays guarded. Waiting on the agent's revision.
- PR C revision verified (page zoom exempt, zoom-check red→green). Committed 0ff3223, PR #189 open.
- PR #189 merged. Branched `ui-tweaks-usage` off merged main; launching PR D agent from
  scratchpad/brief-pr-d-usage.md.
- INCIDENT: PR D agent drove David's INSTALLED app via `osascript tell application "worktrees"`
  (name resolves to /Applications/worktrees.app, not the sbx instance). David stopped it. No stray
  processes left. Rule added to CLAUDE.md (Tauri section) + both remaining briefs; agent resumed
  with bundle-id-only instruction.
- Agent cannot be resumed after a user stop (tool refuses); a NEW agent needs David's explicit go.
  Branch `ui-tweaks-usage` holds the partial PR D work uncommitted (+ my CLAUDE.md rule).
- David: go ahead. Fresh opus agent launched on `ui-tweaks-usage` to finish PR D on top of the
  partial work, under the bundle-id-only sandbox rule; no System Events, never touch pid 41444.
- PR D (fresh agent) verified the partial work end to end; my CLAUDE.md sandbox rule was WRONG
  (tauri dev binary has no bundle id) → rewritten: pid-only, no scripted input. Review round sent:
  usage-check must fail on dynamic-title buttons without data-track; trackChord must ignore
  ctrl-only chords inside .term-host; profiles.reveal data-track.
- PR D revision verified (dynamic-title guard flagged 7 more buttons, all keyed; terminal ctrl
  chords excluded). Committed c6a7b63 (+ CLAUDE.md sandbox rule), PR #190 open.
- PR #190 merged. Branched `ui-tweaks-drafts` off merged main; launching PR E agent from
  scratchpad/brief-pr-e-drafts.md (sandbox by pid only, no scripted input).
- PR E reviewed (box-edge rule, NBSP after ❯, one chained tmux spawn/15s, counts-only logging).
  Committed a0bae2d, PR #191 open. Stragglers for ROADMAP at close-out: filter Enter picks the
  first VISIBLE row (collapsed groups hide matches); APP_IDENT const → dev/sandbox build logs into
  the installed app's app.log; heatmap blind spots (combo rows, untitled pop-items, span targets).
- PR #191 merged. All five PRs in main (#187 #188 #189 #190 #191). Worktree parked on `ui-next`
  = origin/main. Not released; not installed locally. Close-out pending David's word.
