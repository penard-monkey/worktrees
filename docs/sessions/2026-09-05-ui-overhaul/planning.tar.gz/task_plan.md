# task_plan.md — ui-tweaks: usage metrics, nav states, settings page, release notes, unsent drafts

## Goal
Design (this session) and then ship, in separate PRs, five UI changes in
`app/`: (1) local usage metrics + heatmap, (2) one nav toggle with an
auto-hide/hover state that stays keyboard-navigable, (3) fix the doubled chip
in a renamed place's topbar, (4) compact release notes, (5) Settings as a page
instead of a sheet, (6) "unsent draft" indicator per place from the claude pane.

## Phases
| # | Phase | Status |
|---|-------|--------|
| 1 | Ground every item in the code + screenshot (findings.md) | complete |
| 2 | Design proposal + canvas mockups (this session's deliverable) | complete — canvas published, awaiting David's picks |
| 3 | PR A — topbar duplicate chip fix — merged as #187 | complete |
| 4 | PR B — sidebar — merged as #188 | complete |
| 5 | PR C — Settings modal + compact notes + chord guard — merged as #189 | complete |
| 6 | PR D — usage metrics — merged as #190 | complete |
| 7 | PR E — draft marker — merged as #191 | complete |
| 8 | ~~Decide lenses from data~~ — decided: out in PR B | complete |

## Decisions
- Nav: TWO persisted states (open / collapsed) + `nav_auto_reveal` behaviour on
  collapsed; the overlay is NOT a grid column (no terminal reflow). ⌘B pins.
- Release notes: lead sentence only, paragraph behind a disclosure; changelog
  text untouched.
- Settings: full page in `.space` (Home precedent), rail+nav stay usable,
  section index on the left, ⌘, toggles, Esc restores previous selection.
- Metrics: local-only, backend-owned `ui-events.jsonl`, delegated DOM listener
  + explicit chords/dwell. Never in ui-state.json.
- Drafts: one chained tmux call per 15s tick, parse `❯` line; busy → "queued".

## Errors Encountered
| Error | Attempt | Resolution |
|-------|---------|------------|
| `tmux capture-pane -t session:%N` → can't find window | 1 | pane ids are global: `-t %N` |
- Settings: MODAL, centered (~1000×680, scrim, category column), not a page and
  not the right sheet. Needs the "a modal is on top" predicate for app chords
  (ROADMAP item) — ⌘B/⌘J/⌘1-9 must not rearrange panels behind the scrim.
- Sidebar default: AUTO-HIDE (overlay, never a grid column — "doesn't bleed
  into the spaces"). Pinned stays available via the Places icon / Settings.
- Lenses: Recent and Attention come OUT in PR B (not after data). Attention →
  count badge/filter in the Places header; Recent → ⌘K.
- PR A in flight: branch `ui-tweaks-header-chip` off origin/main @ v0.20.0 (#186);
  opus agent implementing from scratchpad brief `brief-pr-a-header-chip.md`;
  fable reviews the diff, commits, PRs, squash-merges.
