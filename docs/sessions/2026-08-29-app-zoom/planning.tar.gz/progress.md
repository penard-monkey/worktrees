# Progress

## Session 2026-08-29 — app-wide zoom
- Researched the sizing architecture and the existing ⌘+/− binding; wrote findings.md.
- Asked the user the two blocking design questions. Answers: WebView page zoom;
  ⌘+/− is app zoom always, markdown moves to ⌘⌥+/−.
- Phases 2–6 implemented: backend set_zoom, settings.ts app_zoom+ZOOM_STEPS+applyZoom,
  App.tsx chord rebind + apply effect, SettingsSheet Overall-size row + shortcuts table,
  FilesPane titles, mock sink.
- Phase 1: branched `ui-changes-app-zoom` off freshly fetched origin/main
  (ui-changes-next was 30 commits behind).
- Added `app/scripts/zoom-check.mjs` (mirror guard: ZOOM_STEPS vs the Rust
  clamp in `set_zoom`). Shown to FAIL three ways before being trusted:
  a 4× step past the clamp, `1` dropped from the table, and the Rust clamp
  removed. All three red, restored green.
- CHANGELOG [Unreleased] written.
- Gates running in background → ~/.cache/worktrees/worktrees/ui-changes/gates.log
- Browser verification abandoned after 3 failures (chrome-devtools MCP profile
  locked by another session; claude-in-chrome could not load localhost:5251 —
  chrome-error://chromewebdata on both `localhost` and `127.0.0.1`, while curl
  served the page fine). Pivoted to race-check.mjs's technique instead.
- `zoom-check.mjs` grew a second half: it slices the REAL chord block out of
  App.tsx and drives it with stubs (⌘ vs ⌘⌥ routing, saturation at both ends,
  the keyRef fast-double-tap mutation, the deliberate ungating while a sheet is
  open, ctrl falling through). Shown RED four ways: keyRef mutation dropped,
  ungating undone, ⌥ polarity flipped, ⌘0 resetting to the wrong value.
- bats: 318 ok, 0 not ok.
- Caught before shipping: matching the ⌥ variants on `e.key` alone would have
  left ⌘⌥+/⌘⌥− DEAD on every composing macOS layout (⌥- is an en dash, ⌥= is
  "≠"). Added ZOOM_BY_KEY/ZOOM_BY_CODE + `zoomDir`, with `??` (not `||`, since
  0 = reset). zoom-check grew cases for the composed keys, the numeric keypad,
  and fall-through; both regressions shown RED.
- Gates: bats 318 ok / 0 not ok; core 254 passed; cli 7 passed; app --lib 42
  passed; tsc clean; cargo check -p app clean; zoom-check green.
  `make lint` could NOT run — shellcheck is not installed on this machine
  (pre-existing). Ran its other two halves by hand: `bash -n` clean, bash-3.2
  gate clean. The diff contains no shell files.
- Added the two hard-won rules to CLAUDE.md (page zoom vs zoomHotkeysEnabled;
  ⌥ chords cannot be matched on e.key).
- PR #169 opened: https://github.com/penard-monkey/worktrees/pull/169
- OPEN: phase 8 (real-app run) still needs a GUI session — `app/scripts/sandbox.sh --app`.
- User ran `sandbox.sh --app` on the real build: looks ok. Phase 8 closed.
- Sending the diff to fable for review before squash-merge.
- Fable review: merge with 2 conditions. Both addressed — the false
  "registered once" comment corrected, and the real-app run was yours.
  Non-blocking findings (px column floors vs. an elastic viewport, no layout
  assertion for the raised caps, pre-hydration chord overwrite) → ROADMAP.
- Closed a gap fable named: zoom-check now also asserts the WIRING (the
  applyZoom effect, set_zoom in generate_handler!, the mock case) — without
  which every other check passes on a disconnected feature. Shown red 3 ways.
- CI: all 9 checks pass (lint included — that covers the shellcheck I could
  not run locally). Squash-merged as ce6351c. PR #169 closed, remote branch
  deleted. Worktree parked on a fresh ui-changes-next off origin/main.
