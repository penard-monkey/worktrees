# Findings — app-wide zoom

## Current sizing architecture
- `app/src/tokens.css:56` — `--ui-rem: 15px`, ONE knob, everything else in rem.
- `app/src/tokens.css:74` — `--term-size: 13px`, deliberately INDEPENDENT of
  `--ui-rem` (comment at the top of the file says so) so UI zoom never disturbs
  the xterm grid. This is why the user's slider did nothing to tmux.
- `app/src/settings.ts:244-245` — `clampRem` 13–18, `clampTerm` 10–20.
- `app/src/settings.ts:339-341` — `applySettings` writes both to `document.documentElement`.
- `app/src/TerminalPane.tsx:32` reads `--term-size` via getComputedStyle;
  `:167` a ResizeObserver calls `fit.fit()` then `tx.resize(cols, rows)` → the
  tmux/pty pane is resized. So ANY layout-px change refits and re-cols tmux.
- Icons (`app/src/Icons.tsx`) take a px `size` prop, default 15; ~33 call sites
  pass literals. These do NOT scale with `--ui-rem` — an argument for page zoom
  over a CSS multiplier.

## Existing ⌘+/⌘−/⌘0 binding
- `app/src/App.tsx:104` `ZOOM_KEYS = new Set(["+","=","-","_","0"])` — both faces
  of each key (⌘+ arrives as ⌘⇧= on US layout; keypad sends unshifted +/−).
- `app/src/App.tsx:3101` the handler sits ABOVE the meta-only gate at :3115
  precisely because that gate drops every shifted chord.
- Guarded by `keyRef.current.mdPreview` — only fires with a RENDERED markdown
  doc on screen (dock Files tab or reading mode).
- Steps: `MD_ZOOM_STEPS = [70,80,90,100,110,125,150,175,200]` (settings.ts:252).

## Tauri / wry facts (verified in the vendored source, not from memory)
- tauri 2.11.5, wry 0.55.1.
- `wry-0.55.1/src/wkwebview/mod.rs:933` — `zoom(scale)` → `setPageZoom`,
  macOS 11+. `tauri-2.11.5/src/webview/mod.rs:2098` — `Webview::set_zoom`.
- **Do NOT use `zoomHotkeysEnabled`.** `tauri/src/manager/webview.rs:555` injects
  `webview/scripts/zoom-hotkey.js`, which is a plain `window` keydown listener
  that: (a) never checks `defaultPrevented`, so it would fire ALONGSIDE our
  handler; (b) keeps zoom in a script-local `zoomLevel` that desyncs from any
  programmatic `set_zoom`; (c) steps by a coarse 0.2; (d) does not persist across
  restarts. Our own command + our own step table is strictly better.
- `capabilities/default.json` has only `core:default` + opener/dialog/updater/
  process. The built-in `plugin:webview|set_webview_zoom` would need an added
  permission; a plain command in lib.rs needs none and matches the repo style
  (every other command lives there).

## Risks to check in the REAL app (the mock cannot express any of these)
1. xterm after a zoom change: `devicePixelRatio` moves, canvas texture atlas may
   need a `clearTextureAtlas()`/refresh or glyphs go blurry.
2. Page zoom shrinks the CSS-px viewport → `fitLayout` (nav/dock ceilings,
   `MAIN_TIGHT`) recomputes against a much narrower width. At 3.0× a 1280px
   window is ~427 CSS px; the dock must yield gracefully, not wedge.
3. `minWidth: 900 / minHeight: 560` in tauri.conf.json are PHYSICAL, so they do
   not fight zoom — confirm the layout still holds at the extremes.
4. Zoom must be re-applied on startup from persisted settings, and applied
   before/after `fixup_gui_path()` does not matter (no PATH involvement).

## Layout at extreme zoom (checked, accepted)
Page zoom shrinks the CSS-px viewport, and a `resize` fires, so App's `setVw`
→ `fitLayout` re-runs and the nav/dock clamp down on their own. The floors are
absolute though: `RAILS_W 88 + NAV_MIN 220 + MAIN_MIN 420` needs 728 CSS px, so
3× wants a ~2200px physical window. Below that the topbar gets cramped. Left
as-is deliberately: on the headset's virtual display the window is far wider
than that, and the escape hatch always works — the ⌘+/⌘−/⌘0 chord is
ungated (it fires even with Settings or the ⌘K palette open), so no zoom level
can trap the user.

## Test
`app/scripts/zoom-check.mjs` — ZOOM_STEPS (settings.ts) vs the `.clamp()` inside
`set_zoom` (lib.rs). Shown RED three ways before being trusted: a 4× step past
the clamp, `1` removed from the table, the Rust clamp deleted.
