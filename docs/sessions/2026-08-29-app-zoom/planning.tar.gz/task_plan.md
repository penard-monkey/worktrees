# Task: app-wide zoom (⌘+ / ⌘− / ⌘0)

## Goal
Give the app a single "overall size" knob driven by ⌘+ / ⌘− / ⌘0 that scales
EVERYTHING — chrome, icons, markdown, the embedded terminal and therefore the
tmux pane geometry — so worktrees is usable on an Apple Vision Pro virtual
display. The existing `ui_rem` slider tops out at 18px and deliberately does not
touch the terminal; that is the gap.

## Decisions (user, this session)
- **Mechanism: WebView page zoom.** A Rust command calls
  `WebviewWindow::set_zoom()` → WKWebView `setPageZoom`. Uniform, no per-token
  conversion, and the ~33 hardcoded `Icon size={13}` px props come along for free.
- **⌘+/⌘−/⌘0 = app zoom ALWAYS.** Markdown reading zoom moves to ⌘⌥+/⌘⌥−/⌘⌥0
  and keeps its header +/− buttons.
- Secondary: raise the `ui_rem` and `term_size` slider caps so the BASE size can
  go higher independently of zoom.

## Phases
| # | Phase | Status |
|---|-------|--------|
| 1 | Branch off fresh origin/main | complete |
| 2 | Backend: `set_zoom` command in lib.rs + invoke_handler + mock harness | complete |
| 3 | settings.ts: `app_zoom`, ZOOM_STEPS, clamp/step helpers, raised rem/term caps | complete |
| 4 | App.tsx: chord rebind (⌘ = app zoom, ⌘⌥ = markdown), apply on startup + change | complete |
| 5 | SettingsSheet: Zoom row + slider ranges + diagnostics dump | complete |
| 6 | FilesPane: md zoom button titles say ⌘⌥ | complete |
| 6b | `app/scripts/zoom-check.mjs` — ZOOM_STEPS vs the Rust clamp (shown red 3 ways) | complete |
| 7 | Gates (build → make test → lint → cargo tests → tsc/check) | complete (shellcheck not installed here — see Errors) |
| 8 | REAL-app verification (`app/scripts/sandbox.sh --app`) — mock cannot express this | complete — user ran sandbox.sh, looks ok |
| 9 | CHANGELOG + PR | complete — merged as ce6351c |

## Errors Encountered
| Error | Attempt | Resolution |
|-------|---------|------------|
| `make lint` → `shellcheck: command not found` | 1 | shellcheck is not installed on this machine at all; pre-existing, not caused by this change. The diff touches NO shell files. Ran the target's other two halves by hand — `bash -n` clean, bash-3.2 gate clean. CI runs shellcheck. |
| chrome-devtools MCP: browser profile locked by another session | 1 | switched to claude-in-chrome |
| claude-in-chrome: `chrome-error://chromewebdata` on both `localhost:5251` and `127.0.0.1:5251` while curl served the page fine | 2 | abandoned the browser after the 3rd failure; verified the chord instead by slicing the real handler out of App.tsx and driving it under node, the way `race-check.mjs` does |
