# Progress

## Session 2026-09-06 (ui-tweaks, branch ui-next)
- Read both annotated screenshots; transcribed to findings.md.
- Located UsageWidget, add-footer/rail twin, statusbar footer, BranchSwitcher,
  header branch chip in App.tsx/App.css (anchors in findings.md).
- Talk-through delivered; David asked for design options of the compact
  one-line usage form with hover detail. Next: design canvas.
- Design canvas "Usage Meter Home" published:
  https://claude.ai/code/artifact/44e3c1a7-4c5c-4581-9716-d05400a4d8a0
  Working files (re-seed from these): ~/.cache/worktrees/worktrees/ui-tweaks/design/usage-home/
  (gen.mjs emits the five artboards; canvas.json carries the per-option notes).
  Options: A window-wide strip (Main) · B footer re-tenanted · C rail tile ·
  D header cluster · Forms sheet (F1 three segments / F2 bars only / F3 worst window).

## Session 2026-09-07 — implementation
David picked A + B + C behind a Settings → Appearance control, and chose "move
the branch switcher to the header chip" for the footer's other tenant.

Built:
- `usage_place` setting ("strip" | "footer" | "rail" | "off", default "strip"),
  Appearance → Usage meter. No Rust change, no migration (merge over DEFAULTS).
- `UsageWidget` → `useUsage` (App-owned poller) + `UsageRows` (hover detail) +
  `UsageMeter` (compact trigger, hover/focus/click-pin popover).
- Sidebar lost the usage block AND the "+ Add project" footer.
- `.statusbar` renders only in footer mode, holds only the meter. tmux facts deleted.
- `BranchSwitcher` → `HeaderBranch`: the header chip is the switcher.

### Verified in the mock harness (port 1425, chrome-devtools)
- strip spans the full 1280px window at the bottom; `.app` shrinks 820→793.
- rail tile 32×32 with three 18px bars; popover flies right, 8px gap, in-viewport.
- footer row spans the main column only, no tmux facts.
- "off" is a real off switch: two window focus events produced ZERO
  `claude_usage` calls (one while enabled); re-enabling fired exactly one pull.
- branch chip: text + caret when the branch differs, icon-only when it does not,
  plain non-interactive span on (main). A switch to `develop` committed and the
  chip updated.
- strip background vs app/rail/nav in all six themes: 16+/16+/8+ RGB units, and
  its border-top is 18–35 from its own fill. `--bg-panel` as CLAUDE.md advises.
- `usage-check.mjs` proven LIVE for the new button: removing the `branch-chip`
  testid makes it fail on the interpolated branch name (a real metrics leak).

### Bug found and fixed by the harness (would have shipped)
`.branch-pop` as `position: absolute` inside `.identity` (`overflow: hidden`):
the combo's branch list rendered at y=39..239 with a perfectly plausible rect
but was CLIPPED entirely out of the 17px identity box — invisible and
unclickable (`elementFromPoint` returned `.menu-catch` at every row's centre).
Focusing the input also SCROLLED `.identity` by 34px, pushing the place name off
the header. Fix: `position: fixed` placed from the chip's rect, plus
`focus({preventScroll: true})` instead of the combo's `autoFocus`. Post-fix:
identity scrollTop 0, every visible row hit-tests to `.combo-item`.

### Gates
cargo test core 285 ok · cli 7 ok · app --lib 47 ok · make lint clean ·
tsc --noEmit clean · cargo check -p app clean · all 9 app/scripts/*-check.mjs PASS.
make test (bats) running at time of writing.

## Session 2026-09-07 — review pass (fable)
David ran `sandbox.sh --app`, toggled the placements; two screenshots of the
strip in narrow windows (~458 and ~605 CSS px) showed bordered pills, no labels,
percentages clipped. Persistence confirmed: sbx `ui-state.json` carries
`usage_place`, written by the same `updateSettings` → `saveSettings` path as
every other key.

Found and fixed:
1. **Class collision** — compact segments were `usage-row seg`; `.seg` is the
   Settings segmented control (App.css:2140: border, overflow hidden, width
   fit-content). The border was the pill; `overflow: hidden` made each segment a
   flex item that can shrink to 0, so labels collapsed and pcts clipped in a
   narrow window. Renamed `usage-seg`. Harness at 1280px never showed it.
2. **Pinned panel ate Escape everywhere** — my Esc listener was window-CAPTURE
   with stopPropagation, which would also take Escape from xterm (vim, prompts)
   for as long as the panel was pinned. Now bubble phase, no stop.
3. **Branch popover had no Escape** — BranchCombo closes only its list (and
   stops the event while the list shows). Added a window keydown while open.
4. Stale App.css comment: combobox "opens upward; the status bar is the last
   row" — every current host passes drop="down".
Verified post-fix in the harness at 500px: segments border 0 / overflow visible,
label widths 13/12/27, every pct right edge ≤ innerWidth, trigger 321px fits.
All 9 check scripts PASS, tsc clean.

## Session 2026-09-07 — second review pass (real app still broken)
David's next screenshots: bars + percentages, NO labels, in the real app, with
the sandbox's vite confirmed serving the renamed class — so not the `.seg` bug.
Backend ruled out (kinds map to "5h"/"7d" unconditionally). Installed Playwright
WebKit in the scratchpad and REPRODUCED it headless: label widths 0, button 201px
(Chrome: 321). Two WebKit-only sizing gaps, both in a `<button>`:
1. A `<button>` that is itself a flex container is shrink-wrapped without its
   `overflow: hidden` children → labels (the only shrinkable items) → 0.
   Fix: the button is `display: block`; an inner `.usage-shape` span is the
   flex container; `.usage-label` is `flex: none` in the compact line.
2. Even then the button was 120px short = three 40px bars: an empty span sized
   only by `flex-basis` contributes 0 to WebKit's intrinsic width. Fix: an
   explicit `width: 40px` on the bar too. Probe: 201 → 321.
Probe scripts: scratchpad/wk/probe*.mjs (run against the mock on :1425).
Lesson for CLAUDE.md at close-out: the mock harness runs in CHROME; the app is
WKWebView. Anything sized by flex inside a <button> needs the WebKit probe.

## 2026-09-07 — shipped
David confirmed the WebKit fix in the sandbox. Branch `ui-tweaks-usage-meter`
off origin/main (0/0 vs HEAD), commit 420f404, CHANGELOG [Unreleased] entry,
PR #194: https://github.com/penard-monkey/worktrees/pull/194
Mock harness still running on :1425 (kill: `kill $(lsof -ti:1425 -sTCP:LISTEN)`).
- PR #194 squash-merged: ccf7375 on origin/main. Remote branch deleted. Local
  `ui-tweaks-usage-meter` still checked out; close-out will park on a fresh
  `ui-next` off origin/main.
