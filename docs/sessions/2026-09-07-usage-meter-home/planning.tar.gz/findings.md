# Findings

## Screenshot annotations (2026-09-06 16:03, `_tmp/`)
Screenshot 1 (sidebar overlay revealed over a live place):
- Red box around the usage widget at the bottom of the sidebar (rows `5h`
  43% 56m / `7d` 18% 1d 6h / `Fable` 30% 1d 6h): "New home for this? I like
  it always visible".
- Red box around the sidebar footer button "+ Add project ▾": "Remove this as
  it is redundant".
Screenshot 2 (sidebar hidden, terminal full width, Files dock open):
- Red box around the terminal footer (`switch branch…` combobox on the left,
  `tmux ● up · worktrees-ui-tweaks · pane0 claude` on the right): "This
  probably needs to be removed/hidden or be somewhere else".
Layout facts visible: left rail (places toggle top; add-project + settings at
bottom), place header (name · ↗branch · … `● live` pin `…`), right rail (files,
terminal icons), Files dock ~580px wide.

## Code anchors (app/src)
- `UsageWidget` App.tsx:1771 — polls `claude_usage` every 180s while visible,
  15s tick for the ETA clock; labels 5h/7d/model bucket (`labelFor` ~1715).
  Rendered at App.tsx:~5386 inside `<aside>` after `.nav-hint`, before the
  add-footer. Comment: "sidebar-only by design: no rail affordance".
  CSS `.usage*` App.css:181–222 (rows, bar, pct, eta, warn/over colours).
- Sidebar add button App.tsx:5392 `.add-footer` testid `add-menu-open`;
  rail twin App.tsx:5302 testid `add-menu-rail` (same `openAddMenu`);
  ctx menu "Add existing…" App.tsx:6214.
- Terminal footer `<footer className="statusbar">` App.tsx:5663–5677:
  `.switch-wrap` (GitBranch icon + `BranchSwitcher`, non-main only) and
  `.sb-facts` (tmux up/down + session name + " · pane0 claude"). CSS
  App.css:1643 (`.statusbar`), 1648–1649, 1704–1710.
- `BranchSwitcher` App.tsx:1272 wraps `BranchCombo` (placeholder "switch
  branch…", testid `switch-branch`, lazy `list_branches` on open).
- Header branch chip App.tsx:~5450 `.branch` (`↗ ` prefix when branch ≠ slug,
  `hi` class), guarded by `showBranch`. `.status-cluster` follows it.
- Footer sits inside the selected place's workbench (`.main` column), NOT
  window-wide; Home (`.briefing`) has no footer.

## Design constraints from CLAUDE.md
- No UI libraries; tokens.css; everything scales off `--ui-rem`.
- Six themes — check any borrowed surface token against the host in every
  theme (prefer `--bg-panel`).
- Mock harness answers instantly; hover/timing shapes need the real app
  (`app/scripts/sandbox.sh --app`, drive by pid only).
- A menu/popover that resizes must re-clamp on resize (CtxMenu lesson).
