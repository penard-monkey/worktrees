# Task Plan: post-v0.21 sidebar follow-ups (usage meters, footer, add-project)

## Goal
The auto-hiding sidebar (v0.21.0) took the Claude usage meters off screen and
left two redundant strips. Find the meters a home that is always visible in a
compact one-line form (full three-row detail on hover), remove the sidebar's
"+ Add project" footer, and retire or relocate the terminal footer
(branch switcher + tmux facts).

Source: David's two annotated screenshots, `_tmp/Screenshot 2026-09-06 at 16.03.44.png`
and `16.03.54.png` (see findings.md for the transcription).

## Phases
| # | Phase | Status |
|---|-------|--------|
| 1 | Talk-through of the three annotations, agree the problem framing | complete |
| 2 | Design canvas: compact usage line variants + where the strip lives | complete |
| 3 | David picks a direction; write the implementation brief | complete |
| 4 | Implement from the brief, run gates | complete |
| 5 | Review the diff; run the REAL app for the hover/timing shapes | complete |
| 6 | Squash-merge PR #194 (done: ccf7375), then close-out (/close-out) | in_progress |

## Decisions
- 2026-09-06: The two bottom annotations are ONE problem — the footer is the
  wrong tenant, not the wrong room. Proposed: branch switcher → header branch
  chip popover; tmux facts dropped (all duplicates); the strip becomes the home
  for a compact usage line. (proposed, not yet confirmed by David)
- 2026-09-06: David wants to SEE the compact-line-with-hover-detail as several
  design options before choosing. He did not follow "global strip" wording —
  show it visually (full-window-width bar vs terminal-column-only bar).
- "+ Add project" sidebar footer: remove (rail FolderPlus opens the same
  three-way menu; project ctx menu has "Add existing…"). Check harness testid
  `add-menu-open` users before deleting.

## Errors Encountered
| Error | Attempt | Resolution |
|-------|---------|------------|

## The brief (agreed 2026-09-07)
**Setting**: `usage_place: "strip" | "footer" | "rail" | "off"`, default `"strip"`,
in Settings → **Appearance** as a `.seg .seg-plain` (Strip / Footer / Rail / Off).
Frontend-owned key only — `loadSettings` merges over DEFAULTS, so NO migration
and no Rust change. "off" must mean no poll at all, not a hidden poller.

**One poller, three hosts.** `UsageWidget` splits into `useUsage(enabled,
pageVisible, onError)` (owned by App, so placement never multiplies the
endpoint), `UsageRows` (today's three-row block, now the hover detail) and
`UsageMeter` (trigger + popover).
- A `strip` — `.usage-strip`, a 26px row spanning the whole window. `.app`
  (the 4-col grid) gets wrapped in `.appwrap` (flex column) so the strip is a
  sibling BELOW the grid; `.nav.overlay` is `top:0;bottom:0` against `.app`, so
  wrapping is what keeps the revealed sidebar off the strip.
- B `footer` — `.statusbar` renders ONLY in this mode and holds only the meter.
- C `rail` — a 32px tile above the rail's add/settings buttons, popover flies right.
- Compact line = today's `.usage-row`s laid ACROSS (`.usage-row.seg`), so every
  severity rule (`.usage-row.warn > .usage-bar > i`) still applies. Bars are
  fixed 40px, never flex: three bars sharing a row must not resize each other
  as percentages change, or the strip twitches on every poll.
- Popover: hover (140ms arm) + focus, click pins, Esc unpins. `position: fixed`,
  clamped to the viewport, re-clamped by a ResizeObserver on the pop (CtxMenu
  lesson: a menu that GROWS after opening keeps the top computed for its old
  height). Measure with offsetWidth/Height. z-index 45, above `.nav.overlay` (30).

**The footer's old tenants** (decided by David, 2026-09-07 — "Move it to the
header chip"):
- tmux facts: DELETED. All three are duplicated (nav dot, agent dot, prefix+slug).
- branch switcher: moves into the header branch chip. `BranchSwitcher` becomes
  `HeaderBranch`: the chip is a button that pops the same `BranchCombo`
  (`drop="down"`). main → plain span as today; non-main → button ALWAYS, and
  when `showBranch` is false (branch === slug) it collapses to the icon alone.
  Outside-click via the existing `.menu-catch`.
- Sidebar `.add-footer` ("+ Add project"): DELETED (rail twin `add-menu-rail`
  opens the same menu). Check `add-menu-open` testid users first.

**Gates**: the full CLAUDE.md list, plus `node app/scripts/race-check.mjs` and
`termresize-check.mjs` (the strip changes `.space` height → one SIGWINCH).
Real app for hover/timing (`app/scripts/sandbox.sh --app`, by pid only).
