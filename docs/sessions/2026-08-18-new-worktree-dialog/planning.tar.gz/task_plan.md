# task_plan — New-worktree modal + branch dropdowns

## Goal

Replace the nav-pinned new-worktree form with a modal in the `NewProjectDialog`
family that names the project it will create in, mirrors branch → folder name
until the name is edited, offers Base as a branch dropdown, and makes the
status-bar branch switcher use the same dropdown component.

## Decision: modal, not a dismissible nav card

The nav form already HAS a dismiss (`✕` in its header, Esc, and `+` toggles it).
Dismissal is not the real problem. The real problems are:

1. It renders at the **top of the nav**, not under the project whose `+` was
   clicked — with several projects the form does not say which one it belongs to
   beyond one line of small text, and it shoves the whole tree down.
2. Three bare inputs with no verdict: nothing says whether the branch will be
   created, checked out, or tracked; nothing says what folder/tmux session comes
   out; "base (default: main)" is wrong on a `master` repo.
3. No room to grow — a verdict line, a path preview and an error all have to fit
   in a 260px-wide nav card.

A modal fixes 1–3 for free (title carries the project, `.sync-body` has room, the
scrim is an obvious dismiss). Tradeoff accepted: the modal covers the tree, so
the things you would have looked away to check — existing slugs, which worktree
already holds the branch — get answered **inside** the modal instead.

## Design

```
┌ New worktree · worktrees ─────────────────────────────────┐
│ ~/workspace/worktrees · 9 worktrees · tmux prefix wt       │
│                                                           │
│ Branch                                                    │
│ [ feat/checkout                                      ▾ ]  │
│ new branch — created off main                             │
│                                                           │
│ Base                                                      │
│ [ main                                               ▾ ]  │
│                                                           │
│ Folder name                                               │
│ [ feat-checkout                                        ]  │
│ mirrors the branch · clear to re-link                     │
│                                                           │
│ will create ~/workspace/worktrees/.worktrees/feat-checkout │
│ tmux session wt-feat-checkout                             │
│                                                           │
│ [ error / warning line ]                                  │
│                                      [ Cancel ] [ Create ]│
└───────────────────────────────────────────────────────────┘
```

**Branch** — editable combobox (`BranchCombo`), list = `list_branches`, plus the
DWIM create row, exactly like the status-bar switcher. Autofocus.

**Verdict line** (under Branch) — the whole point; states:
- branch in the list → `existing branch — checked out here` (Base disabled)
- branch not in the list → `new branch — created off <base>` (Base enabled)
- branch is held by a place in this project → warn
  `already checked out in <slug>`; with a stock name adds `— that worktree will
  be reused` plus an **Open <slug>** button; with a CUSTOM name it is an error
  and Create is disabled (core refuses that combination — findings.md).
- slug already exists as a place here → warn `a worktree named <slug> already
  exists — it will be switched to this branch`.

**Base** — same combobox, `allowCreate: false`, still free-text (a tag or SHA is
a legal start point). Prefilled from `default_base` — no more "default: main"
guess. Disabled with the reason when the branch already exists.

**Folder name** — mirrors `slugify(branch)` live until the user types in it;
after that it is independent. Clearing it re-links the mirror (and is the
documented escape hatch, in the hint under the field). Reuses `nameProblem()`.
Sent to the backend **only when it differs from `slugify(branch)`** — see the
holder-reuse trap in findings.md.

**Preview** — `.np-path`-style: the worktree dir and the tmux session name.

**Unborn HEAD** — the modal body is replaced by today's `UnbornPrompt` copy +
its "Create initial commit" button, so the `+` never opens something dead.

**Submit** — unchanged flow: modal closes, `PendingRow` ghost appears, a rejected
create reopens the modal with the draft intact.

**Status-bar switcher** — same `BranchCombo`, gaining a ▾ caret that opens the
list on click (today the list only appears on focus/typing, so it reads as a
plain text box). Behaviour otherwise identical: type-to-create stays first class.

## Phases

| # | Phase | Status |
|---|---|---|
| 1 | Extract `BranchCombo`; ▾ caret; switcher rewired | **done** — PR #152, MERGED `4d3a491` |
| 2 | `NewPlaceDialog` — combos, mirrored name, verdict, preview, unborn state | **done** — PR #155 `2734a51` |
| 3 | Wire App; drop `NewPlaceForm`/`UnbornPrompt`; keep `InitRepoPrompt` on `.nav-newform` | **done** — in `2734a51` |
| 4 | CSS: `.combo.down`/`.off`, `.nw-verdict`, `.np-hint`, `.nw-body`, `.nw-modal` | **done** |
| 5 | Harness: testids, `record-readme.py` selectors | **done** — `list_branches` needed no mock change (`"(main)"` already resolves) |
| 6 | Gates | **done** — green twice (before and after the review rework); CI 9/9 on both PRs |
| 6b | REAL app run (`sandbox.sh --app`) | **BLOCKED — needs a human.** WKWebView is not CDP-drivable |
| 7 | *(optional)* `remote_only: string[]` on `BranchList` → a "tracking origin/x" verdict; modal-ize `InitRepoPrompt` | deferred, not started |

## If PR2 comes back for another round

The verdict chain is the part to re-read: it mirrors `cmd_new`'s ORDER, and the
first version got that order wrong in four places. Any change to `ops.rs`'s
create path has to be walked against it — there is no test that catches drift
(same shape as the `dnd-check.mjs` mirror problem, but without the checker).
Worth considering a `dnd-check`-style parser if the chain grows again.

## Errors Encountered

| Error | Attempt | Resolution |
|-------|---------|------------|
| — | — | — |

## Files expected to change

- `app/src/App.tsx` (new component, one deleted, ~4 wiring sites)
- `app/src/App.css`
- `app/src/mock/install.ts` (only if `list_branches` mishandles `"(main)"`)
- `app/scripts/record-readme.py`
