# progress

## Session 2026-08-17 — new-worktree modal

Branch: `ui-changes-next` (idle base — a work branch `ui-changes-<slug>` is due
before any commit).

### Done
- Explored the current new-worktree path end to end (nav form → `createPlace` →
  `new_place` → `ops::cmd_new`) and the status-bar `BranchSwitcher`.
- Read `NewProjectDialog` + its CSS as the modal template.
- Wrote `findings.md` (call sites, backend contracts, the holder-reuse trap).
- Wrote `task_plan.md` with the design and 7 phases.

### PR plan (approved 2026-08-17)
Each phase = its own PR, Fable reviews the diff before each squash-merge.
- **PR1** `ui-changes-branch-combo` — extract `BranchCombo`, add the ▾ caret, rewire the switcher.
- **PR2** — the New-worktree modal (needs PR1's component).
- **PR3** *(optional)* — `remote_only` on `BranchList` for a "tracking origin/x" verdict.

### PR1 — in review
- Split `BranchSwitcher` (App.tsx:926-1041 on the old base) into `BranchCombo`
  (list, keyboard, click-away, caret) + a thin `BranchSwitcher` that keeps the
  text state, the lazy `list_branches` fetch and the clear-only-on-success rule.
- Added `.combo-caret` CSS (overlaid ▾, input gains `padding-right`).
- Escape inside an open pop now `stopPropagation()`s — PR2's dialog must not
  take the same key as "cancel".
- Verified live in the mock harness (port 1425): caret opens/closes the list,
  focus stays in the input, the pop opens UPWARD, the current branch is excluded,
  the DWIM create row still switches and the text clears on success.
- Screenshot: `~/.cache/worktrees/worktrees/ui-changes/combo-caret.png`.

### Environment note
`app/node_modules` was STALE — `@xterm/addon-unicode-graphemes` was declared in
package.json but never installed, so `tsc --noEmit` failed on a file this branch
never touched. Fixed with `nvm use 22.23.2 && pnpm install` (default node here is
22.12.0, below the 22.13 floor).

### PR1 — MERGED as 4d3a491 (#152)
Fable's review found no blockers; three findings fixed before merge (double
`list_branches` on the caret's first click, stale `exclude` after a switch,
half-done ARIA). `gh pr merge` printed *fatal: 'main' is already used by
worktree* — the documented false failure, AFTER the merge landed. Not retried.

### PR2 — #155, open, in review
`ui-changes-new-worktree-modal`, two commits:
- `2734a51` the dialog (verdict line, base dropdown, mirrored folder name,
  preview, unborn state folded in, `NewPlaceForm`/`UnbornPrompt` deleted).
- `f85e475` the verdict no longer guesses while `list_branches` is in flight.

**The bug the mock could not express.** `known` is false until the branch list
lands, so for the whole fetch window an EXISTING branch was reported as "will be
created off main" — the wrong one of the two answers the dialog exists to give.
The mock resolves in a microtask; the real read is a `git for-each-ref` fan-out.
Found by re-reading CLAUDE.md's mock-timing rule, reproduced by delaying the
invoke in the page, now reads "reading this project's branches…".

**Four things the harness caught that the design missed:** the popover was
clipped by `.sync-body`'s `overflow-y: auto` instead of floating over it; it was
240px wide under a 571px field; autofocus opened a list covering the fields
below; and a popover holding one exact match covered the verdict line.

### Gates — PR2, all green
`make test` 0 not-ok · lint · core 251 / cli 7 / app 35 · tsc · cargo check ·
`dnd-check.mjs` · `race-check.mjs`. Logs: `~/.cache/…/ui-changes/pr2-*.log`.

### PR2 round 2 — Fable's review, `a50bd0b`
Two keyboard blockers and four verdict inaccuracies, all confirmed by reading
before fixing:
1. **Enter on Cancel created the worktree.** Enter was taken on the modal DIV so
   it worked from any field; a keydown on a focused button bubbles there too.
   Now ignored when `e.target` is a BUTTON.
2. **An invisible popover ate Enter/Escape.** The one-exact-match suppression
   left `open` true while nothing rendered, and both guards keyed on `open`.
   Every branch now tests `showPop`.
3. **Verdict order was not core's order.** `cmd_new` reaches holder logic only
   when the derived dir does NOT exist (ops.rs:417) — so `taken` decides first.
   Reordered; two missing cases added (unregistered dir, taken+holder).
4. **A branch on the MAIN checkout** read as "will be checked out here"; git
   always refuses. `wt_for_branch` scans only `.worktrees/`, so core sails past
   its own pre-check and dies in `git worktree add`. Now blocking. (Typing
   `main` is not an exotic input.)
5. **Base was greyed in the switch case**, where `do_switch` creates the branch
   off it (ops.rs:320-333). `usesBase` now comes from the verdict.
6. **The preview promised a path reuse never creates.** It follows the verdict
   now; a reuse names the HOLDER's real path and tmux session.
7. Branch list read while the repo was unborn survived its first commit →
   `unborn` added to the dialog key.
8. Filed as speculative, **was real**: at a 430px viewport the footer was pushed
   past `.sync-modal`'s hidden overflow. Create rendered, reported a plausible
   bounding box, and `elementFromPoint` at its centre returned the scrim — not
   clickable. `.nw-modal` scrolls now. Anything short of hit-testing would have
   called that fine.

Gates re-run after the rework: all green (`pr2b-*.log`). CI on #155: 9/9 pass,
mergeStateStatus CLEAN. Mock harness stopped; port 1425 free; tree clean.

### BOTH MERGED
- PR #152 → `4d3a491` (BranchCombo + caret)
- PR #155 → `bc59839` (the dialog), merged on David's explicit go-ahead with the
  real-app pass knowingly outstanding — see the note below for what that means.

`gh pr merge` printed *fatal: 'main' is already used by worktree* BOTH times —
its local checkout step, after the merge had already landed on GitHub. Verified
via `gh pr view --json state,mergeCommit` instead of retrying.

Before deleting the local branches, `git diff origin/main <branch>` was NOT empty
— 364 deletions. That was #153 and #154 landing while PR2 was open, not lost
work; confirmed by grepping merged `main` for every marker from both PRs
(`BranchCombo`, `combo-caret`, `NewPlaceDialog`, `nw-modal`, `slugProblem`,
`openOnFocus`, `mainHolder` all present; `NewPlaceForm`/`UnbornPrompt` gone).
Worth keeping: after a squash-merge that diff is never empty if anything else
landed meanwhile, so it proves nothing on its own — grep for your own markers.

Worktree parked on `ui-changes-next` at `bc59839`, clean, 0/0 vs origin/main.

### The real-app pass — still not done, now shipped anyway
`app/scripts/sandbox.sh --app` launches a native WKWebView window; Playwright
speaks CDP, which WKWebView does not, so the interactive pass needs a human.

Judgement: PR2 does NOT touch `createPlace`'s optimistic ghost-row path, refresh,
or per-place state, so CLAUDE.md's strict trigger is arguably not met — and the
one real-timing risk it DOES add (a slow `list_branches`) was found and fixed by
simulating the delay. Still not merging it unilaterally: that rule exists because
three v0.12.x bugs passed gates AND review and were only caught by running the
real thing.

### Gates — PR1, all green
- `cargo build --release -p worktrees-cli` ✓ (frontend-only diff, so the binary
  built at session start is still ahead of every Rust source file)
- `make test` exit 0, `^not ok` count 0
- `make lint` exit 0
- `cargo test -p worktrees-core` 251 passed · `-p worktrees-cli` 7 · `-p app --lib` 35
- `tsc --noEmit` ✓ · `cargo check -p app` ✓
- Logs: `~/.cache/worktrees/worktrees/ui-changes/gate-*.log`
