# findings — new-worktree modal + branch dropdowns

## Where the current UI lives

| Thing | File / line | Notes |
|---|---|---|
| `NewPlaceForm` (3 bare inputs) | `app/src/App.tsx:369-400` | class `.newform .nav-newform` |
| Render site | `App.tsx:4096-4117` | **pinned at top of nav**, under the filter box — NOT under the project whose `+` was clicked |
| `+` button | `App.tsx:3911` | toggles `newFor`; also resets `newBase`/`newDraft` |
| ctx "new from branch" | `App.tsx:2951-2960` (`openNewForm`) | passes a base, un-collapses the nav |
| `createPlace` | `App.tsx:3425-3455` | closes form → ghost `PendingRow` → on failure restores draft + reopens |
| `UnbornPrompt` | `App.tsx:488-511` | replaces the form when repo has no commits |
| `InitRepoPrompt` | `App.tsx:461-484` | different flow (folder isn't a repo) — also uses `.nav-newform` |
| `BranchSwitcher` (status bar) | `App.tsx:952-1067` | already a combobox, opens on focus, no visible affordance |
| `NewProjectDialog` (the modal to copy) | `App.tsx:1435-1502` | `.scrim.scrim-center` + `.sync-modal` / `.sync-h` / `.sync-body` / `.sync-foot` + `.np-*` fields |
| modal CSS | `App.css:1399-1499`, `1536-1541` | `.np-field/.np-label/.np-input/.np-row/.np-path/.sync-err` |
| combo CSS | `App.css:1295-1314` | `.combo-pop` is **bottom-anchored** (status bar sits at the bottom) |

## Backend facts that constrain the design

- `list_branches(repo, slug) -> {branches, current, default_base}` — `lib.rs:825`.
  It needs a **slug**; `place_dir("(main)")` returns `main_root` (`project.rs:417`),
  so `slug: "(main)"` is the legal project-level call. No backend change needed.
- `branch_names()` (`project.rs:440`) = local heads ∪ `origin/*` with no local
  twin, **`origin/` stripped**. So the frontend CANNOT tell local from
  remote-only from this list alone.
- `default_base()` = main → master → current HEAD (`project.rs:506`). The current
  form's placeholder "default: main" is therefore a **lie** on a master repo.
- `new_place(repo, branch, base, name)` — `lib.rs:760`. base is positional arg 2,
  `--name` is a flag, empty strings are filtered to `None`.
- Slug = `slugify(name ?? branch)` = `/` → `-` (`ops.rs:414`, `resolve_new_slug`
  at `project.rs:491`).

### ⚠ The trap that decides the mirroring implementation

`cmd_new` (`ops.rs:417-428`): when the target dir does not exist and the branch is
**already checked out in another worktree**, core REUSES that worktree — but only
`if name.is_none()`. With a name it hard-errors instead.

So a mirrored name that is always sent would silently convert today's
"reusing that worktree" into a refusal. **Send `name` only when it differs from
`slugify(branch)`** — i.e. only when the user actually customized it.

### Branch-field semantics (also not communicated today)

`cmd_new` (`ops.rs:452-523`) branches five ways: registered worktree at that slug
→ reuse/switch · dir exists unregistered → error · local branch exists → check out
· `origin/<branch>` exists → track · else → create off base (`origin/<base>` if
present). **Base only matters in the last case** — which is why base deserves to
be disabled with a reason rather than always live.

## Other consumers to keep in sync

- `app/src/mock/install.ts:671` (`new_place`, branch containing "fail" → refusal),
  `:838` (`list_branches`) — mock must track every command (CLAUDE.md).
- `app/scripts/record-readme.py:84-96` drives the README gif through
  `get_by_title("new worktree")` → `input[placeholder^="branch"]` →
  `button:has-text("Create")`. Changing the form breaks it.
- No bats/playwright test asserts the nav form today; only the recorder does.

## Prior art / rules in play

- Components with local state or focus go at **module scope** (CLAUDE.md) — App
  re-renders on the 3s poll.
- HMR is dead inside `.worktrees/`; restart vite with `--force`, and verify with
  `curl` against a CODE string (esbuild strips comments).
- Duplicating Rust logic in TS needs a drift check (`dnd-check.mjs` precedent).
  Here the only duplicated rule is `/`→`-`, already duplicated twice
  (`App.tsx:3433`, mock). Holder-reuse prediction reads live `ws` place branches,
  not a reimplementation.
