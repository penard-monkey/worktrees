# pi phase 2 — task plan

Brief: .planning/brief.md. Source: docs/proposals/pi-harness.md (Decisions, §1–3, §7, §8, §9.4, §11 phase 2, §2.3).

## Design (decided while reading phase-1 code)
- `provider::Provider` gains `model_arg`; row `pi` (`~agent~pi`, canonical_default false).
- `AiLaunch` gains `model: Option<String>` and `resume: bool`. Callers set them
  after `ai_launch_for`. model_arg emitted ONLY when !resume. claude/codex resume
  words still ride in cmd via resume_command (unchanged); pi's resume_arg is ""
  (structural: `--session-id`), and pi ignores the ai_resume_arg override.
- `Adapter::resume_display()` for Settings/config display (fixes config.rs:242).
- New adapter hook `prepare(p, slug, &mut AiLaunch) -> Result<(), String>` run in
  `launch()`'s CREATE branch only: pi reads/bumps generation in declared store and
  pushes `--session-id <id>` into place_flags. `--session-dir` + trust flag via place_flags(wt).
- Session id: sanitise canonical to [A-Za-z0-9._-], collapse `-` runs, trim ends,
  + `-<fnv6 of unsanitised>` + `-g<N>`. Generation in `.worktrees.places.json`.
- Session dir: `<PI_CODING_AGENT_DIR|~/.pi/agent>/sessions/--<cwd / \ : → ->--` (0.99.1 source).
- Model default for a fresh pi: --model > place `agent` (harness pi) > user `[model] pi` > refuse naming ready options.
- Reachability: curl `GET <baseUrl>/models`, -m 3, cache 60s per baseUrl. No HTTP dep.
- Preflight: `$SHELL -ic` probe, cache 10 min, engines.node from pi's package.json.
- Trust: user config `pi_project_trust` (never|ask), `[trust] pi = [roots]`, CLI `worktrees trust pi [<repo>] [--revoke]`.
- USER_ONLY_KEYS += model, harness, trust, pi_project_trust.

## Phases
- [ ] 1 core: provider row + marker test + session_in fix; model types; pi.rs (id, dir, jsonl, screen, list-models, auth, reach, preflight, trust)
- [ ] 2 core: Pi adapter + AiLaunch model/resume + prepare hook + resume_display; launch refusal
- [ ] 3 CLI: --model/--force on new/open; trust verb; doctor pi section
- [ ] 4 MCP: create_worktree model + refusal; place_status model; USER_ONLY; phase-1 follow-ups (pub(crate), mid-file use)
- [ ] 5 docs/pi-manual-checks.md, CHANGELOG, gates, ls --json diff, PR A
- [ ] 6 app (PR B): picker, switch sheet, marks, Settings → pi, mock, follow-ups
- [ ] 7 gates, PR B, report

## Blocked
- Live pi TUI launch denied by auto-mode classifier ("Create Unsafe Agents"). Using
  0.87.1 captures + 0.99.1 source as fixtures; need David's permission to re-measure screens.
