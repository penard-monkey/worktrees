# progress

## 2026-09-29
- Read brief, proposal, phase-1 code. Probed pi 0.99.1 help/list-models/auth check (no model calls). Host up.
- Live pi TUI probe DENIED by auto-mode classifier → fixtures from research lane's 0.87.1 captures + 0.99.1 source reading.
- Core: provider row pi + model_arg + marker is_sidecar; pi.rs (id/dir/jsonl/screen/activity); choice.rs; pimodels.rs (list-models, auth, models.json, reach, preflight); trust.rs; store agent + pi_session_gen; AiLaunch model/resume/force; Adapter resume_display/exact_resume/prepare/running_model; Pi adapter; ops launch prepare-before-kill + EXIT_LAUNCH_REFUSED(5); --model/--force on new/open; USER_ONLY_KEYS.
- Shown-fail-first: pi retry rule, pi screen position, USER_ONLY keys, is_sidecar marker (2 tests), model_words resume guard (2 tests).
- NOTE: shell `grep` is a wrapper that skips files `file` calls "data" (projcfg.rs) — use /usr/bin/grep -a.

## Next
- CLI: trust verb in main.rs, doctor --pi, usage text. MCP: create_worktree model + ready-list errors; place_status model; tests enum. CHANGELOG, manual checks doc, gates.

## PR A — #366 (pi-phase2-core), pushed. Gates all green (bats 382/382).
## PR B — pi-phase2-app (stacked)
- Backend: Adapter::installed() (codex/pi), lib.rs literals gone; new_place/open_place model+force; agent_models, pi_status, set_pi_trust, set_pi_allowed; plan_prompt refuses pi; AgentSession doc comment fixed; live_model pi arm.
- Frontend: harness.ts pi + NEEDS_MODEL; HARNESS_MARK record + PiMark (drawn π, not the logo); USAGE_READ record; ModelPicker.tsx; AgentSwitchSheet replaces ProviderSwitchDialog + N menu items; LaunchRefusedDialog (exit 5); PiTrustNote; PiPanel (Settings → pi); settings default_models + pi_project_trust.
- Mock: agentSessions() keyed by HARNESSES; the four new commands; "dead" model → exit 5.
- Headless Playwright vs mock (port 1437): all flows OK; screenshots in ~/.cache/worktrees/worktrees/pi-phase2/pw/.
- xterm "dimensions" pageerror on session swap in headless — xterm internals, same path as claude↔codex.
- scripts/harness-check.mjs (registry mirror + preselect), shown to fail first.
- plan-usage-check.mjs fails on main too (pre-existing).
