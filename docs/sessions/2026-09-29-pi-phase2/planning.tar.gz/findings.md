# findings

- pi 0.99.1 (managed, ~/.local/bin/pi → ~/.pi/agent/bin/pi shell launcher → install/current-version → releases/<v>/node_modules/.bin/pi).
- Launcher prepends ${XDG_DATA_HOME:-~/.local/share}/pi-node/current/bin to PATH when that node exists → pi's node is pi-node, not the shell's. Here → /opt/homebrew/opt/node (26.10).
- engines.node ">=22.19.0" in @earendil-works/pi-coding-agent/package.json.
- 0.99.1 has `pi mcp <command>` (NEW vs 0.87.1 — proposal §4.1 "no MCP in core" is stale). Phase 3 concern.
- `--list-models --offline`: `provider  model  context  max-out  thinking  images` header, 2+ space columns. 1.6s wall.
- auth check json: ready {"status":"ready","provider":..,"authType":"api_key"} rc0; not_ready reason credentials_not_configured / provider_not_found rc1.
- models.json: providers.lm-studio.baseUrl http://100.119.64.78:1234/v1, models [{id}]. Host up, serves 16.
- session-manager.js: id regex ^[A-Za-z0-9](?:[A-Za-z0-9._-]*[A-Za-z0-9])?$ ; dir `--${cwd.replace(/^[/\\]/,"").replace(/[/\\:]/g,"-")}--`; file `${iso ts with [:.]→-}_${id}.jsonl`; findById scans headers; version 3.
- entry types: session, model_change, thinking_level_change, message, context_edit, compaction, custom, custom_message, label, session_info, usage, branch_summary.
- Screens (0.87.1 captures in ../pi-harness-research): Working rule `── ⠙ Working ──…`, Retrying `── ⠼ Retrying (3/3) in 7s... (escape to cancel) ──`, trust modal footer ` ↑↓ navigate  enter select  escape/ctrl+c cancel`.
- Live TUI launch: DENIED by auto-mode classifier.
