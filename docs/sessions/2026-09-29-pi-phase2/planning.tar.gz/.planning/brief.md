# Build: pi phase 2 — pi launches, resumes, shows a dot, and models are a choice

## Source of truth
`docs/proposals/pi-harness.md` on main: "Decisions", §1–§3, §7, §8 (incl. item 5, the
per-repo allowance), §9.4, §11 "Phase 2" (anchor `phases`), and §2.3 "Shared harness ×
model shape" (anchor `shared-shape`). Phase 1 is merged (#363 core adapter trait +
for_pane fix, #364 app `Harness` type / keyed `agent_sessions`) — build ON that trait;
read its code before planning. Read AGENTS.md (gates + traps) first.

## Decided (do not re-open)
- pi launches with `--no-approve` by default; a user setting `pi_project_trust`
  switches to `ask` (neither flag; pi's own modal). A repo in the user-scoped
  allowance (`[trust] pi = [<canonical repo roots>]` in
  `~/.config/worktrees/config.toml`, a USER_ONLY key) launches with `--approve`. Only
  the user grants it (Settings → pi, `worktrees trust pi [<repo>] [--revoke]`); MCP
  and agents can only READ it. Never write pi's `trust.json`.
- Unreachable model host at launch → REFUSE with "launch anyway": app button, CLI
  `--force`, MCP `create_worktree` returns the named reason and does not launch; the
  worktree + brief are still created.
- One pi (the managed install at `~/.local/bin/pi`), no bundling; a preflight
  measures the pane's pi + node (§9.4) and refuses below pi's own `engines.node`.

## Scope (phase 2 only — not the bus, not `send`, not the pi extension)
1. Registry row `pi` (sidecar `~agent~pi`, `canonical_default: false`) and its
   adapter: launch `pi --model <backend>/<id> --session-id <derived>
   --session-dir <pi default dir> (--no-approve | --approve | neither) "<BRIEF_OPENER>"`;
   resume = same minus `--model`. Session id per §1.3 as corrected: sanitised
   canonical name + short hash of the UNSANITISED name + generation counter
   (`worktrees-(main)` is the counter-example), generation persisted in declared state.
2. `model_arg` on the registry + `ModelRef` / `ModelOption` / `AgentChoice` (§2.3).
   pi's model adapter parses `pi --list-models` (text table — fixture-pinned to the
   pi version you build against), with `pi auth check --provider X --json
   --no-refresh` for reasons. Never read models-store.json, never evaluate
   models.json `!command` keys, never touch auth.json.
3. Activity from pi's session JSONL (§3.1/§3.2 traps: no file until first reply;
   `error`+`context_edit` = retrying; key on the newest MESSAGE entry; mtime is never
   activity) + the screen's `Working`/`Retrying` rule line for the first-turn gap.
   Model label per §3.1. N-ary `most_active` gets a pi reading.
4. Preflight (§9.4) and reachability probe (§7): `GET <baseUrl>/models`, 2–3s
   timeout, from the app/CLI process, cached per baseUrl 60s; reasons
   `endpoint_unreachable` / `not_served`. Both in `worktrees doctor` and the refusal.
5. Trust: `pi_project_trust` setting + the `[trust]` allowance + CLI verb; `may_type`
   / any key-sending path treats pi's trust modal as waiting (Enter selects Trust).
6. Surfaces: CLI `--ai pi --model …` (`--model` also accepted for claude/codex, mapped
   to their existing flags — keep claude/codex behaviour unchanged when absent); MCP
   `create_worktree` gains `model` (validated `[A-Za-z0-9._/:-]+`, named error listing
   ready options); `model`/`harness` join USER_ONLY_KEYS.
7. App: harness + model picker in the new-worktree dialog and a "Switch agent…" sheet
   (§2.4), not-ready rows disabled with the reason; pi row mark + `pi · <model>` label;
   Settings → pi (resolved pi + version, pane node, per-backend readiness, trust
   setting + allowed repos). Mock harness (`app/src/mock/install.ts`) tracks every new
   command.
8. `docs/pi-manual-checks.md` (launch, resume, trust modal, allowance, dead host, Esc).

Suggested split: PR A core+CLI+MCP (1–6, 8); PR B app (7), stacked on A. Keep each
reviewable; if A is too big, split it further rather than growing it.

## The machine you're on (verified 2026-09-29)
- pi is the managed install, now **0.99.1** (probed at 0.87.1 for the proposal) —
  RE-MEASURE the TUI screens, JSONL shape and `--list-models` table on 0.99.1 before
  writing parsers/fixtures. `~/.local/share/pi-node/current` → Homebrew node 26.10,
  so pi no longer depends on nvm; the stray nvm pis are gone.
- `~/.pi/agent/models.json` declares `lm-studio` (a Tailscale host) with one model,
  `qwen3.6-27b`. settings.json defaults to `kimi-coding`, which is NOT signed in.
- **Codex is out of tokens right now.** Do not start Codex sessions; anything Codex
  must be covered by unit tests and called out in the PR as not live-verified.

## Rules
- NEVER write under `~/.pi/` (except the session files pi itself creates during your
  probes — list them in the PR); never open or print `~/.pi/agent/auth.json`.
- Live probes: throwaway tmux servers (`tmux -L <name>`, killed after) in scratch repos;
  use `lm-studio/qwen3.6-27b` only. No Kimi, no paid provider. If the host is down,
  say so and use `PI_CODING_AGENT_DIR` fakes for the dead-host paths.
- Do NOT drive David's running worktrees app. Mock harness on a port ≠ 1420; the
  sandbox app only by PID if real timing is needed.
- New tests shown to FAIL first. Gates per AGENTS.md, reported by grep; release binary
  rebuilt and newer than your edits; `worktrees ls --json` diffed against the shipped
  binary for existing places (no change expected for claude/codex rows).
- CHANGELOG under `## [Unreleased]` with bold leads; exactly one `[Unreleased]` and one
  of each `###`.
- Do not merge. Open PRs, report back, stop; a fable review precedes each merge.
- Scratch in `~/.cache/worktrees/worktrees/<this worktree>/`. Keep Co-Authored-By; NO
  session URLs or Claude-Session trailers.

## Follow-ups from the phase-1 review (fold into phase 2 where they apply)
- `config.rs:~242` calls `resume_arg("")` for the Settings display default. For pi that
  would render `--session-id <derived from "">`. Split "display default" from "resume
  words for a place" before pi's adapter lands.
- `provider.rs`: `for_pane` keys on `SIDECAR_MARKER` (`~agent~`) while `is_sidecar` /
  registry rows use literal suffixes — add a test that every row's `sidecar_suffix ==
  SIDECAR_MARKER + id`, and consider `is_sidecar` using the marker. Also
  `PaneList::session_in` (tmux.rs:~233) skips only `is_sidecar` names, so a
  `~agent~<unknown>` session running `node` can still be ADOPTED as a place's
  canonical session — decide and fix while adding pi.
- App: `AgentMark` (App.tsx:~803) is still `claude ? ClaudeMark : OpenAIMark` — a
  third harness silently renders the OpenAI mark. Make it a `Record<Harness, …>`
  (e.g. `HARNESS_MARK` beside `HARNESS_LABEL`), plus the `.g-agent-<id>` CSS.
  Same shape: `useProviderUsage` (App.tsx:~2118) dispatches claude-else-codex — make
  it a record/explicit default (pi returns no usage per §6).
- `data-testid="topbar-switch-provider"` is emitted once per other harness —
  make it `topbar-switch-provider-${to}`.
- `lib.rs` `if provider == "codex" && codex_bin().is_none()` in `new_place`/`open_place`
  (and frontend `ensureCodexCli`) — this is where pi's preflight hooks in; make it
  per-harness (`installed()`/preflight on the adapter) rather than a second literal.
- Mock `install.ts:~1183-1258` hard-codes `{claude, codex}` agent_sessions — redo it
  keyed by harness when pi arrives.
- `lib.rs`: `struct AgentSession` was inserted between `snapshot`'s `///` doc comment
  and `fn snapshot`, so rustdoc attaches it to the struct — move those two lines back.
- `harness.rs` `SEND_*`, `submit_codex`, `may_type` are `pub` with no outside caller —
  `pub(crate)`; `mcp.rs:~1942` has a mid-file `use …::SendOutcome` — move to imports.
