# Progress

## Session 2026-07-31 (start)
- Fresh session after /clear; no prior planning files.
- Explored: App.tsx TerminalTabs (610-738), SettingsSheet.tsx (12 flat sections), settings.ts (Settings/DEFAULTS/applySettings), App.css plumb lines (233-261), lib.rs shell sessions (1584-1631).
- Wrote task_plan.md + findings.md. Plan: settings redesign → guides toggle → named tabs → log tail → gates/PR.
- Next: Phase 1 (SettingsSheet reorganization).

## Session 2026-08-01 (implementation)
- **Phase 1 done** — SettingsSheet is now a 140px category rail + single-category
  pane (`.settings-split` / `.settings-cats` / `.settings-cat`), sheet widened to
  `min(560px, 92%)`. 8 categories: Appearance, Terminal, Navigation, Commands,
  Behavior, Updates (with `upd` badge on the rail item when actionable),
  Data & Logs, Shortcuts. Category is local state, reset to Appearance on open,
  deliberately not persisted. No settings semantics / invoke / onChange changes.
- **Phase 2 done** — `nav_guides` (default true) → `data-guides` on <html> via
  applySettings; `html[data-guides="off"]` hides the 4 rails + the (main) tick.
  Toggle lives in Navigation.
- **Phase 3 done** — module-scope `TermTabRename` (Enter/blur commit, Esc cancel,
  keys stopPropagation'd so Esc doesn't close sheets). `term_tab_names` keyed
  `repo|slug` → index → name in ui-state.json. Restore seeds the tab list with the
  UNION of live shells + named indices (gated on sessionUp); closeTab drops the
  name and prunes empty buckets. No backend or mock changes (rides get/set_settings).
- **Phase 4 done** — Logs tail pre gets `update-log log-tail`; `.log-tail`
  max-height 40vh (326px vs the old 9rem ≈ 135px). Update-run log untouched.
- Extra: `.settings-body { overflow-x: hidden }` + `.ver-row { min-width: 0 }` —
  the long log/settings paths were forcing a body-level horizontal scrollbar.
- Gates: all green (release CLI build, 238 bats, lint, 137 core tests, tsc, cargo
  check -p app). Harness-verified on :1425 — rename focus survives every keystroke,
  name survives a reload, Esc cancels, close clears the name, all 8 categories
  render their intended sections exactly once, guides toggle flips the rails.
- Screenshots: ~/.cache/worktrees/worktrees/ui-changes/.
- Next: review the diff, then PR (deliberately not pushed).

## Session 2026-08-01 (review + merge)
- Fable-reviewed the full diff: no findings. Notes: settled-ref guards Esc/blur
  double-commit; restore reads names via ref; hooks stay unconditional above the
  category branching; session-down keeps names (matches pre-existing tab behavior).
- PR #68 opened, CI 5/5 green, squash-merged → main @ 30f4ff8. Remote ui-tweaks
  deleted (local branch kept — this worktree still sits on it; /close-out later).
- Known env issue: pnpm scripts broken here (needs Node ≥22.13, machine has 22.12).

## Session 2026-08-01 (release v0.6.0)
- CHANGELOG [Unreleased] → [0.6.0]; workspace Cargo.toml 0.5.0 → 0.6.0.
- Release PR #69: CI 6/6 green, squash-merged @ 5dd86ca; tagged v0.6.0 on that
  commit + pushed (manual tag ≡ make release — main checked out in primary
  worktree, couldn't tag from here via make).
- release.yml run 30684241088: success. Assets complete: CLI ×4, signed app
  bundles ×2 (+ .sig), latest.json, checksums.
- Session fully done — ready for /close-out.
