# Task Plan — UI batch: named terminal tabs, nav-lines toggle, settings redesign, bigger log tail

## Goal
Four UI features on branch `ui-tweaks`:
1. **Named terminal tabs** — rename dock terminal tabs; names persist per place (survive restart as name only — fresh shell, no history).
2. **Nav plumb-lines toggle** — setting to hide the vertical tree guide lines in left nav.
3. **Settings layout redesign** — sheet is a flat pile of 12 sections; reorganize into categories before adding more settings.
4. **Bigger log tail** — the Logs section tail pane (`.update-log` pre) is too small.

## Phases

### Phase 1: Settings layout redesign — status: done
Do FIRST — the other features add settings and need a home.
- [x] Categorize existing sections: Appearance (UI font, theme, density), Terminal (font/size), Navigation (width, tiers, + new lines toggle), Commands (editor/terminal/AI), Behavior (startup, git fetch), Updates (version), Data & Logs, Shortcuts
- [x] Layout: left category list inside sheet (tabs) vs. grouped headers + scroll-to — pick in impl; plain CSS, tokens.css only
- [x] No settings semantics change — pure reorganization of SettingsSheet.tsx + App.css

### Phase 2: Nav plumb-lines toggle — status: done
- [x] `nav_guides: boolean` (default true) in settings.ts (Settings + DEFAULTS)
- [x] applySettings → `data-guides` on root; App.css gates plumb-line rules on it
- [x] Toggle lives in Navigation category of new layout

### Phase 3: Named terminal tabs — status: done
- [x] Frontend: double-click tab label → inline rename input (module-scope component — remount rule!)
- [x] Persistence: `term_tab_names: Record<string, Record<number, string>>` keyed `repo|slug`, in ui-state.json via settings
- [x] Restore semantics: persisted names seed the tab list after restart (fresh shells, spawn on activate) — name survives, history doesn't
- [x] Default label stays `sh N` unnamed; closing a tab clears its name
- [x] Mock harness tracks any new/changed commands (expect none — rides get/set_settings)

### Phase 4: Log tail bigger — status: done
- [x] Give the Logs tail pane its own class / bigger max-height (vs shared `.update-log`)

### Phase 5: Gates + PR — status: done
- [x] `cargo build --release -p worktrees-cli` FIRST, then `make test`, `make lint`, `cargo test -p worktrees-core`, `cd app && tsc --noEmit && cargo check -p app`
- [x] Sanity in mock harness (vite --port 1425 directly; pnpm broken on this machine — needs Node ≥22.13, have 22.12)
- [x] Fable review of diff (clean, no findings) → PR #68, CI 5/5 green, squash-merged as 30f4ff8; remote branch deleted

## Decisions
| Decision | Choice | Why |
|----------|--------|-----|
| Where tab names live | ui-state.json (app settings) | App-only feature; places.json is engine-declared state, CLI has no dock-tab concept |
| Order | Settings redesign first | New toggles need a home; avoids re-layout churn |
| Restore semantics | Names seed tabs on restore, fresh shells | User: "survive restarts… just the name, not the history" |

## Errors Encountered
| Error | Attempt | Resolution |
|-------|---------|------------|
| (none yet) | | |
