# Findings

## Terminal tabs (App.tsx:610-738)
- `TerminalTabs` at module scope. State: `ids: number[]`, `active`, `dead: number[]`.
- Restore from backend `list_shell_sessions(repo, slug)` → `{index, dead}[]` (lib.rs:1614). Shells do NOT outlive app process (PTYs owned); after restart list is empty → dock opens fresh `[1]` if sessionUp.
- Tab label hardcoded `sh {id}` (App.tsx:710). Close = `close_shell_session`; add = max+1.
- Session down → tabs cleared (scratch shells die with place).
- ShellPane spawns shell on mount (shell_open); only active tab mounted.
- Backend sidecar tmux naming: `<session>~term`, `~term~2`… (lib.rs:1584-1600).

## Settings (settings.ts, SettingsSheet.tsx)
- `Settings` type + DEFAULTS in settings.ts; persisted via get_settings/set_settings → ui-state.json (backend tolerates unknown/missing fields — mock too).
- SettingsSheet: 12 flat `<section className="setting">` blocks in one scroll: UI font, Terminal font, Commands, Theme, Density, Git, Startup, Version, Nav tiers, Logs, Nav width, Shortcuts, Data.
- App owns settings state; sheet is presentational (`onChange(patch)`).
- applySettings writes CSS vars + `data-theme`/`data-density` on root — pattern to copy for guides toggle (`data-guides`).

## Nav plumb lines (App.css:233-261)
- `.kids::before`, `.kids-d::before`, `.group > .places::before`, `.subgroup > .places::before` = 1px vertical rails; `.kids > .places::after` = horizontal solder tick to (main) dot. Hover/sel brighten via :has.
- Gate all with `html[data-guides="off"]` (or only draw when attr ≠ off).

## Log tail
- SettingsSheet Logs section: `log_tail` invoke (200 lines) rendered in `<pre className="update-log">` — same class shared with update run log. Find `.update-log` in App.css; give tail its own class or bump max-height.

## Mock harness
- app/src/mock/install.ts must track every lib.rs command. New settings fields need no new commands (ride get/set_settings). Rename is frontend-only + persistence → likely NO backend change at all.

## Gotchas (from CLAUDE.md)
- Components inside App() remount every render — rename input must be module scope.
- Stale release binary breaks bats — build release CLI before make test (no CLI change expected here, but gates require it).
- macOS case-insensitive FS — watch new filenames.
