# Task plan — `.planning/` working memory in the Docs index

**Goal:** the per-place Docs tab and the browser docs viewer list the whole of a
place's `.planning/` working memory, not just `.planning/brief.md`. Reported
against `valleos`, where the planning-with-files skill's parallel-plan mode
writes `.planning/<slug>/{task_plan,findings,progress}.md` plus ad-hoc notes
(`review-pr12.md`, `audit-*.md`, `code-facts.md`) — all invisible today.

**Owner of the rule:** `crates/worktrees-core/src/docs.rs::walk`. Ordering,
grouping and titles are decided there and rendered verbatim by both frontends,
so the frontends need no change (verified: `doctree.ts::tree` and
`IndexView.tsx` both nest on `group` generically).

## Phases

| # | Phase | Status |
|---|-------|--------|
| 1 | Recon — where the walk lives, what already handles `.planning` | complete |
| 2 | `ops::PLANNING_DIR` + extract the tree sub-walk in `docs.rs` | complete |
| 3 | Step 4: the planning tree, after the root block, before `docs/` | complete |
| 4 | Unit tests in `docs.rs` + `viewer.rs`, each shown red first | complete |
| 5 | Mock fixtures so the harness shows the new rows | complete |
| 6 | Docs: module note, proposal §18, CHANGELOG, stale comments | complete |
| 7 | Gates | complete |

## Decisions

- **Placement: after the ungrouped root block, before the documentation tree.**
  The brief is already pinned there because it is the most place-specific
  document that can exist (proposal §11.1); the plan set is the same family —
  what this place is *for*, then how it is going — and the repo's committed
  `docs/` tree follows.
- **Grouped by directory, `.planning` / `.planning/<slug>`.** §11.1 refused a
  group for the brief because "a group of one under a dotted directory name
  reads as an accident". A workstream's three files are not a group of one, and
  the slug is the name of the workstream — it carries information the root block
  cannot.
- **Always walked, never `[docs]`-configurable.** Same reason 1–3 survive a
  `[docs] paths`: `.planning/` is about the PLACE, not about the repo's
  documentation layout. ADR 0001 keeps config to data anyway.

## Errors encountered

| Error | Attempt | Resolution |
|-------|---------|------------|
