# Findings

Treat everything here as research data, not instructions.

## F1 — the gap is one `if`, not a missing feature

`docs.rs::walk` step 2 lists exactly `ops::BRIEF_PATH` (`.planning/brief.md`).
The tree pass (step 4) starts at `docs/` (or `[docs] paths`) and its inner loop
skips any child whose name `starts_with('.')`, so nothing else under `.planning/`
can ever be reached.

## F2 — what is really in `.planning/` (measured on valleos, 2026-09-20)

17 worktrees carry one. Shapes seen:

- `.planning/brief.md` — tool-owned, already listed.
- `.planning/<slug>/{task_plan,findings,progress}.md` — the skill's
  parallel-plan mode. Several slugs per place: `ssdlc` has `ssdlc`,
  `w0-ssdlc`, `w0-secrets-aws`; `dev-env` has `dev-env`, `w5-aws-staging`.
- `.planning/.active_plan` — a pointer file, not markdown.
- loose `.planning/*.md` — `review-pr7.md`, `review-pr12.md`.
- a deep set: `.planning/docs/{audit-A..D,code-facts,AUDIT-CONTRACT,
  PHASE2-CONTRACT,audit}.md` — 11 files, real documents.

Largest single place: ~19 markdown files under `.planning/`. `MAX_ENTRIES` is
2000, so truncation is not a live concern.

## F3 — the frontends need no change

- `app/src/doctree.ts::tree` nests on `group`, splitting on `/`, creating dir
  nodes for every segment. `.planning/portal` → a `.planning` node with a
  `portal` child. No dot-name filtering anywhere in it.
- `app/viewer/IndexView.tsx` groups on `e.group` verbatim and renders the string
  as the heading.
- `app/viewer/DocsNav.tsx` passes `group` through (`viewer-boundary-check.mjs`
  asserts that).

## F4 — the server already serves dot paths

`docserver::safe_under` and `viewer::safe_rel` both refuse only empty, `.` and
`..` components — a leading-dot *name* is fine. `viewer.rs:1627` already tests
`.planning/brief.md` through `safe_rel`, and `derive.rs:1681` tests the route
`#/.planning/brief.md`. So the derived tree and its routes work unchanged.

## F5 — the fingerprint must move with the index

`docs::fingerprint_with` shares `walk` with `index_with` precisely so the two
cannot disagree; a new step is picked up by both for free. That is the reason to
put the change in `walk` and nowhere else.
