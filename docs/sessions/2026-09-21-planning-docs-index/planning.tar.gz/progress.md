# Progress

## Session 2026-09-20 — `.planning/` in the Docs index

- Recon complete. Wrote findings F1–F5.
- Confirmed the fix is one new step inside `docs.rs::walk`; no frontend change.

- Implemented `docs.rs` step 4 (`.planning/**`), extracting `subtree()` so the
  documentation tree and the working-memory tree share one walker. Added
  `ops::PLANNING_DIR`.
- 5 new tests in `docs.rs`, 1 in `viewer.rs`. Each shown RED first: 4 by
  disabling step 4, `a_symlinked_planning_directory_is_walked_as_nothing` by
  removing the walker's own symlink guard, and the viewer one by making
  `safe_rel` refuse a dotted component.
- `docs-check.mjs` fixture now carries a real `.planning/<slug>` group; proved
  it fails (2 messages) on a path-derived `tree()`.
- Swept the four comments that reasoned FROM "a `.planning/` the walk does not
  show" (doctree.ts, contract.ts, IndexView.tsx, viewer-boundary-check.mjs).
- Verified against the reported repo with a throwaway `--example` (deleted):
  valleos/.worktrees/ssdlc now lists 8 plan rows in 3 workstream groups,
  .worktrees/docs lists 18, main (empty `.planning/`) is unchanged.
- Gates: `make test` 340/340, `make lint` clean, core 393, cli 11, app --lib
  136, tsc clean, all 11 `app/scripts/*-check.mjs` ok.
