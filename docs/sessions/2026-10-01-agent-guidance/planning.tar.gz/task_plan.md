# Agent guidance phase 2 (branch agent-guidance-phase2)

Goal: per-launch guidance (proposal §8 phase 2 + Decisions). Managed repos only.

## PR A — core/CLI
- [ ] core `guidance.rs`: HEAD (moved from mcp.rs), SKILL.md + rules text via include_str!, content-hashed materialize dir under $XDG_DATA_HOME/worktrees/agent/<hash>/ (skills/worktrees, claude plugin, claude-guard plugin, rules.md)
- [ ] settings file ~/.config/worktrees/agent-guidance.json {enabled (default true), guard (default false)}; env WORKTREES_AGENT_GUIDANCE=off overrides
- [ ] Project::is_managed() (move from mcp.rs Server::managed)
- [ ] AiLaunch.guidance: Vec<String> (shell-quoted), emitted in launch_cmd head for every adapter
- [ ] claude: --plugin-dir <claude|claude-guard>; pi: --skill + --append-system-prompt; codex: -c developer_instructions=<rules> unless user has own (cached prompt-input probe)
- [ ] `worktrees guard pretooluse` (hook command, reads stdin JSON) — pure verdict fn in core
- [ ] `worktrees guide [--status] [--json]`
- [ ] doctor: info finding when codex skipped
- [ ] tests red-first; bats for launch line; ls --json identical
## PR B — app
- [ ] Tauri agent_guidance_status / set_agent_guidance; mock harness
- [ ] Settings → Agent guidance category; offer `agent-guidance` in offers.ts; offers-check.mjs
- [ ] see it in mock + WebKit
