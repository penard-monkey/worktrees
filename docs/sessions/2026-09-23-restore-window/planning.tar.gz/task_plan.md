# Task: "Restore window on launch" setting

Goal: a Settings toggle that makes the app reopen in the window state it last had
(size, position, maximized, FULLSCREEN) after a quit, restart, or in-app update relaunch.

## Phases
1. Research (window config, settings plumbing, plugin, relaunch path) — complete
2. Branch — complete
3. Backend winstate — complete
4. Frontend setting — complete
5. CHANGELOG — complete
6. Gates — complete (all green after pnpm install for mermaid)
7. PR #331 squash-merged as 64d424f (fullscreen retest after the fix NOT done) — complete

## Decisions
- OWN small module instead of tauri-plugin-window-state: the plugin records width/height
  on every Resized while fullscreen (it only filters maximized), so a fullscreen quit
  restores a screen-sized window once you leave fullscreen. We only record the frame
  while NOT fullscreen/maximized/minimized, and keep the flags separately.
- Default ON (typical macOS behaviour). Backend treats a missing key as ON to match DEFAULTS.
- Backend only READS ui-state.json (frontend writes it whole-blob); state goes in its own
  backend-owned `window-state.json` (same pattern as shell-cwds.json).
- Always record, restore only when enabled — turning it on later uses the last session.
- Takes effect at next launch (restore happens in setup, before the frontend loads).

## Errors Encountered
| Error | Attempt | Resolution |
|-------|---------|------------|
