# Progress
## 2026-09-23
- Research done (see findings.md). Plan written.
- Branch ui-changes-restore-window. Added app/src-tauri/src/winstate.rs (+6 unit tests; fullscreen test shown red under the plugin's rule), wired into lib.rs (manage, setup attach, Ready, Exit).
- settings.ts restore_window (default true), SettingsSheet checkbox under Behavior → Startup, CHANGELOG [Unreleased].
- Gates green; PR #331 opened. Hand test in sandbox still needed (fullscreen restore, leave-fullscreen size).
- Hand test 1 failed (restored windowed). Switched to settled saves + no exit save + fullscreen check/retry + logging. Pushed to #331.
- Rebased (CHANGELOG conflict with #329), app gates re-run green, squash-merged #331 as 64d424f. Worktree parked on ui-changes-next = origin/main.
