# Findings
- Window from tauri.conf.json: label "main", 1280x820, min 900x560. No window-state code before this.
- Settings: frontend-owned ui-state.json, free-form JSON; `loadSettings` spreads DEFAULTS. No mock change needed.
- Existing `.run(|handle, event|)` handles RunEvent::Exit (saves shell cwds) — hook the save there.
- Update relaunch: SettingsSheet `relaunch()` → plugin-process 2.3.1 `restart` → `app.request_restart()` → request_exit → RunEvent::Exit fires. So the Exit save covers updates.
- tauri-plugin-window-state 2.4.1 (in registry): restores in on_window_ready, saves on Exit; its Resized handler ignores fullscreen → records screen size as the normal size. Reason we roll our own.
- Crash / kill -9 skips Exit: the frame from the previous clean exit is used. Acceptable.
