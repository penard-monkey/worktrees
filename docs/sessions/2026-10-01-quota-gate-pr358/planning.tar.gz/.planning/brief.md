# Finish brethash's PR #358 (quota gate) on his branch, so it can merge

## Context
PR #358 (`feat/agent-load-balance`, by brethash, in THIS repo — not a fork) refuses a Claude/Codex
launch onto a nearly spent plan window, as a Soft refusal in the adapter's `prepare`
(`quota::gate`), plus moves the usage readers into core. It has been reviewed twice; read both
review comments first: `gh pr view 358 --comments` (from penard-monkey). David asks us to push the
remaining fixes onto his branch ourselves and merge it.

## Rules for working on someone else's branch
- Check it out IN THIS PLACE: `git fetch origin && git checkout -B feat/agent-load-balance
  origin/feat/agent-load-balance` (this place is yours; never check that branch out anywhere else).
- **Never force-push and never rewrite his commits.** Add commits on top. Bring in main with a
  MERGE (`git merge origin/main`), not a rebase. Squash-merge flattens it at the end anyway.
- Do not edit his PR description; I'll set the squash message at merge time. Keep his authorship.

## Do
1. `git merge origin/main`. Resolve CHANGELOG: one `## [Unreleased]`, ONE `### Added`, ONE
   `### Changed`, ONE `### Fixed` (count: `awk` between [Unreleased] and the next `## [`), every item
   from both sides kept with bold leads. Check NOTHING landed inside `## [0.34.1]` or older.
   Resolve any other conflict (main has #385, #391, #393, #394 and possibly early cross-project
   phases since his base).
2. MUST-FIX (the open one): **the brief opener is lost after a quota refusal for Claude and Codex.**
   `cmd_open` (ops.rs) only sends `ops::BRIEF_OPENER` when `Adapter::never_launched` is true, and only
   Pi overrides it. Give Claude and Codex `never_launched` in pi's shape
   (`!self.session_present(p, &p.place_dir(slug))`; check how #376's re-used-slug logic and #393 shaped
   it on main — match pi exactly). Extend test/quota.bats's "open --force relaunches…" to use
   `--brief` and assert the opener on pane 0 (shape: test/pi.bats "a dead model host refuses with exit
   5, and open --force launches WITH the brief's opener"), plus the plain `open` later once the window
   has headroom. Show the test RED on his code first.
3. Text: `LaunchRefusedDialog` (app/src/App.tsx ~195-196) uses pi's dead-host sentence — make it
   generic or keyed on the reason; fix the comments (~169, ~296, ~5014) that reason from "the model
   host did not answer". `crates/worktrees-core/src/claude_usage.rs:4` says "The quota gate in
   `ops::cmd_new`…" — update to the adapter design.
4. Nits (do them): README/CHANGELOG — `WORKTREES_USAGE_PROBE=off` switches the GATE off, not the
   app's meter; `other_harnesses` must not list a harness whose `installed()` is the default Ok when
   its binary isn't on PATH (or say why it's fine); doc on `Window::model` that a lane with no model is
   never graded against a model-scoped bucket (fail-open by design); an MCP `force: true` case in
   quota.bats or mcp.bats; consider a shorter deadline for the gate's probe than the meter's (offline
   `new` can stall 10–15s) — do it if small, else a README line.
5. Gates per AGENTS.md (release build first and newer than edits; `make test` exit code + plan line +
   `grep -cE '^not ok'`; lint; core/cli/app tests; tsc + `cargo check -p app` after `nvm use` +
   `corepack pnpm install` in app/; ALL app/scripts/*-check.mjs from the repo root); `ls --json`
   byte-identical vs ~/.local/bin/worktrees (v0.34.1). Never call the real usage endpoints in tests.
6. Push (plain `git push origin feat/agent-load-balance`), watch CI with
   `gh run watch <id> --exit-status`, then SendMessage me: commits added, what each fixed, gates,
   CI result. Do NOT merge; I review the delta and merge.
Scratch in ~/.cache/worktrees/worktrees/<this worktree>/; scratch checkouts only as worktrees places.
Codex is out of tokens. Don't drive David's running app. Keep Co-Authored-By; no session URLs.
