# Findings
- `app/src-tauri/src/lib.rs:2874` `github_url(repo, slug)`: discover → `git remote get-url origin` → `normalize_remote` → `/tree/<branch>` on github.com. No unit tests for `normalize_remote`.
- Place ctx menu (App.tsx ~6520) already has "Open on GitHub" via `openOnRemote(repo, slug)` (App.tsx:4111). Project ctx menu (App.tsx ~6560) has none.
- Topbar (App.tsx:5701): `.identity` holds slug, alias, then `HeaderBranch` (worktree) or `.branch` span (main), then `.status-cluster`. `.identity` is `overflow: hidden` — no popovers inside it (HeaderBranch uses fixed positioning).
- `Place.upstream` is in the TS type (App.tsx:62) and the snapshot; set only when it RESOLVES (project.rs:191). `ops.rs:539` creates with `--track origin/<branch>` only when the branch exists on origin, so upstream name == local branch name.
- Snapshot carries NO remote URL; the workspace has `ProjectView{root, ok, error, snapshot}`.
- Mock: `install.ts:893` `github_url` case returns a demo URL.
- Icons in `app/src/icons.tsx` are named exports (`GitBranch`, `Ellipsis`, …); no external-link icon yet.
- Opener plugin: `openUrl` from `@tauri-apps/plugin-opener` is already used in App.tsx; `opener:default` covers open-url.
