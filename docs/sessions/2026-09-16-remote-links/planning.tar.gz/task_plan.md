# Task: remote-repo links (project right-click + topbar)

**Goal:** From the left nav, right-clicking a project offers "Open on GitHub" (the
repo home on its origin remote). In the topbar, right of the branch chip, a link
icon opens the selected place on the remote (branch page when the branch is
tracked on origin, repo home otherwise). No more hunting on GitHub.

## Phases
| # | Phase | Status |
|---|-------|--------|
| 1 | Research: existing `github_url`, ctx menus, topbar, mock | complete |
| 2 | Backend: `github_url(repo, slug)` → `remote_url(repo)` (base only) + unit tests for `normalize_remote` | complete |
| 3 | Frontend: `remoteWebUrl()` rule in `app/src/remote.ts`, per-root cache, project menu item, topbar link, place menu reuse | complete |
| 4 | Mock harness: `remote_url` case (one project with no remote) | complete |
| 5 | Guard script `app/scripts/remote-check.mjs` (shown to fail first) | complete |
| 6 | Gates + harness layout check | complete (bats 335 ok, lint, core 298, cli 7, app 48, tsc, cargo check) |
| 7 | CHANGELOG, PR | complete |

## Decisions
- URL rule lives in ONE place: TS (`remote.ts`); Rust only normalizes the remote
  spec to an https base. The old Rust `github_url` built `/tree/<local branch>`,
  which 404s for an unpushed branch — new rule uses `Place.upstream` (`origin/x`
  → `/tree/x`, github.com only), else the repo home.
- Topbar link is hidden until the base is known (one `git remote get-url` per
  project root, cached, refreshed on selection change). Menus always show the
  item and report "No origin remote" on click, like the place menu did.
- Branch: `ui-remote-links` off origin/main 84b89fa.

## Errors Encountered
| Error | Attempt | Resolution |
|-------|---------|------------|
