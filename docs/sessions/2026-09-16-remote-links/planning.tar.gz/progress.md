# Progress
## Session 2026-09-16
- Branched `ui-remote-links` off origin/main (84b89fa). Research complete (see findings.md).
- Phase 2: lib.rs github_url → remote_url + normalize_remote tests written (not yet run)
- Phase 3+4: remote.ts (rule), Icons.ExternalLink, App.tsx (remoteBase cache, loadRemote, openRemote, project-menu item, topbar link), App.css `.remote-link`, mock `remote_url` + fixture upstreams. tsc clean.
- Phase 5: app/scripts/remote-check.mjs — shown RED twice (null-upstream crash; "origin" vs "origin/" prefix → `tree//feat/x`), then green.
- Rust: `cargo test -p app --lib a_remote_spec` 1 passed (not yet shown red — do at gate time).
- Phase 6 harness (mock :1477, Chrome devtools MCP): topbar link renders right of the branch chip (x 307 vs chip right 295, same midline y=25), hit-test OK, title "Open github.com/demo/worktrees/tree/feat/ui-redesign" on the pushed place and ".../worktrees" (home) on random-work (no upstream). Project menu shows "Open on GitHub" in the Copy/Reveal group, hit-test OK. Screenshots in .playwright-mcp/ → move to ~/.cache/worktrees/worktrees/ui-tweaks/.
- Mock click paths: both surfaces reach `plugin:opener|open_url` (console shows the mock opener called twice, no error banner). The two `Cannot read properties of undefined (reading 'dimensions')` console errors come from TerminalPane.tsx:196's post-switch setTimeout in the mock's xterm — pre-existing harness noise, not this change.
- CHANGELOG [Unreleased] entry added. Screenshots moved to ~/.cache/worktrees/worktrees/ui-tweaks/. Harness on :1477 stopped.
