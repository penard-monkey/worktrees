# Progress
## 2026-10-02
- Read brief, mapped App.tsx nav state, checked xterm key handling.
- Wrote docs/proposals/nav-history.md + index row. Committed + pushed; messaged orchestrator for review. STOPPED.
- Design approved via orchestrator (project sheet no; dock_open no; 600ms; chords as proposed). Merge origin/main before PR (#409/#411).
- Phase 2 done: navHistory.ts + navhistory-check.mjs (red vs 4 mutations), f729cb9 pushed.
- Phase 3 done: observer/apply/buttons/chords/mouse in App.tsx; zoom-check extended (real navChordDir inlined, red vs 3 mutations). Harness: Chromium + WebKit drive OK (~/.cache/worktrees/worktrees/nav-history/drive.cjs, mock on :1431). xterm 'dimensions' pageerrors are pre-existing on main (verified with main's App.tsx).
- Decision in code: no explicit prune on remove — navAlive skips places missing from ws (covers removal by agents too).
- Phase 4 done (4a98878): dock tab/file/line in Loc; parked apply (navPending); restore stand-down; clearDockAt amends. Harness: dock.cjs in Chromium + WebKit + ?stalefile all correct.
- Phase 5 done (f30a211): onFront/goto on TerminalTabs; skip obs while front unknown (fixed forward-truncation bug). Agent dropped from Loc. shell.cjs Chromium+WebKit OK; 'unregisterListener' pageerrors pre-existing on main.
- Phase 6 done (086bf3e): right-click list via CtxMenu (menu.cjs Chromium+WebKit OK, hit-tested); bare Files tab dropped from labels.
- Phase 7: CHANGELOG entry (3a57217); merged origin/main twice (9b0e50f; 71bff8e resolved CHANGELOG conflict with #413 — both items kept, one ### Added/### Fixed). Full gates green on the FIRST merge (bats 1..451 0 fail, lint, core 665, cli 70, app 151, tsc, cargo check, test-frontend); final harness drive Chromium+WebKit OK. PR #416 opened (non-draft).
- PAUSED on orchestrator request after pushing 71bff8e (tsc + test-frontend green on it; full gates NOT yet re-run on this merge; CI not yet watched). No harness/vite running.
- Resumed: full gates on 71bff8e green (bats 1..451 0 not ok, lint, core 665, cli 70, app 151, tsc, cargo check, 29 frontend checks). CI 37010156431: 9/9 success. PR #416 not draft, CLEAN. Stopped for review.
- Review (MERGE AFTER FIXES): fixed closed-Terminal-dock location (stripUp + navSeenFront fallback, so ⌘J is still no step) and stale file_readable (navApplyGen ticket + selRef check); foreign setSel ends apply; navGo closes menu; prune on removal; comments. Guard navwire-check.mjs: 7 fails on pre-fix App.tsx, 4/3 with each fix reverted alone. Reviewer repros closeddock/twoback/race/shells/removed all OK; my 4 drives OK in Chromium+WebKit. Merged main (#417). Full gates + CI 37034260519 green on e29992f.
