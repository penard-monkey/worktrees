# Findings
- State map + line refs: see docs/proposals/nav-history.md §1.
- xterm 5.5 Keyboard.ts: ⌘←/⌘→ (`case 37/39: if (ev.metaKey) break;`) emit NO bytes and are not cancelled → reach window listener. Terminal loses nothing if Back takes them. xterm focus sink is `.xterm-helper-textarea` (a textarea) — special-case in the "editable" test.
- Topbar only renders with a place selected; Home has none.
- Project row click = toggleProject (fold); project sheet is a modal.
- TerminalTabs owns `active` locally; `activeTab` prop only read at restore → needs a goto token for apply.
- updatePanels writes for selRef.current (assigned in render) → apply must park dock part until sel lands (pendingDoc pattern, App.tsx:4433).
- files_open restore effect (App.tsx:3487) would reopen remembered file over an applied entry without one → must stand down.
