# Task plan — nav-history (back/forward navigation)

## Goal
Browser-style back/forward history over what the app's two panes show (place/Home, dock tab, file+line, shell, agent), with ‹ › buttons and ⌘[ ⌘] / ⌘← ⌘→ chords. Brief: `.planning/brief.md`.

## Current Phase
Phase 8 — review fixes DONE (455f687; tip e29992f after merging main #417). Gates green; CI 37034260519 9/9 success; PR CLEAN. Waiting on orchestrator to merge.

### Phase 1: Design → docs/proposals/nav-history.md
**Status:** complete (approved)

### Phase 2: navHistory.ts pure module + navhistory-check.mjs (red-first)
**Status:** complete (f729cb9)

### Phase 3: Observer + Home/place capture + buttons + chords + mouse buttons
**Status:** complete

### Phase 4: Dock tab + file/line capture and parked apply
**Status:** complete (4a98878)

### Phase 5: Shells (TerminalTabs goto token) + agent
**Status:** complete (f30a211; agent dropped — one live agent per place)

### Phase 6: Gone targets (prune, notice) + right-click list
**Status:** complete (086bf3e)

### Phase 7: Harness Chromium + WebKit, CHANGELOG, gates, PR, CI
**Status:** complete

### Phase 8: Review fixes (closed Terminal dock unrecorded; stale file_readable apply)
**Status:** complete (455f687)
