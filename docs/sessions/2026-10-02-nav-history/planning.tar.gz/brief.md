# Back / forward navigation history (⌘← / ⌘→) across the app's two panes

## What David wants (2026-10-02)
A browser-style navigation history for what appears in the app's two panes. Every navigation counts:
selecting a place or project in the LEFT nav, whatever the RIGHT side shows (the dock: Files / Plan / Docs
/ shells / … tabs, the file open in the viewer — incl. a line from a ⌘-click or show_doc), switching
terminals/agents. As you click around a history builds; Back (left arrow) and Forward (right arrow)
buttons move through it, and ⌘← / ⌘→ do the same.

## How to work — David may stop you halfway (he's moving locations)
- Use the `planning-with-files` skill: `.planning/nav-history/` with task_plan.md (`## Goal`,
  `## Current Phase`, `### Phase N` + `**Status:**`), findings.md, progress.md; `echo nav-history >
  .planning/.active_plan`. Keep them CURRENT after every step — they are how the work survives a stop.
- Keep everything ATOMIC: small self-contained commits, each building and passing its own checks; push the
  branch after each phase so nothing lives only on disk; the PR can be a draft until the last phase.
- Phases: (1) design → write it into `docs/proposals/nav-history.md` (short) and STOP for my review via
  SendMessage to the orchestrator; (2+) build in small slices after I say go.

## Design questions to answer (with evidence from the code — App.tsx is large; map the state first)
1. What is a "location"? Likely `{repo, slug|home, rightPane: {tab, file?, line?, shellTab?}, …}` — find
   every piece of state that decides what the two panes show (`sel`, dock tab/file, `openDockFile`,
   `place_panels` per-place record, Settings sheet?, Home). Which navigations are history entries and
   which are noise (e.g. scrolling, hover, a refresh re-selecting the same place, the 3s polls, the
   restore-on-launch path, the `app:open-doc` inbox)? Coalescing rules (rapid clicks, same location twice).
2. ⌘← / ⌘→ CONFLICT: in text inputs and in the terminal, ⌘← / ⌘→ mean "line start/end" (zsh, Claude's
   composer, the markdown editor, the guidance editor). Decide: only when focus is NOT in an editable
   field/terminal? always, with the terminal getting it some other way? or an alternative chord
   (⌘[ / ⌘]) plus ⌘←/⌘→ where safe? Recommend with reasons. AGENTS.md: xterm STOPS PROPAGATION of keys it
   handles (a window listener never hears them while the terminal has focus); all modal Escape goes
   through `useEscape.ts`'s capture stack; ⌥ chords must match on `e.code`; zoom chords live in App.tsx
   `zoomDir` (zoom-check.mjs) — don't collide.
3. Navigating back to something that no longer exists (place removed, file deleted, shell closed):
   skip, or land and show why? History size cap, per-window, persisted across relaunch or not (ui-state.json
   is a whole-blob frontend file — mind the place_panels SEED rule in AGENTS.md).
4. UI: where the ← → buttons go (title/top bar?), disabled states, tooltips with what's behind them,
   maybe a long-press/right-click list. WebKit button sizing rule; hit-test with elementFromPoint.
5. Interplay: drag-drop, the Switch agent sheet, Settings sheet open (does Back close it?), the offers
   modal, the cross-project drop, ⌘-click opening a file at a line (an entry), show_doc from agents (an entry?).

## Build (after design approval)
Pure history reducer in its own module (push/back/forward/coalesce/prune) with a check script in
app/scripts/ evaluating the real module (the race-check/termresize-check pattern: fails on breakage,
red-first). Wire capture points one area at a time (left nav, dock tabs, files, terminals) — each a commit.
Mock harness: drive it in Chromium AND headless WebKit; keyboard chords via a KeyboardEvent dispatched at
the focused element (AGENTS.md: synthetic Chrome-extension keys don't reach the page). CHANGELOG under the
fresh `## [Unreleased]` (count headings — other lanes add entries). Gates per AGENTS.md (`nvm use` +
`corepack pnpm install` in app/). PR, CI watched with `gh run watch <id> --exit-status`, reply, STOP.

## Rules
Don't drive David's running app (mock on a port ≠ 1420, as a real background job). Scratch checkouts only
via `worktrees new <name> --ai none --no-spare --no-attach` + `worktrees rm`. Any throwaway tmux:
`tmux -L <unique-name>` on EVERY command incl. kill-server. Keep Co-Authored-By; no session URLs. Don't merge.
