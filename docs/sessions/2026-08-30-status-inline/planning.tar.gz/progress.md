# Progress

## Session 2026-08-29 — planning: status check into main window
- Fresh planning session (no prior files; catchup empty).
- Researched StatusSheet, App.tsx empty-state, markdown.tsx, mock harness,
  backend ai_status_report/place_health. All findings → findings.md.
- Wrote task_plan.md (6 phases; phase 1 complete).
- Delivered assessment to David; awaiting go-ahead + decisions
  (menu item on session-less places; layout width).
- No code changes yet. Branch: ui-next (clean); origin/main = v0.19.0 c956724.

## Session 2026-08-30 — implementation kickoff
- David confirmed: Ask Claude button-only; SWR fetch keyed repo|slug; hide
  "Status check…" menu items on session-less places (both menus).
- Created branch `ui-status-inline` off origin/main c956724 (v0.19.0).
- Launched workflow wf_0340c3f1-aa7: opus implement (brief in workflow script)
  → harness UI verify → 4 review lenses → 3-refuter adversarial verify → opus
  fix → full gates. Working tree only, no commits.
- Next: fable reads final diff, then report to David.
- Workflow wf_0340c3f1-aa7 COMPLETE (65 agents, all gates green incl. full
  suite: bats 325 ok, core 267, cli 7, app 45, tsc/check clean).
  Implementation + fix pass landed in working tree (4 files, +486/−209).
  19 raw findings → 6 distinct defects, all fixed: healthCache invalidation +
  seq ticket; checking-init flash; sheet/inline mutual exclusion (selection
  change closes sheet, inline body suppressed while sheet open);
  .term-empty split into base + .term-empty-scroll (dock hosts untouched);
  .term-status .update-log gets --bg-panel (was invisible on --bg-abyss main,
  worst in tokyo-day); fence font-size inherit in hs-read-md.
- JUDGMENT CALL to surface: ctx-menu gate is "hide only when check already on
  screen for this exact place" (not blanket session-less) — preserves Home
  resume-row route where no inline panel exists. Topbar gate IS blanket
  (that site is always the selected place).
- Fable diff review: clean. Verified .md-fence .code selector real (App.css
  1509), hs-read-md source-order wins over .update-log pre-wrap, ctx gate
  expression compares right pair, inline onReport ordering + comments carried.
- First harness run: 13 checks PASS (incl. button-only ask proven by IPC spy,
  effect keying proven under forced sweeps, SWR both directions, plain-text
  back-compat, error path). Its 1 FAIL (update-log contrast) drove fix 6.
- Fix-layer harness verification: ALL 7 CHECKS PASS with counterfactuals —
  dock empty states dead-centred (base .term-empty untouched); flex-start
  preserves exactly the 32px bottom padding (stretch loses it); update-log
  contrast ≥16 Δmax in all six themes (pre-fix was 0 in all six; --bg-input
  would have been 0 in mocha); fence font 11.25px == prose (pre-fix 13px),
  dock doc view unaffected; sheet/inline exclusion 0 duplicate testids over
  1385 frames; ctx gate correct in all 5 cases incl. Home resume row;
  cold mount 0 wrong-copy frames (falsified by forced reject: 732).
  Console errors observed are pre-existing (TerminalPane.tsx:189, App.tsx:803
  — outside all diff hunks).
- Status: DONE pending David — working tree uncommitted on ui-status-inline.
- Still owed before RELEASE (not PR): real-app run `app/scripts/sandbox.sh
  --app` — mock cannot express the in-flight-sweep ordering (per CLAUDE.md).

## MERGED 2026-08-30
- PR #179 squash-merged as `ecf7b96` on origin/main. CI: all 9 checks green
  (lint, rust/app/install/test on ubuntu + macos) — `test (macos-latest)` was
  still running at merge time and was CONFIRMED success afterwards. `gh pr merge` printed
  "fatal: 'main' is already used by worktree" — the documented post-merge
  local-checkout failure, NOT a merge failure; verified via
  `gh pr view --json state,mergeCommit` before touching anything.
- Commit includes a CHANGELOG `[Unreleased]` section (3 entries, house voice).
  CHANGELOG is outside CI paths-ignore because it ships via include_str! —
  re-ran `cargo test -p app --lib` after the edit: 45 pass.
- Remote branch deleted; worktree parked on `ui-next` at origin/main (0/0).
- NOT DONE (deliberate, owed before the next RELEASE): real-app pass
  `app/scripts/sandbox.sh --app`.

## Phase status
- Phases 2–6 of task_plan.md: COMPLETE (implementation, inline host, menu
  wiring, markdown render, gates + harness verification ×2).
