# Status check → main window + legible Claude read

## Goal
Two changes to the v0.19.0 status-check feature (#173/#174):
1. When a selected worktree has **no live session**, the main window's empty
   area ("No live session for X — Enter to start") hosts the full status check
   inline: verdict, reasons, facts, commits-not-on-base, Claude's read, and the
   act-on-it buttons — with the Enter CTA kept as the hero. Worktrees **with**
   a live session keep access via the existing StatusSheet (menu items).
2. Claude's read renders as **markdown** (existing `Markdown` component), not a
   raw `<pre>` — in both hosts.

## Phases

### Phase 1: Research — COMPLETE
See findings.md. Key: extract a shared body from StatusSheet; both commands
already mocked; `.md` works standalone (`--md-z` defaults 1).

### Phase 2: Extract shared StatusBody — COMPLETE
- Pull the sheet's sections (verdict/reasons, facts rows, commits, Claude's
  read, act-on-it) into a module-scope `StatusBody` component in
  StatusSheet.tsx, props = report + declared read + callbacks (same seam the
  sheet already has: onEnter/onLifecycle/onRemove/onCopy/onReport).
- StatusSheet becomes a thin host: scrim + header + Re-check + StatusBody.
- data-testids move WITH the body (only one host visible at a time if we hide
  the menu item for session-less places — see decisions).

### Phase 3: Inline host in the term-empty area — COMPLETE
- App.tsx `.term-empty` branch: keep the card title + Enter button as hero,
  render StatusBody below it.
- `place_health` fetch keyed on (repo, slug): effect runs on selection change
  ONLY (not on every list_workspace sweep). Cache last report per place;
  stale-while-revalidate ("Checking…" only when nothing cached).
- "Ask Claude" stays strictly button-only (⚠ NEVER automatic — lib.rs guard
  comment). onReport reuses App's existing patchDeclared-then-refresh ordering
  (App.tsx ~5464 comment — order is load-bearing).
- Layout: give the panel a readable measure (~60ch column) centered in .main;
  don't fill the whole width.

### Phase 4: Menu wiring — COMPLETE (gate refined: hide only when check already on screen for that place)
- Live-session place: "Status check…" opens the sheet (unchanged).
- Session-less place: panel is already on screen — hide the menu item (or make
  it a no-op highlight). Decision recorded below.

### Phase 5: Markdown for Claude read — COMPLETE
- Replace `<pre className="update-log hs-read">` with a div hosting
  `<Markdown src={read.text} />` (no onLink → links inert-safe; lexer-only
  renderer, no injection surface).
- Container CSS: keep recessed box + max-height scroll; override `.md`'s own
  padding inside it. Plain-text cached reads still render fine (paragraphs).

### Phase 6: Gates + verification — COMPLETE except real-app sandbox run (owed before release)
- Full gate list from CLAUDE.md (release build FIRST, bats, lint, core/cli/app
  tests, tsc + cargo check).
- Mock hides timing (instant invokes): run `app/scripts/sandbox.sh --app` for
  real; selection→health fetch and patchDeclared ordering are exactly the
  class race-check.mjs covers — run `node app/scripts/race-check.mjs`.

## Decisions (CONFIRMED by David 2026-08-30)
| Decision | Choice | Why |
|----------|--------|-----|
| Sheet's fate | Keep for live-session places; shared StatusBody prevents drift | Sheet is right when terminal owns .main |
| Auto-run place_health on selection | Yes; Ask Claude stays strictly button-only (David: "button only") | Selection is the gesture; cost is git-only |
| Menu item on session-less places | HIDE "Status check…" (topbar + ctx menu) — David: "no sense in cluttering things up". Menu item only for live-session places | Panel already visible; no duplicate testids |
| Prompt change for markdown | None needed | Renderer handles plain text; old cached reads stay valid |
| Branch | `ui-status-inline` off origin/main c956724 (v0.19.0) | This tree's prefix is `ui-`, idle base `ui-next` |
| Execution | Workflow: opus implements from brief + gates; harness agent verifies in mock UI; review lenses + adversarial verify; opus fixes; fable reads final diff | David's cost split + ultracode |

## Errors Encountered
| Error | Attempt | Resolution |
|-------|---------|------------|
| (none yet) | | |
