# Findings — status check into main window

## Current implementation (v0.19.0, origin/main c956724)

### StatusSheet (app/src/StatusSheet.tsx, 402 lines)
- Right slide-over, ProjectSheet's twin. Renders `place_health` (real
  `cmd_status --json` in-process → `health::Report`) — verdict computed in
  core, sheet renders judgement it never makes (no drift by construction).
- Sections: verdict+blurb (`VERDICT` map), reasons, facts rows (Row grid),
  commits-not-on-base pre, Claude's read, act-on-it buttons.
- Claude's read: `<pre className="update-log hs-read">{read.text}</pre>` —
  **plain text render of markdown-shaped output. This is the legibility bug.**
- `read = fresh ?? declared?.status_report` — belt & braces: sheet-local state
  survives the place vanishing from a snapshot.
- Actions are props (onEnter/onLifecycle/onRemove/onCopy) — App owns flows.
- `ask()` → `ai_status_report` (30–90s, spawns claude headless, 180s deadline);
  ⚠ comment: NEVER automatic, button-only. `refresh()` (place_health) runs on
  open — local git only.

### App.tsx wiring
- `statusSheet` state (~2373), `openStatus` (~3689). Menu items: topbar popover
  (~5092, testid topbar-status) + nav ctx menu (~5651).
- StatusSheet render ~5433: `onReport` does **patchDeclared FIRST, refresh
  second** — comment says order is load-bearing (in-flight list_workspace sweep
  carries pre-write declared state; landing after resolve would blank a report
  being read). Inline host must reuse the same handler.
- Empty state ~5131: `selected.tmux_session.up ?` TerminalPane `:` `.term-empty`
  → `.term-empty-card` with "No live session for {slug}" + Enter button.
  Below both: `.statusbar` footer (tmux up/down). Home "briefing" is the
  no-selection branch — NOT touched by this work.

### Backend (app/src-tauri/src/lib.rs)
- `status_of` (~2112) shared by `place_health` (~2128) and `ai_status_report`
  (~2245). `status_prompt` (~2209): embeds report JSON verbatim; asks
  (1) what for, (2) end state, (3) resume/push-then-abandon/abandon; under 250
  words; bans running commands. Numbered answers ⇒ output is markdown-shaped
  (lists, bold) — unit test at ~5606 pins prompt clauses.
- `AiStatusReport { text, epoch, verdict }` cached under declared
  `status_report` (store.rs `extra` round-trips verbatim).

### Markdown renderer (app/src/markdown.tsx)
- `marked` lexer only, builds React nodes, no dangerouslySetInnerHTML — safe
  for AI output. `safeHref` guards schemes; omitting `onLink` makes links
  inert (preventDefault + no handler). Memoized.
- `.md` CSS (App.css ~1395): `--md-z: var(--md-zoom, 1)` — **works standalone**
  outside the dock's zoom context. Has own padding (--md-s4/s5/s6) → host
  container should override for a compact box. Currently only host:
  FilesPane.tsx:661.

### CSS
- `.update-log.hs-read` (App.css ~874): already un-does mono/micro/break-all
  for prose — half the legibility fix exists; markdown render supersedes it.
- `.hs-verdict/.hs-reason/.hs-row` etc. (~836–867) — reusable by inline host.
- `.term-empty` (~973): grid place-items center, card is minimal.

### Mock harness (app/src/mock/install.ts)
- `place_health` (case ~1216) and `ai_status_report` (~1240, writes
  declared.status_report ~1266) both mocked. Instant resolve — hides the
  selection→fetch timing; real-app run required before release (CLAUDE.md).

## Constraints / traps for the brief
- Components at module scope with props (inside-App() = remount every render).
- Effect for auto health fetch must key on repo+slug, not on the workspace
  object identity (refresh sweeps replace it every tick).
- Only one StatusBody host visible at a time or testids duplicate (Playwright).
- `isMain` hides destructive actions — logic travels with shared body.
- HMR dead in .worktrees/ — restart vite --force after edits; curl-diff served
  vs disk before debugging (CLAUDE.md).
- Version: workspace Cargo.toml still 0.18.0 on this branch; origin/main is
  v0.19.0 — branch off freshly fetched origin/main for the work.
