# Fix: flaky MCP heartbeat test on macOS CI

## The failure (verified)
CI run 36793011965 (PR #359, a `.gitignore`-only change), job `rust (macos-latest)`:
`mcp::tests::a_heartbeat_pulses_while_a_call_runs_and_never_after` panicked at
`crates/worktrees-cli/src/mcp.rs:3428` (`assert!(n >= 3, "{n} pulses in 60ms at 5ms")`).
A re-run passed. The test (added in #376, pi phase 3 follow-ups) runs `with_heartbeat`
(mcp.rs:~310) on REAL time: a 5ms heartbeat thread for a 60ms sleep, asserting ≥3 pulses, then a
30ms real sleep asserting no pulse after return. A loaded macOS runner starves the thread → flake.

## Task
1. Make the heartbeat testable on a VIRTUAL clock (AGENTS.md: `termresize-check.mjs` and
   `poll_until_looks_every_step_and_stops_at_the_deadline` already use injected/virtual time for
   exactly this reason — "on real timers a scheduler stall mid-drag fails it while blaming the
   component"). Inject the wait/clock into `with_heartbeat` (and `Pulse` if it shares the shape)
   the way `poll_until` takes its sleep, so the test drives ticks deterministically and asserts
   EXACT pulse counts, strictly growing numeric `progress`, the token, and zero pulses after the
   call returns (thread joined before the reply — keep that guarantee; production behaviour must
   not change).
2. Audit the sibling timing tests in mcp.rs for the same real-time shape and fix any that can flake
   the same way: `stdin_closing_stops_a_wait` (~3395, `< 5s` wall-clock), `a_long_tool_call_carries_
   the_heartbeat` (~3441), `wait_pulses_the_callers_token_and_stops_silently_on_cancel` (~3490),
   `poll_until_stops_at_the_step_after_a_cancel` (~3460). Generous upper bounds on "stopped early"
   are fine; lower bounds on how much work a thread did in N ms of real time are not.
3. Prove it: each changed test still FAILS when the behaviour it guards is broken (e.g. heartbeat
   thread not joined → a pulse after return; no token → pulses anyway) — show red-first. Then run
   the changed tests in a loop under load (e.g. `for i in $(seq 50); do cargo test -p worktrees-cli
   heartbeat …; done` while `yes > /dev/null` runs on every core, killed after) to show they are
   stable; report the counts.
4. No production behaviour change: the heartbeat cadence (PROGRESS_EVERY_MS), the join-before-reply
   order and cancel handling stay exactly as they are. Gates per AGENTS.md (grep-reported; release
   build first). Test-only change → no CHANGELOG entry needed unless production code changes shape
   (say so either way). Open a PR, watch CI with `gh run watch <id> --exit-status`, reply, STOP.

## Rules
Codex is out of tokens. Don't drive David's running app. Scratch in ~/.cache/worktrees/worktrees/<this
worktree>/. Keep Co-Authored-By; NO session URLs or Claude-Session trailers. Do not merge.
