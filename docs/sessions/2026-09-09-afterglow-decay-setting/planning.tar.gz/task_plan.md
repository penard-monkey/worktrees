# Task: Afterglow (purple dot) decay becomes a setting

## Goal
Turn the fixed 15m / 2h / 12h purple-dot decay into user-tunable settings so the
horizon can be longer and the step count can change. Default is too short today.

## Status
Done — PR #199 squash-merged as 074f1c6 on 2026-09-09. Follow-up: watch whether the 12h default still feels short; 24h is the next stop.

## Phases
| # | Phase | Status |
|---|-------|--------|
| 0 | Research current dot logic + settings surface | complete |
| 1 | Agree design (knobs, spacing rule, defaults, range) | complete |
| 2 | Implement: settings keys + SettingsSheet sliders + generalised doneTier + CSS from fixed classes to computed opacity | complete |
| 3 | Guard: slice-the-real-source check script for tier math (like zoom-check.mjs) | complete |
| 4 | Mock fixtures + manual check (docs/ai-profiles-manual-checks.md §10) + CHANGELOG | complete |
| 5 | Gates, PR | complete |

## Decisions
- Geometric spacing, first step pinned at 15m, horizon from a stop table (1h…7d), steps 2–6. Dot keeps meaning "Claude finished here" (workedAt). Defaults reproduce today (12h, 3 steps).

## Errors Encountered
| Error | Attempt | Resolution |
|-------|---------|------------|
