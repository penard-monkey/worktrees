# Progress

## 2026-09-08 session 1
- Researched purple-dot decay path (App.tsx doneTier, App.css .done tiers,
  workedAt source, rollup, tick). Recorded in findings.md.
- Sent David a design proposal (horizon slider + steps slider, geometric spacing).
  Awaiting decision before implementing.

## 2026-09-09 session 2
- David: "is this ready to merge?" — no, nothing built. Decisions: geometric spacing,
  keep the dot's current meaning (Claude finished). Branch
  `ui-tweaks-afterglow-decay` cut from fresh origin/main (v0.22.0, 1862d79).
- Launched opus implementation agent with the brief (settings keys, afterglow.ts
  module, App.tsx tier generalisation, CSS to computed opacity, Settings sliders,
  afterglow-check.mjs, docs/CHANGELOG). Fable reviews the diff next.
- Opus agent delivered; fable review found one cosmetic blocker (Settings labels
  not using the title/`sub` pattern), fixed inline. tsc + afterglow/zoom checks green.
- Committed b678d74, pushed, PR #199 opened. CI running. Not merged — David decides.
- CI green (9/9). David: "go ahead and merge" → squash-merged as 074f1c6 (gh's
  local checkout step printed the known false 'main is already used' error).
  Worktree parked on ui-next = origin/main; feature branch deleted.
