# Findings — afterglow dot decay

## Where it lives (2026-09-08)
- `app/src/App.tsx:229-240` — `DONE_T1_SECS=15m`, `DONE_T2_SECS=2h`, `DONE_T3_SECS=12h`,
  `doneTier(epoch, nowSec)` → "" | t1 | t2 | t3. Past 12h the dot is simply gone.
- `app/src/App.css:~479-483` — `.status-dot.done` purple (`--done`); `.t1` adds a
  3px 30% ring (box-shadow, never animated); `.t2` opacity .65; `.t3` opacity .3.
  Classes are FIXED — a variable step count needs computed opacity (inline style
  or a CSS var), not more classes.
- Source clock: `workedAt(p) = max(sessions:done event epoch, declared.last_worked_epoch)`
  (App.tsx:3229). Opens and commits do NOT feed the dot (commits feed `activityAt`
  = row age/sort only).
- Precedence: busy (green) > waiting (amber) > done (purple). `doneOf` returns ""
  whenever the session is live.
- Tick: `DECAY_TICK_MS = 60_000` (App.tsx:1801), gated on page visibility. Fine for
  any horizon ≥ minutes.
- Project rollup (folder icon, App.tsx:5364) lights "done" ONLY on t1 — "a session
  just finished". If t1's length becomes user-set, the rollup follows it.
- Hover title (`dotTitle`) already prints "Claude finished Xm ago" for any tier.
- `IDLE_WINDOW_SECS` (7d, store.rs + dnd.ts) is a DIFFERENT concept: lifecycle
  tier reconciliation active→idle. Do not conflate; do not touch.
- Settings: sliders already exist for term_size / ui_rem / nav_width in
  `SettingsSheet.tsx` (`<input type="range">` + `<label className="sub">` + `.val`).
  Settings keys + defaults in `app/src/settings.ts` (~line 216 / 292).
- Coverage: none automated for the afterglow (ROADMAP.md:440 records it as
  by-necessity). Manual: `docs/ai-profiles-manual-checks.md` §10. Mock fixtures
  reference tiers: `app/src/mock/fixtures.ts`.
- Design rationale in the App.tsx comment: DISCRETE steps on purpose — absolute
  opacity is unreadable, a 12h CSS animation freezes under reduced-motion, steps
  are assertable with getComputedStyle. Keep that property with any slider.
