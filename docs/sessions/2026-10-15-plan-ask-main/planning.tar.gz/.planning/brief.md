# Plan tab: "Ask main to update" button

David wants a button in the dock's Plan tab that asks the orchestrator, `(main)`'s Claude, to update the plans.

## What exists

- `app/src/PlanPane.tsx` has a **Generate plan** button in the empty state.
- It calls the `plan_prompt` command (`app/src-tauri/src/lib.rs` ~5651). That command pastes the fixed `ops::PLAN_PROMPT` into the PLACE's own AI pane with `tmux::paste_to_ai`.
- The paste carries no trailing newline, so nothing is sent until the user presses Enter. Read the doc comments there: the app writes no plan, and only fixed text reaches a pane.
- Tests in `ops.rs` pin that prompt: no path, no newline.

## The new ask

A button on the Plan tab, shown when a plan or brief exists and maybe in the empty state too. It puts a prompt into **(main)'s** session asking the orchestrator to update this place's plan. That is the plan or brief main wrote and steers.

## Phase A: proposal first (≤1 page, then stop and wait)

Write `~/.cache/worktrees/worktrees/plan-ask-main/proposal.md`. Message the orchestrator (`worktrees-(main)`) with a short summary, then WAIT for an OK.

The proposal must answer:

1. **Prompt text.**
   - A fixed constant plus the place's slug. The slug comes from our own data, never from the frontend's free text.
   - What does main do with it: re-read the place's progress, then update `.planning/brief.md`, task_plan.md or both?
   - Read the global orchestrator pattern in `(main)`'s AGENTS.md / CLAUDE.md to keep it consistent with how main runs lanes.
2. **Paste vs send.**
   - The Generate pattern pastes and the user presses Enter. But here the user is looking at the PLACE, not main, so they may never see main's composer.
   - Options:
     - paste, then switch focus to (main);
     - send through the MCP message log (`report` to main);
     - send-keys with Enter, but only after a composer-empty check.
   - Recommend one.
   - Note the hazard: a paste glues onto David's half-typed input in main's composer.
3. **Finding (main)'s session.** It may be adopted, may be absent, or may not be Claude. Give an honest error for each case.
4. **Button placement and label.** It sits next to the dock header's open button or in the plan band. Note the tooltip wording.
5. **Gaps.**
   - What a `(main)` place itself shows: hide the button there.
   - Which other projects' mains it applies to.

## Phase B (after OK): build it

- Frontend + command + mock harness entry (`app/src/mock/install.ts` must track every command).
- A unit test pinning the prompt like the existing PLAN_PROMPT tests.
- Add a CHANGELOG `### Added` item under the existing [Unreleased] header. Don't add a second header.
- One PR, squash-merged after the orchestrator's review.

## Rules

- Use worktrees places, never `git worktree add`.
- `tmux -L <name>` on every throwaway tmux call; never a bare `tmux kill-server`.
- Never drive David's running app. Use the mock harness (not port 1420). The sandbox is by pid only, with no scripted input.
- Run heavy gates through `/Users/davidpena/workspace/worktrees/target/release/worktrees run --slot gate -- <cmd>`, one at a time, and don't fan out sub-agents.
- Commits keep Co-Authored-By. No session URLs or Claude-Session trailers.
- Gates: see AGENTS.md "Gates". Build the release CLI first.
