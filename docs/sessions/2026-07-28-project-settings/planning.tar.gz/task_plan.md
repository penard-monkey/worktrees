# Task Plan — per-project settings ("stack projects")

## Goal

Decide how `worktrees` absorbs per-project setup — secret-file sync, port
isolation, docker-compose namespacing — so the Casa del Valle monorepo stops
running two worktree tools. Output of THIS session: a decision-ready design,
not code.

Source proposal: `docs/proposals/project-settings.md` (written from the
consumer side, in a different session).
Consumer repo: `/Users/davidpena/workspace/casadelvalle/casa-del-valle-monorepo`

## Phases

| # | Phase | Status |
|---|-------|--------|
| 1 | Read proposal + locate consumer repo | complete |
| 2 | Parallel audits (4 agents): cdv stack tooling, core seams, app surface, format/security | complete |
| 3 | Synthesize findings → answer the proposal's 5 open questions | complete |
| 4 | Present design + phasing to user; get decisions | complete |
| 5 | Write revised proposal | complete |
| 6 | Commit the proposal; add ROADMAP entry | complete (`15179b1`) |
| 7 | **v1-S1** foundation: `toml` dep, `diag.rs`, `projcfg.rs`, `config.toml` | complete (`5fe3e9b`, fixes `ebb2ebe`) |
| 8 | **v1-S2** files: `materialize.rs`, `relink`, `doctor`, ensure_excluded, CaptureUi severity | complete (`92c85ce`, fixes `3c7fe9b`) |
| 9 | **v1-S3** ports + compose: slot lock, `.worktree.env`, `provision`, teardown | complete (`159b219`, fixes `0bf0732`) |
| 10 | **v2-S4** `worktrees init` — detection + suggestion flow (CLI) | complete (`d233a1d`, fixes `b5ac445`) |
| 11 | **v2-S5** app surface: ProjectSheet, drift glyph, Relink button, init banner | complete (`aad6fb6`) |
| 12 | **v3** `[project] prefix` + session adoption | complete (`8f2f103`) |
| 13 | Review fixes across all slices (2 reviews + cdv dry-run) | complete (`fa59ece`) |
| 14 | GUI adopted-close + name-binding + sticky errors | complete (`adc3269`, `a4efa03`, `dcfc2f1`) |
| 15 | **v0.3.2 release** | complete — merged `df9d7e2`, tagged, published |
| 16 | Project-settings PR | **complete — PR #58 squash-merged as `eb32f7f`** |
| 17 | **cdv migration** — runbook written, step 0 blocked on David | pending |
| 18 | Close-out: delete `next-stream` remote branch, archive session | pending |

## cdv migration — state

Dry-run complete, READ-ONLY, repo verified unmodified. Artifacts in
`~/.cache/worktrees/worktrees/everything-settings/dryrun/`:
- `cdv.worktrees.toml` — transcribed from `scripts/worktrees.sh` on cdv `main`
  @ `03a0a787`. **Do NOT use `worktrees init` for cdv** — it suggests `link` for
  `apps/backoffice/.env.local` (must be `copy`) and names ports after compose
  services (`POSTGRES`/`LOCALSTACK`) rather than the `PG`/`LS`/`WEBSITE`/
  `META_MOCK` the repo consumes.
- `RUNBOOK.md` — 8 steps, each with rollback.

Key findings: all 17 worktrees already correctly linked (relink is a no-op);
11 of 15 lack `WEBSITE_PORT` and bind main's 3002; 2 have no `.worktree.env` at
all (the §1.1 `pkill -9` hazard). Decided: leave the 4 out-of-tree worktrees
under `.dmux/` alone; re-fetch `google-services.json` from Firebase to be safe.

## Build conventions for phases 7-12

- Spec is `docs/proposals/project-settings.md` — **the** source of truth. Section
  refs below point into it.
- Gates before every PR (CLAUDE.md order — release build FIRST):
  ```sh
  cargo build --release -p worktrees-cli
  make test && make lint
  cargo test -p worktrees-core
  cd app && ./node_modules/.bin/tsc --noEmit && cargo check -p app
  ```
- One squash-merged PR per slice. Opus agents implement from a detailed brief and
  run the gates; fable reviews the diff before each merge.
- Working branch: `next-stream` (off `e06accb` = main tip).

## Slice boundaries (why these cuts)

S1 is pure — no wiring, no behavior change, so a repo with no `.worktrees.toml`
provably still behaves identically. S2 wires files only. S3 adds ports, which is
the destructive-if-half-done part (proposal §1.1) and wants its own review.

⚠ v0.3.2 was decided to cut BEFORE this work. It hasn't been cut. The release
comes off `main` so it doesn't block this branch — but it's still owed.

## Phase 2 — audit assignments

- **A. cdv-stack** — reverse-engineer the real behavioral contract from
  `scripts/worktrees.sh`, `docker-compose.worktree.yml`, env-sync tooling.
- **B. core-seams** — where in worktrees-core a project config loads and where
  link/copy/port/compose apply; plan→apply seam; test harness impact.
- **C. app-surface** — Tauri command list, settings sheet, place rows, mock
  harness parity cost for a project-settings pane.
- **D. format+security** — TOML vs existing kv parser, path-escape rules,
  trust model, declared-vs-derived split for port slots.

## Key constraints (from CLAUDE.md)

- One engine: `worktrees-core`; app links it in-process, no subprocess.
- Commands must be `async fn` in the Tauri layer.
- git/tmux shelled out on purpose (bats fake-shim harness).
- Declared state = `.worktrees.places.json`; derived = live git/tmux.
- Config today is "parsed as data, never executed" (config.rs docstring).
- Mock harness must track every command in lib.rs.

## Decisions log (David, 2026-07-27)

1. **Ports in v1** — and the design must be **generic**, not cdv-shaped. Each
   section stands alone: `[[file]]` works with no `[ports]`; `[ports]` works with
   no docker. cdv is the first consumer, not the spec.
2. **No repo-supplied argv, ever.** `[hooks]` never ships; `DESIGN.md:225-228`'s
   `[infra] up/stop/down` is reversed (locked-doc reversal, signed off). Escape
   hatch is a user-scoped `post_create` in `~/.config/worktrees/config.toml`.
   The tool assembles the compose argv itself from `[compose]` data.
3. **TOML for both human-authored files** — `.worktrees.toml` + a new
   `~/.config/worktrees/config.toml`, keeping the kv parser as a permanent silent
   fallback. Net two formats: machine-JSON vs human-TOML.
4. **Sequencing: cut v0.3.2 first**, then build this.

Deferred out of v1 by these decisions: `[project] prefix` (session-orphaning),
`init` + app surface (v2).

## Errors Encountered

| Error | Attempt | Resolution |
|-------|---------|------------|
| — | — | — |
