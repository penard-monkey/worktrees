# Findings — per-project settings ("stack projects")

Four parallel opus audits, 2026-07-27. Sources: A = cdv monorepo, B = worktrees-core
seams, C = app surface, D = format/security/state design.

---

## 0. Headline — the proposal understates the urgency

The proposal treats ports as "v2, the fiddly bit." **It is not deferrable.**

A found the fork is already live and actively destructive on this machine:

- 18 dirs under `casa-del-valle-monorepo/.worktrees/`; 16 have `.worktree.env`.
- `claude-work-integration` and `prod-reviews` have **none** — created by the Rust
  tool, invisible to slot accounting.
- `deploy-local.sh:283-301` branches on `WORKTREE_MODE` (= presence of
  `.worktree.env`). The `false` branch runs a **global `pkill -9`** over
  `next-server`, `tsx.*watch`, `next dev`, `wo-mock-server`, then force-frees :3000.

So running `deploy-local.sh` in a Rust-tool-created worktree **kills the main
checkout's entire running stack**, then fights it for :3000/:5432/:4566.

⇒ A half-provisioned worktree is worse than no worktree. Either ports ship with
v1, or `worktrees new` must **refuse** in a stack repo it can't fully provision.

---

## 1. Corrections to the proposal's facts (agent A, verified against source)

| Proposal said | Truth |
|---|---|
| `relink` exists | Only on branch `feat/mobile-v1-mensajes` (commit `5a22db33`), checked out at `.worktrees/general-fixes`. **`main` has no `relink`.** |
| link list incl. Firebase files | Only on that branch. `main`'s `STACK_ENV_LINKS` is 5 entries, no Firebase. |
| 5 ports (`BACKOFFICE/API/WS/WO_MOCK/PG`) | **7**: `BACKOFFICE 3000, API 3001, WEBSITE 3002, WO_MOCK 3010, META_MOCK 3011, PG 5432, LS 4566`. Missing `WEBSITE` + `META_MOCK` → those two collide with main on first run. |
| slot from sibling `.worktree.env` | Union of **two** sources: declared (`grep WORKTREE_SLOT .worktrees/*/.worktree.env`) **or** observed (`lsof` on all 7 ports). Both must pass. `k ∈ 1..50`, main is implicitly slot 0. Currently 1–15 assigned, contiguous. |
| `max_slots = 50` | Correct (`seq 1 50`). |
| compose `{prefix}-wt-{slug}` | Correct → `cdv-wt-<slug>`, from `.worktree-prefix` = `cdv`. |
| "the monorepo runs two tools" | Confirmed on disk, and the docs already lie about it: `CLAUDE.md` + `docs/PUSH-NOTIFICATIONS.md` say `worktrees relink --all`, but `which worktrees` → the **Rust binary**, which has no `relink`. Only `./scripts/worktrees.sh relink --all` works. |

Where the list lives: **a hardcoded bash array**, `worktrees.sh:77-81`. No config
file. The copy target (`apps/backoffice/.env.local`) isn't even in the array —
it's a separate hardcoded `cp`.

### `.worktree.env` is a public wire format, not an internal artifact

`deploy-local.sh:54-57` does `set -a; . .worktree.env; set +a` — **every line is
sourced as shell**. Consumers: the compose override (`PG_PORT`/`LS_PORT`),
`mocks/wo-mock-server.ts:22`, `mocks/meta-mock-server.ts:24`, and `worktrees.sh`
`ls`/`rm`. `deploy-local.sh` then derives ~15 further values (DATABASE_URL, 4 SQS
queue URLs, CORS_ORIGIN, AUTH_URL, …). Also: `WATCHPACK_POLLING=true` is keyed off
the mere **presence of `WORKTREE_SLOT`** (`:758`) — drop that var as "internal
state" and every stack regains the EMFILE→all-routes-404 bug they already debugged.

### Docker concurrency today

`docker-compose.worktree.yml` is 25 lines and does **only** host-port remapping on
`postgres` + `localstack`, via `ports: !override`. Namespacing (volumes, network,
containers) comes entirely from `-p $COMPOSE_PROJECT_NAME`, which comes from
`.worktree.env`. It works because `deploy-local.sh:362` only ever containerizes
those two services — api/backoffice/website/mocks run natively on `.worktree.env`
ports. Step off that path (`pnpm docker:up` → no `-p`, no override file) and all
five services land on base ports.

### Other env-sync tooling (the thing you mentioned)

**No vault.** No 1Password/sops/age/gpg/git-crypt/dotenv-vault. Five mechanisms:

1. **`scripts/sync-macs.sh` (325 lines)** — the big one, and it's undocumented
   (referenced by nothing in the repo). rsync mirror of the whole working set
   between two Macs over an external SSD. Carries `.git/`, `.worktrees/**`,
   `.env*`, keystores. Both machines keep the **identical absolute path** so git
   worktree absolute paths stay valid. Opt-in `--with-sessions` ferries Claude
   transcripts. Manual `push`/`pull`/`status`.
2. `worktrees.sh` link/copy — the actual env-sync-between-checkouts mechanism.
3. `_tmp` → iCloud symlink (committed symlink, ignored contents).
4. AWS Secrets Manager / Vercel — authoritative for **deployed** envs only, never
   written into a local `.env`.
5. `scripts/sync-docs.sh` — build-time doc copy, not secrets.

Flagged: `.env.vercel.dev` at repo root holds a live `VERCEL_OIDC_TOKEN` JWT, is
read by nothing, and rides the SSD unencrypted.

**Implication:** `sync-macs.sh` is out of scope for this feature but it is the
reason absolute symlinks (not relative) are load-bearing. Don't "improve" the link
to be relative.

---

## 2. Core seams (agent B) — the feature was designed for, not bolted on

- **Insert materialize at `ops.rs:282`** — after the git create block closes
  (`:281`), before `detect_install_cmd` (`:283`) and therefore before `launch`
  (`:300`). Mandatory: pane 1 runs the install command; `pnpm install` racing
  `.env` appearing is exactly the silent-failure class.
- **Insert teardown at `ops.rs:628`** — after the confirm block, before
  `tmux::kill_session`. Anything after `:633` is too late (dir gone).
- **`Project` should NOT hold the config.** `discover()` is the hot path (CLI
  invocation *and* every 3s app poll), already 4 subprocesses. Load on demand.
- **Creation is deliberately non-transactional** (`ops.rs:297-300`: "a failed
  session is a partial success the user MUST see"). Materialize adds a 4th
  half-success with no rollback ⇒ **`doctor` must ship in v1, not v4**, or the new
  failure mode is itself silent.
- **`Place.stack: Option<Value>` (`model.rs:41-42`) is already reserved** for "the
  infra phase (P3)", always `None` today. `DESIGN.md:126-133` sketches its JSON
  shape; `DESIGN.md:280` already made the hot-path ruling ("status off the hot
  path"). Filling it needs **no schema bump, no frontend break**.
- **`store.rs` extension is free**: `#[serde(flatten)] extra` on both structs means
  adding a field needs zero migration. But see §4 — don't put the slot there.
- **Error model gap**: `CaptureUi` (`ui.rs:58-84`) flattens info/warn/error into
  one `Vec<String>` — **severity is erased at capture**. `errored: bool` is set and
  never read. A `doctor` whose warnings the app drops doesn't solve the problem.
  Needs a new `diag.rs` with `Finding { severity, code, place, path, message }` —
  not a widened `WtError`.
- **CLI is trivial**: flat `match` in `main.rs:63-85`, no clap. 3 arms + 3 usage
  lines. `ls --json` (`model.rs`, `schema_version: u32`) is the template for
  `doctor --json`.
- **Test harness is friendlier than expected**: git and the FS are **real** in
  bats; only tmux is faked. So `[ -L path ]` / `readlink` / `grep .worktree.env`
  assertions work directly. `test/close.bats:172-183` (cp store aside, run, diff)
  is the exact model for proving read-only-ness. `tmux.rs:181-252` is the template
  for the pure plan→apply split.
  ⚠ Do symlinks via `std::os::unix::fs::symlink`, **not** by shelling to `ln` —
  `install_no_tmux_path` uses a PATH whitelist that would break.

### New risk B found, not in the proposal

`.worktree.env` is untracked ⇒ `git status --porcelain` reports it `??` ⇒
`wt_dirty` is true forever ⇒ `switch` **and** `rm` refuse without `--force`, and
**the GUI never passes `--force` to switch** (`lib.rs:386`) → the app becomes stuck
with no remedy. One-line fix in `ensure_excluded` (`project.rs:390`), but it must
land in the same change.

---

## 3. App surface (agent C)

- **There is no project-level surface today.** `sel` is `{repo, slug}`
  (`App.tsx:418`); the main pane is binary (place | briefing). `SettingsSheet`
  takes no repo prop. Clicking a project header only toggles collapse.
  ⇒ **Ship a `ProjectSheet` (SettingsSheet's twin), not a pane.** One new state,
  zero disruption to the selection model, reuses `.scrim`/`.settings-sheet`/
  `.ver-rows`/`.ver-actions`/`.update-log` wholesale. A real project pane means
  touching ~30 `sel?.repo` sites + 3 subtle effects — only worth it if the project
  view must host a terminal.
- **Do not use a dot for drift.** `.status-dot.waiting` is already amber `--warn`
  (Claude-needs-input, the app's highest-value signal). Use a `⚠` glyph in the
  existing `.glyphs` cluster — `glyphs()` (`App.tsx:89-98`) already has MAX=4 +
  `+N` overflow. **~3 lines total**, the cheapest item in the proposal.
- **Do not put doctor on the 3s poll.** `places:changed` triggers a full
  `list_workspace` = up to 16 concurrent git calls per project × 4 projects
  (`lib.rs:194-212`). `DESIGN.md:280` already ruled on this. Run `doctor`
  on-demand, hold as `Record<root, Set<slug>>` next to `busyPaths`/`waitingPaths`
  — the house pattern for row decoration outside the snapshot.
- **`run_op` (`lib.rs:322-335`) does discover + capture + applog + `CmdResult` in
  13 lines** ⇒ the `relink` handler is ~6 lines.
- **`doctor` must return a typed report, not `CmdResult`** — badges need structure.
- **Template for the Relink button: `SettingsSheet.tsx:347-396`** (the CLI-update
  block), including its already-solved hazard — it re-fetches state in `finally`
  *before* re-enabling the button, because "a stale-enabled button in the re-check
  window would re-run the whole installer on a click." Applies verbatim.
- **No Playwright specs exist.** No `@playwright/test`, no `e2e/`, no `*.spec.*`.
  Every reference is prose describing ad-hoc Playwright MCP driving `pnpm
  dev:mock`. So: nothing to keep green, but **no regression net either**. Budget
  manual verification.
- **Mock harness silently returns `null`** for unknown commands
  (`install.ts:286-289`) → a typed `invoke<DoctorReport>` yields `null` and you get
  a blank pane + an unread console warning. New UI must tolerate it.
- **Per-project keys in app-global `ui-state.json` already exist twice**
  (`collapsed`, `manual_order`, both keyed by project root) ⇒ precedent for
  `init_dismissed: Record<root, hash>`. Hash-keyed beats boolean: a repo that
  later gains a credential file has a genuinely new suggestion.
  ⚠ But `onReset` (`App.tsx:742-747`) would resurrect every dismissed banner, and
  the CLI's own once-only hint is a **second, independent** dismissal store.
- ⚠ `PlaceRow` is defined **inside** `App()` (`App.tsx:1002`), against CLAUDE.md's
  own rule. Safe today (no local state/focus); hoist before adding a tooltip.
- ⚠ macOS case-insensitivity: don't name it `Project.tsx` (would collide with a
  future `project.ts`, as `Settings.tsx` did with `settings.ts`).

---

## 4. Format / security / state (agent D)

### Format → TOML, and it makes the format count go **down**

`toml 1.1.3` is **already in `Cargo.lock:4191`** as a runtime dep of `tauri-utils`
+ `tauri-plugin-fs` — already compiled into the shipped app today. Marginal cost is
6 crates for the **CLI only** (`toml`, `toml_parser`, `toml_writer`,
`toml_datetime`, `serde_spanned`, `winnow`); `indexmap` is already there.
`basic-toml` is a maintenance-mode toml-0.5 fork with no line/column in errors —
and `serde_spanned` line numbers are exactly what you want to say
`.worktrees.toml:14: absolute path not allowed`.

Also: **`DESIGN.md` risk #3 is dead** — it worried a bash awk TOML reader would
disagree with the Rust `toml` crate. There is no bash engine anymore.

The "third format" objection dissolves if you split on **who writes the file**
rather than user-vs-project:

| File | Author | Format |
|---|---|---|
| `.worktrees.toml` | human, committed, PR-reviewed | TOML |
| `~/.config/worktrees/config.toml` | human, per-machine | TOML |
| `.worktrees.places.json` | machine only, gitignored | JSON |

Teach `config.rs` to read `config.toml` in the same PR, keep the 25-line kv
`cfg_get` as a permanent silent fallback → net **two** formats.

Extending `cfg_get` is a hard no on security grounds: it's a last-match-wins line
scanner whose failure mode is **silent omission**. A mistyped `[link]` heading
drops entries wordlessly. The motivating bug here is *"the failure is silent."*

Use `features = ["parse","serde"]` only — **hand-template the `init` output as a
string**, because that file's whole job is its explanatory comments and no serde
serializer emits those.

### Path-escape validation — layered, with the boundary made **structural**

**Layer A, literal string (parse time, reject whole config):** non-empty, no NUL,
≤1024B, ≤256 entries; no leading `/`; no leading `~` (no expansion happens, so it'd
silently become a literal dirname); no `$` anywhere; split on `/` and reject empty
/ `.` / `..` components; **reject any component == `.git` case-insensitively**;
reject `.worktrees` first component and self-reference; **reject case-only
duplicates** (one file on macOS, two in Linux CI); reject same path in both modes;
**apply the same rules to `[ports] file` and `[compose] file`** — `[ports] file` is
written *into* the worktree, so `file = "../../.ssh/authorized_keys"` is the same
attack in write form (the proposal misses this).

`.git` is the highest-value target and containment **cannot** catch it —
`.git/hooks/pre-commit` *is* inside the repo, and linking it is code execution on
the victim's next commit. Must be a name rule.

⚠ Windows is a hard non-goal (4 CLI targets: darwin×2, linux-gnu×2) ⇒ `\` is an
**ordinary filename byte**. Do not treat it as a separator or you make a
legitimately-named file unlinkable.

**Layer B, resolved path (apply time — the actual security boundary):**
- B1 `canonicalize(main/<rel>.parent())` must be inside `main` → catches a
  **symlinked ancestor**.
- B3 if the source is itself a symlink, its `canonicalize` must be inside `main` →
  **git can commit a symlink**, so a hostile repo ships
  `apps/mobile/google-services.json` as a committed symlink to `~/.ssh/id_rsa` and
  every string rule passes. Cost: a legit `main/.env → ~/secrets/prod.env` stops
  working. Accept + document in v1.
- B4 followed metadata must be a regular file (a FIFO source hangs `copy` forever).
- B6 never blind `create_dir_all` — walk components, hard-error on a symlinked
  ancestor you didn't make.
- B7 destination branch: absent→create; symlink to expected src→no-op (this is what
  makes `relink` idempotent); symlink elsewhere→replace+log; **regular file →
  shadowing, do NOT overwrite, report, require `--force`**; directory→hard error.
  Zero recursive deletes anywhere in this module.
- **B8, the check the proposal misses and arguably the highest-value one:**
  `git -C <wt> check-ignore -q <rel>`. Not ignored ⇒ **error**: *"declared link is
  not gitignored — `git add -A` here would commit it."* Containment stops the
  hostile repo; this stops the far more likely **accident**.

**TOCTOU:** the adversary is the repo contents, not a racing local process (anyone
who can win that race already has your uid). So: validate and act on the **same
resolved `PathBuf`**, never re-derive from the string; `File::open` then fstat for
copies; `symlink(src, tmp)` + `rename(tmp, dst)` (atomic, never follows `dst`) —
reuse `store.rs::write_atomic`'s pattern.

**Make it unbypassable structurally, not procedurally:**
```rust
pub struct RelPath(String);       // private field
impl RelPath { pub fn parse(s:&str) -> Result<RelPath, CfgError> }  // ONLY ctor, Layer A
pub struct PlannedOp { src: PathBuf, dst: PathBuf, mode: Mode }     // private fields
pub fn resolve(&Project, &Path, &RelPath) -> Result<PlannedOp, CfgError>  // ONLY ctor, Layer B
pub fn apply(op: PlannedOp) -> Result<Outcome, io::Error>  // syscalls only, ZERO string work
```
`ProjectConfig`'s list is `Vec<RelPath>` via a custom `Deserialize` calling
`parse` ⇒ **a `ProjectConfig` holding an invalid path is unconstructible**. `new`,
`relink`, `doctor --fix`, and the app's button are all type-forced through
`parse → resolve → apply`. There is no `link_file(&str)` to find and misuse.

### Hooks → don't ship them. Ever.

The "we already run `ai_cmd`" argument proves the opposite, because provenance is
the whole thing:

| Channel | Who writes the string |
|---|---|
| `ai_cmd` → `sh -ic` (`ops.rs:52`) | flag / `$WORKTREES_AI_CMD` / user config — **a cloned repo cannot set it** |
| `install_cmd` (`ops.rs:303-316`) | one of **4 literal constants** picked by lockfile detection — repo picks *which of my commands*, not *what* |
| `[hooks] post_create` | **the cloned repo's committed file, verbatim** |

That's a categorical change from *"the repo selects among my commands"* to *"the
repo writes my command."* Today, **nothing a cloned repository contains can cause
execution** — every subprocess in core is literal argv. That's a README sentence
worth keeping.

direnv's model also transfers badly here: direnv prompts on `cd` into a repo you
already work in; this tool's hot path is `worktrees new` **on a fresh clone** — the
moment of least knowledge. And the GUI would fire a security modal from a
background poll, which is the definition of a dialog people click through. The
proposal's own "CI defaults to untrusted" is a tell that the shape is wrong.

**Replacement, ~20 lines, zero new surface:** a **user-scoped** hook in
`~/.config/worktrees/config.toml` (`post_create = "./scripts/dev-setup.sh"`).
Identical execution power, user provenance, no hash file, no modal, no CI question.
The repo still ships the script; each dev opts in once per machine.

A confirms this empirically: the only behavior in the whole bash script not
expressible as link/copy/ports/compose is `docker compose -p … down -v` at removal
— better as a first-class `[compose]` teardown (the tool already knows the project
name and file list) than as an arbitrary string. `pnpm install` is already covered
by lockfile detection.

⚠ **Corollary needing your sign-off:** `DESIGN.md:225-228` puts
`infra.up = "./scripts/deploy-local.sh"` in the committed `.worktrees.toml`, gated
by a first-run trust prompt (`DESIGN.md:343,399`). Same category. Dropping it is a
deliberate reversal of a doc marked "design locked (2026-07-20)". Nothing is built,
so it's cheap — but it's your call. Replacement: the project declares `[compose]`
(files + name template + port map), and the **tool assembles**
`docker compose -f <validated> -p <sanitized> up -d` itself. Argv built by the tool
from validated data, never a string from the repo. Bonus: no trust prompt at all.

### Port slots → derive from `.worktree.env`. B and D converged independently.

Not `.worktrees.places.json`, because:
- The store's contract (`DESIGN.md:158-176`) is **sticky user intent that survives
  the worktree being gone**. A slot is meaningless without the worktree.
- `DESIGN.md:176` says "any derived field found here is ignored" — a slot there
  would be a derived field you *couldn't* ignore. Contradiction.
- The store is gitignored and safely-losable by design. Losing a lifecycle label is
  annoying; losing a port assignment orphans a running docker stack under a stale
  project name.
- **`remove_one` never calls `store::edit`** (verified: `store::` appears nowhere
  outside `store.rs` in `crates/`) ⇒ a stored slot leaks on every `rm`, and
  `max_slots=50` becomes a silent exhaustion bug months later.
- With derivation there is **no release step at all** — `rm` deletes the dir,
  `.worktree.env` goes with it, next scan sees the hole.

**Algorithm:** `mkdir(2)` O_EXCL lock at `<main_root>/.worktrees.slots.lock` with
PID written inside → scan siblings **inside** the lock → if this place already has
a unique slot, return it unchanged (idempotent) → else lowest free k not in the
declared set and whose ports all bind → write `.worktree.env` atomically → unlock.
`git worktree add` happens **outside** the lock; scan+write inside.

**Probe by `TcpListener::bind`, not `lsof`** — kills the `lsof` dependency
(`DESIGN.md:276`), ~100× faster, identical on both targets, no docker-proxy false
negatives.

**Conflict policy:** two places claiming k ⇒ **refuse, never silently
re-allocate** (rewriting a slot under a running stack orphans containers and moves
ports the dev has bookmarked). `doctor` errors; a conflicted k counts as **used**
so conflicts never compound. Hand-edited `.worktree.env` ⇒ **the user always
wins**; never rewrite `WORKTREE_SLOT` without `--reallocate`.

**Free parse-time lint** (catches `DESIGN.md` risk #4 statically): with a shared
stride, services i and j collide iff `(b_i − b_j) % stride == 0` and
`|b_i − b_j| <= stride * max_slots`. Plus all bases distinct and
`max(base) + stride*max_slots < 65536`.

⚠ D flags `store.rs:104-113` uses **wall-clock (15s mtime) staleness**,
contradicting `DESIGN.md:205` which mandates PID-liveness. False-positives across
laptop sleep. Fix there, or at minimum don't copy it into the slot lock.

⚠ D recommends **dropping `[ports] file` as a key** (fix it at `.worktree.env`):
the sibling scan hard-depends on every place using the same filename, so changing
it after worktrees exist makes old places invisible and double-allocates slots. No
consumer needs it configurable.

### Precedence

```
flag > env (WORKTREES_*) > .worktrees.toml > ~/.config/worktrees/config[.toml] > default
```
…but the project rung **exists only for allow-listed keys**. Governing principle:
**a project declares structure; a user declares behavior. Anything that becomes
argv, or names a program, is user-only, permanently.**

- Project MAY set: `[[file]] path/mode`, `[ports] *`, `[compose] file`,
  `[compose] project` (template with a **closed** placeholder set `{prefix}`/
  `{slug}`, pushed through `sanitize_prefix` before it reaches `docker -p`),
  `[project] prefix`.
- `prefix` is safe because (i) `sanitize_prefix` (`config.rs:10-21`) reduces it to
  `[a-z0-9_-]`, and (ii) **the project already sets it today** via the committed
  `.worktree-prefix`. Order: `$WORKTREES_PREFIX > .worktree-prefix >
  [project] prefix > user config > basename`. Legacy file first keeps migration
  non-breaking; `doctor` warns when both exist and disagree.
- Project may NEVER set: `ai_cmd`, `ai_resume_arg`, any install-cmd override,
  `post_create`, `[infra] up/stop/down`. **All argv.**
- A user-only key in `.worktrees.toml` is a **hard parse error** with a pointing
  message — not a silent ignore (silent ignore trains people to write it, and
  someone eventually "fixes" the ignore).
- Unknown keys: warn once, ignore (forward-compat, same discipline as
  `#[serde(flatten)] extra`).
- Add `WORKTREES_NO_PROJECT_CONFIG=1` — the "auditing an untrusted clone" switch.

⚠ B's counterweight on prefix: `session_name` is the tmux identity, reconstructed
independently at `ops.rs:31`, `ops.rs:521`, `ops.rs:607`, `project.rs:195`. Merely
*adding* a `.worktrees.toml` with a prefix to a repo with live sessions renames
them all; `close_one:521` would report "nothing to close" for a live session.
⇒ Slot it strictly after `.worktree-prefix`, and consider deferring out of v1.

### `copy` — keep it, but reshape and define drift

Keep, because the alternative ("link it and fix the script") means changing the
**consumer's** code — exactly the coupling this tool exists to remove. And without
it the failure is destructive in the worst direction: the script rewrites *through*
the symlink and corrupts main's real `.env.local` **for every worktree at once**.

Reshape to **one list with a per-entry mode** (`[[file]] path / mode`, as
`DESIGN.md:257-263` already has it) rather than parallel `[link]`/`[copy]` tables:
separate tables make "same path in both" a reachable state you then have to reject,
`doctor` output is cleaner over one list, and each entry carries its own
`# why this is a copy` comment — the file's whole teaching job.

**Drift policy: a copy is a seed, not a mirror.**

| State | Condition | Severity |
|---|---|---|
| missing | dest absent, or dest is a symlink (wrong mode, older config) | **error** |
| pristine | `hash(dest) == hash(src)` | ok |
| drifted | differs **and** `mtime(dest) >= mtime(src)` | **info**, never affects exit code |
| stale | differs **and** `mtime(src) > mtime(dest)` | **warn**; non-zero only under `--strict` |

The mtime comparison converts the unanswerable *"is this drift OK?"* into the
answerable *"is this drift older than the source?"* — precisely the motivating bug.
Hash is checked first so a `git checkout` that only touches mtime can't false-flag.
`relink` without `--force` never touches an existing regular file; with `--force`
it writes a `.bak` first.

**Exit codes:** `0` clean, `1` usage/guard (the tool's existing convention),
**`2` findings present**. The proposal's "exit non-zero" collides with `1`.

**`doctor` in CI:** yes, but a *different* check — declared sources are gitignored
so they're **absent in CI**. What you can check on a bare clone with pure git:
(1) every declared path is gitignored, (2) no declared path is tracked. Ship as
`doctor --config-only`.

---

## 5. The three things a naive port gets wrong (agent A)

1. **`ln -sfn` silently destroys a real file at the destination.** Verified
   empirically: a worktree-local file with edits is replaced, exit 0, no output, no
   backup. And **this is live right now** — the only `google-services.json` on this
   machine is a real file at `.worktrees/general-fixes/apps/mobile/`, and
   `MAIN_ROOT` has **none**. A faithful port deletes the only copy the first time
   someone puts it in main and runs `relink --all`. ⇒ Deliberately **diverge** from
   the bash behavior. Symmetrically, `cp` is unconditional on every relink and
   clobbers whatever `deploy-local.sh` last wrote ⇒ `relink` must treat copy ≠ link.
   (Also: `ln -sfn` onto an existing *directory* creates the link **inside** it.)
2. **`.worktree.env` is a public wire format with 6 consumers** (see §1), sourced
   as shell, and the proposal's port map is missing 2 of 7 entries.
3. **A worktree with no `.worktree.env` is not "portless" — it's destructive**
   (see §0).

Plus, from A: `link_secrets` **silently skips** a listed file absent from main
(`[[ -f ]] || continue`) — that is the silent-failure mode itself, and must become
a warning. And `main`'s version has **no `mkdir -p`**, so a credential in a
directory the worktree lacks fails outright.

---

## 6. Open items needing David's decision

1. Ports in v1, or refuse-to-create in unprovisioned stack repos? (recommend: v1)
2. Hooks never (user-scoped `post_create` instead) — and the `DESIGN.md` `[infra]`
   reversal that implies.
3. Migrate user config to TOML in the same PR, or leave the kv file alone?
4. One `[[file]]` list with `mode`, vs the proposal's `[link]`/`[copy]` tables.
5. Sequencing vs the ROADMAP (v0.3.2 + global summon hotkey are queued ahead).
6. Does the cdv repo's `feat/mobile-v1-mensajes` branch land first, so the
   transcription source for `[ports] base` and the link list is `main`?

## 7. Could not be determined

- Whether `DESIGN.md`'s `[infra] up/stop/down` is still intended (doc marked
  "design locked 2026-07-20"; nothing built, so cheap to change — but a reversal).
- Whether `store.rs`'s mtime-vs-PID lock divergence was conscious or drift.
- Which `docker compose` version the target machines run (`DESIGN.md:281` wants to
  tolerate both array ≤2.20 and NDJSON ≥2.21 `compose ps` output).
