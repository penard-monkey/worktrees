# Progress

## Session 1 — 2026-07-27/28 (branch `next-stream`, worktree `everything-settings`)

### Part A — design (complete)
Started as "thoughts?" on a proposal doc written from the consumer side. Four
parallel opus audits → `findings.md`; corrected 6 factual claims and found the
live destructive state (cdv worktrees with no `.worktree.env` + that repo's
`pkill -9` branch). David's decisions: ports in v1 **and generic, not
cdv-shaped**; no repo-supplied argv ever; TOML for both human files; cut v0.3.2
first. Proposal rewritten, committed `15179b1`.

### Part B — build (complete, MERGED as `eb32f7f`)

17 commits squashed into `main`. Final gates: **235 bats, 135 unit**, lint
clean, tsc clean, `cargo check -p app` clean. All 9 CI checks green.

| Commit | What |
|---|---|
| `5fe3e9b` +`ebb2ebe` | v1-S1 `projcfg.rs` + `diag.rs` + `config.toml`, pure/unwired |
| `92c85ce` +`3c7fe9b` | v1-S2 `materialize.rs`, `relink`, `doctor` |
| `159b219` +`0bf0732` | v1-S3 `provision.rs`, `.worktree.env`, compose teardown |
| `d233a1d` +`b5ac445` | v2-S4 `worktrees init` |
| `aad6fb6` | v2-S5 app surface |
| `8f2f103` | v3 `[project] prefix` + cwd-based session adoption |
| `fa59ece` | cross-slice review fixes |
| `adc3269` +`a4efa03` | GUI adopted-close + name-binding |
| `dcfc2f1` | sticky error banner + init's blind-spot warnings |

Workflow: opus implements from a detailed brief and runs gates → fable reviews
the commit → fixes land as a follow-up commit. Fable found something real in
**every** slice. The ones that mattered most:
- `--force` clobbered its own `.bak`, so the backup survived exactly one force.
- The slot lock's acquire could return `Ok` on a lock it no longer held → two
  concurrent scans → same port slot twice.
- `close` killed adopted sessions with no prompt; then the fix broke the GUI;
  then the confirmation turned out not to be bound to the session it named.
- `init` hard-failed on legal repos; detection silently dropped credentials
  under accented directory names (git C-quotes them).
- A failed `doctor` run read as "zero problems" and cleared every drift glyph.
- The mock's `relink` cleared findings the real command cannot clear.
- `runCmd` wiped its own error banner a tick after setting it.

### Part C — v0.3.2 (complete, RELEASED)
Cut off `origin/main` in a scratch worktree (the local `main` checkout was 23
commits stale). Merged `df9d7e2`, tagged `v0.3.2`, build green, all assets
published — 4 CLI targets, 2 signed app bundles + sigs, `latest.json`.

### Part D — cdv migration (NOT STARTED, deliberately)

Dry-run complete and READ-ONLY; the repo was verified unmodified before and
after. Artifacts in `~/.cache/worktrees/worktrees/everything-settings/dryrun/`:
`cdv.worktrees.toml` (transcribed from `scripts/worktrees.sh` on cdv `main`
@ `03a0a787`) and `RUNBOOK.md` (8 steps, rollback each).

Findings: all 17 worktrees are already correctly linked, so `relink --all` is a
no-op. The real work is `provision --all` — 11 of 15 lack `WEBSITE_PORT` and
bind main's 3002, and 2 have no `.worktree.env` at all.

**Do not use `worktrees init` there.** Verified against the real repo: it
suggests `apps/backoffice/.env.local` as a link (must be `copy`) and emits
`POSTGRES`/`LOCALSTACK` where the scripts read `PG_PORT`/`LS_PORT`, missing
`WEBSITE` and `META_MOCK` entirely. init now warns about both classes in its
generated comments, but it still cannot infer them.

**Blocked on David:** step 0 is verifying `apps/mobile/google-services.json`
against the Firebase console (sender id `86759926600`). The old script's
`relink --all` replaced `general-fixes`' real copy with a symlink on 2026-07-27
at 21:33 and `ln -sfn` leaves no backup.

Decided: leave the 4 registered worktrees outside `.worktrees/` (three under
`.dmux/`, one sibling) alone — `provision --all` cannot see them, and they are
another tool's.

### Left for a follow-up
- `app/src/mock/install.ts`'s `SUGGESTED_TOML` is a hand-written fixture, not a
  mirror of `render()`, so the harness preview no longer carries init's new
  warnings. No user-facing drift (production uses the real emitter).
- A refresh-raised error is retracted by identical-string match; two different
  sources producing byte-identical text would cross-clear.
- The 4s arm auto-disarm is tight for the long "Kill X — whole session?" label.
