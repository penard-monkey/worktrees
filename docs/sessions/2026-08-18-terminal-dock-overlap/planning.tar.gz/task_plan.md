# Task plan — terminal / dock overlap

## Goal
Fix the visual overlap shown in `_tmp/Screenshot 2026-08-17 at 23.22.41.png`:
the terminal pane's right edge runs under the FILES dock. tmux status line and
terminal text are clipped mid-glyph at the boundary (annotated "We have an
overlap here").

## Phases
| # | Phase | Status |
|---|-------|--------|
| 1 | Read screenshot, characterise the overlap | complete |
| 2 | Locate layout: terminal pane + dock CSS/TSX, fit/resize path | complete |
| 3 | Root-cause: `.term-host` has no `min-width: 0` (see findings.md) | complete |
| 4 | Fix + regression guard + CHANGELOG/CLAUDE.md | complete |
| 5 | Verify in harness (4 paths) + gates | complete |
| 6 | Fable review → nit fixed → PR #157 squash-merged | complete |
| 7 | Optional: run the real app to see it on WKWebView | not started |

## Landed
PR #157, squash-merged as `9dc108b` on main. CI 9/9 green twice (once after the
review fix). Worktree parked on `overlay-issues-next` off the new origin/main;
`overlay-issues-termfit` deleted local + remote.

Fable review: merge-ready, two LOW findings. Fixed #1 (the premise check knew
only `flex-direction`, so a `flex-flow: column` rewrite would have silently made
the width assertions vacuous — widened to `flex-(?:direction|flow)`, shown red
against that mutation). #2 was informational: the guard is manual, like
`dnd-check.mjs` and `race-check.mjs` — a CI step for the static pair is a
candidate for ROADMAP, not this PR.

## Fix
`app/src/App.css` — `.term-host` gains `min-width: 0` (load-bearing) and
`overflow: hidden` (backstop), with the reasoning inline.
`app/scripts/termfit-check.mjs` — new static guard; shown RED against the
pre-fix rule, green after.

## Verified in the mock harness (getBoundingClientRect, viewport 1600)
| path | before | after |
|------|--------|-------|
| open dock | host 1206 vs main 852 → **354px overhang** | host 852, screen re-fit 1190→830, overhang **0** |
| close then re-open dock | ratchets wide, never returns | 1212 → 852, tracks exactly |
| window 1600→1150 | would overhang | main/host 420, screen 399, no body h-scroll |
| drag dock 360→660→310 | dock shell ratchets too | both hosts track; spill 0 |

`overflow: hidden` side-effects checked: host `scrollWidth == clientWidth`
(nothing clipped), xterm viewport fully inside, ⌘F opens, searches (1/8, 9
decorations) and the find bar still renders outside the host box.

## Gates
tsc --noEmit ✅ · cargo check -p app ✅ · make lint ✅ · core 251 ✅ · cli 7 ✅ ·
app --lib 37 ✅ · make test (bats) 314 ✅ 0 not ok

## Constraints (from CLAUDE.md)
- Assert layout with `getComputedStyle`, do not eyeball.
- Real-app check: `app/scripts/sandbox.sh --app` (mock hides timing/layout).
- HMR dead inside `.worktrees/` — restart vite with `--force` after edits,
  keep it out of a foreground shell's process group.
- Gates before PR: cargo build --release -p worktrees-cli, make test, make lint,
  cargo test (core/cli/app --lib), tsc --noEmit + cargo check -p app.

## Errors encountered
| Error | Attempt | Resolution |
|-------|---------|------------|
| (none yet) | | |
