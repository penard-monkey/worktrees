# Progress log

## Session 2026-08-17/18 — overlay-issues worktree
- Fresh worktree `overlay-issues`, branch `overlay-issues`, clean at 9537986.
- Bootstraps: `git submodule update --init --recursive`, `pnpm install` on
  Node 22.23.2 (worktree started on 22.12.0 — nvm use is required).
- Read `_tmp/Screenshot 2026-08-17 at 23.22.41.png`; characterised the overlap.
- Traced layout: `.space-body` (flex row) → `.main` + `.dock`; `.main` (column)
  → `.term-wrap` (flex row) → `.term-host` (xterm).
- ROOT CAUSE: `.term-host` had no `min-width: 0` → min-content floor from
  `.xterm-screen`'s inline px width → one-way ratchet. findings.md has the
  measurements.
- Reproduced in the mock harness (vite `--port 1431`, place `messaging`):
  354px overhang past the dock's left edge.
- Fixed in App.css; re-verified all four resize paths — all clean.
- Added `app/scripts/termfit-check.mjs`; demonstrated RED against the pre-fix
  rule (2 failed, exit 1), green after restore.
- CHANGELOG `[Unreleased] / Fixed` entry + a CLAUDE.md hard-won rule.
- Gates: tsc, cargo check -p app, make lint, core/cli/app tests all green;
  bats running.

### Close-out (2026-08-18)
- PR #157 squash-merged as `9dc108b`; CI 9/9 twice. `gh pr merge` printed the
  documented false failure (its local checkout step) — merge had landed.
- Fable review before merge: merge-ready, one nit taken (`flex-flow` shorthand
  in the guard's premise check), one left as ROADMAP (static checks not in CI).
- Archive: `docs/sessions/2026-08-18-terminal-dock-overlap/`; two ROADMAP items
  added (WKWebView verification, static checks in CI).
- Worktree ends on `overlay-issues-next` off origin/main.

### Notes for next time
- The harness must be launched with an ABSOLUTE `cd` inside the same command —
  a backgrounded relaunch inherited the repo root and died with exit 127.
- HMR is dead here, so every CSS edit needs a kill + `vite --force` restart and
  a `curl` diff of the served file before believing a measurement.
