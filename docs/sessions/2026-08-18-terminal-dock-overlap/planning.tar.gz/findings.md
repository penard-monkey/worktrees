# Findings

## Screenshot evidence (`_tmp/Screenshot 2026-08-17 at 23.22.41.png`, 1920x1080-ish)
Layout left→right: icon rail | PLACES nav | terminal pane | FILES dock | right rail.

- Terminal text column ends ≈ x=1143; FILES dock panel starts ≈ x=1160.
- Red annotation box drawn ≈ x=1095..1175, y=540..1040 — a vertical strip at
  the terminal/dock seam, full height of the terminal body.
- Clipping visible:
  - line `/rc` (cut mid-token, likely `/rou…` or a right-aligned tmux status
    field) at y≈945.
  - green tmux status bar bottom line `[worktrees0:claude.exe*  …  23:22 17-Aug…`
    is cut on the right — trailing date text disappears under the seam.
  - body text lines ("nothing to park. Actual stragglers went in instead:",
    "1. Exclude migration — PR #150 gap: repos with pre-existing store never get")
    also run right up to / past the seam.
- So: the terminal's rendered content is WIDER than its visible box — content
  is being clipped/occluded at the dock edge rather than reflowed.

## ROOT CAUSE — confirmed, reproduced in the mock harness

`.term-host` (App.css:851) is a **row** flex item of `.term-wrap` and declares
`min-height: 0` but **not `min-width: 0`**. Its computed `min-width` is therefore
`auto` → the automatic-minimum-size rule floors it at its **min-content** width.
Min-content is not small: xterm gives `.xterm-screen` an **inline `width:
1190px`** (cols × cell width), and that px width is what the floor is computed
from. So the host can GROW but can never SHRINK — a one-way ratchet. The
ResizeObserver in `TerminalPane.tsx:208` observes that host, so it never sees a
shrink, never re-fits, and never tells tmux to narrow: tmux keeps painting the
old column count and the extra columns sit **under the dock**, which paints over
them (later sibling, both `position: relative`).

### Measured (mock harness, viewport 1600, place `messaging`)
| | `.main` | `.term-wrap` | `.term-host` | `.xterm-screen` | `.dock` |
|---|---|---|---|---|---|
| dock closed | 344–1556 (1212) | 1212 | 1212 | 1190 (inline) | — |
| dock open   | 344–**1196** (852) | 852 | 344–**1550** (1206) | 1190 (inline, unchanged) | 1196–1556 |

`.term-host` overhangs the dock's left edge by **354px**; the painted screen by
**346px**. `getComputedStyle(host).minWidth === "auto"`, `overflow: visible`.
That is the screenshot's annotated seam.

### Scope
Same rule serves BOTH terminals, so the dock's `ShellPane` has the identical
ratchet when the dock is dragged narrower. One fix at `.term-host` covers both.

### Repro (no real app needed — pure CSS, mock reproduces it)
1. `VITE_MOCK=1 vite --port 1431` ; open, click place `messaging`
2. measure `.term-host` — fills `.main`
3. click rail "Files (⌘J)" to open the dock
4. `.main` shrinks, `.term-host` does not → `host.right > dock.left`

### Why it survived review
Every gate passes: the value written is correct at the moment it is written, and
the harness's own layout assertions were never pointed at this seam. It also only
bites AFTER the terminal has been sized wide once — open the dock first and the
terminal is born narrow and looks perfect.
