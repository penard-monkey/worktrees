# Task Plan — new-worktree delay + spurious "already in this worktree" warn

## Goal
1. **Creating a worktree appears stuck** — ~2.07 s of silence, no UI feedback at all.
2. **`tmux session 'x' already in this worktree — attaching.`** logged at WARN on
   every open; the text is also wrong on the app path (it never attaches).

## Decisions (user, this session)
- **Create UX** → *optimistic ghost row in the nav*. Form dismisses on submit; a
  placeholder place appears with a spinner and resolves (or errors) when the op returns.
- **Fetch cost** → *collapse to a single `git fetch origin`*. One round trip answers both
  "does origin/<branch> exist?" and "is origin/<base> current?" (2 RT → 1 RT, ~0.8 s saved).
- **Warn** → demote to info + make the wording match what actually happened.

## Phases

| # | Phase | Status |
|---|-------|--------|
| 1 | Locate message + launch path; read app enter/create flow | complete |
| 2 | Confirm from app.log; sync branch to origin/main (v0.9.0) | complete |
| 3 | Measure the create delay (fetch / worktree add / tmux / refresh) | complete |
| 4 | Decide fixes with user | complete |
| 5a | core: `ops.rs` launch message — severity + wording | complete |
| 5b | core: `cmd_new` single-fetch | complete |
| 5c | app: optimistic ghost row (App.tsx + mock harness) | complete |
| 6 | Update bats goldens; run gates | all green EXCEPT `make lint` (not run) |
| 7 | CHANGELOG → fable review → PR | pending |

## RESUME HERE (session interrupted — power out, 2026-08-07)
Code complete, **uncommitted**. See `progress.md` for the full state. Next:
1. `make lint`
2. Check `.playwright-mcp/` isn't about to be committed
3. CHANGELOG `[Unreleased]`
4. fable review → squash-merge PR

## Gates (CLAUDE.md — run in this order)
```sh
cargo build --release -p worktrees-cli   # FIRST, or bats fails mysteriously
make test
make lint
cargo test -p worktrees-core
cd app && ./node_modules/.bin/tsc --noEmit && cargo check -p app
```

## Known test goldens that will move
- `test/new.bats:94` — `"Fetching origin/rb2"`
- `test/open.bats:67` — `"already in this worktree"`
- `test/misc.bats:276` — `"tmux session 'repo-feat-x' already in this worktree"`

## Errors Encountered
| Error | Attempt | Resolution |
|-------|---------|------------|
| zsh: `--include=*.rs` unquoted glob | 1 | Quote the pattern |
| `worktrees rm --delete-branch` unknown flag | 1 | Flag is `--branch`; used `git branch -D` for probe cleanup |
