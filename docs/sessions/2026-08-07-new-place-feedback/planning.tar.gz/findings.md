# Findings — new-worktree delay + "already in this worktree" warn spam

## Environment
- Worktree `ui-changes` / branch `ui-next` was **7 commits behind** origin/main
  (repo said 0.8.0, installed CLI 0.9.0). Fast-forwarded to `6b47e16`
  (release: v0.9.0). Branch had **0 commits of its own** — clean FF, nothing lost.

## Bug B — "tmux session 'x' already in this worktree — attaching." every open

**Confirmed from `~/Library/Logs/net.casadelvalle.worktrees/app.log`:**

```
15:15:55Z [info] open ui-changes fresh=false ok repo=/Users/davidpena/workspace/worktrees
15:15:55Z [warn] open ui-changes fresh=false warnings repo=...: tmux session 'worktrees-ui-changes' already in this worktree — attaching.
```

Every single `open` logs it. Chain:
1. `crates/worktrees-core/src/ops.rs:102` — `ui.warn("tmux session '{session}' already in this worktree — attaching.")`
   fires whenever `tmux::session_exists(&session)`.
2. `CaptureUi::warnings()` (`ui.rs:108`) collects Warn+ severity.
3. `run_op` (`app/src-tauri/src/lib.rs:344-351`) logs them at `[warn]` **even when the op succeeded**
   and ships them in `CmdResult.warnings`.

**Two defects in one line:**
- **Wrong severity.** A live session on reopen is the *expected, healthy* state — the
  whole point of a durable place. Warn-level is reserved for things needing attention.
- **Factually wrong text on the app path.** `open_place` calls `launch(..., do_attach=false, ...)`
  (`lib.rs:432`+, passes `--no-attach`). It does **not** attach — the app embeds the
  session via its own PTY. The message says "— attaching." regardless.

Not a new regression in the line itself (present since #6 `e60c2a5`); what changed is
that the app now *routes and logs* warnings (`eb32f7f`, #58) so the noise became visible.

Frontend does NOT banner it (`App.tsx:1302` only sets `err` when `!r.ok`) — the user is
seeing it in **Settings → Logs**.

## Bug A — new worktree "appears stuck"

### No UI feedback at all (primary cause)
- `NewPlaceForm.submit()` (`App.tsx:271`) calls `onCreate(...)` **fire-and-forget** —
  not awaited, button never disabled, no spinner. Form just sits there.
- `createPlace` (`App.tsx:1705`) only calls `setNewFor(null)` **after** `r.ok`.
- `runCmd` (`App.tsx:1281`) sets no pending state.
- Contrast: `InitRepoPrompt` (`App.tsx:299`) directly below DOES have a `busy` flag and
  awaits. The pattern exists in this file; `NewPlaceForm` just lacks it.

### Measured cost of `new` (real runs, this machine)
| Step | Time |
|------|------|
| `worktrees new <new-branch> --no-tmux` end-to-end | **2.07 s** |
| `git fetch origin refs/heads/<new-branch>:...` — **guaranteed to fail** | 0.80 s |
| `git fetch origin <base>` | 0.80 s |
| `git worktree add` (worktrees repo) | ~0.5 s |
| `git worktree add` (monorepo, 1944 files, 300M .git) | 0.51 s |
| `tmux list-panes -a` / `list-sessions` (20 live sessions) | 0.006 s |
| `worktrees --json ls` (what refresh uses) | 0.05 s |

tmux and the workspace sweep are **not** the problem. Network is ~1.6 s of the 2.07 s.

### Wasted round trip
`ops::cmd_new` (`ops.rs:336-350`) for a brand-new branch name does:
1. `show-ref refs/heads/<branch>` → miss (local)
2. `show-ref refs/remotes/origin/<branch>` → miss → **`git fetch origin refs/heads/<branch>:refs/remotes/origin/<branch>`**
   → `fatal: couldn't find remote ref` — a full network round trip that can never succeed
   for a branch the user is inventing.
3. `show-ref refs/remotes/origin/<branch>` → still miss
4. `git fetch origin <base>` → second round trip
5. `git worktree add -b <branch> <wt> origin/<base>`

Creating a new branch always pays **two** network round trips, one of them doomed.

## Open design question (needs decision before implementing)
Collapsing steps 2+4 into one round trip changes CLI stdout ("Fetching origin/x...").
`test/*.bats` gates CLI output byte-for-byte against fake git/tmux shims — must check
which golden strings that would move.
