# Progress — new-worktree delay + "already in this worktree" warn

## Session 1 — 2026-08-07 (interrupted by power outage, then resumed)

### DONE — PR #89 open, awaiting merge
https://github.com/penard-monkey/worktrees/pull/89
Branch `fix/new-place-feedback`, commit `0510e2a`, pushed. Squash-merge when ready.

### Diagnosis (see findings.md for the evidence)
1. **Warn spam** — `ops.rs` `launch()` warned on every reopen; `run_op` logs warnings
   even at rc=0, so every app `open` wrote a `[warn]` line. Proven from
   `~/Library/Logs/net.casadelvalle.worktrees/app.log`. Text also said "attaching" on
   the app path, which passes `do_attach=false`.
2. **Create appeared stuck** — ~2.07 s with zero UI feedback. ~1.6 s of that was two
   network fetches, one guaranteed to fail.

### Shipped (7 files)
| File | Change |
|------|--------|
| `crates/worktrees-core/src/ops.rs` | `launch()`: warn → info, tail follows `do_attach`. `cmd_new`: two fetches → one **guarded** `git fetch origin` |
| `app/src/App.tsx` | `pendingNew`/`pendingSeq`/`newDraft` state; `PendingRow`; form dismissed on submit, restored on failure |
| `app/src/App.css` | `.status-dot.pending`, `.row.pending` |
| `app/src/mock/install.ts` | `?slowcreate[=ms]` knob; branch containing `fail` → rejected create |
| `test/new.bats` | golden update + 2 new tests |
| `CHANGELOG.md` | `[Unreleased]` |
| `ROADMAP.md` | `do_switch` follow-up |

### Fable review — 3 real defects found, all fixed
1. **Regression I introduced.** Dropping the `!show-ref origin/<branch>` guard turned the
   already-tracked path from 0 round trips into 1 — offline that is a DNS/TCP timeout
   before producing the identical worktree. Guard restored; test added that points
   `origin` at an unreachable path so any network attempt fails loudly.
2. **`do_switch` untouched** — same doomed two-fetch pair, and `cmd_new` routes through
   it on the holder-reuse path. Deliberately deferred → ROADMAP; CHANGELOG wording
   corrected (it had overclaimed "`new` contacts the remote once").
3. **Failed create discarded all typed input.** Old code kept the form on failure; my
   up-front dismiss killed it. Added `newDraft` + `initialBranch`/`initialName` props.

Fable cleared as sound: the `pendingNew` lifecycle (StrictMode, concurrent creates,
`finally` retire, no empty frame), the severity change (no consumer keyed on Warn), and
the remaining fetch edge cases.

### Gates — ALL GREEN (re-run after the review fixes)
`make test` 288 ok / 0 fail · `cargo test -p worktrees-core` 205 · `cargo test -p
worktrees-cli` 6 · `make lint` clean · `tsc --noEmit` clean · `cargo check -p app` ok

### Verified in the mock harness (Playwright, port 5199)
- `?slowcreate=60000` → form dismisses, ghost row renders (`listitem "creating
  feat-ghost-row…"`), resolves into the real selected row.
- `?slowcreate=1500` + branch `feat/fail-me` → error banner
  `Failed to create branch 'feat/fail-me': mock refusal`, form returns with all three
  fields intact (`feat/fail-me` / `my-topic` / `devlop`), **no** stranded pending row.

The xterm `Cannot read properties of undefined (reading 'dimensions')` console error is
PRE-EXISTING harness noise (hidden terminal, zero dimensions), not from this change.

### Cleanup done
- Timing probe worktree `zzz-timing-probe` + branch: removed, verified gone.
- Stray `ghost-row-inflight.png` moved out of the repo root to
  `~/.cache/worktrees/worktrees/ui-changes/`. `.playwright-mcp/` is gitignored.

### Still running
- vite mock harness on port 5199 (background). Kill when done.

### Next
Merge #89, then `/close-out`.

## Errors Encountered
| Error | Attempt | Resolution |
|-------|---------|------------|
| zsh: `--include=*.rs` unquoted glob | 1 | Quote the pattern |
| `worktrees rm --delete-branch` unknown flag | 1 | Flag is `--branch` |
| Ran `make test` 3× in one pipeline (~15 min waste) | 1 | Single run logged to a file |
| `find /` for a screenshot — hung twice | 2 | Playwright only writes under the repo root |
| Playwright refs go stale between snapshots | 2 | Use xpath/CSS selectors, not `eNNN` refs |
| Dropped the fetch guard, silently regressing the offline path | 1 | Caught by fable review; guard restored + test |
