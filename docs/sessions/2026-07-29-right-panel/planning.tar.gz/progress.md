# Progress

## Session 2026-07-29 — right panel + icons (discussion)

- Branch `ui-next`, clean at start. Head: `4aafad1 chore: close out right-dock
  session (#61)`.
- Read the 3 newest `_tmp/` screenshots (10.23.25, 10.33.35, 10.35.10) and
  transcribed every red annotation into findings.md (multimodal → text).
- Traced all 4 complaints to code: `clampDock` 680 cap, `gridCols` `1fr` +
  no resize re-clamp, Unicode glyph rail/topbar vs the SVG house style,
  dock has tabs but no rail, `do_switch` is DWIM so branch input must stay
  free-text (combobox, not `<select>`).
- Nothing edited yet. Waiting on D1–D5.

- D1–D5 answered: always-visible right rail (topbar `▧` deleted), Lucide paths
  normalized to the 16-box house style, degrade-in-order narrow policy.
- Scope grew: dock Terminal tab drops tmux sidecars for owned PTYs (D6/D7).
  Traced the two-process chain and every sidecar touchpoint; the blocker is that
  unmount currently *detaches*, which becomes *kill* without tmux — hence the
  registry + ring-buffer design in findings.md.

### Slice 1 — layout hardening → `596cec0`
- `fitLayout()` in settings.ts owns column geometry; prefs stay intent-only.
- Two bugs found in my OWN first cut, via the harness (not by reading):
  1. `.status-cluster` escaped `.identity` and landed on `.controls` — the same
     overlap, relocated. Fixed with the min-width:0 + overflow chain, and the
     badges now retire below `MAIN_TIGHT` (560) instead of clipping mid-glyph.
  2. `window.innerWidth` counts the scrollbar gutter (1284 vs 1269 clientWidth),
     quietly eating 15px of MAIN_MIN's reserve. Now one `viewportWidth()` helper.
- Harness numbers (mock, kitchen-sink place):
  | vw | grid | note |
  |----|------|------|
  | 1920 | 44 / 300 / 420 / **1156** | old flat cap stopped at 680 |
  | 1600 | 44 / 300 / 420 / 836 | dock returns after a narrow round-trip |
  | 1284 | 44 / 347 / 420 / 458 | sums exactly to clientWidth, no overlap |
  | 900 | 44 / 300 / 556 | dock dropped, toggle disabled + explains why |
- Console errors in the harness are pre-existing xterm noise (`reading
  'dimensions'`, no real PTY in mock) — present before these edits.

### Slice 2 — icon set → `dda317c`
- `app/src/icons.tsx`: Lucide paths at their native 24 viewBox / stroke 2 rather
  than rescaled to the 16-box. Rendered stroke matches (1.25 vs 1.22px at 15px),
  and hand-rescaling ~20 paths would only have invented transcription errors.
- Kept Unicode where it's DATA (◆ ★ ⚑ ● ↑↓ in rows, ✓/✗ in log output/prose).
  Reworded the two sentences that referred to a button by its glyph.

### Slice 3 — right rail → `4c1b02b`
- Permanent 44px column; active icon collapses the dock; topbar toggle deleted.
- `RAILS_W` — the fit math reserves BOTH rails now.
- Harness caught a 1px document overflow: the right rail's `active::before` at
  `right:-6px` sat a half-pixel past its content box → real horizontal
  scrollbar. Moved to -5px AND made the shell `overflow:hidden` (an app shell
  should never scroll at the document level regardless).

### Slice 4 — dock shells → owned PTYs → `8e09c78`
- Registry keyed (repo, slug, index) + 256KB ring per shell; reader takes
  ring-then-sink in the same order the attach path does, so a write landing
  mid-replay is neither duplicated nor dropped.
- Unmount DETACHES. That was the whole risk: it used to be a harmless tmux
  detach and would have become a kill.
- Swept on app exit, place close/remove, and tab close. One-time sweep of
  upgraders' orphaned `~term` sessions on first shell open.
- Mock gained `__mock.exitShell()` — the exited-shell state is otherwise
  unreachable headlessly. Verified: 2 tabs survive dock collapse/reopen;
  exit → Restart cycles. The harness has no PTY, so this is the UI contract only.

### Slice 5 — branch combobox → `95a01c1`
- `Project::branch_names()` unions local heads with origin-only branches.
- Combobox, NOT `<select>` — `do_switch` is DWIM and a select would have deleted
  the create path. Verified all three: click-select, ArrowDown+Enter onto the
  create row, Esc+Enter raw text.

### Gates (after slices 4 and 5)
237 bats · 137 core tests · 0 failures · tsc clean · `cargo check -p app` clean ·
`make lint` clean.

### Fable review of PR #62 → fixes `423e231`, merged `8fe445d`
- F1 stale detach killed live attach (StrictMode) → attach generation on
  shell_open/shell_detach. F2 create race leaked a shell → registry lock held
  across the whole open. F3 dead shell resurrected on dock reopen →
  list_shell_sessions reports liveness via try_wait, restore seeds `dead`.
- F3 verified in harness: exit-while-closed → reopen shows dead tab → Restart.

### Nav bugs (screenshot 16.10.42) → branch `nav-fixes`, PR #63
- ↑↓ was vs @{u}: pushed branch merging origin/main showed ↑494 while in sync
  with main. Now vs `Project::base_ref()` (origin/<base> else local base),
  resolved once per snapshot. json.bats contract tests updated + scenario test
  (238 bats now). `cfd4e7a`
- Manual drag-sort dead in app only: Tauri `dragDropEnabled` default true eats
  HTML5 DnD in WKWebView; harness has no Tauri layer → worked in dev, never in
  app. Set false (nothing uses Tauri file-drop). `e3fdbe0` — NOT verifiable
  headlessly; needs a real app build to confirm drag.

### Files touched
- created: task_plan.md, findings.md, progress.md, app/src/icons.tsx
- app/src/{App.tsx,App.css,settings.ts,TerminalPane.tsx,SettingsSheet.tsx,
  ProjectSheet.tsx,mock/install.ts}
- app/src-tauri/src/lib.rs, crates/worktrees-core/src/project.rs, CHANGELOG.md
