# Findings — screenshots 2026-07-29 (right panel / icons)

## Source screenshots (annotated, red marker)

- `_tmp/Screenshot 2026-07-29 at 10.23.25.png` — 4 marks: "don't like these
  icons" (arrows → left-rail ▤ **and** topbar ▧; the « collapse is boxed too),
  "add Rail here for terminal and file browser like on the left side of the app"
  (→ right edge of window), "I think this should open a select box"
  (→ `switch branch…` input).
- `_tmp/Screenshot 2026-07-29 at 10.33.35.png` — narrow window, "After a reboot
  have this mess": topbar children (slug / branch chip / Enter / ★ / Lifecycle /
  ⋯) overlap; center pane crushed to ~310px while dock keeps its px width.
- `_tmp/Screenshot 2026-07-29 at 10.35.10.png` — fullscreen 1918px, dock sits at
  ~673px: "when full screen this has a max width, should expand almost all the
  way."

## Root causes (verified in code)

1. **Dock cap** — `app/src/settings.ts:109`
   `clampDock = v => Math.max(240, Math.min(680, v))`. Hard 680 ceiling,
   viewport-blind. Fullscreen hits it exactly → the screenshot.
   `clampNav` (`:108`) has the same shape: 220–460.
2. **Narrow-window overlap** — `App.tsx:1746` builds
   `gridCols = rail | navPx | 1fr | dockPx`. `1fr` = `minmax(auto,1fr)`, so main
   cannot shrink past its content; fixed px tracks never yield → total > window →
   children overlap. `.topbar` (`App.css:286`) is `display:flex` with no wrap and
   `.controls` (`:311`) `margin-left:auto` with no `flex:0 0 auto`; `.identity`
   has `min-width:0` but slug/branch have no ellipsis. Nothing re-clamps
   nav/dock widths on window resize — a restored-small window keeps the widths
   saved from a big one ("after a reboot").
3. **Icon inconsistency** — rail (`App.tsx:1738-1772`) and topbar
   (`:1855,1872,1875,1890`) use raw Unicode: `▤ ◷ ⚠ « » ＋ ⚙ ▧ ★ ⋯ ⎇ ▸ ▾`.
   Font-fallback roulette → mismatched stroke weight, size, baseline. Two of
   them (`▤` places lens, `▧` dock toggle) are near-identical boxes doing
   unrelated jobs — exactly the pair the user arrowed. Meanwhile `FolderIcon` /
   `HomeIcon` (`App.tsx:95-106`) are proper inline SVG: **16×16 viewBox,
   `fill=none`, `stroke=currentColor`, `strokeWidth 1.3`, round caps**. That is
   the house style to extend.
4. **Right dock has no rail** — dock is text tabs `Files | Terminal`
   (`.dock-tabs`, `App.css:571`) plus an `×`. The only open/close affordance is
   the topbar `▧`. Left side is rail(44px)+panel; right side is panel only —
   asymmetric.
5. **Branch switch must stay free-text** — `switch_place` (lib.rs:394) →
   `ops::do_switch` (core/ops.rs:147) is DWIM: local branch → switch; remote →
   track; **otherwise create a new branch off base**. A plain `<select>` would
   delete the create path. Needs a combobox. No `list_branches` command exists
   in lib.rs — new core helper + tauri command + mock entry required.

## Dock terminal: tmux sidecar → owned PTY (added 2026-07-29)

Current chain: `open_shell_session` (lib.rs:1577) creates tmux session
`<session>~term[~n]` (`tmux::shell_sidecar_name`, core/tmux.rs:24) running
`exec "${SHELL:-/bin/sh}"` cwd'd in the place, then `term_open` (lib.rs:1658)
spawns a PTY running `tmux -u attach-session -t <sidecar>`. Two processes.

Sidecar touchpoints: lib.rs:1582/1605/1615; `ops.rs:697,756,867`
(`kill_shell_sidecars` on close/rm); `tmux.rs:190` (`is_shell_sidecar` excludes
them from adopted-session detection — still fine once they're gone).

**Why owned PTY wins here**: `C-b` stops being swallowed; xterm.js scrollback
replaces tmux copy-mode (wheel just works); the resize-clamp workaround
(`tune_session` + aggressive-resize, comment at lib.rs:1670) becomes moot with a
single client; dock works with tmux absent (today it hard-errors "tmux not
found"); no `~term` clutter in `tmux ls`.

**Why it isn't a one-liner**: `TerminalPane` unmount calls `term_close`
(TerminalPane.tsx:94) — a harmless *detach* under tmux, a *kill* for an owned
PTY. And tmux was providing scrollback-across-detach for free.

Design (D6):
- `Shells(Mutex<HashMap<(repo,slug,index), Shell>>)` in app state.
  `Shell { master, writer, child, stop, ring: Arc<Mutex<RingBuf>>, sink }`.
- Reader thread always runs → appends to ring (~256KB) AND to `sink` if attached.
- Commands: `shell_open` (create-if-absent + attach + **replay ring**),
  `shell_detach` (clear sink, keep process — the unmount path),
  `shell_write`, `shell_resize`, `shell_close` (kill; the tab `×`).
  `list_shell_sessions` now enumerates the registry, not tmux.
- Spawn `$SHELL -l` (Terminal.app convention) with `TERM=xterm-256color`, cwd =
  `place_dir`. `-l` also makes PATH correct independent of `fixup_gui_path()`.
- App must sweep the registry for a place on `close_place` / `remove_place` —
  core's `kill_shell_sidecars` calls can't see app state.
- Kill every shell on `RunEvent::Exit` so no orphan `zsh` survives the app.
- Child EOF → keep the tab, print `[process exited]`, offer Restart.
- **Migration**: upgraders have live `<session>~term*` sessions that nothing will
  ever reattach to. Sweep once per place on first `shell_open`
  (`tmux::kill_shell_sidecars`, guarded, only when tmux is present). Keep the
  core calls in cmd_rm for pre-upgrade leftovers.
- Frontend: extract a `useXterm()` hook; two thin wrappers (tmux-attach for the
  hero, shell for the dock) — components stay at module scope per CLAUDE.md.

## Tokens / constraints

- `--rail-w: 44px`, `--nav-w: 300px` (tokens.css:89-90). `--dock-w` is written
  by `applySettings` but never declared in tokens.css.
- CLAUDE.md: no UI libraries, plain CSS, everything scales off `--ui-rem`.
  → icons must be hand-inlined SVG, not a package.
- Mock harness (`app/src/mock/install.ts`) must gain any new command.

## Decisions — RESOLVED 2026-07-29 (see task_plan.md table). Originals below.

## Open decisions (D1–D5)

- **D1** right-rail persistence: always-visible 44px rail (VS Code model, active
  icon toggles the panel, topbar `▧` deleted) vs rail only while dock open
  (topbar toggle stays).
- **D2** icon source: hand-drawn in the existing 16-box house style vs
  Lucide geometry normalized to 16/1.3 (MIT, copied as paths, no dependency).
- **D3** pin affordance: keep star (favorite metaphor) vs switch to pin glyph.
- **D4** dock max: viewport-relative cap (reserve ~420px for main) vs a plain
  `85vw`. Plus: re-clamp both nav and dock on `resize`.
- **D5** narrow-window policy: auto-collapse dock below a threshold vs let the
  user hit a hard floor with everything ellipsised.

## Proposed icon map (all inline SVG, 16-box, stroke 1.3)

| Where | Now | Proposed |
|-------|-----|----------|
| lens: places | `▤` | list-tree (indented tree lines) |
| lens: recent | `◷` | history (clock + ccw arrow) |
| lens: attention | `⚠` | triangle-alert |
| nav collapse | `«` / `»` | panel-left-close / panel-left-open |
| add project | `＋` | folder-plus |
| settings | `⚙` | settings gear |
| topbar dock toggle | `▧` | panel-right-close / panel-right-open (or deleted, D1) |
| topbar pin | `★` | pin / pin-off (D3) |
| topbar more | `⋯` | ellipsis (3 dots) |
| topbar lifecycle | `▾` | chevron-down |
| enter | `▸` | chevron-right / play |
| statusbar branch | `⎇` | git-branch |
| right rail: files | (text tab) | folder |
| right rail: terminal | (text tab) | square-terminal |
| dock close | `×` | x |
| new terminal | `＋` | plus |
