# Task plan — right-panel + icon system pass

**Goal**: act on 3 annotated screenshots (_tmp/, 2026-07-29). Right dock gets a
real activity rail, the icon set stops being Unicode glyph roulette, the narrow
window stops overlapping, the dock stops capping at 680px, branch switch becomes
a combobox.

**Status**: SHIPPED. #62 (`8fe445d`), #63 (`132843f`), release PR #64
(`9272820`) all squash-merged. Main worktree ff'd, `v0.5.0` tagged on `9272820`
and pushed; release.yml run 30504912366 **completed success** — v0.5.0
published, all 10 assets up (CLI ×4, signed app ×2 + sigs, latest.json,
checksums). Local branch still `release-0.5.0`; close-out ritual pending.

## Phases

| # | Phase | Status |
|---|-------|--------|
| 1 | Read screenshots, locate root causes in code | complete |
| 2 | Decide icon set + right-rail semantics with user | complete |
| 3 | Icon module (inline SVG, 16-box, stroke 1.3) + swap all glyphs | **complete** (dda317c) |
| 4 | Right activity rail (Files / Terminal), retire topbar ▧ | **complete** (4c1b02b) |
| 5 | Layout hardening: viewport-aware clamps, resize re-clamp, topbar shrink | **complete** (596cec0) |
| 6 | Dock shells: tmux sidecars → owned PTYs (registry + ring buffer) | **complete** (8e09c78) |
| 7 | `list_branches` backend + branch combobox (keeps create-new path) | **complete** (95a01c1) |
| 8 | Gates: tsc, cargo check, cargo test, make test, mock harness parity | **complete** — all green |

Ship order (one squash-merged PR each): 5 → 3 → 4 → 6 → 7.

## Decisions log

| # | Decision | Chosen |
|---|----------|--------|
| D1 | right-rail persistence | **always-visible 44px rail**; active icon toggles the dock; topbar `▧` deleted |
| D2 | icon geometry | **Lucide paths (MIT) normalized to the 16-box / stroke-1.3 house style**, in a new `app/src/icons.tsx`. No npm dep. |
| D3 | pin affordance | pin / pin-off glyph (star retired) — my call, cheap to flip |
| D4 | dock cap | viewport-aware: `max = vw - rail - navW - MAIN_MIN(420)`, floor 240. Re-clamped on `resize`. |
| D5 | narrow policy | **degrade in order**: shrink dock → hide dock → collapse nav. Restores when the window grows. Hidden-by-fit ≠ user-closed (kept separate so ⌘J/⌘B intent survives). |
| D6 | dock shell backing | **owned PTY, no tmux.** Lifetime = until app quit: survives tab flip / ⌘J / place switch via a registry + replay ring buffer. Tab `×` kills. |
| D7 | scope of D6 | **dock Terminal tab ONLY.** Center hero keeps the canonical tmux session (Claude lives there; must survive quit and stay `tmux attach`-able from the CLI). |

## Errors encountered

| Error | Attempt | Resolution |
|-------|---------|------------|
| `ls -lt` → eza rejects `-t` | 1 | use `/bin/ls -lt` |
| `--include=*.css` unquoted → zsh glob | 1 | quote the pattern |
