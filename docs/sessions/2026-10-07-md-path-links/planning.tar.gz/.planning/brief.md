# Brief: clickable file paths in rendered markdown (Files preview + Plan tab)

## Goal
The terminal already turns printed file paths into ⌘-click links (`termLinkProvider` in
`app/src/TerminalPane.tsx` → `resolve_term_paths` in `app/src-tauri/src/lib.rs` ~5860-5960).
Do the same for markdown the app renders: the Files pane's markdown preview and the Plan tab
(both render through `Markdown` in `app/src/markdown.tsx`). A path that names a real file in the
project becomes a link; clicking it opens that file in the Files pane (`openDockFile` in App.tsx,
which since #449 also reveals it in the tree). `path:line` / `path:line:col` should jump to the line,
like the terminal links do.

## Design David agreed to (recommendation; adjust with evidence, say why)
1. **Paths, not guesses — resolved by stat, never by tree walk.** Candidates are tokens that look like
   paths: inline code spans (`codespan` case at markdown.tsx:112) and plain-text tokens containing a `/`
   plus a file-ish last segment (`app/src/App.tsx`, `./x.md`, `~/…`, absolute). Batch every candidate in a
   document into ONE backend call and cache answers per (place, doc). Reuse `resolve_term_path`'s rules
   (canonicalise, must be a regular file, must be under a registered project root, `a/`/`b/` fallback) —
   do NOT fork a second resolver. Bases for relative paths: the markdown file's own directory first, then
   the place root. Either extend `resolve_term_paths` with an optional `bases`/`doc` argument or add a thin
   sibling command that calls the same `resolve_term_path`; keep `TERM_PATHS_MAX`-style capping (a big doc
   may need several batches — don't silently drop candidates past 64; batch them).
2. **Bare filenames (stage 2, same PR if it stays cheap):** an inline-code token with no `/` but a file
   extension (`App.tsx`, `quota.rs`) is looked up in a per-place basename index built from `git ls-files`
   (an index read, no directory traversal). One match → link. Several → the click opens a small dropdown
   (reuse `CtxMenu`, it already clamps/escapes) listing the candidate paths. Zero → plain text. Cache the
   index per place and rebuild on the Files tree's existing refresh signal, not per render. MEASURE
   `git ls-files` on this repo and on the biggest registered project and report the numbers; if it is not
   comfortably cheap, ship stage 1 only and say so in the PR.
3. Existing markdown `[text](href)` links keep their current behaviour (they already work — see
   "Codex support proposal" links in a preview). Do not linkify inside fenced code blocks in stage 1
   (too noisy); say in the PR whether you think fences should follow.
4. Plain left click on a resolved path should open it (this is prose, not a terminal — no ⌘ needed).
   Style: same link token the markdown links use, maybe dotted underline to distinguish "detected" from
   authored links. Hover title = resolved repo-relative path.
5. Unresolved/pending candidates render exactly as today — no layout shift when answers arrive beyond
   the link styling.

## Rules (repo + orchestrator)
- Read AGENTS.md first — especially: mock harness must track every new/changed command
  (`app/src/mock/install.ts`); HMR is dead inside `.worktrees/` (restart vite with `--force`); harness is
  Chrome, keep it off port 1420; a new test must be shown to FAIL first; drift/`*-check.mjs` scripts run
  from the REPO ROOT.
- Add a `app/scripts/*-check.mjs` or unit tests that pin: candidate extraction (what is / isn't a
  candidate), the batching, and that the resolver is the shared one. Rust unit tests for any new
  backend surface (`cargo test -p app --lib`).
- Verify in the mock harness by clicking a detected path in a markdown preview and confirming the file
  opens AND the tree reveals it. Never drive David's running app; sandbox only by pid.
- Throwaway tmux: `tmux -L <name>` on EVERY call; never a bare `tmux kill-server`.
- Scratch → `~/.cache/worktrees/worktrees/md-path-links/`. Never `git worktree add`.
- Run all gates from AGENTS.md (cargo build --release first). CHANGELOG entry under `## [Unreleased]`
  (count `### Added`/`### Fixed` headers after any rebase).
- No session URLs / Claude-Session trailers in commits or PR; keep Co-Authored-By.
- Open a PR, then message the orchestrator `(main)` with the PR number, gate results and the
  `git ls-files` measurements. Don't merge — a fable review runs first.
