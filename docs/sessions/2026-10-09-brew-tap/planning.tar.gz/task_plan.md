# Task: Homebrew tap for worktrees (CLI formula + app cask)

## Goal
`brew install penard-monkey/worktrees/worktrees` (CLI) and
`brew install --cask penard-monkey/worktrees/worktrees-app` (desktop app),
kept current automatically by release.yml, without fighting the app's own updaters.

## Phases
### Phase 1: Research + design — Status: complete
- [x] Inventory release assets, install.sh behaviour, app CLI-update path
- [x] Write findings.md + proposed layout

### Phase 2: Create tap repo — Status: pending
- [ ] `penard-monkey/homebrew-worktrees` (public; name MUST start `homebrew-`)
- [ ] Formula/worktrees.rb (prebuilt binaries, 4 targets, depends_on tmux)
- [ ] Casks/worktrees-app.rb (app tar.gz ×2 arch, auto_updates true, quarantine postflight)
- [ ] Hand-test: `brew install`, `brew test`, `brew audit --strict --tap`, `brew uninstall`

### Phase 3: Automate from release.yml — Status: pending
- [ ] New `homebrew` job after `release`: render both files from checksums.txt, push to tap
- [ ] Secret: fine-grained PAT (contents:write on the tap only) → `HOMEBREW_TAP_TOKEN`
- [ ] Skip on prerelease tags

### Phase 4: App/installer awareness — Status: pending
- [ ] `update_cli`: detect brew-managed CLI (path canonicalises into `/Cellar/`) → refuse, say `brew upgrade worktrees`
- [ ] install.sh: same detection, don't overwrite brew's symlink
- [ ] README install section + CLAUDE.md release step

## Decisions
- Tap repo separate from main repo (brew requires `homebrew-*` repo for short tap name).
- Formula `worktrees`, cask `worktrees-app` (distinct tokens, no --formula/--cask ambiguity).
- Cask `auto_updates true`: the in-app updater owns app upgrades; brew won't downgrade/fight.

## Open questions (for David)
- Tap under `penard-monkey`? Cask token name?
- Accept quarantine-strip postflight until notarization (ROADMAP) lands?

## Errors Encountered
| Error | Attempt | Resolution |
|-------|---------|------------|
