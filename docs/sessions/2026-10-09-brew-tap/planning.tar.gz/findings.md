# Findings — Homebrew tap

## Release assets (v0.30.0, public repo penard-monkey/worktrees)
- CLI: bare binaries `worktrees-{aarch64,x86_64}-apple-darwin`, `worktrees-{x86_64,aarch64}-unknown-linux-gnu` (+ .sha256; combined checksums.txt)
- App: `worktrees-app-{aarch64,x86_64}-apple-darwin.app.tar.gz` (+ minisign .sig, used by Tauri updater), latest.json
- Everything a formula/cask needs already exists; no new build artifacts required.

## install.sh
- Copies CLI to ~/.local/bin (override WORKTREES_INSTALL_DIR); app to /Applications or ~/Applications
- App is unsigned/ad-hoc → install.sh runs `xattr -cr` after checksum verify. A cask needs the same (postflight) until Developer ID + notarization (ROADMAP.md:943).
- Requires tmux → formula `depends_on "tmux"` does this properly.

## App update paths (conflict risk)
- cli_binary() (lib.rs ~2440) probes candidates incl. /opt/homebrew/bin/worktrees and /usr/local/bin/worktrees.
- update_cli (lib.rs:2507) runs install.sh with WORKTREES_INSTALL_DIR=<dir of resolved CLI>.
  With a brew CLI that dir is /opt/homebrew/bin, where `worktrees` is a SYMLINK into Cellar →
  install.sh would replace brew's symlink with a copy; brew then believes it has the old version,
  `brew upgrade`/`uninstall` operate on a Cellar the PATH no longer points at. MUST be guarded.
- In-app app updater (Tauri, latest.json) rewrites the .app in place → cask must declare
  `auto_updates true` so `brew upgrade` skips it (unless --greedy) instead of fighting.

## Homebrew mechanics (from knowledge; verify during Phase 2)
- Tap = GitHub repo named `homebrew-<name>`; `brew tap penard-monkey/worktrees` clones it.
  Layout: Formula/*.rb, Casks/*.rb. No review/approval from Homebrew needed for a 3rd-party tap.
- Homebrew has been tightening unsigned casks (`--no-quarantine` deprecated); 3rd-party taps
  still commonly strip quarantine in postflight. Verify current brew behaviour before relying on it.
- Formula shipping a prebuilt binary is fine in a personal tap (homebrew-core would require source builds).
