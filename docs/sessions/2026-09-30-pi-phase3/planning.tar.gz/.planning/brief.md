# pi phase 3 — pi on the bus, via pi's own MCP (research, then build)

## Why this lane exists
`docs/proposals/pi-harness.md` §4 planned pi's bus access WITHOUT MCP ("none in core,
by design"): new `worktrees msg report|list|wait` CLI verbs + a worktrees-owned skill
(`--skill`), optionally a `-e` extension; plus `send` to pi (§4.3). pi **0.99.1 now ships
MCP** (`pi mcp add/remove/list/login/logout`), so §4 is stale (ROADMAP says so). Phases 1
and 2 are merged and released in v0.33.0 (pi launches with `--model`, `--session-id`,
`--session-dir`, `--no-approve`/allowance `--approve`; activity from JSONL + screen;
refusal on a dead host). Read the proposal (Decisions, §3, §4, §8, §11 phase 3),
`docs/proposals/opencode-harness.md` §4 (opencode's MCP setup is the closest precedent),
the phase-2 session archive `docs/sessions/2026-09-29-pi-phase2/`, and AGENTS.md first.

## Two stages, two PRs
### Stage 1 — research → proposal update (docs-only PR, then STOP)
Rewrite pi-harness.md §4 (and §11 phase 3) from evidence. Answer:
1. How pi's MCP works on 0.99.1: config files (`~/.pi/agent/mcp.json`; project
   `.pi/mcp.json` only when trusted — confirm `--no-approve` really ignores it and that
   an allowed repo's `.pi/mcp.json` then CAN spawn commands: say what that means for the
   allowance), stdio vs HTTP, `--exposure` modes (codemode default, deferred, direct,
   hidden) — which one makes `report`/`messages`/`wait`/`place_status` usable by the model
   and how tool names appear; does `pi mcp list` LAUNCH servers (the `claude mcp list`
   trap in AGENTS.md); is there any per-launch way to add a server without writing
   mcp.json (flag, env, `PI_CODING_AGENT_DIR` is NOT acceptable for real lanes).
2. Does `worktrees mcp --mutations` work inside pi: handshake, cwd discovery (server
   cwd = the place?), `report`'s `from` derived correctly, `wait` blocking behaviour
   under pi's tool timeout, the `WORKTREES_MCP_PROVIDER` / provider-awareness paths in
   mcp.rs (does the server need to know it is serving pi?).
3. Setup UX, mirroring Claude/Codex: worktrees shells out to `pi mcp add worktrees --
   worktrees mcp --mutations` (user scope, never `-l`, never writes mcp.json itself —
   the `~/.claude.json` rule), detection by READING mcp.json (not `pi mcp list` if it
   launches), uninstall, Settings → pi + `worktrees mcp --install/--status --ai pi`,
   the after-update offer (`offers.ts`) if appropriate.
4. What of the old plan survives: are the `worktrees msg` CLI verbs still worth
   building (harness-neutral fallback) or dropped? The `-e` extension? Recommend.
5. `send` to a pi pane (§4.3 still stands? re-verify on 0.99.1): typed text inline,
   steering while busy, confirmation from the JSONL user entry, trust modal = refuse.
Update §4/§11 with [observed]/[source]/[inferred] marks, list open questions, open ONE
docs-only PR, and STOP. A review happens before stage 2.

### Stage 2 — build (after you are told stage 1 is merged)
Implement the agreed phase 3: MCP setup for pi, bus participation, `send` to pi with
confirmation, anything stage 1 decides. Split PRs if large (core/CLI/MCP, then app).
CHANGELOG under `## [Unreleased]` with bold leads (exactly one `[Unreleased]`, one of
each `###`). Gates per AGENTS.md, grep-reported; new tests shown to FAIL first; `ls
--json` byte-identical vs the shipped v0.33.0 binary for existing places. Open PR(s),
watch CI to completion with `gh run watch <id> --exit-status`, then STOP.

## Machine facts (2026-09-29)
- pi 0.99.1 managed install; pi-node → Homebrew node 26.10. `~/.pi/agent/mcp.json`
  does not exist yet. Model: `lm-studio/qwen3.6-27b` (Tailscale host). Kimi is not
  signed in. **Codex is out of tokens** — no Codex sessions; Codex paths by unit test.
- Live pi launches in YOUR session need David's approval in this session (the safety
  check blocked phase 2's until he approved there). If blocked, stop and say exactly
  which command.

## Rules
- Never write `~/.pi/agent/mcp.json` or any `~/.pi` config by hand. For probes use a
  THROWAWAY agent dir (`PI_CODING_AGENT_DIR` under ~/.cache/worktrees/worktrees/<this
  worktree>/) — and a real `pi mcp add` into David's global config only if David
  explicitly approves it in this session. Never open auth.json. List every file pi
  creates under ~/.pi.
- Throwaway tmux servers (`tmux -L <name>`, killed after), scratch repos, lm-studio only.
- Do NOT drive David's running app. Mock harness on a port ≠ 1420.
- Do not merge anything. Scratch in ~/.cache/worktrees/worktrees/<this worktree>/.
  Keep Co-Authored-By; NO session URLs or Claude-Session trailers.
