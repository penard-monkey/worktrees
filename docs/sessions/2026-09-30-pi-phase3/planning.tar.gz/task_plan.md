# pi phase 3 — stage 2 build

## PR1 core/CLI/MCP (branch pi-phase3-core)
- [x] f. trust::pi_flag protect-ours (+ ai_launch_for warn, doctor --pi line)
- [x] d. pimcp.rs + `mcp --ai pi` + usage text + bats
- [x] c. trusts_claude_project_dir allowlist + bats + unit
- [ ] show bats c/d failing first
- [ ] a. stdin reader thread + cancel (pending/cancelled ids), no response after cancel
- [ ] b. progressToken + request id → wait emits numeric progress every 15s (injectable)
- [ ] e. SendOutcome::Queued, pi send (idle → JSONL, busy → Steering), fixtures pi-send/0.99.1, drop refusals
- [ ] BUG1 (own commit): pi reader uses newest *.jsonl in pinned dir with header cwd == place; session_present/resume the real file (check main.js --session vs --session-id + model)
- [ ] DEC2 (own commit): read ~/.pi/agent/trust.json per 0.99.1 ProjectTrustStore; precedence protect-ours > explicit untrusted (no approve) ... > allowance grants > pi trusted → approve > else no-approve. Settings→pi show match, doctor --pi, docs Decisions/§8, CHANGELOG
- [ ] docs/pi-manual-checks.md MCP section; CHANGELOG [Unreleased]
- [ ] gates, ls --json vs ~/.local/bin/worktrees (v0.33.0), live probe (throwaway), PR, CI watch

## PR2 app
- [ ] Settings → pi "Worktrees tools" block (pi_mcp_status/install/uninstall), mock, offer pi-mcp + offers-check, allowance wording, pi trust match display, Plan-tab paste refusal removal
