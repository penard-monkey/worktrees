# findings — `.worktreeinclude` evaluation

## What we actually have (shipped, v0.3.x)

`.worktrees.toml`, committed at repo root. Three independent sections
(proposal principle #1: each stands alone):

| Section | Job |
|---|---|
| `[[file]]` | one entry per gitignored path, `mode = "link"` (default) or `"copy"` |
| `[ports]` | `stride`, `max_slots`, `base = { NAME = n, … }` → slot k → `<NAME>_PORT` |
| `[compose]` | `files = [...]` (ordered), `project = "{prefix}-wt-{slug}"` |

Emits tool-owned `.worktree.env` (`WORKTREE_SLOT`, `COMPOSE_PROJECT_NAME`,
`<NAME>_PORT`) — a **public wire format**, sourced as shell by consumers.

Code: `crates/worktrees-core/src/{projcfg,materialize,provision,init,diag}.rs`.
`materialize.rs` = probe (only FS read) / plan (pure) / apply (only FS write).
Docs: `docs/proposals/project-settings.md` (843 lines, §14 lists prior art
consulted: direnv, mise, lefthook, devcontainer.json, git-worktree).

## Why not a `.gitignore`-style `.worktreeinclude` glob list

Not recorded as an explicitly rejected alternative in §14, but every design
principle rules it out:

1. **No place for `mode`.** link-vs-copy is load-bearing, not cosmetic:
   cdv's `apps/backoffice/.env.local` is rewritten at runtime by
   `deploy-local.sh`; a link would scribble on the main checkout AND on every
   sibling worktree. A path-only line cannot say that.
2. **Globs cannot fail loud** (principle #5 — the bug being fixed is silence).
   An explicit `path = "apps/mobile/google-services.json"` missing from main is
   a *warning* with an exit code. A glob that matches nothing is
   indistinguishable from a glob that matched everything it should.
3. **Security surface.** Layer A (`projcfg::RelPath`, literal-string rules at
   parse) + Layer B (resolved-path containment at apply, catches committed
   symlinks to `~/.ssh/id_rsa`). A glob expands against a *hostile clone's*
   directory tree — `**` re-opens B3 through a set nobody wrote down.
4. **Two-thirds of the file isn't files.** `[ports]` + `[compose]` need
   structure regardless. `.worktreeinclude` + `.worktrees.toml` = two parsers,
   two discovery paths, one more way to disagree — for zero new capability.
5. **Per-entry comments are the file's teaching job** (§3). The cdv config is
   mostly `# why this is a copy` prose citing `worktrees.sh` line numbers.

## The glob use case is already served — at authoring time

`init.rs`: `walk(main_root)` → `classify(name)` → `keep_gitignored_untracked`
(shells `git check-ignore` + `ls-files`) → `render()` emits explicit
`[[file]]` entries. Anything it can't confidently declare is emitted
**commented out with the reason** rather than dropped.

So the discovery-by-pattern step exists; its output is a reviewed, explicit
list. That is the correct place for a glob — resolved once by a human, not
re-resolved on every `new` against whatever happens to be on disk.

## Gap A — the config is write-once. Detection never runs again. (real, sharp)

Three independent code paths, all confirmed by reading:

1. **`ops.rs:373-380`** — `hint_init` sits inside `match project_cfg { None => …
   }`. The passive nudge on `new` runs **only for repos with no
   `.worktrees.toml`**. Write the config once and that arm is unreachable
   forever. Comment even says so: "the ONLY thing a config-less repo gains
   here."
2. **`ops.rs:1666-1672`** — `cmd_init` hard-refuses (exit 1) when the config
   exists: *"already exists — refusing to overwrite it. Edit it by hand, or:
   worktrees init --force"*. `--force` re-renders from scratch → destroys every
   hand-written `# why this is a copy` comment, every hand-set `mode = "copy"`,
   every hand-tuned `[ports] base`. For the cdv config that is ~80% of the file's
   value. So `--force` is not usable as a re-scan.
3. **`materialize::probe`** iterates **config entries only**. There is no code
   path anywhere that asks "what gitignored file is on disk and NOT declared."
   `doctor` cannot see it. `Code` (diag.rs:50) has 17 slugs, none of them for it.

### The concrete failure

Dev adds `apps/newsvc/.env` to cdv main. Gitignored, untracked.

- Every existing worktree lacks it. Every new worktree lacks it.
- `worktrees doctor` → **clean, exit 0**.
- `worktrees new` → **no hint** (config exists).
- `worktrees init` → **exit 1, refuses**.

That is byte-for-byte the §1.2 silent-failure the whole feature exists to kill —
just displaced from "no config" to "stale config". And stale-config is the
steady state of any repo older than a month.

### The one workaround that exists today

`print_only` bypasses the refusal (ops.rs:1667 `&& !print_only`), so:

```sh
worktrees init --print | diff - .worktrees.toml
```

Works, but the renderer emits the full file with banner prose, so the diff is
~90% noise and misses nothing only by accident. Nobody will run it.

### Fix shape (small — the expensive half already exists)

`init::probe_files(main_root)` (init.rs:598) is already the standalone file half:
one bounded BFS walk (`MAX_DIRS`/`MAX_ENTRIES`/`MAX_HITS`/`MAX_DEPTH`, skips
hidden + vendor dirs, never follows symlinked dirs) + two `git -z` calls
(`check-ignore --stdin`, `ls-files`). **No file is opened.** Cheap enough that
`new` already runs it on a hot path.

So: `probe_files` → set-subtract `cfg.files` rel set → leftovers are undeclared.

Four decisions the build needs:

- **New `Code::Undeclared`.** Closed enum, so it is a one-line add + the
  kebab-slug round-trip test at diag.rs:224.
- **Severity split.** `Kind::Credential` → `Warn`; `Kind::Env` → `Info`. Mirrors
  the existing hint rationale (§12: missing `.env` breaks loudly next command,
  missing `google-services.json` dies on a device days later).
- **Exit code.** `Report::exit_code` (diag.rs:187) returns 2 **only on `Error`** —
  warns exit 0. So undeclared-as-warn will NOT fail §7's "doctor in CI". Either
  accept that (drift is advisory) or add an `--undeclared-is-error` /
  `--strict` flag. Do not silently promote it to `Error`; that breaks every
  existing CI that pins on exit 0.
- **Scope wrinkle.** `Finding::at_place` assumes per-place. Undeclared is
  **repo-scoped** — emit once, not once per place, or `doctor --all` prints it N
  times. Needs a repo-level findings slot in the report, or dedupe at render.

Also worth adding: `worktrees init --diff` (render only the stanzas that are
missing, ready to paste) — the ergonomic other half. Optional; the doctor
finding alone closes the correctness hole.

## Gap B — monorepo `[[file]]` volume (weak; don't build)

cdv's real config is **6 `[[file]]` stanzas**. Not painful. Gap only bites a repo
with `packages/*/.env` × N for large N — no such repo in evidence here.

And a glob at apply time costs the two things that make the format work:
`mode` per entry, and "declared but missing = warning". Gap A's `init --diff`
gives the same ergonomics with neither cost — human reviews the expansion once,
config stays explicit.

## Gap C — the never-list ADR (cheap, unwritten)

§12 last line: *"**Never — `[hooks]`, `[infra] up/stop/down`.** §5. Record as an
ADR so this does not get quietly re-added in six months."* Six months from the
proposal is roughly now. The reasoning is principle #3: nothing a cloned repo
contains may become argv. Currently that constraint lives only inside an
843-line proposal doc labelled with a phase table that reads ✅ BUILT — i.e. it
reads as finished history, not as a live rule. One `docs/adr/` file.

## Non-gap, recorded so it isn't rediscovered as a bug

**Two dismissal stores** — CLI `$XDG_STATE_HOME/worktrees/init-hints/<fnv1a of
canonical repo path>` (content = digest of what was detected, not a boolean, so
a new credential re-suggests), app `ui-state.json`. Deliberate (§12): unifying
would mean the CLI reading an app-owned file. Note the app calling `cmd_new`
in-process **shares** the CLI marker; only the app's own banner needs the second
store.

## Verdict

No redesign. `.worktreeinclude` would be a strict downgrade: loses `mode`,
loses fail-loud, widens the security boundary, and covers only one of three
sections. The docker/ports half the user flagged is exactly the reason the
format is TOML and not a line-oriented include file.
