# progress

## Session 1 — 2026-08-02

**Asked:** why not `.worktreeinclude`, should file sharing be redesigned.
**Answered:** no — see `findings.md`. Then built follow-up A.

### Built — undeclared drift detection

| File | Change |
|---|---|
| `diag.rs` | `Code::Undeclared` + kebab round-trip test entry |
| `init.rs` | `probe_files_bounded`, `undeclared_in` (pure), `undeclared`, `render_undeclared`, `declarable`; 6 unit tests |
| `ops.rs` | `undeclared_findings`, wired into `cmd_doctor`, `--strict` promotion, `init --diff` → `init_diff` |
| `worktrees-cli/main.rs` | usage lines for `init --diff` and doctor |
| `test/doctor.bats` | 3 tests (reported / repo-scoped once / not in `--config-only`) |
| `test/init.bats` | 3 tests (fragment / no-config fallback / rejected path commented) |
| `CHANGELOG.md` | Unreleased → Added ×2 |
| `docs/proposals/project-settings.md` | §12 "v4 — undeclared drift ✅ BUILT" |

### Behavior

- `doctor` (whole-project runs only) reports gitignored+untracked files in main
  that no `[[file]]` declares. Warn = credential, Info = `.env*`. `place: null`.
- Exit 0 by default; `doctor --strict` promotes Warn → Error, alongside
  `copy-stale`. Deliberate: promoting by default breaks CI pinned on exit 0.
- Excluded from `--config-only` — that mode is config-vs-git on a bare clone,
  where every gitignored file is absent by definition.
- Excluded from `doctor <name>` — a named place is a question about that place
  (same rule the session scan follows).
- Walk truncation surfaces as an Info finding; an empty result from a truncated
  walk must not read as an all-clear.
- `init --diff`: appendable fragment on stdout, prose on stderr, writes nothing.
  Round-trip guarded through `projcfg::parse` like `cmd_init`. No config at all
  → falls back to `--print` with a note.

### Gates — all green

```
cargo build --release -p worktrees-cli   ok
make test                                247 ok, 0 not ok   (was 241)
make lint                                shellcheck + bash-3.2 gate clean
cargo test -p worktrees-core             143 passed
cd app && tsc --noEmit                   clean
cargo check -p app                       clean
cargo clippy --all-targets               only the pre-existing shell_open warning
```

### Environment notes (not code problems)

- `test/lib/bats-*` submodules were uninitialized in this worktree —
  `git submodule update --init --recursive`.
- Shell `grep` in this session silently returns nothing on some files; use
  `/usr/bin/grep`.
- `corepack pnpm` fails with a keyid signature error; homebrew `pnpm` 11.1.1
  under node 22.13.0 (`.nvmrc`) works.
- `cargo fmt --check` is dirty repo-wide on files this branch never touched —
  not a gate in CLAUDE.md, left alone.

### Not done, by decision

- Gap B (glob `path` inside `[[file]]`) — costs `mode` and fail-loud, and
  `init --diff` covers the ergonomics. See `findings.md`.
- Gap C (ADR for the `[hooks]`/`[infra]` never-list) — still open, cheap.
- No app surface for `init --diff`; the app renders the new finding already
  (`ProjectSheet.tsx` maps all findings; `place: null` correctly marks no row).
