# task_plan — A: undeclared-file drift detection

**Goal:** `doctor` (and `init`) can see gitignored files on disk that
`.worktrees.toml` does not declare. Closes the write-once hole: today the
config is authored once and detection never runs again.

**Verdict on the original question (done):** keep `.worktrees.toml`, no
`.worktreeinclude`. See `findings.md`.

| # | Phase | Status |
|---|-------|--------|
| 1 | Recon: `Code`/`Report`, `cmd_doctor`, `projcfg::ProjectConfig`, render path | complete |
| 2 | `Code::Undeclared` + kebab round-trip test | complete |
| 3 | Repo-scoped findings slot (emit once, not per place) | complete — `Finding.place` was already `Option`, so no new slot; `undeclared_findings` just never calls `at_place` |
| 4 | `undeclared()` in `init.rs`: `probe_files` − declared rels | complete |
| 5 | Wire into `cmd_doctor`; severity split Credential=Warn / Env=Info | complete |
| 6 | `worktrees init --diff` — render only missing stanzas | complete |
| 7 | Unit tests + bats | complete — 6 unit, 6 bats |
| 8 | Gates: build release, `make test`, `make lint`, `cargo test -p worktrees-core`, app tsc+check | complete — all green, see `progress.md` |
| 9 | CHANGELOG + PR | complete — PR #77, OPEN, mergeable, CI green |

## Merge readiness (2026-08-02)

Was **CONFLICTING** — main moved to v0.8.0 (dock document rendering, #78) while
this branch sat. Rebased onto `origin/main`; one conflict, `CHANGELOG.md`:
my `[Unreleased]` block vs the new `## [0.8.0] - 2026-08-03` section. Resolved
by keeping both — Unreleased on top, 0.8.0 below. The `CLAUDE.md` overlap
auto-merged (main edited the tokens bullet, this branch added `## Decisions`).

Gates re-run on the rebased tree, all green. Force-pushed with `--with-lease`.
CI: 9/9 SUCCESS (lint · rust ×2 · test ×2 · install ×2 · app ×2).
`mergeable: MERGEABLE`, `mergeStateStatus: CLEAN`.

## Fable review (2026-08-02) — 6 findings, no severe ones

Reviewer independently re-ran the gates and read the proposal. Verdict: safe to
merge; nothing mis-reports a declared file as undeclared or vice versa.

| # | Finding | Action |
|---|---------|--------|
| 1 | Docs said `--strict` promotes Undeclared, unqualified — it promotes only the Warn (credential) half; an undeclared `.env*` is Info and can never fail | fixed — CHANGELOG + `Code::Undeclared` docstring now say which half |
| 2 | Truncation finding reused `init`'s `TRUNCATED` ("add anything **it** missed" — no referent in a doctor report) and read as a file finding, so a `--json` file count is off by one | fixed — own doctor-phrased message that says it is not about a file |
| 3 | `init --diff` silently swallowed `--force`/`-y`/`--print` | fixed — usage error, exit 1, `doctor --config-only <name>`'s guard shape, + bats |
| 4 | All-rejected `--diff` said "0 undeclared entries. Append to…" | fixed — aside emitted only when something is appendable |
| 5 | DESIGN.md banner claimed every affected section was marked; 5 sites inside otherwise-current sections were not | fixed — all 5 marked |
| 6 | `WORKTREES_NO_PROJECT_CONFIG=1` + config present: `init --diff` says "No .worktrees.toml" while plain `init` refuses | accepted — matches how `doctor` already describes the switch ("ignored == not there") |

Verified fine by the reviewer: the case fold coupling (`to_lowercase` ≡
`fold_key`, tested), zero-`[[file]]` configs, the audit switch on doctor, the
depth-1 `--print` recursion, fragment validity when all-rejected, repo-scoped
emission (structurally enforced), determinism of walk order, ADR claims against
the actual code, and that no new test is vacuous.

Third commit `54ccd71`. Gates re-run: 248 bats (+1), 143 core, lint clean,
clippy adds nothing (all 5 warnings pre-existing, in untouched files).
CI 9/9 SUCCESS, `MERGEABLE` / `CLEAN`.

Not merged — waiting on the go-ahead.

## Phase C — ADR for the never-list (in progress)

§12: *"**Never — `[hooks]`, `[infra] up/stop/down`.** §5. Record as an ADR so
this does not get quietly re-added in six months."*

⚠ Found while starting: the re-add vector is not hypothetical. **`DESIGN.md`
still carries the reversed design as if it were live** — `[infra] up/stop/down`
with `sh -c` strings (l.215-240), a per-place `up_cmd` override (l.174),
`worktrees up/down` verbs (l.93-94), `infra_up/stop/down` Tauri commands
(l.328), and a **first-run trust prompt** for "repo-authored strings run via
`sh -c`" (l.344, l.401). CLAUDE.md points readers at DESIGN.md as the app's
design doc. An ADR alone would be a third buried file; DESIGN.md needs
superseded markers pointing at it.

| # | Step | Status |
|---|------|--------|
| C1 | `docs/adr/0001-no-repo-supplied-argv.md` | complete |
| C2 | Superseded markers in DESIGN.md at each infra/trust-prompt site | complete — 6 sites + a header banner |
| C3 | Cite enforcement points so a re-add trips a test, not a review | complete — table in the ADR |
| C4 | Gates + PR | complete — 2nd commit on PR #77, title/body updated |

Also pointed at the ADR from `CLAUDE.md` (new "## Decisions" section) and from
the proposal's §12 "Never" line.

Enforcement already in the code (the ADR's teeth):
- `projcfg.rs:44` `USER_ONLY_KEYS` — includes `hooks`, `infra`, `post_create`,
  `ai_cmd`, `ai_resume_arg`, `install_cmd*`, `no_install`.
- `projcfg.rs:427` `is_user_only` — prefix match on `install_cmd*`, so a future
  `install_cmd_pnpm` is refused on arrival.
- `projcfg.rs` test `a_user_only_key_is_a_hard_error_that_points_at_the_user_config`
  — asserts `[hooks]` and `[infra]` are hard errors at any nesting depth.
- `provision.rs:554` `compose_down` — argv assembled from validated paths + a
  sanitized name; no command string from the repo exists to run.
- `projcfg.rs:366` `WORKTREES_NO_PROJECT_CONFIG=1` — the audit switch.

## Decisions taken (from findings.md analysis)

- **Severity:** `Kind::Credential` → `Warn`, `Kind::Env` → `Info`. Mirrors the
  existing `hint_init` rationale (§12): a missing `.env` breaks loudly on the
  next command; a missing `google-services.json` dies on a device days later.
- **Exit code:** `Report::exit_code` returns 2 only on `Error`, so undeclared
  exits 0. KEEP that — promoting to `Error` breaks every CI pinned on exit 0.
- **Scope:** repo-scoped, emitted once. `Finding::at_place` is per-place;
  `doctor --all` must not print this N times.
- **NOT doing:** glob `path` in `[[file]]` (gap B). Costs `mode` + fail-loud.

## Errors Encountered

| Error | Attempt | Resolution |
|-------|---------|------------|
| `(eval):1: no matches found: --include=*.rs` | 1 | zsh glob expansion — quote the flag |
