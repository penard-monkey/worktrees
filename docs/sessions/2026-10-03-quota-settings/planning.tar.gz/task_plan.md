# Task plan — quota settings

## Goal
User can turn the launch quota gate off, and set the weekly % it refuses at.

## Phases
- [x] 1. Survey + design (findings.md)
- [x] 2. Core: QuotaCfg reader + weekly-aware gate + refusal remedy (tests fail-first)
- [x] 3. Core: setter for `[quota]`; `quota` in USER_ONLY_KEYS
- [x] 4. bats: off + threshold cases
- [x] 5. App: commands, QuotaSection in Behavior, mock, check script
- [x] 6. Gates, ls --json diff, CHANGELOG
- [x] 7. PR, CI watch, report to (main)
