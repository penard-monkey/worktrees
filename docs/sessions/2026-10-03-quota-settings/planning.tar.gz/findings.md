# Findings — quota settings (turn the launch gate off / set a weekly %)

## Survey

- **One surface warns/refuses on usage: the launch gate.** `quota::gate`, called
  from `Adapter::prepare` for Claude and Codex (`harness.rs:319,407`), reached
  by CLI `new`/`open`, the app's launch (in-process core), and MCP
  `create_worktree` (which runs `new` under the hood). Refusal = `Refusal::Soft`
  → exit 5, "Launch anyway", `force: true`.
- The app's **usage meter** (`App.tsx` ~2420/2480) tints bars by the provider's
  `severity`. That is a GAUGE, not a warning about launching; it does not stop
  anything. No offer/toast keys on usage.
- Windows as core sees them (`harness.rs` `windows_from_*`):
  - Claude: `kind` = `session` | `weekly_all` | `weekly_scoped` (labels
    `Session`, `Weekly`, model name e.g. `Fable`). `kind` is the robust signal.
  - Codex: `bucket_label` is the bucket NAME (`Codex`), not the span; the span
    is `window_minutes` (`windowDurationMins`, 300 / 10080 observed). The label
    string says nothing about weekly — matching "7d" would be wrong.
- Config: `config.toml` user tier. Writers exist with the right pattern:
  `reach::set_user_level_at` (top-level key, in-place, re-parse to verify,
  tmp+rename) and `trust::with_allowed` (a `[trust]` table). `projcfg`'s
  `USER_ONLY_KEYS` turns a repo key into a hard parse error.
- App: `set_cross_project` command + `CrossProjectSection` is the pattern.
  Settings categories: Behavior holds launch/startup behaviour.

## Design (decisions)

1. **Config** — `[quota]` table in `~/.config/worktrees/config.toml`:
   ```toml
   [quota]
   gate = true             # false: never refuse a launch on usage
   weekly_warn_pct = 90    # 1–100; absent = the provider's own grade
   ```
   `quota` joins `USER_ONLY_KEYS` (a repo must not set your spending policy).
2. **Rule** (one knob, the brief's lean):
   - `gate = false` → no refusal on any window. Nothing else changes.
   - `weekly_warn_pct` absent → today's behaviour exactly (provider grade on
     every window).
   - `weekly_warn_pct = N` → a WEEKLY window refuses iff `percent >= N`,
     whatever the provider graded it (both directions: 81% `warning` at N=90
     allows; 85% `normal` at N=80 refuses). Non-weekly windows (5h session)
     keep the provider's grade.
3. **"Weekly" is structural, never a label match.** `Window.weekly: bool`:
   Claude `kind.starts_with("weekly")`; Codex `window_minutes > 24h` (a long
   window — 10080 today; a span the reader cannot see is NOT weekly, so it
   keeps the provider grade = today's behaviour). Fixture: `"weekly": true`.
4. **Invalid values** (hand-edited): reader stays lenient like the rest of
   `config.rs` — a bad `gate` is the default (on), a bad pct is absent
   (provider grade) — but the problem is REPORTED, not swallowed: the status
   carries `problem`, shown in Settings. Setter refuses out-of-range with a clear
   error. Rationale: a typo must not lock you out of launching, nor silently
   turn the gate off.
5. **Read at gate time**, not at server start: a long-lived MCP server and the
   app pick a change up on the next launch, no restart.
6. **Refusal names the remedy**: "…not starting another agent on it (<rule>;
   change it in Settings → Behavior → Plan limits, or `[quota]` in
   ~/.config/worktrees/config.toml)."
7. **Meter tint is NOT governed** — it shows the provider's reading; turning the
   gate off must not make a gauge lie. Stated in the Settings hint.
8. App: `quota_settings` / `set_quota_settings` commands, `QuotaSection`
   (module scope, own file) in Behavior: checkbox + a select ("Provider's
   warning" | 50…100) disabled when the gate is off. Mock tracks both.
