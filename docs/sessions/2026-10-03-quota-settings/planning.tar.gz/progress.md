# Progress — quota settings

2026-10-03
- Design in findings.md (one weekly knob; gate off; meter not governed).
- Core: 1ceccde policy + weekly flag + refusal remedy; 3cb6331 setter + USER_ONLY_KEYS.
  Fail-first: threshold test red before `trips` wired; mutations (no gate check,
  threshold on all windows, label-based weekly for Claude/Codex, quota not
  user-only, setter keeping old keys) each turned exactly their test red.
- bats 4a9f32b: 8 new cases; all 8 FAIL on shipped 0.36.1, 22/22 pass on branch.
- App 60ebf3b: Plan limits panel in Behavior, mock, quota-check.mjs (shown red on
  3 mutations). Driven in mock harness: renders, problem line, 90% write, gate
  off disables + dims select, initial off state.
- Docs adac3aa: README + CHANGELOG (one ### Added).
- Mistake: a `git checkout <file>` to undo a mutation also reverted my
  uncommitted SettingsSheet edit; re-applied. Restore from a backup copy instead.
- PR #437 opened; CI run 37171900351 green (9/9); report sent to worktrees-(main). Not merged.
- Review round 1 (from (main)): dea1283 config::edit_user_config (symlink-through, mode kept, lock) for quota/reach/trust;
  1947ad5 CRLF+inline comments, gate_with seam + panicking-adapter test, [quota.sub], real config path in refusal, --txt-dim problems line.
  All fail-first shown. Gates green (472 bats), CI 37173536571 green. Reply sent. Not merged.
