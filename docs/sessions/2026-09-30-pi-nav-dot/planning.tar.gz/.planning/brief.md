# Fix: pi lanes never show a nav dot in the app (busy / waiting / done)

## The bug (verified 2026-09-30 on v0.34.0)
valleos `charterpanel-write-spec` is a pi lane (tmux `valleos-charterpanel-write-spec~agent~pi`,
pane `node`, launched by worktrees with `--session-id …-b1e58b-g1`, its session file present with
that exact id, screen showing `── ⠋ Working ──`). Core is RIGHT: `worktrees mcp` `place_status`
returns `agent_state: busy`, provider pi, the model. The APP's nav shows no dot.

Cause: the app's dot poll in `app/src-tauri/src/lib.rs` (~7835-7880) builds `sessions:busy`
from `claude_activity()` (Claude probes) + `codex_tick(&fp)` (Codex rollouts), merged by
`merge_activity`, then `completion_edges` → `sessions:done`. **pi contributes nothing.** Phase 2
(#366/#367) wired pi into core `activity`/`place_status` but never into this poll; nothing
tested the app's dots against pi. The same gap means no afterglow/`sessions:done` for pi, and
possibly no re-list when a pi model/session moves.

## Task
1. Read the poll end to end (claude_activity, codex_tick, merge_activity, completion_edges, the
   `models_moved` re-list trigger, what the frontend does with `sessions:busy`/`sessions:done`,
   how it matches a place — by cwd path) and core's pi reader (`worktrees_core::pi`: session dir,
   `current_session` newest-file rule, activity/state, `session_runs_program`, screen fallback for
   the first-turn/startup gap and the trust modal = waiting).
2. Add a pi tick to the poll: for every live `~agent~pi` session, derive busy / waiting / done the
   SAME way `place_status` does (one derivation — AGENTS.md: keep the nav dots and MCP on one
   reader), feed busy/waiting into `merge_activity` and completion edges into `sessions:done`, and
   trigger a re-list when a pi lane's model or session changes (like `codex_models_moved`). Keep it
   cheap: per tick, stat + tail-on-growth, no pane capture unless the file can't answer (startup
   gap / trust modal), and no capture storm across many pi lanes.
3. Consider generalising: the poll is now three hand-written branches; if a small per-adapter hook
   (e.g. `Adapter::nav_activity`) removes the pi special case cleanly, do it — but no behaviour
   change for Claude/Codex (their dots must be byte-for-byte the same sets).
4. Tests shown failing first: a unit test that the merged sets include a busy pi cwd (fixture
   session file + stubbed pane), and a drift/check guarding that every harness in `PROVIDERS`
   feeds the poll (so the NEXT harness can't miss it the same way). Mock: make the harness able
   to show a pi dot. Gates per AGENTS.md (grep-reported), `ls --json` byte-identical vs the shipped
   v0.34.0 binary. CHANGELOG `### Fixed` under a new `## [Unreleased]` (exactly one of each).
5. Live check (read-only): the running valleos pi lanes exist — you may READ their tmux state and
   session files to confirm your derivation says busy/idle correctly, but do NOT send keys to them,
   do NOT drive David's running app. A throwaway tmux server + fake/probe pi session is fine for
   anything interactive.
Open a PR, watch CI with `gh run watch <id> --exit-status`, report, STOP (don't merge).

## Rules
Codex is out of tokens (no Codex sessions). Scratch in ~/.cache/worktrees/worktrees/<this worktree>/.
Keep Co-Authored-By; NO session URLs or Claude-Session trailers.
