# findings — drag & drop for places + projects

## Where things live today

| Thing | Location |
|---|---|
| Nav tree render | `app/src/App.tsx` — `ProjectNode` (2677), `PlaceRow` (2631), `GroupHeader` (2669) |
| Bucketing | `bucketOf` (App.tsx:112) — `declared.pinned ? "pinned" : lifecycle_effective` |
| Tier lists | `LIVE_TIERS` = pinned/active/idle; `DORMANT_TIERS` = saved/closed/archived/abandoned (App.tsx:95) |
| Sorting | `sortPlaces` (2303) — recent / alpha / manual |
| Manual order | `settings.manual_order: Record<repoRoot, slug[]>` (settings.ts:143) — ONE flat array per repo; each bucket sorts by it |
| Existing drag | `dropOnRow` (2319) + `PlaceRow` HTML5 DnD attrs (2642-2647); `drag`/`dragOver` state (1257) |
| Drag CSS | `App.css:619` — `.row.dragover { box-shadow: inset 0 2px 0 accent }` (a line, not a gap) |
| Project order | `projects.json` in app config dir, **backend-owned** (`read_projects`/`write_projects`, lib.rs:343-355); `list_workspace` returns roots in file order |
| Lifecycle write | `set_lifecycle` cmd (declared label) / `patchDeclared` for `pinned` |

## THE constraint: half the tiers are DERIVED, not settable

`store::reconcile` (crates/worktrees-core/src/store.rs:101):

```
declared archived|abandoned|saved  → that label (sticky)
else tmux up                       → "active"
else last_opened_epoch < IDLE_WINDOW → "idle"
else                               → "closed"
```

So per drop target:

| Target group | Settable? | Drop means |
|---|---|---|
| **Pinned** | yes | `patchDeclared {pinned:true}` (lifecycle label untouched) |
| **Active** | NO — pure `tmux_up` | nothing to set. Either reject the drop, or reinterpret as "open the place" (spawns tmux) |
| **Idle** | NO — derived from `last_opened_epoch` | best available = unpin + clear declared label. Result may derive to **active** or **closed**, i.e. the row does NOT land where it was dropped. Faking it by writing `last_opened_epoch = now` would lie to the Recent lens and `activityAt`. |
| **Saved / Closed / Archived / Abandoned** | yes | `set_lifecycle` (existing `SETTABLE` list) |

`pinned` outranks lifecycle in `bucketOf`, so a pinned+archived place renders under Pinned. Dragging it to Archived = "unpin" only.

## Empty groups do not exist in the DOM

`LIVE_TIERS.filter(g => buckets[g]?.length …)` (2758) — a tier with zero rows renders nothing. Dormant subgroups likewise (2781). **You cannot currently drop into an empty Pinned/Archived group.** Drag must render placeholder drop-zones for eligible-but-empty tiers while a drag is live.

Also: `settings.hidden_tiers` can hide a tier entirely → a lifecycle change can make the row VANISH with no feedback.

## HTML5 DnD is a known trap here

- `tauri.conf.json:19` sets `"dragDropEnabled": false` — the window-level OS file-drop had to be turned OFF for in-webview HTML5 DnD to work at all (WKWebView-only behavior). Side effect: dropping a folder from Finder onto the app to add a project is unavailable while that stays false.
- ROADMAP.md:307 records that manual-sort drag is **not verifiable in the mock harness** — it needed a real-app smoke. Playwright's DnD does not drive WKWebView's dataTransfer reliably.
- Inserting a gap under the cursor changes hit-testing → `dragenter`/`dragleave` thrash. Insertion index must be computed from pointer Y against **cached row rects**, not from per-row dragenter.

⇒ Pointer-events (pointerdown + threshold + pointermove) is the stronger base: testable in Playwright (`browser_evaluate` dispatching pointer events), gives us the gap animation, auto-scroll, and spring-open for free, and does not depend on `dragDropEnabled`.

## Race / refresh hazards (CLAUDE.md's three v0.12.x bugs live here)

- The mock resolves invokes in a microtask; the real `list_workspace` is a git fan-out (0.28s for one project × nine worktrees). Every drop = optimistic local mutation + confirming refresh. Must go through the existing `mutate` / `patchDeclared` / `refreshSeq` discipline and be checked with `node app/scripts/race-check.mjs`.
- `patchDeclared`'s own doc-comment (App.tsx:1970) warns: it is ONLY for fields the backend copies through verbatim — **NOT lifecycle**, which is reconciled server-side. A drag into Archived must go via `set_lifecycle` + `mutate`, not a `patchDeclared` guess.
- `ui-state.json` is written WHOLE-BLOB by the frontend — the backend must never write it. Project order therefore belongs in `projects.json` (backend) via a new command, not in settings.

## Misc

- Main (`◆`) row is excluded from buckets and from drag today — keep it non-draggable AND non-droppable.
- Cross-project place drags are meaningless (different repos); current `drag.repo !== repo` guard rejects them silently — should show a no-drop cursor instead.
- Flat lenses (Recent/Attention, `FlatLens` 2799) mix projects and order by activity — no drag there.
- `manual_order` is only consulted in `sort_mode === "manual"`; a **tier change** is not an ordering change, so it must work in all three sort modes.
