# progress

## Session 2026-08-14 — planning drag & drop (places between tiers, project reorder)

- Branch `reorder-places-projects`, clean at `7f3a4cb`.
- Read the nav tree, sorting, manual_order, lifecycle reconcile, projects.json.
- Wrote `findings.md` (constraints) + `task_plan.md` (7 phases, 5 open decisions).
- Key discovery: Active and Idle tiers are DERIVED (`store::reconcile`), so they
  are not writable drop targets — this shapes the whole feature.
- Second discovery: HTML5 DnD here already cost a `dragDropEnabled:false`
  workaround and is untestable in the harness (ROADMAP:307) → proposing pointer
  events instead.
- No code changes yet. Awaiting D1–D5.

## Session 2026-08-14 (cont.) — built it

Shipped in the working tree (not committed):

- `app/src/dnd.ts` — pure rules: `predictTier` (mirrors `store::reconcile`),
  `dropIntent`, `landingNote`, alpha/recent/pointer landing slots,
  `naturalTop` gap compensation, `spliceOrder`/`moveBefore`.
- `app/src/navdrag.ts` — pointer-events drag controller (4px threshold, Esc,
  edge auto-scroll, click swallowing).
- `app/scripts/dnd-check.mjs` — 53 checks; also re-reads `store.rs`/`lib.rs` and
  fails if the mirrored constants drift.
- `lib.rs` — `reorder_projects` (+ `merge_project_order` unit test),
  `set_lifecycle` now clears on an empty label. Mock mirrors both.
- `App.tsx`/`App.css` — tier drop zones, gap, empty-tier stubs, spring-open,
  ghost with landing tier, flash, undo, project reorder.

### Verified

| Check | Result |
|---|---|
| `dnd-check.mjs` | green; shown RED by breaking the unpin rule and the gap clamp |
| `cargo test -p app --lib reordering…` | green; shown RED by dropping the known-roots filter |
| release build, `make test` (288), `make lint`, core 208, cli 6, app 30, `tsc`, `cargo check -p app` | all green |
| `race-check.mjs` | ALL GREEN |
| Harness (Playwright, pointer events) | pin drop, Active reject + hint, Idle→Active honest landing + note, dormant drop after spring-open, empty-tier stubs, alpha slot ≠ pointer, manual reorder with a STABLE gap, project reorder, Escape cancel, click-still-enters |
| `?slowlist=900` | optimistic pin and project order both hold through the slow refresh — no snap-back |

### Not verified — needs a human

Real-app drag. No tool in this session can drive a pointer drag in a native
WKWebView window, so this is the one gate left for a human:

    app/scripts/sandbox.sh --app        # isolated: config dir
                                        # net.casadelvalle.worktrees.sbx,
                                        # tmux prefix sbx-reorder-plac
    app/scripts/sandbox.sh --clean      # tear down

A launch was made during this session and exited on its own after ~2 minutes
(window visible → hidden → exit 0); it was not driven. Config isolation was
confirmed (its own ui-state.json under the .sbx dir); only `app.log` is shared
with the installed app, which is why its lines appear doubled.

What to try there, in order — each one is a shape the mock cannot express, since
its invokes resolve in a microtask while the real `list_workspace` is a git
fan-out of seconds:

1. Drag a place from Active onto Pinned. The row must stay pinned through the
   refresh that follows, not snap back.
2. Drag a pinned place onto Idle. It should unpin and land in Active (its tmux
   is up) with the notice saying so — the derived-tier case.
3. Drag onto Active. Nothing moves; the hint appears.
4. Reorder two projects. Order must survive the confirming `list_workspace`.
5. Drag a row to the top/bottom edge of the nav — it should auto-scroll.
6. Hover a collapsed group for a beat mid-drag — it should spring open.
7. Undo, once, after a tier change.

## Session 2026-08-14 (cont.) — review, fixes, PR #133

Second-model review found three real defects, all in the ten seconds AFTER the
drop rather than in the drop itself:

1. `undo.run` closed over `settings` at drop time and wrote the whole
   `manual_order` map back — a reorder in ANOTHER repo inside the 8s window was
   silently reverted, on disk too. `updateSettings` now takes a functional
   patch; undo merges only its own repo key against current state, and deletes
   the key when there was no prior order.
2. An Escape-cancelled drag still ENTERED a place: the click swallow was reset
   on a 0ms timer while the button was still held. Swallowing is now a
   window-level capture-phase one-shot that waits for the pointerup — which also
   covers drops released over buttons, so all five per-handler guards are gone.
3. The undo banner and the notice were both `position: fixed` at the same
   offset, so the undo banner painted over the landing explanation. Both now
   render in one bottom-anchored `.float-stack`.

Also applied: refresh on a failed `reorder_projects`, an `e.buttons` guard so a
lost pointerup cannot leave a live drag, `rowGeometry` parameterized (the
project branch's IIFE is gone), three comment corrections — and the one the
review argued for hardest, an OPTIMISTIC lifecycle badge patched to
`predictTier`'s answer. Verified under `?slowlist=1200`: the row lands in the
destination immediately and the flash fires there, where before it fired in the
group the row was leaving.

One bug I introduced into the record and then corrected: I reported project
reorder "broken by the refactor". It was not — my test aimed at a no-op
position, then at the scroll-edge strip. But that second target found a real
bug: the padding ABOVE the first project was not a drop target, which is exactly
where you aim to make a project first. Project drags now accept anywhere inside
`.nav-scroll`.

Rebased onto a freshly fetched origin/main (⌘F and md-zoom landed underneath —
two conflicts, both in import/CHANGELOG blocks; `pnpm install` for upstream's
new `@xterm/addon-search`). All gates re-run green on the rebased tree, harness
re-driven on the merged code. PR #133.

## Merged

PR #133 — all 9 CI checks green (lint, rust ×2, app ×2, install ×2, test ×2) —
squash-merged as `58ad9ef`. Worktree reset to origin/main, clean, 0 ahead / 0
behind. Harness stopped, Playwright artifacts moved to
`~/.cache/worktrees/worktrees/reorder-places-projects/`.

Still open: the real-app drag pass (`app/scripts/sandbox.sh --app`, script in the
section above), and `/close-out` for the session archive.
