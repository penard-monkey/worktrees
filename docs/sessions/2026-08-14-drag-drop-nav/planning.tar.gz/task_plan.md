# task_plan — drag & drop: places between tiers, projects reordered

## Goal

In the Places nav: drag a place between tier groups (idle ↔ pinned ↔ dormant
tiers) and have the drop APPLY the tier (pin / lifecycle), landing at the right
position — alpha slot in A–Z mode, pointer slot in Manual mode. Open a real gap
where the item will land while dragging. Separately: reorder projects by drag.

## Decisions (LOCKED 2026-08-14)

| # | Decision | Answer |
|---|---|---|
| D1 | DnD mechanism | **Pointer events**, hand-rolled. pointerdown → 4px threshold → pointermove; rects cached at drag start; Esc / pointerup-outside cancels. No HTML5 `draggable` anywhere in the nav. |
| D2 | Drop onto **Active** | **Reject + hint** — no gap opens, no-drop cursor, one-line hint: "Active means a live tmux session — press Enter to open". |
| D3 | Drop onto **Idle** | **Do it honestly**: unpin + clear declared label, then scroll to + flash the row in whatever tier it actually derived into. When the computed destination ≠ the hovered group, the gap opens at the DESTINATION. |
| D4 | Dormant tiers droppable | Yes — saved/closed/archived/abandoned all take `set_lifecycle`. |
| D5 | Undo | **"Moved to X — Undo"** for ~6s in the existing banner slot; restores prior pin/label + manual position. |

## Phases

### Phase 1 — design lock — `complete`
- [x] Map current bucketing / sorting / manual_order / project order
- [x] Identify derived-vs-declared tiers (the core constraint)
- [x] Resolve D1–D5 with the user

### Phase 2 — order math + drop intent (pure, unit-testable) — `complete`
- [x] `dropIntent(place, targetTier)` → `{kind:"pin"|"unpin"|"lifecycle"|"none", …}` + reason string for rejected drops
- [x] `insertionIndex(sortMode, bucketRows, pointerY | name)` — alpha computes the slot from `nameOf` + `sort_dir`; manual from cached rects; recent = no position (group-level drop only)
- [x] `spliceManualOrder(existing, allSlugs, movedSlug, beforeSlug|end)` — reuses today's `dropOnRow` math, extracted and tested
- [x] node check script (`app/scripts/dnd-check.mjs`) for the three above (no DOM)

### Phase 3 — backend: project order — `complete`
- [x] `reorder_projects(roots: Vec<String>)` in `app/src-tauri/src/lib.rs` — validate it is a permutation of the current file, write `projects.json`, return `list_workspace()`
- [x] Mirror in `app/src/mock/install.ts` (harness parity is mandatory)
- [x] Unit test for the permutation guard (drop unknown roots, keep missing ones)

### Phase 4 — DnD engine (frontend) — `complete`
- [x] Pointer-based drag controller at module scope (threshold ~4px so a click is still a click; Esc cancels; pointer capture)
- [x] Gap placeholder: animated height, `prefers-reduced-motion` → instant; rects cached at drag start, recomputed only on scroll/mutation
- [x] Nav edge auto-scroll while dragging
- [x] Spring-open a collapsed group on hover (~600ms), and render drop-zone stubs for eligible EMPTY tiers during a drag
- [x] Same controller drives project-header reorder (reject nesting; reject dropping a project into a place list)

### Phase 5 — wire semantics — `complete`
- [x] Place drop → `patchDeclared {pinned}` / `mutate(invoke("set_lifecycle"))` per `dropIntent`; manual-mode drops also write `manual_order`
- [x] Tier-change drag enabled in ALL sort modes; position drag only in manual
- [x] Project drop → optimistic `ws.projects` reorder + `reorder_projects` + confirming refresh
- [x] Feedback: land-elsewhere flash, hidden-tier warning, undo (D5)

### Phase 6 — verification — `complete`
- [x] `node app/scripts/race-check.mjs` (drop vs in-flight refresh)
- [x] Playwright over the mock harness: pointer-event drags, gap assertions via `getComputedStyle`, one click per evaluate
- [x] New tests shown to FAIL first (CLAUDE.md rule)
- [ ] REAL app smoke: `app/scripts/sandbox.sh --app` — NOT possible from this session (no way to drive a pointer in a native WKWebView); `?slowlist=1200` in the mock covers the timing shape, the feel does not
- [x] Gates: release build first, `make test`, `make lint`, `cargo test -p worktrees-core|cli|app --lib`, `tsc --noEmit`, `cargo check -p app`

### Phase 7 — ship — `complete`
- [x] CHANGELOG `[Unreleased]`
- [x] Second-model review + fixes (3 must-fixes, all applied and re-verified)
- [x] Rebase onto a freshly fetched origin/main (⌘F + md-zoom landed underneath)
- [x] PR #133, gates green post-rebase
- [x] Squash-merged as 58ad9ef (#133); worktree synced to origin/main
- [ ] `/close-out` (session archive + fresh branch) — not run yet

## Errors Encountered

| Error | Attempt | Resolution |
|---|---|---|
| `rtk: command not found` (hook rewrote `grep`) | 1 | used plain `grep`/`sed` |
| `spliceOrder` sent a row dropped on ITSELF to the end of the list | 1 | caught by the new check script before any UI existed; early-return when `beforeSlug === moved` |
| Reordering INSIDE Active/Idle was rejected — `dropIntent` refused the derived tiers outright, losing the old manual-drag behaviour | 1 | `dropIntent` now takes the row's CURRENT tier; a same-group drop is a pure re-order and writes nothing |
| Harness drag resolved no drop zone — `elementFromPoint` hit a leftover `.menu-catch` overlay | 1 | `body.dragging .menu-catch { pointer-events: none }` |
| Review found undo could revert ANOTHER repo's manual order (whole-blob settings write from a stale closure) | 1 | `updateSettings` gained a functional patch form; undo merges only its own key against current state |
| Review found an Escape-cancelled drag still ENTERED a place on release | 1 | click swallowing moved to a window capture-phase one-shot that waits for the pointerup when the button is still down |
| Review found the undo banner painting over the landing explanation | 1 | both toasts render in one bottom-anchored `.float-stack` |
| I reported project reorder "broken by the refactor" — it was not; two bad test targets (a no-op move, then the scroll-edge strip) | 1 | corrected; the second target did expose a real bug (below) |
| The strip ABOVE the first project took no drop — `closest([data-project-root])` is null over the scroller's own padding, which is exactly where you aim to make a project first | 1 | project drags now accept anywhere inside `.nav-scroll` |
| `tsc` failed after the rebase on a missing `@xterm/addon-search` | 1 | upstream dependency; `pnpm install` |
