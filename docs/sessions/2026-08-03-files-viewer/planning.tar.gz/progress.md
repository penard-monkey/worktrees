# progress — dock Files tab redesign

## Session 1 — 2026-08-02

**State:** Phases 1–5 built; adversarial round 2 + repo gates in flight.

### Done

**Phase 1 — pure modules**
- `app/src/filekind.ts` — path → `{kind, lang, mime, label}`, `humanSize`.
- `app/src/highlight.ts` — 15-grammar single-pass tokenizer.
- `app/src/markdown.tsx` — `marked.lexer()` tokens → React nodes (no `innerHTML`).
- `app/src/CodeView.tsx` — gutter + highlighted `<pre>`, shared by the code
  viewer and markdown fences.

**Phase 2 — backend + mock**
- `lib.rs`: `read_file_base64` (+ `FileBlob`, hand-rolled `b64_encode`), `size`
  on `FileContent`, both caps clamped against `cap + 1` overflow.
- `mock/install.ts`: `read_file_base64` arm, `size` on `read_file`, fixtures for
  every renderer (GFM markdown doc, TS, TOML, JSON, shell, 152-byte PNG, PDF).

**Phase 3 — viewer** — `app/src/FilesPane.tsx`: tree + `FileView` +
`ImageView` + binary placeholder. The editable textarea, Save, ⌘S and the
conflict banner are GONE (decision D3).

**Phase 4 — layout** — auto split/stack at `SPLIT_AT = 620`, manual cycle button
in the dock header, drag divider with persisted ratio, reading mode (⌘⇧E /
Expand / Esc) over the main pane with the dock falling back to tree-only.

**Phase 5 — styling** — `App.css` Files section rewritten: split/stack, prose
scale, code gutter, image stage, binary placeholder, reading mode. All colours
are existing theme tokens.

### Adversarial round 1 — findings FIXED

Highlighter/filekind agent: **round-trip invariant held** (10 real files × 16
grammars, 54 hostile inputs, 400k fuzz cases — zero violations; merge-runs is
linear, not quadratic). 8 P1 colouring defects, all fixed:
- unterminated quote ran to EOL (`/it's/`, `&'a str`, YAML scalars) → a quote
  that doesn't close on its line now degrades to punctuation
- Rust `r#"…"#` raw strings mis-delimited → dedicated scanner branch
- `//` treated as a comment in plain CSS (`url(https://…)`) → `css` vs `scss` split
- `kw.has(w.toLowerCase())` made `Set`/`Type`/`Default` keywords → gated to `ci`
  grammars (SQL only)
- YAML missing the `hash` rule (`url#frag`) → added
- `;` comments in TOML → moved to a separate `ini` grammar
- `.lock` all treated as TOML → per-name table (Cargo/poetry=toml,
  flake/composer=json, yarn/Gemfile=none)
- markdown grammar coloured prose → grammar removed, markdown source is plain
- plus P2s: `-` as an identifier char scoped to CSS, `humanSize(1048575)`,
  multi-segment dotfiles (`.env.local`), `LICENSE`/bare `readme` → text

Rust agent: `b64_encode` **correct** (diffed against python base64 on 16 vectors
incl. 3 real PNGs, 1 MiB random — 0 mismatches); path guard identical to
`read_file`; FIFO/device rejected by `is_file()`. Fixed: `cap + 1` overflow
(panic in debug, wrap-to-0 lying "empty file" in release) → clamped; base64 cap
8 MB → 4 MB (20 concurrent calls measured at 447 MiB RSS); mock `read_file_base64`
was stricter than the backend (threw for non-images) → now encodes any file and
can force the `truncated` branch.

### Visual round — found and fixed from screenshots
1. `[x]`/`[ ]` literals printed in task lists — `checkbox` tokens now consumed.
2. Task text wrapped under the checkbox — tight list items render inline.
3. Fence language badge sat ON the first line of code — moved into flow.
4. Viewer header controls clipped at a narrow dock — container queries drop the
   size, then the kind chip; controls never clip.
5. First fix flattened NESTED lists into literal text — the inline unwrap now
   bails when an item carries a block token.
6. Reading mode showed the same doc twice — the dock falls back to tree-only.

### Adversarial round 2 — findings FIXED

**Markdown/security agent** (46 real repo docs lexed; every token type covered —
`default` arms proved unreachable; reference links, setext headings, nested
quotes, GFM tables all correct; raw HTML inert; path traversal stopped by the
Rust guard; 0 duplicate React keys):
- **P0 — `marked`'s LEXER blows the stack** on 8 KB of `****…a…****` or a
  2000-deep blockquote, well inside the 1 MB read cap, and with no error
  boundary in the app that unmounts the whole window. Fixed at two layers:
  `Markdown` catches the RangeError and degrades to plain source, and a
  `ViewErrorBoundary` now wraps the viewer body so any renderer failure costs
  the pane, not the window. Verified: all four pathological cases render.
- **P0/P1 — `href` carried dangerous schemes.** `preventDefault()` in onClick is
  not a boundary: a middle-click fires `auxclick` with NO `click`, so the
  handler never runs and the WebView follows the attribute. React only blocks
  `javascript:`; `file:`, `data:`, `vbscript:` and custom schemes rendered
  intact. Fixed by sanitizing where the href is WRITTEN (`safeHref`) — only
  http(s), relative paths and `#anchors` get an href at all; anything else
  renders as inert struck-through text. Verified.
- P1 — in-document anchors were dead (no heading ids). Headings now carry slugs
  and `onLink` scroll-targets them.
- P1 — the whole doc was re-lexed on EVERY render (~85ms lex + ~165ms build for
  1 MB), including every mousemove of a divider drag. `Markdown` is now `memo`'d
  with `useMemo` on both the lex and the element tree.
- P2 — `<div>` inside `<p>` for images; entity table gaps; fence-language chip
  unbounded; image `title` dropped. Fixed except the entity table (7 entities,
  zero occurrences in the repo's 46 docs).

**React/CSS/a11y agent** (in-browser; dropped: stale-response overwrite, re-read
loop, per-mousemove settings writes — `saveSettings` debounces 250ms —, 620
threshold thrash, sticky gutter, table overflow, xterm refit which is a
ResizeObserver):
- P1 — divider drag leaked window listeners; unmounting mid-drag (⌘J) left it
  armed against a detached node → `x/0 = Infinity` → split slammed to 85%. Now
  torn down on unmount and on window blur, with a degenerate-rect guard.
- P1 — Escape closed the BACKGROUND reader while the settings sheet stayed open.
  Escape and ⌘⇧E are now gated behind both modals.
- P1 — a PINNED split at `DOCK_MIN` clipped the header controls unreachably.
  Added a `SPLIT_FLOOR` (420px) that beats the pin, plus `overflow-x` on the
  header as a last resort.
- P1 — **both light themes failed contrast**: 6/8 token colours under 3:1 in
  tokyo-day, 5/8 in catppuccin-latte (worst 1.98:1 — comments). Added a
  dedicated `--syn-*` ramp in tokens.css with per-light-theme overrides; all 16
  now ≥ 4.5:1, verified live via getComputedStyle (tokyo-day measured
  4.54–5.05).
- P2 — orientation captured at mousedown inverted the drag axis after a flip;
  one ratio served both axes (now `files_split_pct` + `files_stack_pct`);
  "Expand" made the doc NARROWER than the dock (the overlay was bounded by
  `.main`) — it now spans main + dock, measured 1272px vs the dock's 474px.
- P2 — ⌘J hid the dock but left the reader up; ⌘⇧E fired behind modals and over
  the Terminal tab. All gated now.
- P2 — divider had `role="separator"` with no keyboard path (now arrows/Home/End
  + aria-valuenow); the layout button's accessible name was the glyph (now
  `aria-label`).

Also fixed: the mock only materialized file content when a directory was
listed, so a markdown doc's relative image 404'd until you expanded its folder —
a harness artifact that read as an app bug.

### Test results
- `tsc --noEmit` — clean
- `cargo check -p app` — clean
- `pnpm build` — clean (App chunk 441.90 kB / 119.18 kB gzip)
- repo gates — PASSED (exit 0 through the whole chain): release CLI build,
  `make test` (bats numbering reached 241), `make lint` (shellcheck + bash-3.2),
  `cargo test -p worktrees-core`
- final `tsc --noEmit`, `cargo check -p app`, `pnpm build` — all clean
  (App chunk 445.14 kB / 120.26 kB gzip; +3.2 kB over pre-fix, +~13 kB gzip for
  `marked`'s lexer)

### Evidence
41 screenshots in `~/.cache/worktrees/worktrees/ui-changes/` (repo is clean of
scratch): split markdown, code + gutter, image (checkerboard, 64×48, 1:1),
reading mode before/after the width fix, stacked at 380px, binary placeholder,
light-theme code, and the review agent's per-theme contrast captures.

### Files touched
| File | State |
|---|---|
| `app/src/filekind.ts`, `highlight.ts`, `markdown.tsx`, `CodeView.tsx`, `FilesPane.tsx` | new |
| `app/src/App.tsx` | old tree/viewer removed (−7.4 kB), FilesPane wired, reading mode + ⌘⇧E + Esc |
| `app/src/App.css` | Files section rewritten |
| `app/src/settings.ts` | 4 new settings + defaults |
| `app/src-tauri/src/lib.rs` | `read_file_base64`, `b64_encode`, `size`, cap clamps |
| `app/src/mock/install.ts` | new arm + fixtures |
| `app/package.json` | `marked` ^18.0.7 (first runtime dep beyond React/Tauri/xterm) |

### Next
1. CLAUDE.md: note that "no UI libraries" means COMPONENT libraries (`marked`'s
   lexer is a parser); ROADMAP.md: retire the "dock file viewer: syntax
   highlighting" item.
4. CHANGELOG `[Unreleased]`, screenshots → `~/.cache/…`, then close-out.
