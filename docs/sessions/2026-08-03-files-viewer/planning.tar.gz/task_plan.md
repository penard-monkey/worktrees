# task_plan — dock Files tab: layout + document rendering

**Goal:** turn the dock's Files tab from a tree-over-textarea peek into a proper
read surface — responsive split layout, a full-pane reading mode, and real
rendering for markdown, source code, images and other binaries. Not an IDE:
read-only, no editor library.

Branch `ui-next`, worktree `ui-changes`. Companion files: `findings.md` (options
considered, current-code map), `progress.md` (session log).

## Decisions (user, 2026-08-02)

| # | Decision | Consequence |
|---|---|---|
| D1 | **Auto split + reading mode** | `.dock-files` flips to tree-left/content-right at a dock-width threshold (~620px); stacked below it. Manual override button in the dock header. ⌘⇧E expands the viewer over the main pane. |
| D2 | **Render markdown, code, images, other binaries** | four renderers behind one `FileView` component, chosen by `fileInfo(path).kind` |
| D3 | **Read-only viewer** | the editable `<textarea>`, Save button, ⌘S and the mtime-CAS conflict banner come OUT of the UI. `write_file` stays in the backend (unused by the frontend for now). "Open in editor" becomes the edit path. |
| D4 | **`marked` lexer + hand-rolled highlighter** | one runtime dep (`marked`), used for `marked.lexer()` only — tokens are rendered to React nodes we own, so no `innerHTML` and no sanitizer. Highlighting is `app/src/highlight.ts` (already drafted). |

D4 is the app's first runtime dep beyond React/Tauri/xterm — CLAUDE.md's
"no UI libraries" line needs a note that it means *component* libraries.

## Phases

### Phase 1 — pure modules (no wiring) — `complete`
- [x] `app/src/filekind.ts` — path → `{kind, lang, mime, label}`, `humanSize`
- [x] `app/src/highlight.ts` — 12-grammar tokenizer → `Tok[]`
- [ ] `app/src/markdown.tsx` — `marked.lexer()` tokens → React nodes; headings,
      lists (incl. task lists), tables, blockquotes, fenced code (→ highlighter),
      inline code/emphasis/links/images. Relative image + `.md` link resolution
      against the file's dir, via callbacks.

### Phase 2 — backend + mock — `pending`
- [ ] `lib.rs`: `read_file_base64(path, max_bytes) -> {b64, mime, size, truncated}`
      behind the same `guard_under_projects`; register in the handler list
- [ ] `read_file`: add `size` to `FileContent` so the header can show byte size
- [ ] `app/src/mock/install.ts`: arm for `read_file_base64`, `size` on `read_file`,
      and richer fixtures — a real markdown doc, a source file, a tiny inline PNG,
      a "binary" entry — so the harness can drive every renderer

### Phase 3 — viewer components — `pending`
- [ ] `FileView` (module scope): header (breadcrumb path, kind label, size,
      mode toggles, wrap toggle, expand, Editor, Reveal) + body switch
- [ ] `MarkdownView` — Preview | Source toggle, prose measure capped for reading
- [ ] `CodeView` — line-number gutter + highlighted tokens, wrap toggle
- [ ] `ImageView` — data: URI, fit | 1:1 toggle, natural dimensions + size,
      checkerboard backdrop; SVG additionally offers Source
- [ ] `BinaryView` — named placeholder (PDF/video/font/…), size, Editor + Reveal
- [ ] Delete `FileViewer` (the textarea path) per D3

### Phase 4 — layout — `pending`
- [ ] `settings.ts`: `files_layout: "auto" | "stack" | "split"`, `files_split_pct`,
      `files_wrap`, `files_md_source` — defaults + `DEFAULTS` entry
- [ ] `.dock-files` orientation from `fit.dockW` vs threshold (or the override)
- [ ] draggable divider between tree and content, ratio persisted per orientation
- [ ] reading mode: viewer over the main pane, ⌘⇧E toggle + ✕ / Esc to close
- [ ] tree polish: file-kind icon glyph per row, selected-row contrast

### Phase 5 — styling — `pending`
- [ ] `App.css`: markdown prose scale, code gutter, image stage, split + reading
      mode, all off existing tokens (no new colors unless added to `tokens.css`)
- [ ] verify every theme (Tokyo Night/Day, Catppuccin ×2, Nord, Gruvbox) — the
      highlight classes must resolve per theme, not hard-coded hexes

### Phase 6 — gates + evidence — `pending`
- [ ] `cargo build --release -p worktrees-cli` (FIRST — stale release binary
      breaks bats mysteriously), `make test`, `make lint`, `cargo test -p worktrees-core`
- [ ] `cd app && ./node_modules/.bin/tsc --noEmit && cargo check -p app`
- [ ] `pnpm dev:mock` on a non-1420 port + Playwright screenshots of: narrow
      stacked, wide split, markdown preview, code with gutter, image, reading mode
- [ ] screenshots → `~/.cache/worktrees/worktrees/ui-changes/`

## Errors Encountered

| Error | Attempt | Resolution |
|-------|---------|------------|
| _(none yet)_ | | |

## Notes / risks

- Threshold flip must not thrash while dragging the dock edge — hysteresis or a
  single breakpoint evaluated on the committed width.
- Reading mode overlays the main pane, which hosts an **xterm**: xterm needs a
  `fit()` when it comes back. Check `TerminalPane`'s resize path before shipping.
- `marked` must be imported so only the lexer lands in the bundle; verify the
  built chunk doesn't pull the HTML renderer.
- Mock parity is a hard rule (CLAUDE.md): a new backend command with no mock arm
  silently breaks headless UI development.
