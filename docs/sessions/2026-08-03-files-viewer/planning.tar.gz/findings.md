# findings — dock Files tab redesign

_Session start: 2026-08-02. Branch `ui-next`, worktree `ui-changes`._

## Current implementation (as read)

| Piece | Where | Notes |
|---|---|---|
| `TreeNode` / `FileTree` | `app/src/App.tsx:446-516` | lazy `list_dir` per dir, cached per node, no icons, no filter |
| `FileViewer` | `app/src/App.tsx:518-604` | plain `<textarea>`, mono, `white-space: pre`, ⌘S save w/ mtime CAS |
| Dock shell | `app/src/App.tsx:2362-2396` | `.dock-files` = tree (flex `0 0 40%`) over viewer |
| CSS | `app/src/App.css:667-780` | `.dock`, `.dock-tree`, `.viewer`, `.viewer-text` |
| Layout math | `app/src/settings.ts:130-176` | `DOCK_MIN=240`, default `dock_width=360`, ceiling = viewport − rails − nav − `MAIN_MIN` |
| Backend FS cmds | `app/src-tauri/src/lib.rs:1655-1825` | `list_dir` (gitignore-filtered, dirs first), `read_file` (1 MiB cap, NUL→`binary:true`, mtime), `write_file` (CAS + atomic rename) |
| Path guard | `lib.rs:1692` `guard_under_projects` | canonicalize + must be under a registered project root |
| Mock parity | `app/src/mock/install.ts:448-465` | `seedDir` virtual FS, all-Rust content, no images, no markdown |

## Constraints that shape the design

- **No UI libraries.** CLAUDE.md + ROADMAP.md:110 — the textarea is deliberate. Any
  highlighting/markdown must be hand-rolled or it becomes the first UI dep (a decision,
  not a default).
- **Components at module scope** (CLAUDE.md) — anything with local state can't be defined
  inside `App()`.
- **Mock harness must track every backend command** — new commands need a mock arm.
- `tauri.conf.json` `security.csp = null` → `data:` URIs for images are fine, no capability
  change needed.
- Dock competes with the terminal pane for width: `MAIN_MIN` guards the centre column, so a
  "wide dock" is only usable on a large window. Layout must degrade to narrow.
- ROADMAP.md:110 already flags "syntax highlighting" as the known follow-up — this session
  is that item plus the layout question.

## Layout options considered

| Option | What | Pros | Cons |
|---|---|---|---|
| **A. Keep stacked** (today) | tree 40% top / content bottom | works at 240px; zero layout work | content gets ~55% of an already narrow column; unusable for a doc |
| **B. Auto side-by-side** | dock flips to tree-left / content-right past a width threshold | one panel serves both a peek (narrow) and a read (wide); no new window | needs a second resizer + persisted ratio; wide dock squeezes the terminal |
| **C. Full-width overlay** | Files takes over the main pane (⌘⇧E), terminal behind | max reading area; real doc experience | hides the terminal — the app's centre of gravity; modal state to manage |
| **D. Separate window** | file viewer in its own Tauri window | true IDE-ish | new window lifecycle, per-window settings, tmux/PTY none — big scope |

**Recommendation: B + C.** B is the everyday improvement (auto by width, manual override,
draggable split). C is the "I actually want to read this" escape hatch, cheap once the
viewer is a standalone component (same component, bigger box). D is out of scope. A alone
does not solve the stated problem.

## Content-rendering options

| Need | Option | Verdict |
|---|---|---|
| Source code | hand-rolled tokenizer (~250 lines, per-language table) | **yes** — no dep, read-mode only, approximate is fine |
| | CodeMirror / Shiki | no — first UI dep, 100–800 KB |
| Markdown | hand-rolled block+inline parser → React nodes (no `innerHTML`) | **yes** — XSS-safe by construction |
| | `marked` + DOMPurify | no — two deps for a viewer |
| Images | new `read_file_base64` cmd → `data:` URI | **yes** — CSP already permits |
| | Tauri `asset:` protocol | no — needs capability + scope config for arbitrary worktree paths |
| PDF / video / fonts | named placeholder + "Open in editor / Reveal" | **yes** — no in-app render |

## Open questions (for the user)

1. Side-by-side threshold + whether the manual override belongs in Settings or a dock button.
2. Is the full-pane "reading mode" (option C) wanted this session or deferred?
3. Edit story: keep the textarea for Edit mode (highlight read-only), or drop in-app editing
   to read-only entirely and lean on "Open in editor"?
