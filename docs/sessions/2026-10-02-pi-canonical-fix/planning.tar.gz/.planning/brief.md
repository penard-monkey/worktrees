# Take over PR #409 (pi in a place's MAIN session) and finish it properly

## Context
A pi agent (qwen3-coder-next) wrote PR #409 on branch `pi-canonical-fix` (this place is checked out
on it). A fable review says REWORK — it is below, verbatim, plus the original investigation. David
asks a Claude lane (you) to take it over: same branch, same PR, add commits on top (no force-push),
fix everything, add the tests, and get it mergeable. Read AGENTS.md first.

Bring the branch up to date with a MERGE of origin/main (it is behind #407, #408, #410 = v0.35.0).
CHANGELOG: v0.35.0 is RELEASED — your entry goes under a fresh `## [Unreleased]` → `### Fixed`
ABOVE `## [0.35.0]`; check nothing lands inside the released section (AGENTS.md: an entry can rebase
cleanly into the wrong release). Guidance VERSION: the pi PR bumped 3→4; VERSION 3 shipped in v0.35.0,
so a bump IS now warranted if the SKILL text changes meaning — keep 4 and make the text accurate.

## What to build (the original brief's scope, done right)
A. Recognise pi running in a place's CANONICAL tmux session (tmux pane reads `node`): resolve ONCE in
   `PaneList::fetch` — add `#{pane_tty}` to the format, and only when at least one pane reads `node`,
   ONE `ps -A -o tty=,pid=,tpgid=,comm=` call; foreground = pid==tpgid; NORMALISE tty names (tmux gives
   `/dev/ttys009`, ps gives `ttys009`; Linux `/dev/pts/3` vs `pts/3`). Store per pane in ONE row struct
   `{session, path, cmd, pid: Option, tty: Option, fg: Option}` (no parallel vectors). `for_pane` and
   `canonical_provider` stay PURE over the fetched data (no subprocesses). pi activity/send route through
   `PI.session_name(canonical, owner)` like Codex. `open --ai pi` must see pi already running (no second
   pi on the same session file).
B. One derivation for place_status AND wait: an unclaimed non-shell program in the canonical session is
   `unknown` with a reason ("a program this place did not launch is running"); wait doesn't return
   immediately; `may_type` text for Unknown; rank Unknown sensibly vs None.
C. SKILL.md: "Start an agent only through create_worktree / `worktrees new|open --ai`; never type an
   agent command into a place's pane" — with the REAL reasons (second pi on one session file, no record),
   not "worktrees cannot tell".
Tests, each shown FAILING first: the reviewer's list below (pure ps parser over macOS+Linux fixture incl.
`/dev/` prefix; PaneList 3/4/5-field rows; attribution via injected data; pi_session_for; Unknown from
BOTH place_status and wait; bats with a fake `ps` + a `list-panes` shim emitting 5 fields and a `node`
canonical pane; no ps spawned when no pane is node). `ls --json` byte-identical vs ~/.local/bin/worktrees
(now v0.35.0 after David updates — if it is still 0.34.1, diff against the v0.35.0 release build).
Gates per AGENTS.md (release build first; `nvm use` + `corepack pnpm install` in app/). Push, watch CI
with `gh run watch <id> --exit-status`, update #409's description (credit the pi agent's first cut), reply,
STOP (don't merge).

## Rules
Never touch the valleos repo (a pi benchmark may still be running in valleos `pi-bench-log-redact` — read
its tmux state at most; NO keys, no `worktrees open` there). Any throwaway tmux: `tmux -L <unique-name>`
on EVERY command incl. kill-server — you are inside a tmux pane; a bare `tmux kill-server` kills all of
David's sessions. Scratch checkouts only via `worktrees new <name> --ai none --no-spare --no-attach` +
`worktrees rm`. Don't drive the running app. Keep Co-Authored-By; no session URLs.

## The fable review of #409 (verbatim summary)
# PR #409 review (pi-authored) — verdict REWORK
1. A is dead: tmux `#{pane_tty}` = /dev/ttys000, ps `tty=` = ttys000 → lookup never hits; live pi still reads as Claude. Normalise (strip /dev/).
2. Zero tests; bats tmux shim emits 3 fields and no `node` pane, so the suite can't see the change. Needed: pure ps-parse fn over macOS+Linux fixture; PaneList 3/4/5-field rows; attribution with an injected foreground map; pi_session_for; State::Unknown from place_activity AND place_status; bats with a fake ps + 5-field list-panes; ls --json byte diff.
3. B reaches `wait` only — place_status (mcp.rs add_agent_status) still answers none; no reason string. One derivation for both.
4. ps/tmux spawned lazily per call (100ms ps) inside canonical_provider / for_pane / agents_in loops; for_pane became impure (an existing unit test now hits the real tmux). Resolve once in PaneList::fetch, store per pane row.
5. resolve_tty_foreground's set loop keeps at most one tty; parallel vectors can't be zipped — one row struct per pane.
Nice: CHANGELOG/SKILL wording claims what doesn't work; guidance VERSION 3→4 unnecessary (3 unreleased); may_type text for Unknown; Unknown rank; trailing whitespace.
Merges cleanly; core/cli/app tests pass but none exercise the new code.

## The original investigation (findings.md)
# pi-bench-inspect — findings (2026-10-01, ~20:30–20:50 local)

Subject: valleos place `pi-bench-log-redact`, tmux `valleos-pi-bench-log-redact`.

## Q1 How pi got there (CONFIRMED, orchestrator transcript 82a15075…jsonl ~L41671–41699)
- 01:23:34Z David: "spin up a lane with pi … qwen-coder-next … checkout a previous commit".
- Orchestrator grepped its memory for `--ai pi` (nothing; only codex-lanes.md exists, which says
  "create in one CLI step" with `--ai codex`), read `pi --help`.
- 01:24:07Z `worktrees new pi-bench-log-redact 97d51be --ai claude --no-spare --no-attach`.
- 01:24:17Z wrote `.planning/brief.md` by hand, then `tmux send-keys … C-u`, `/exit`, Enter (killed
  the Claude that worktrees launched — it never wrote a transcript, hence no project dir).
- 01:24:31Z `tmux send-keys -t valleos-pi-bench-log-redact "pi --provider lm-studio --model
  qwen3-coder-next 'Read .planning/brief.md and begin.'"` + Enter → pi pid 94379 at 20:24:33.
- Then a background `until [ -f bench-report.md ]` watcher (not worktrees `wait`).

## Q2 What worktrees thinks (installed v0.34.1 and main @a19dbd8 release build — identical)
- tmux `pane_current_command` = `node` (ps comm/command = `pi`, pid==tpgid on ttys009).
- `ls --json`: session up, no harness field. `.worktrees.places.json`: no entry.
- MCP `place_status`: `agent_state: none`, `agents: []`, `activity.provider: null` — while pi is
  mid-turn. CONFIRMED by stdio probe.
- MCP `wait until:idle`: returns at once `event: none, waited_s: 0`. CONFIRMED.
- App (code-derived, app not driven): `agent_sessions_for` → `canonical_provider` matches only an
  exact `pi` command word → owner = claude → `agent_sessions.claude = {up: true, name: canonical,
  model: null}` (no probe), `pi = {name: …~agent~pi, up: false}`. No dot: no claude probe at that
  cwd, and `watch_lane("pi")` gets `None` so `pi_tick` never watches it.
- `send`: Claude adapter has no probe, codex/pi adapters look only at sidecars, `agents_in` finds
  the canonical session (owned) → "no agent is running in pi-bench-log-redact". Refuses (safe).
- `open --ai pi` (code-read, NOT run): `agent_session_name` → owner claude → sidecar `~agent~pi`;
  `pi::current_session` is by cwd, so it would resume the SAME jsonl the live pi is writing — two
  pi processes on one session file. Hazard.
- Reopen after the session dies: relaunches `claude --name …`, not pi.
- pi's file IS findable: it is in pi's default dir for the cwd, which is exactly where
  `pi::session_dir` looks; only the session→harness attribution is missing.

## Q3 Whose fault
- Primarily the orchestrator: it had v0.34.1 (its server pid 21510 started 18:54:49, binary mtime
  Sep 30 16:18; server advertises `create_worktree.provider: claude|codex|pi`), and the CLI has
  `worktrees new … --ai pi --model lm-studio/qwen3-coder-next`. It followed a stale memory recipe
  (CLI + `--ai codex`), had no pi recipe, and hand-launched a harness into a Claude lane.
  The worktrees SKILL says "`provider` picks the agent (claude, codex, pi)" but nothing says
  "never start a harness by hand in a place".
- Product gap too: any harness that runs as `node` in a CANONICAL session is attributed to Claude
  (the wrapper heuristic), and pi's adapter (`pi_activity`, `send` at harness.rs:650) hard-codes the
  sidecar name, unlike codex which uses `session_name(canonical, owner)`. place_status/wait
  answer "none" for a working agent — the worst kind of wrong for an orchestrator.

## Q4 Fixes (not implemented — see reply for why)
A. Product, attribution: in `PaneList::fetch`, for panes whose command is `node`, add
   `#{pane_tty}` to the format and resolve the tty's foreground leader with ONE
   `ps -A -o tty=,pid=,tpgid=,comm=` (pid == tpgid) — macOS ps reports `pi` there. Only spawned when
   some pane reads `node`. Then make `pi_activity` + pi `send` use
   `PI.session_name(canonical, owner)` like codex. Needs fake-ps/fake-tmux in bats.
B. Product, honesty (cheap): place_status/wait — when the canonical session runs a non-shell
   program and no harness claims it, report `state: unknown` ("something runs here that this
   place did not launch") instead of `none`; `wait` must not return instantly on it.
C. Guidance: SKILL.md line "Start an agent only through create_worktree/`worktrees new --ai` /
   `open --ai`; never type a harness command into a place's pane"; valleos memory gets a pi-lanes
   recipe (`--ai pi --model lm-studio/qwen3-coder-next`).
