# Findings — reveal the dock's file in the Files tree

## Root cause
- The tree has NO model of "the open file" beyond one comparison. `TreeNode`
  (FilesPane.tsx) keeps `open` as per-node `useState(false)`; the only thing
  that ever sets it is a click (and the changes-only filter). Expansion is not
  persisted, not per place, not in settings — it lives and dies with the
  mounted nodes (FileTree is keyed on `root`, and FilesPane unmounts whenever
  the dock is on another tab or the reader is expanded).
- Selection IS derived: `isSel = openPath === entry.path`. So a show_doc /
  terminal open already "selects" the row — but the row is never MOUNTED,
  because its ancestors are collapsed and children mount only when a parent
  is open. A tree click "works" only because you can only click a row whose
  ancestors you already opened.
- Nothing anywhere scrolls the tree.
- Every caller (termlinks via openPathFromTerm, show_doc pendingDoc effect,
  nav-history apply, plan/docs onOpen, tree click, reader links) funnels into
  `openDockFile` → `setDockFile`. The place-switch restore calls `setDockFile`
  directly (with an `alive` + `dockFileRef` guard). None tells the tree.

## Paths
- list_dir canonicalises the DIR (`guard_under_projects`) and joins names, so
  every row path is canonical. resolve_term_path and inbox (show_doc) both
  canonicalise too. The `root` prop (place path) may NOT be canonical; docs/
  plan pane paths are built from it. → normalise `root/...` to the canonical
  root (derived from the top-level listing's parent) before comparing.
- A followed symlinked directory (e.g. `_tmp` → iCloud) lists its children
  under the TARGET's canonical path, so a file inside it has no path prefix
  under the place: not revealable by prefix. Accepted (see decisions).

## Decisions
- Always reveal, no setting (VS Code default; the brief's lean).
- Unrevealable (outside the place, inside a hidden/gitignored dir while
  ignored files are hidden, behind a followed symlink): do nothing, quietly.
  The viewer header already names the file; a hint for an outcome the user did
  not ask for is noise.
- Reveal = expand ancestors + mark (existing `.sel`) + scroll the `.dock-tree`
  scroller only (manual scrollTop, not `scrollIntoView`, which also scrolls
  every overflow ancestor).
- Triggered by `openPath` changing OR a reveal token bumped by every
  `openDockFile` (re-open of the same file re-scrolls) and on tree mount (dock
  opened later, place switch, reader collapse).
- A reveal is consumed once its row scrolls, so collapsing/re-expanding by
  hand later does not re-open the chain.

## Result
PR #449. Harness (Chromium + WebKit): terminal ⌘-click, show_doc deep,
re-open after scrolling away, show_doc into another place, ⌘[ Back — all
present/.sel/in view/ancestors open/outer scroll 0. Pre-fix: present:false.
All gates green locally; CI run 37522413048.
