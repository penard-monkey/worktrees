# Brief: a file opened from a session or MCP should be revealed in the Files tree

## Symptom (David)
A file can be opened in the dock's Files viewer from outside the tree:
- a ⌘-click on a path in a Claude session's terminal (the open-file links, #400);
- MCP `show_doc`.

The file opens, but **the Files tree does not move to it**. Its folders stay collapsed, and the row isn't selected or scrolled into view. A file opened by clicking in the tree is, of course, highlighted.

## Expected
Whenever the dock shows a file, the tree reveals it:
- expand every ancestor folder;
- select or highlight that row;
- scroll it into view.

Behave like VS Code's "reveal active file". Decide whether this always happens or follows a setting. My lean: always, with no setting. Say what you decided.

## Start here
- `App.tsx` ~4639, `openDockFile(path, at)`: the single entry for opening a file in the dock.
- `FilesPane.tsx`: the tree, its expanded-folder state, the selected row, and how a click selects. Find out how the tree tracks its expanded set and selection. Is it per place (`place_panels`)? Persisted? A frontend-only Settings field? (AGENTS.md: `ui-state.json` is frontend whole-blob.)
- Trace every caller of `openDockFile`:
  - the terminal link provider (`termlinks`);
  - the `show_doc` event handler;
  - nav-history restore (#416);
  - drag-drop;
  - the plan tab.
  Find why only tree clicks update the tree's selection.

## Cases to handle
- **Paths:** the path is absolute (show_doc, terminal), and the tree is rooted at the place, so map one to the other. Handle symlinks and `/private` paths with the canonical root.
- **Files outside the tree:**
  - files that are gitignored or hidden, if the tree hides them;
  - files outside the place, which can't be revealed. Do nothing quietly, or show a hint. Decide which, and say what you decided.
- **Lazy folders:** if the tree loads directory children lazily, revealing a deep path must load each ancestor level before it can expand.
- **Place switches:** `show_doc` for a file in ANOTHER place switches places first. The reveal must apply after the new place's tree has loaded, not to the old one.
- **History and dock state:**
  - nav history: Back/Forward to a file entry should reveal it too, without pushing extra history entries (#416's rules);
  - the dock may be closed, or open on another tab. Reveal once the Files tab is showing, without forcing the dock open beyond what `openDockFile` already does.
- **Re-opens:** opening the same file again should re-scroll to it.

## Process
- Use the planning-with-files skill. Investigate first, then write findings.md with the root cause. Build only after that.
- If a frontend rule here mirrors anything in core, add a `*-check.mjs` guard. Show any new test or check FAILING first.
- Drive it in the mock harness: `pnpm dev:mock` on a port other than 1420, run as a real background task, after checking that the served file contains your code. Use headless Playwright Chromium AND WebKit.
- Measure; don't eyeball. After a simulated terminal-link open, a `show_doc` event and a Back step, assert:
  - the row is present;
  - it is selected (its class);
  - `scrollIntoView` happened (the row's rect is inside the tree scroller);
  - the ancestors are expanded.
- Make sure the mock can emit the `show_doc` / open-file event.
- CHANGELOG: under `## [Unreleased]`, add a `### Fixed` (or `### Added`) entry. Keep one of each `###` heading, and count them.

## Gates (AGENTS.md; run with `make -C <place root>`)
1. `git submodule update --init --recursive`.
2. `nvm use`, then `corepack pnpm install` in app/.
3. Release build first.
4. `make test`: check the plan line and the not-ok count.
5. `make lint`.
6. `cargo test` for each of `-p worktrees-core`, `-p worktrees-cli` and `-p app --lib`.
7. tsc, `cargo check -p app` and `make test-frontend`.

## Rules
- Never drive David's running app; use the mock harness only.
- Any tmux use is `tmux -L <unique>` on every call.
- Never edit the (main) checkout. Use worktrees places, never `git worktree add`.
- Commits keep the Co-Authored-By line. No Claude-Session trailers or session URLs.

## Finish
1. Open a PR.
2. Watch CI with `gh run watch <id> --exit-status`.
3. Report to the orchestrator in (main) via SendMessage: the PR number, the root cause, your decisions, the measurements and the gates.
4. Do NOT merge.
