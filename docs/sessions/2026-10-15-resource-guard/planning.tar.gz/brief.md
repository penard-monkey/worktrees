# resource-guard — keep many places from melting the machine

## The incident (2026-10-14, read this first)
David's Mac (14 cores, 36 GB) locked up at about 21:51 local and needed a reboot. Reconstructed from transcripts (UTC 02:49–02:56 on 10-15):

- valleos (main) checked 11 lanes and sent "keep going" to all of them in one `tmux send-keys` loop.
- Within 22 s, seven lanes ran `pnpm gate`: `pnpm install` + `turbo run typecheck|build|test --force`, uncached, the whole monorepo, every core each.
- Meanwhile five casa-del-valle-monorepo lanes were working, and about 35 Claude sessions had been active across both repos in 4 h.
- Each Claude session costs ~1.2 GB and ~4 node processes before doing any work:
  - claude ~740 MB;
  - the chrome-devtools-mcp npm chain ~300 MB;
  - gmail MCP ~120 MB.
- Activity Monitor showed dozens of 11–12-thread `node` processes at ~20% each, 0% idle; swap was still 7.7/9 GB long after.
- Transcript extract: `~/.cache/worktrees/worktrees/main/lockup-tools.txt`.
- ROADMAP already has "A concurrency cap is the signal the quota gate cannot be" (quota.rs header explains why the quota gate can't stop a burst).

The trigger was a broadcast nudge turning into N heavy jobs at once. Session count made it worse.

## Scope: three features
1. **Machine-wide slots for heavy jobs.**
   - `worktrees run --slot <name> [--slots N] -- <cmd…>`: block until one of N shared slots for `<name>` is free, run cmd, release on exit, including on kill and crash.
   - Default N: 2 for `gate`, and pick a sane default for unnamed slots. Make it configurable in user config, never from a repo (ADR 0001).
   - Visible: print "waiting for slot gate (2/2 held by valleos:photo-order, …)", and let `worktrees slots` list holders.
   - The MCP surface and the app's place status can show "waiting for slot".
   - Locking must be robust on macOS and Linux. Use flock on files in a worktrees data dir, keyed per machine, NOT per repo, because the incident spanned two repos. Handle stale holders by pid liveness.
   - The agent guidance (`guidance/SKILL.md`, `HEAD`/rules where appropriate) teaches "wrap gates/builds/full test runs in `worktrees run --slot gate`". Coordinate with the in-flight `project-rules` lane: don't edit its files; note what the rules pack should say.
2. **Staggered fan-out.**
   - A batch of MCP `send` calls, or launches (`create_worktree`, `worktrees new`/`open`), from one orchestrator goes out spaced: a configurable gap of a few seconds, and/or a max in flight.
   - Decide where the throttle lives: the long-lived MCP server can serialize its own calls; separate CLI processes need a shared lock/timestamp.
   - Guidance line: "nudge/launch in batches of ≤3; wait for heavy work to finish before the next batch".
3. **Live-agent cap + memory check at launch.**
   - A user-settable cap on live agent sessions (per machine, optionally per provider), counted from live panes (`tmux::PaneList::agents_in`, `activity`).
   - A memory-pressure check (macOS `kern.memorystatus_level` / `memory_pressure`, swap use via `vm.swapusage`; Linux `/proc/pressure/memory` or MemAvailable). It fails OPEN when unreadable.
   - Both sit on the existing launch-refusal path (`Adapter::prepare`, like `quota`): the place + brief are created, only the launch is refused, `--force` / "Launch anyway" / `open --force` overrides.
   - Consider "queue and auto-start when a slot frees" vs "refuse"; recommend one.

Also note, with no build needed: whether the app restarts every place's session at once after a reboot or tmux server restart. If it does, that's a third stampede; say how 2 covers it.

## Phase A — proposal (STOP after this and report)
Write `~/.cache/worktrees/worktrees/resource-guard/proposal.md` with:
- the design for each of 1–3: CLI/MCP/app surfaces, config keys and defaults, locking mechanics, failure modes;
- interaction with `quota`;
- what goes into guidance vs the rules pack;
- tests (how to prove locking with real processes, not mocks);
- size and phases.

Keep it tight. SendMessage `worktrees-(main)` when written, then WAIT for David's go-ahead before code.

## Phase B — implement the agreed phases
Gates: all of AGENTS.md's, `cargo build --release -p worktrees-cli` FIRST. Show every new test RED first. CHANGELOG under `### Added` in `## [Unreleased]` (count headers). Open a PR per phase, SendMessage with the number + gates. Don't merge — a fable review runs first.

## Rules
- Read AGENTS.md first.
- Never drive David's running app; sandbox by pid only, no scripted input.
- tmux only as `tmux -L <unique>` on EVERY call. Never `git worktree add`.
- Tests never touch real `~/.config/worktrees/`, `~/.claude.json`, `~/.claude/settings.json`, `~/.codex`, `~/.pi`.
- **Do not stress the machine yourself:** run heavy gates one at a time, and never benchmark by spawning dozens of real agents.
- Don't touch the valleos benchmark place or other projects' trees.
- Scratch → `~/.cache/worktrees/worktrees/resource-guard/`.
- No session URLs / Claude-Session trailers; keep Co-Authored-By. AGENTS.md edits need David's OK.
