# Progress log

## Session 2026-08-17/18 — left-nav menu clipping + remove confirm dialog

### What happened

- Read `_tmp/Screenshot 2026-08-17 at 23.37.19.png`: armed remove pair, second
  button ("Confirm remove + branch") below the window edge, no scroll.
- Root-caused to `CtxMenu.tsx:15` — clamp `useLayoutEffect` keyed `[x, y]`, so
  it never re-runs when the menu's CONTENT grows.
- User asked mid-turn for a real confirm dialog with a "cannot be undone"
  warning instead of the inline arm. Asked two scoping questions; answers:
  **both entry points** (nav ctx menu + topbar ⋯) and **show what's at risk**.
- Surveyed modal infra: `.scrim-center` + `.sync-modal` family already exists
  and is used by three dialogs — reused it, invented no new shell.
- Fresh worktree: ran both bootstraps (`git submodule update --init
  --recursive`, `pnpm install` under `nvm use 22.23.2`).

### The correction that mattered

First draft of the dialog said *"9 uncommitted files will be lost."* Driving the
mock harness produced the backend's real answer instead:

    Worktree 'feat-redesign' has uncommitted changes:
    Refusing to remove. Commit/stash, or pass --force.

`ops.rs:1014` REFUSES a dirty remove without `--force` — so nothing was about to
be lost, and the dialog was crying wolf while hiding the one thing the user
needed (tick force). Same re-read showed unpushed commits survive too: the
branch stays, and `git branch -d` will not delete it unmerged. Rewrote the body
against what `remove_one` actually does — two ⚠ (dirty→refused, live tmux→
killed), one plain note (unpushed commits are safe), and a `--force` checkbox.
The harness found this; every gate passed with the wrong copy in.

### Verification

| Check | Result |
|-------|--------|
| `tsc --noEmit` | exit 0 |
| `ctxmenu-check.mjs` (new) | exit 0 |
| `ctxmenu-check.mjs` vs PRE-FIX CtxMenu | **exit 1** — `top 602 → 602, bottom 1100 > 1076` |
| `race-check.mjs` / `dnd-check.mjs` / `relpath-check.mjs` | exit 0 |
| `make test` | exit 0, 314 tests, 0 `not ok` |
| `make lint` | exit 0 |
| `cargo test -p worktrees-core` | 251 passed |
| `cargo test -p worktrees-cli` | 7 passed |
| `cargo test -p app --lib` | 35 passed |
| `cargo check -p app` | exit 0 |

Real driving (mock harness on :5200, viewport 1100×760, content-verified served
source — not a port check):

- ctx menu opened at cursor y=635 → clamped to top 274, bottom **752 ≤ 760**,
  "Remove worktree…" fully visible, `max-height: 744px`, `overflow-y: auto`.
- dialog: correct risks/note/warning, force box present only when dirty,
  del-branch box only when there is a branch, button label tracks both flags.
- dirty + no force → backend refusal, **dialog stays open** with the reason
  inline. Tick force → remove lands, place gone, dialog + scrim closed.
- topbar ⋯ → same dialog, popover closed; clean tree shows no force box.
- Esc dismisses, nothing removed. Console: 0 errors from this change (one
  pre-existing xterm `dimensions` error, mock harness has no real pty).

Screenshots → `~/.cache/worktrees/worktrees/left-nav-menu-bug/`.
