# Findings

## Screenshot evidence (`_tmp/Screenshot 2026-08-17 at 23.37.19.png`)

Right-click menu on place `docker-to-podman` in project `casa-del-valle-…`.
Menu runs from ~y=610 to the window's bottom edge (1080). Visible tail:
`Copy path` → `Copy branch` → `Confirm remove` (armed, danger-tinted, flush
with the bottom edge). **`Confirm remove + branch` is not rendered on screen** —
it is below the viewport. Menu has no scrollbar, so there is no way to reach it.

## Code map

| Thing | Where |
|-------|-------|
| Menu shell (position + clamp + dismissal) | `app/src/CtxMenu.tsx` |
| `.ctxmenu` / `.pop-item` / `.ctx-sep` / `.ctx-life` styles | `app/src/App.css:566-583` |
| Nav place ctx menu items | `app/src/App.tsx:4773-4855` |
| Armed remove pair (ctx menu) | `app/src/App.tsx:4838-4851` |
| Armed remove pair (topbar) | `app/src/App.tsx:4400-4408` |
| `armRemovePlaceCtx` / `confirmRemovePlaceCtx` | `app/src/App.tsx:3046-3061` |
| `armRemove` (topbar) | `app/src/App.tsx:3551` |
| Existing modal shell | `.scrim.scrim-center` (App.css:1373) + `.sync-modal` (1408) + `.sync-h` (1413) + `.sync-body` (1419) + `.sync-foot` (1545) |
| Existing checkbox row in a modal | `.sync-opt` (App.css:1456) |
| Danger footer button | `.sync-foot .enter-btn.danger` (App.css:1549) |

## Backend contract

`confirmRemovePlaceCtx` → `invoke("remove_place", { repo, slug, delBranch, force: false })`.
camelCase over IPC (Tauri renames snake_case). With `force: false` the core uses
`git branch -d`, so an UNMERGED branch is not deleted — it degrades to a warning
while the remove itself still succeeds. So "delete branch" is safe by
construction, and the dialog must not promise more than that.

## Why the clamp never re-runs

```tsx
useLayoutEffect(() => { ...measure + setPos... }, [x, y]);   // CtxMenu.tsx:15,23
```

`x`/`y` are the cursor coords, frozen for the life of the menu. Any content
change (arming remove, a lifecycle row appearing) resizes the box without
re-clamping. A `ResizeObserver` on the menu element is the fix that covers every
caller, including ones that do not exist yet.

## Trap noted (not yet hit)

`getBoundingClientRect()` inside the layout effect measures through the `pop`
keyframe's `scale(0.98)`. `offsetWidth`/`offsetHeight` ignore transforms and are
the right probes for a clamp.
