# Task plan — left-nav context menu: clipped bottom + remove confirm dialog

## Goal

Two things, one session:

1. **Bug**: right-click a worktree in the left nav → "Remove worktree…" arms and
   grows the menu by one row. The menu does not re-clamp, so the last item
   ("Confirm remove + branch") falls off the bottom of the window. Screenshot:
   `_tmp/Screenshot 2026-08-17 at 23.37.19.png`.
2. **Feature** (user, mid-turn): replace the inline two-step arm with a real
   confirm **dialog** carrying an explicit "cannot be undone" warning.

Both land in one PR on branch `left-nav-menu-bug`.

## Phases

| # | Phase | Status |
|---|-------|--------|
| 1 | Reproduce + root-cause the clipping | complete |
| 2 | Decide dialog shape (asked user) | complete |
| 3 | Fix `CtxMenu` clamping (ResizeObserver + max-height/scroll) | complete |
| 4 | Build `RemoveDialog` (scrim-center + sync-modal shell) | complete |
| 5 | Wire nav ctx menu + topbar to the dialog; drop the inline arm | complete |
| 6 | Mock harness parity + verify in the real app | complete |
| 7 | Gates (tsc, cargo check, app tests, bats) | complete |
| 8 | PR | complete |

## Root cause (phase 1 — confirmed by reading)

`app/src/CtxMenu.tsx:15` clamps in a `useLayoutEffect` keyed **`[x, y]`**.
Arming remove swaps 1 item for 2, growing the menu ~1 row, but the effect never
re-runs — the menu was already sitting at `top = innerHeight - h - 8`, so the
new row overflows past the window edge. Two secondary defects in the same
component:

- `.ctxmenu` (App.css:567) has **no `max-height` / `overflow`**, so a menu
  taller than the viewport clamps to `top: 4` and still overflows.
- The clamp measures with `getBoundingClientRect()` while the `pop` keyframe is
  at `scale(0.98)` — the measured box is ~2% small. Use `offsetWidth/Height`
  (transform-independent).

## Decisions

- The dialog's copy is pinned to `ops.rs::remove_one`, not to intuition. A dirty
  tree is REFUSED (not destroyed) without `--force`; unpushed commits survive on
  the branch, which `-d` will not delete unmerged. Only "live tmux session gets
  killed" and "dirty blocks the remove" are ⚠. Found by driving the harness —
  the first draft claimed the files "will be lost" and every gate passed.
- `force` is a checkbox the user ticks, never inferred from `place.dirty`.
- `place.dirty` (≤3s stale) decides what to SAY, never whether the button works
  — the backend is the authority, and disabling would block a just-committed
  tree.

- Dialog reuses the existing modal shell (`.scrim.scrim-center` +
  `.sync-modal` / `.sync-h` / `.sync-body` / `.sync-foot`), not a new one.
- Delete-branch stays a **checkbox** (`.sync-opt` exists) + one danger button,
  rather than two danger buttons — one destructive control, one decision.
- `CtxMenu` still gets fixed even though the dialog removes this menu's tallest
  state: the clamp bug is generic to every menu the shell serves.

## Errors encountered

| Error | Attempt | Resolution |
|-------|---------|------------|
| `grep --include=*.tsx` → `(eval):1: no matches found` | 1 | zsh globbing; quote the pattern or drop `--include` |
