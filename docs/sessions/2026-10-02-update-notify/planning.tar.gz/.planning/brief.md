# Design pass + build: hourly release check, a dismissable update bubble, a blue dot on the gear

## What David wants (2026-10-02)
Poll for new releases periodically (hourly). When one is available: a dismissable "conversation bubble /
banner" bottom-LEFT, and a BLUE dot on the Settings gear meaning "an update is available". He wants a
DESIGN PASS on it first.

## What exists (verify)
- `check_update` (app/src-tauri/src/lib.rs, `latest_release_tag()` ~1388: a `curl -fsSLI` of
  github.com/<repo>/releases/latest, 6s, no API/auth) is called ONCE ~3s after launch and from Settings'
  manual re-check (App.tsx ~4204-4215), gated on `settings.update_auto_check`. `updateAvail = cliStale ||
  cliMissing || appStale` (~3419); the gear already gets an `upd` class + "settings — update available"
  title (`railAlert`, ~3817/6868) — check what that looks like today and its colour.
- Offers: the dock-rail sparkles button (#384) + offers.ts, What's new modal. The bottom-left corner: what
  lives there today (usage meter / status strip / Places rail when mirrored)? Measure, don't guess.
- AGENTS.md rules that bite here: visibility-gated polls (`document.visibilityState`, a hidden tab never
  polls — a poll must still be cheap and must not stack), WebKit button sizing, `useEscape`, accent tokens
  are FILLS not text (contrast across all six themes), "a suggestion's surface may not add preconditions",
  "one mark per fact" (#384 removed the gear's purple offer dot for that reason — reconcile: is the blue
  update dot the ONLY gear mark?), offers-check guards FEED and render.

## Design pass (deliver first, as a short write-up + mock screenshots in the PR body)
- Poll: hourly while visible (and once on regaining visibility if an hour has passed), backoff on failure,
  never while `update_auto_check` is off; cache "latest seen" so a dismissed version stays dismissed and a
  NEWER release re-shows the bubble. Is the existing curl call OK hourly (rate limits? redirect only)?
- The bubble: placement bottom-left without colliding with anything there (measure at 900px and 1280px,
  mirrored Places), what it says (app vs CLI update, version, "What's new" link, Update / Later / dismiss),
  dismissal semantics (per version), keyboard/Escape, motion. Relationship to the existing offers band and
  the sparkles button — one surface or two? Recommend.
- The blue dot: token (check `--accent`/info tokens in tokens.css across themes), size, coexistence with
  any other gear state, title text.
Then build it. Tests red-first: a check script evaluating the real poll scheduling on a VIRTUAL clock
(the termresize-check pattern — real timers make it flaky), offers/feed checks if it touches offers,
mock harness knobs (`?latest=v9.9.9`, `?offline`) and the mock tracks any new command; see it in Chromium
AND headless WebKit (elementFromPoint, all six themes for contrast). Gates per AGENTS.md (`nvm use` +
`corepack pnpm install`). CHANGELOG under a fresh `## [Unreleased]` above `## [0.35.0]` (count headings —
other lanes add entries). Open the PR, watch CI (`gh run watch <id> --exit-status`), reply, STOP.

## Rules
Scratch checkouts only via `worktrees new <name> --ai none --no-spare --no-attach` + `worktrees rm`.
Any throwaway tmux: `tmux -L <unique-name>` on EVERY command incl. kill-server. Don't drive the running
app (mock on a port ≠ 1420). Keep Co-Authored-By; no session URLs. Do not merge.
