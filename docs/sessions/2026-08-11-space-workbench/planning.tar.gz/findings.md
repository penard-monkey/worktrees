# Findings — space-scoped panels + place rename

## Repo / branch state (2026-08-11)

- Fresh branch `ui-space-scoped-panels` off `origin/main` @ `82be263`
  ("close out files-tab-visibility session", #108).
- The old branch `close-out-nav-activity-age` had 1 local commit already
  squash-merged as `c7f2a76`; `rev-list --left-right --count` read `2 1`.

## Concept model (DESIGN.md)

- The unit is a **place** (= worktree = "space"). Identified by **slug**.
- Declared store `$MAIN_ROOT/.worktrees.places.json` — `places` is a **map keyed
  by slug**, values `{lifecycle, pinned, note, last_opened_epoch, created_by,
  created_epoch}` + `#[serde(flatten)] extra` for unknown-key round-trip.
  Rust is **sole writer**; mkdir-O_EXCL lock, per-field merge, atomic rename.
- tmux session name = `<prefix>-<slug>` with `.` → `-`.
- DESIGN.md's layout picture (written pre-dock) describes: left nav = places,
  **top bar = selected place's branch + switch combobox + dirty/ahead-behind
  chips**, main pane = xterm.js. The Files/Terminal **dock** postdates it, which
  is likely the root of the "terminal isn't part of the space" feeling — the
  dock was added beside the model rather than into it.

## Prior art in the immediate neighbourhood

From `docs/sessions/2026-08-10-files-tab-visibility/summary.md` (last merged
session, #104/#105/#106, v0.11.0):

- **`app/src/settings.ts` is the frontend settings module** and the precedent
  to copy. It has `settings_rev` + `SETTINGS_REV` + `migrate()`.
- `loadSettings` merges `{...DEFAULTS, ...persisted}` — **full-blob
  persistence**, so a stored value outranks a changed default *forever* unless
  `migrate()` bumps the rev. Any new per-place state must plan for this.
- Files and Terminal are **tabs in a dock** ("dock switched between Files and
  Terminal"), not independent panes. Confirms the panel state to remember is at
  least: dock open/closed, active tab, width.
- `--nav-w` / `--dock-w` CSS vars are written by App's layout effect but nothing
  consumes them (grid uses inline px) — a known dead-code nit in exactly the
  code we will touch (ROADMAP, right-panel session).

## Constraints that bear on this work

- **ADR 0001** — a cloned repo never supplies argv. Not directly implicated
  (panel geometry is not argv), but it is the reason to keep *UI* state out of
  the repo-visible declared store where a clone could author it.
- **Components defined inside `App()` remount every render** (CLAUDE.md).
  `PlaceRow`/`GroupHeader`/`ProjectNode`/`FlatLens` are already inside `App()`
  and rebuilt on every render (ROADMAP item). Anything new with local state or
  input focus — e.g. a **rename input** — MUST go at module scope with props.
- **HMR is dead inside `.worktrees/`** — restart vite with `--force` after every
  edit; verify by curling the served file, not by reloading.
- Mock harness (`app/src/mock/install.ts`) must track every command in lib.rs.
- Tauri commands must be `async fn`.

## Open: rename has two very different meanings

1. **Display label only** — new declared field (e.g. `title`), nav + top bar
   render it, slug/dir/branch/tmux untouched. Cheap, reversible, no blast radius.
2. **True rename** — `git worktree move` + `git branch -m` + `tmux
   rename-session` + re-key the declared store + invalidate every cached path
   (dock cwd, PTY, file viewer, `last_opened`), plus whatever holds the old path
   open. Large, and partially failable mid-way (non-atomic across 4 systems).

---

## A. Frontend layout map (Explore agent, verified refs)

`app/src/App.tsx` is a **3023-line monolith** — shell, nav, topbar, popovers all
in it. Only `FilesPane.tsx`, `TerminalPane.tsx`, `SettingsSheet.tsx`,
`ProjectSheet.tsx` are extracted. **No store, no context, no router**; all state
is `useState` inside `App()` (starts `App.tsx:1088`) plus the persisted
`Settings` blob.

### Place identity

```ts
const [sel, setSel] = useState<{ repo: string; slug: string } | null>(null); // App.tsx:1091
```

- Identity is the **pair `(repo, slug)`** — `repo` = project root path,
  `slug` = worktree name. Not a path, not a uuid. `null` = Home/briefing.
- The full `Place` is **derived, never stored** (`App.tsx:1593`): looked up out
  of `ws` by `p.root === sel.repo` then `pl.slug === sel.slug`.
- **Consequence for rename: a slug change invalidates `sel` itself**, plus every
  `Record` keyed on `repo|slug`.

### The 5-column grid (`App.tsx:2447`, cols computed inline 2438–2444)

| Column | Element | Lines |
| --- | --- | --- |
| Left rail | `nav.rail` — lens buttons, collapse, add-project, settings | 2449–2466 |
| Nav | `aside.nav` — Home, lens title, filter, `ProjectNode`/`FlatLens` | 2469–2540 |
| Main | `main.main` — topbar → note-strip → `TerminalPane` → statusbar | 2543–2742 |
| Dock | `aside.dock` — resizer, `dock-tabs`, `FilesPane` or `TerminalTabs` | 2745–2820 |
| Right rail | `nav.rail-right` — Files / Terminal icons (`DOCK_RAIL` 2430) | 2825–2841 |

Nav is **hidden, never unmounted** (`.nav.hidden{display:none}`, App.css:77) so
drafts and scroll survive ⌘B — a precedent worth copying for the dock.

### There are TWO terminals, and that matters

1. **`<TerminalPane>` in MAIN** (`App.tsx:2655`) — the **tmux/agent session**,
   keyed by `selected.tmux_session.name`. This is what the topbar controls.
2. **`<TerminalTabs>` in the DOCK** (`App.tsx:2811`) — **owned PTY shells**,
   keyed `` `${sel.repo}|${sel.slug}` ``, restored from the backend live-shell
   registry (658–681): survives place switches within a session, not a restart.

So "the terminal isn't part of the space" is about the **dock** terminal.

### Topbar anatomy (`header.topbar`, 2547–2648; only when `selected && sel`)

- `.identity` (2548–2565): `◆`-prefixed `selected.slug`, branch chip (`↗` + `.hi`
  when branch diverges from slug), `status-cluster` (live dot, dirty count,
  ↑ahead ↓behind, `lifecycle_effective`) — cluster suppressed when `fit.tight`.
- `.controls` (2567–2647): live-badge, **AI profile badge**, Close (two-step
  confirm) / **Enter**, pin toggle, Lifecycle popover, `⋯` menu (Copy path,
  Remove worktree).
- Then `input.note-strip` (2650) — commits on blur via `set_note`.
- Then `footer.statusbar` (2665–2679) — raw tmux facts + `BranchSwitcher`.

**`selected.slug` is rendered as the place's name at App.tsx:2549** — the single
site a display-label rename must change (plus the nav row).

### Panel show/hide — one dock, two settings

- `settings.dock_open: boolean` (default `false`), `settings.dock_tab:
  "files"|"terminal"` (default `"files"`), `settings.dock_width` (360).
- `pickDockTab(tab)` — `App.tsx:2034–2039`, VS Code model: clicking the ACTIVE
  tab closes the dock, otherwise switch + open.
- `toggleDock()` — `2042–2050`, bound to **⌘J** (2116–2120).
- Render gated on `dockShown` from `fitLayout()` — a too-narrow window
  force-hides the dock **without rewriting the preference**. `Settings` is
  INTENT; `Fit` is what renders (settings.ts:175–179).

### Resizable geometry (three levels)

1. `nav_width` (300) — `onResize` App.tsx:2204–2215, `clampNav`.
2. `dock_width` (360) — `onDockResize` 2218–2229 (drag LEFT grows), `clampDock`.
3. Inside Files: tree/viewer divider, `FilesPane.tsx:461–484` + 499–524, clamped
   15–85%. **Two ratios** because the pane flips axis — `files_split_pct` (32)
   and `files_stack_pct` (40); orientation from `orientationFor()`
   (`FilesPane.tsx:437–442`) using `files_layout` vs live `dockW` against
   `SPLIT_AT=620` / `SPLIT_FLOOR=420`.

Engine: `fitLayout()` settings.ts:186–201. Constants 147–154: `RAIL_W 44`,
`MAIN_MIN 420`, `NAV_MIN 220`, `NAV_MAX 460`, `DOCK_MIN 240`.

### ⭐ The key finding: panel state is GLOBAL

`dock_open`, `dock_tab`, `dock_width`, `nav_width`, `files_layout`,
`files_split_pct`, `files_stack_pct`, `files_wrap`, `files_md_source`,
`files_show_ignored` are **flat scalars** on `Settings` — one value for every
place. That is exactly the jarring-switch complaint.

Two exceptions exist, and they are the precedent to copy:

1. **`settings.term_tab_names`** (settings.ts:56) —
   `Record<string, Record<number,string>>` keyed `` `${repo}|${slug}` ``. The
   **only persisted per-place UI state**. Written by `renameTermTab`
   (App.tsx:1570–1579), read at 2814, and it **prunes empty buckets**
   (1576–1577) so untouched places leave no trace in `ui-state.json`.
2. **`dockFile`** (App.tsx:1160) — per-place but **deliberately reset**:
   `useEffect(() => { setDockFile(null); setReading(false); }, [sel?.repo, sel?.slug])`
   at **App.tsx:1165**. Switching away and back loses the open file. This effect
   is a direct obstacle to "remember what I left open".

Other `Record` state is keyed **per-project-root**, not per-place: `collapsed`,
`manual_order`, `init_dismissed`.

## B. Settings module, read firsthand (`app/src/settings.ts`)

- Persisted 1:1 by `get_settings` / `set_settings`; real backend writes
  `ui-state.json` in the app config dir.
- `loadSettings()` (242): `{ ...DEFAULTS, ...(raw ?? {}) }`, normalizes theme,
  then `migrate(s, raw.settings_rev ?? 0)` and **saves if it moved** (249).
- `SETTINGS_REV = 1`; `migrate()` (235) re-applies changed defaults once.
- `saveSettings()` (257) — **250 ms debounce**, single `invoke("set_settings")`,
  errors swallowed for the harness. Whole blob every time.
- ⚠ Full-blob + `{...DEFAULTS, ...persisted}` means **a per-place map grows the
  blob monotonically** and every keystroke-ish change rewrites the whole file.

## C. ui-state.json persistence, end to end (Explore agent)

### ⭐ The backend is schema-BLIND

`app/src-tauri/src/lib.rs:467–505` is the whole of it:

```rust
// ── UI settings (app-global; ui-state.json in app-config-dir) ────────────────
// Kept SEPARATE from per-repo declared state (.worktrees.places.json). Free-form
// JSON so the frontend owns the schema; a corrupt/absent file → null (defaults).
```

- `ui_state_file()` 471–475 — `app_config_dir()` + `create_dir_all` +
  `join("ui-state.json")`.
- `get_settings` 491–498 — `async fn ... -> Result<Option<serde_json::Value>, String>`.
  **Never `Err` on read/parse failure**: missing file and corrupt file both
  collapse to `Ok(None)` → all DEFAULTS, silently overwritten on next save.
- `set_settings` 500–505 — `async fn (app, settings: serde_json::Value)`,
  `to_vec_pretty` + `fs::write`.
- `settings_info` 484–489 → `SettingsInfo { dir, file }` (the only struct here).
- Registered in `generate_handler!` lib.rs:3067 (entries 3116, 3129, 3130).

**There is NO Rust struct for the settings schema.** The payload is
`serde_json::Value`. ⇒ **Per-place panel state is a PURE FRONTEND change** — no
Rust, no new command, no mock work beyond what already exists.

Documented consequence of the opacity (lib.rs:879–883): the auto-fetch watcher
thread can't read the blob, so the frontend pushes `set_fetch_interval`
separately. Any *backend* consumer of new settings would need the same trick —
ours has none.

### The save funnel and its traps

- State lives in `useState<Settings>(DEFAULTS)` at **App.tsx:1125**. No hook,
  `settings.ts` is a plain module.
- **`updateSettings(patch)` — App.tsx:1551–1565** is the funnel: merge →
  `applySettings` (DOM vars, sync) → `saveSettings(next)`.
- ⚠ **Three callbacks BYPASS the funnel** and inline the same apply/save so they
  can stay `useCallback`-stable: `toggleNav` (2023–2031), **`toggleDock`
  (2042–2050)**, `selectLens` (2053–2063). `toggleDock` is squarely in scope —
  any per-place write must be added there too or ⌘J silently won't persist.
- ⚠ **Drag resizers call `updateSettings` on every `mousemove`** (nav
  2208–2211, dock 2222–2225). The 250 ms debounce is the *only* thing keeping a
  drag from writing hundreds of files. A per-place width write inherits this.
- ⚠ **No flush on unload/quit** — a change made <250 ms before the window dies
  is lost.
- **Hydration guard** `useLayoutEffect` App.tsx:1513–1549: a `hydrated` ref plus
  a `preHydration` ref that records early patches; saves gated on
  `hydrated.current` so a pre-hydration ⌘B can't write a DEFAULTS-seeded blob
  over disk. After load, `preHydration` is merged over loaded state and saved
  once. **Any per-place restore-on-select must run AFTER hydration** or it will
  restore from DEFAULTS and then persist that.

### Validation is thin

- Missing fields → `DEFAULTS` via the spread. Missing/non-number `settings_rev`
  → treated as `0`, so rev-1 migration runs.
- **Unknown/extra fields are silently PRESERVED** — copied by the spread, never
  stripped, written back by the next save. Rust's `Value` passes them through.
  (Good for forward-compat; also means stale per-place keys never self-clean.)
- Only `theme`/`theme_light`/`theme_dark` are validated. **`density`, `lens`,
  `dock_tab`, `files_layout`, `sort_mode`, `sort_dir` are unvalidated** — a
  garbage value flows straight into render logic. Numbers are clamped at *use*
  time (`clampNav`/`clampDock` in `fitLayout`), not at load.

### Mock harness (`app/src/mock/install.ts`)

Backed by **`sessionStorage`**, key `MOCK_SETTINGS_KEY = "wt-mock-ui-state"`
(install.ts:40). `settings_info` 1001–1002 (hardcoded demo paths),
`get_settings` 1008–1016, `set_settings` 1017–1019. `?whatsnew` returns a
partial `{last_seen_version:"0.2.0"}`, which only works because of the DEFAULTS
spread. Unknown commands resolve to `null` + `console.warn` (install.ts:5–7).

⚠ **No automated test covers any of this.** `test/` is the bats CLI suite;
nothing in `test/` or `app/` references `ui-state`, `get_settings`, or
`settings_rev`. Coverage for this work has to be new.

---

## D. Places, slug identity, and rename (Explore agent)

### Slug IS the name — there is no display field

- `crates/worktrees-core/src/store.rs` is the whole store (233 lines).
  `STORE_FILE` :16, `store_path()` :76 = `canonicalize(repo)/.worktrees.places.json`.
- `Declared` :23–60 — every field `#[serde(default, skip_serializing_if=…)]`:
  `lifecycle`, `pinned`, `note`, `last_opened_epoch`, `last_worked_epoch`,
  `profile_id`, `profile_epoch`, + `#[serde(flatten)] extra`.
- `Store` :62–72 — `version`, `updated_epoch`, `places: BTreeMap<String,Declared>`,
  `extra`.
- `edit()` :162–175 is the **only mutator** — process `Mutex` + cross-process
  `DirLock`. ⚠ `:170` `entry(slug).or_default()` — **edit CREATES on absent, and
  there is no delete-key API at all.**
- **Identity = slug = `basename(worktree_dir)`**, or the literal `"(main)"`
  (`project.rs:299`; restated `lib.rs:1052–1059`). Re-derived from disk every
  poll, never stored.

### Rename: does not exist anywhere

Grepped `rename|mv|retitle|relabel|rename-session|git branch -m` across
`crates/`, `app/src/`, `app/src-tauri/src/`, docs. Every hit is `fs::rename`
plumbing or prose. No CLI verb (`main.rs:79–101`), no core op, no Tauri command,
no MCP tool, no `tmux rename-session`, no `git branch -m`.

`cmd_switch` is the nearest thing — moves an existing dir to a different
*branch*; dir name and therefore slug and session stay put.

⚠ `cmd_rm` **never deletes the store entry** (`remove_one`, ops.rs ~980–1050 —
no `store::edit`; confirmed by `provision.rs:14`). So dead slugs linger in the
declared store already.

### The precedent that answers the design question

`profile.rs:207–210` — AI profiles already split identity from label:
*"`id` … Immutable. Directory name + keychain identity. Never renamed."* /
*"`name` — What the user sees and can rename freely."* Places lack this split;
adding `title` gives them the same one.

### Derivation chain

```
branch ──slugify('/'→'-')──▶ slug ══is══ basename(worktree dir) ──▶ store key
                              │
                              ├─ session_name = "{prefix}-{slug}".replace('.','-')
                              │      (project.rs:74-76)  └─▶ "<session>~term[~N]" dock shells
                              └─ COMPOSE_PROJECT_NAME = {prefix}/{slug} (provision.rs:511)
```

⚠ **Claude history is keyed on the ABSOLUTE worktree path**, mangled
char-by-char (`project.rs:645–650`) — a directory rename orphans conversation
history and breaks auto-resume. This is the single fact that decides Phase 3.

⚠ `COMPOSE_PROJECT_NAME` is recorded into `.worktree.env` and **the recorded
value wins forever** (`provision.rs:522`) — a slug rename would not move running
containers.

⚠ Dock shell PTYs are keyed `ShellKey = (repo, slug, index)` (`lib.rs:2712`).

### UI precedent for an editable per-place field

`App.tsx:2650–2652` — the note strip: uncontrolled input, commit on blur via
`set_note`, and `key={repo + slug + currentNote}` so a value arriving from the
poll **remounts** the field instead of fighting the cursor. Mock mirrors at
`install.ts:524/530/535/540`.

---

## E. Fable review of plan v1 (2026-08-11) — 4 blocking, all verified true

1. **`ls --json` is live-only; emitting `title` from `place_json` violates it.**
   Verified: `project.rs:253` comment, `project.rs:349` `declared: None`,
   `model.rs:43–44` "the CLI emits `null` (live-only). The app overlays it."
   **And it was unnecessary** — `lib.rs:270` already serializes the whole
   `Declared` into `place["declared"]`, so the app gets `title` free.
2. **Two `dock_*` read sites missed**, both real desyncs: `App.tsx:1169`
   `filesDockShown` (auto-closes reading mode) and `App.tsx:2067`
   `keyRef.current.filesTabOpen` (gates ⌘⇧E).
3. **A static grid span is unimplementable** — `App.tsx:2438–2444` `.filter(Boolean)`
   *removes* columns, so line indices shift with nav collapse and dock
   visibility. Reviewer's alternative (flex `.space` wrapper) adopted.
4. **Patch-writes to `place_panels` reproduce the bug** — open dock in A, switch
   tab in B, return to A and you get B's tab. Must write the full effective
   triple.

Should-fix also folded in: TmuxBanner placement, prune call sites are
`App.tsx:1911`/`2008` (not 2540 — that's the Rust command), `remove_project`
strands keys, prune-on-load must be post-first-successful-snapshot,
`preHydration` shallow merge at `App.tsx:1523` would replace the whole map,
`dockFile` exclusion must be written down, `--nav-w` **is** consumed
(`App.css:30` + `tokens.css:113`), and six more `title` display/search sites
(⌘K matcher `App.tsx:481–494`, alpha sort `:1939`, Home rows `:2701`, empty-session
card `:2659`, ctx hint `:2898`, plus `Declared` typed twice —
`App.tsx:19` and `mock/fixtures.ts:6`).

**Verdict: ship with the blocking fixes.** The three architecture calls —
title-not-identity, global-as-seed with per-place override, and Phase 2 as a
pure-frontend change — were judged correct and well-evidenced.
