# Task plan — the space owns its workbench

**Branch:** `ui-space-scoped-panels` (off origin/main @ `82be263`)
**Worktree:** `.worktrees/ui-tweaks`
**Revision:** v2 — rewritten after a fable review found 4 blocking problems in
v1. Every change from v1 is marked **[rev2]** with the reason.

## Goal

Three related changes, all pushing toward one idea: **a space owns its whole
workbench, not just its tmux session.**

1. The top banner should crown the *space* (terminal **and** dock), not just the
   agent/tmux pane.
2. Each space remembers its own panel state, so switching back is not jarring.
3. A place can be renamed from the UI.

## Root cause of #1 (found, not guessed)

`.topbar` is a **child of `<main>`** (`App.tsx:2543` → `2547`). The grid
(`App.tsx:2438–2447`) is five columns:

```
rail | nav | main[ topbar · note · TerminalPane · statusbar ] | dock | rail
```

The banner is structurally a header *of the tmux terminal column*. The dock sits
**beside** it, outside its scope, titled with a bare generic word (`App.tsx:2751`).
Nothing on screen says the dock belongs to the selected place. DESIGN.md's layout
picture predates the dock entirely — it was added beside the model, not into it.

---

## Phase 1 — promote the banner to a space header (PR 1)

### **[rev2] Mechanism changed: a flex wrapper, not a grid row-span.**

v1 said "span the header across the main+dock columns." That is not
implementable as drawn. The columns are **conditionally removed, not zeroed** —
`App.tsx:2438–2444` builds `gridCols` with `.filter(Boolean)`, so the main
column's line index shifts with nav collapse and the span end shifts with dock
visibility. A static `grid-column` cannot express it.

**Adopted shape** — collapse main+dock into one grid cell and lay them out with
flex inside it:

```
grid:  rail | nav | .space | rail          ← 4 columns, dock is no longer one

.space          display:flex; flex-direction:column; min-width:0; min-height:0
├── .space-header    (topbar + note-strip)     flex: 0 0 auto
└── .space-body      display:flex; flex-direction:row; min-height:0
    ├── <main>       flex: 1 1 auto; min-width:0
    └── <aside.dock> flex: 0 0 {fit.dockW}px
```

Why this over the span: no conditional line indices, no span math, and the
`.reading` overlay anchors to `.space` naturally instead of to a `<main>` whose
box just changed meaning.

`fitLayout()` is untouched — it stays width-only and keeps returning
`{navW, dockW, mainW}`; `RAILS_W` arithmetic is unchanged because both rails are
still real grid columns. `gridCols` becomes
`[rail, navShown ? navW : null, "minmax(0,1fr)", rail]`.

### What moves

- `{topbar + note-strip}` lift out of `<main>` into `.space-header`.
- `TerminalPane` and `statusbar` **stay** in `<main>` — the statusbar is
  genuinely about the tmux pane (raw session name, `pane0 claude`,
  `BranchSwitcher`).
- Header renders only when a place is selected; otherwise `.space-body` is the
  briefing home screen at full height.

### **[rev2] Details v1 left unspecified**

- **`minmax(0,1fr)` / `min-height:0` chain.** The comment at `App.tsx:2435–2437`
  explains why a bare `1fr` is wrong for columns; the same footgun applies to the
  new flex column. `.space`, `.space-body` and `<main>` each need
  `min-width:0; min-height:0` or the terminal refuses to shrink.
- **`TmuxBanner` placement.** It renders as the first child of `<main>`, *above*
  the topbar (`App.tsx:2544`; App.css:417–419 says so explicitly: "it sits above
  the top bar"). After the move it would land *below* the space header.
  **Decision: keep it above the header**, at the top of `.space` — it is a
  standing "the tool is broken" condition, and demoting it under a per-place
  header would be a downgrade. It stops being a per-place element.
- **`.reading` overlay.** Today it is positioned against `.main`
  (`.main{position:relative}`, App.css:415) and offset `right: dockShown ?
  -fit.dockW : 0` (`App.tsx:2724`) so it deliberately spills over the dock.
  Re-anchor to `.space-body` and **drop the negative-right hack** — spilling over
  the dock is exactly what a `.space-body`-anchored overlay does for free.
  Accepted consequence: it will no longer cover the note-strip (now in the
  header). Cosmetic; call it out in the PR.
- **xterm resize is safe.** `TerminalPane` refits via its own `ResizeObserver`
  (`TerminalPane.tsx:144–146`), so it does not depend on the header's position.
  Dragging `.dock-resizer` keeps the header width constant — main+dock sum is
  fixed — so the header does not reflow during a drag.
- **[rev2] `--nav-w` is NOT dead.** v1 called it "consumed by nothing." False:
  `App.css:30` uses `var(--nav-w)` in the base `.app` rule and `tokens.css:113`
  defines it (`--nav-w: 300px`). Retiring the layout effect
  (`App.tsx:1619–1623`) is only safe because the inline style always wins — so
  the retire must **also** update `App.css:30` and `tokens.css:113`, or the base
  rule silently resolves to a stale 300px. Given it is now a three-file change,
  **defer it out of this PR** and leave the ROADMAP nit standing.
- **[rev2] `MAIN_TIGHT`.** `settings.ts:184` retires the status-cluster when
  `mainW < 560`. The header now spans main+dock, so badges will retire earlier
  than the header's real width warrants. Gate the cluster on the header's width
  (`mainW + dockW`), not `mainW`.

---

## Phase 2 — per-space panel memory (PR 2)

**Precedent to copy exactly:** `settings.term_tab_names` (settings.ts:56) — the
only existing persisted per-place UI state. `Record<string, …>` keyed
`` `${repo}|${slug}` ``, written by `renameTermTab` (App.tsx:1570–1579), pruning
empty buckets so untouched places leave no trace.

### What is remembered (deliberately narrow)

```ts
type PlacePanels = {
  dock_open: boolean;
  dock_tab: "files" | "terminal";
  dock_width: number;
};
place_panels: Record<string, PlacePanels>;   // key `${repo}|${slug}`
```

**Only these three.** `files_*` (layout, split/stack pct, wrap, md-source,
show-ignored) stay **global** — viewer preferences, not "which panel is open."
`nav_width`/`nav_collapsed` stay global too: the nav is how you *leave* a space,
so it must not move under you when you arrive.

**[rev2] `dockFile` (the open file) is explicitly OUT of scope, and that is a
decision, not an omission.** `App.tsx:1165` resets it on every place switch;
`findings.md` flags that as "a direct obstacle to remembering what I left open."
It is excluded because a remembered path can be deleted, renamed, or gitignored
between visits, which turns a restore into an error toast on arrival. The user's
phrase was "open/closed files/terminal" — panel state, not document state.
**Record this in the PR body** so it does not resurface as a bug report.

### Semantics

- **Global values remain the seed.** A place with no entry inherits the current
  globals, so a never-visited place opens looking like the one you came from —
  no jarring reset on first visit, which is the same complaint in reverse.
- **Effective read:** `eff = { ...settings, ...(settings.place_panels[key] ?? {}) }`.
- **[rev2] Write the FULL triple, never a patch.** v1 said `updatePanels` writes
  "the patch" to both scopes. That reproduces the bug: ⌘J-opening the dock in A
  stores only `{dock_open:true}`; picking Terminal in B moves the *global*
  `dock_tab`; returning to A shows the dock open **on B's tab**. Partial memory
  is still "it changes what you left it in." So: on any panel write with a place
  selected, snapshot the whole effective `{dock_open, dock_tab, dock_width}` into
  `place_panels[key]`, and mirror the patch to the globals as last-used seed.

### Call sites that must switch from `settings` to `eff`

| Line | Today | Becomes |
| --- | --- | --- |
| 1613 | `fitLayout(settings, dockEligible, vw)` | `fitLayout(eff, …)` |
| 1617 | `fitLayout({...settings, dock_open:true}, …)` (`dockFits`) | `{...eff, dock_open:true}` |
| **1169** | **[rev2]** `filesDockShown = settings.dock_open && settings.dock_tab === "files"` | `eff` |
| **2067** | **[rev2]** `keyRef.current.filesTabOpen = settings.dock_open && …` | `eff` |
| 2210 | `dockShown ? settings.dock_width : 0` (nav clamp) | `eff.dock_width` |
| 2751/2753/2789 | `settings.dock_tab` (dock title, tools, body) | `eff.dock_tab` |
| 2827 | `dockShown && settings.dock_tab === d.key` (rail active) | `eff.dock_tab` |
| 2034–2039 | `pickDockTab` | `eff` + `updatePanels` |
| 2218–2229 | `onDockResize` → `updateSettings({dock_width})` | `updatePanels` |

**[rev2] 1169 and 2067 were missed in v1 and are a real desync**, not
bookkeeping: leave them on global `settings` while render uses `eff` and ⌘⇧E
opens the full-pane reader over a dock that is closed for this place, while the
auto-close effect fails to fire on a place switch. Grep confirms the rest of the
table is complete — no `dock_open`/`dock_tab`/`dock_width` reader exists outside
`App.tsx` and `settings.ts`.

### Traps to clear

1. **`toggleDock` bypasses `updateSettings`.** `App.tsx:2042–2050` inlines
   apply/save inside `setSettings(prev => …)` with `useCallback([])`, and does
   not close over `sel`. Fix: read the place from a `selRef`. **[rev2]** v1
   justified this by "the keydown effect needs `[]`-stability" — overstated, that
   effect already re-registers on `settings.nav_collapsed` (`App.tsx:2144` deps).
   Keep the ref anyway (it is the cheaper shape), but the real reason is avoiding
   churn, not correctness.
2. **[rev2] Pre-hydration shallow-merge hole.** `App.tsx:1523` merges
   `{...s, ...preHydration.current}`. If a pre-hydration panel write lands in
   `preHydration`, it **replaces the entire loaded `place_panels` map**. Exclude
   `place_panels` from pre-hydration recording (or deep-merge that one key).
3. **Debounce + drag.** `saveSettings` is a 250 ms trailing debounce
   (settings.ts:256–264) and the dock resizer fires on every `mousemove`. Same
   coalescing applies; there is **no flush on quit**, so a resize <250 ms before
   quit is lost. Accepted, pre-existing.

### **[rev2] Growth control — corrected wiring**

- **Prune on removal in ONE funnel.** v1 cited "App.tsx:2540", which is the Rust
  command definition, not a frontend call site. The two real ones are
  `App.tsx:1911` (context menu) and `App.tsx:2008` (topbar confirm). Prune in a
  shared helper both call, not at each site.
- **Prune on load means "once, after the first successful `list_workspace`"**,
  not at settings hydration — at hydration there is no snapshot to compare
  against. Guard per-project: `ProjectView` carries an ok/error variant
  (`lib.rs:327–332`), and a repo that failed to snapshot must **not** have its
  places garbage-collected.
- **`remove_project` (lib.rs:460–465) strands keys.** An untracked repo is
  absent from `ws.projects`, so it is neither "succeeded" nor "failed" and the
  snapshot GC never sees it. Either prune on `remove_project` too, or write the
  acceptance down. **Decision: prune there** — it is one line and the alternative
  is unbounded.
- Drop empty buckets, mirroring `renameTermTab` (App.tsx:1576–1577).
- **[rev2] Offer a reset.** There is no affordance to clear a place's remembered
  panels once set. Add "Reset panel layout" to the `⋯` menu, or accept and note
  it. Cheap; prefer adding it.

**No `SETTINGS_REV` bump.** A new key defaulting to `{}` is filled by the
`{...DEFAULTS, ...persisted}` spread; `migrate()` is only for *changed* defaults.

### Backend work: none

`get_settings`/`set_settings` take `serde_json::Value` (lib.rs:491–505) — the
backend is schema-blind. No Rust, no new command, no mock change.

---

## Phase 3 — rename a place (PR 3)

### The decision: rename the LABEL, not the identity

`slug` is not a name the tool stores — it is **`basename(worktree_dir)`,
re-derived from disk on every poll** (`project.rs:299`; restated
`lib.rs:1052–1059`). A real rename means renaming the directory, which fans out
across six systems, non-atomically:

| System | What breaks |
| --- | --- |
| git | `git worktree move` + re-registration |
| declared store | `BTreeMap` key must move; **no delete-key API** — `store.rs:162–175` has only `edit`, which *creates* on absent (`store.rs:170`) |
| tmux | `session_name = "{prefix}-{slug}".replace('.','-')` (`project.rs:74–76`) plus every `~term` / `~term~N` sidecar (`tmux.rs:24–27`) |
| **Claude history** | keyed on the **absolute worktree path**, mangled char-by-char (`project.rs:645–650`). A dir rename **orphans the conversation history and breaks auto-resume.** |
| compose | `COMPOSE_PROJECT_NAME` recorded into `.worktree.env` **wins forever** (`provision.rs:522`) — running containers do not move |
| in-app | `sel`, `ShellKey = (repo,slug,index)` (`lib.rs:2712`), `term_tab_names`, `manual_order`, `collapsed`, and Phase 2's `place_panels` are all slug-keyed |

The Claude-history row alone is disqualifying: a user renaming what looks like a
label would silently lose their agent conversation.

**The codebase already contains the right pattern one layer up.** AI profiles
split identity from label — `profile.rs:207–210`: *"`id` … Immutable. Directory
name + keychain identity. Never renamed."* / *"`name` — What the user sees and
can rename freely."* Places get the same split.

### What ships

**Core** — one field on `Declared` (`store.rs:23–60`):

```rust
#[serde(default, skip_serializing_if = "Option::is_none")]
pub title: Option<String>,
```

Free by construction: `Declared` already has `#[serde(flatten)] extra`, `edit()`
merges per-field, and the test at `store.rs:203–222` pins exactly this
forward-compat story. **No `version` bump.**

**Tauri** — `set_title(repo, slug, title)`, a clone of `set_note`
(`lib.rs:523–529`; empty string → `None`). Register in `generate_handler!`
(lib.rs:3067). Add the mock case beside `set_note` at `mock/install.ts:535`.

**[rev2] CLI change DROPPED — it was a contract violation and bought nothing.**
v1 wanted `title` emitted from `place_json`. But `ls --json` is **deliberately
live-only**: `project.rs:253` — `// ── \`ls --json\` (live-only: declared=null …)`,
`project.rs:349` — `declared: None`, and `model.rs:43–44` — *"Declared state; the
CLI emits `null` (live-only). The app overlays it."* Carrying `title` would mean
adding a store read to the CLI snapshot path and changing shipped `ls --json`
output — the exact surface CLAUDE.md orders diffed against the shipped binary.
**The app already gets it for free:** `lib.rs:270` serializes the whole
`Declared` into `place["declared"]`, so the UI reads `selected.declared?.title`
with zero core changes. CLI and MCP surface for `title` joins the deferred list.

**UI**
- Entry point: the `⋯` more-menu (`App.tsx:2629–2646`). ⚠ That menu is gated
  `{!selected.is_main && …}` — **Rename must NOT inherit the gate.** The main
  checkout's slug is the literal `"(main)"`, precisely where a title helps most.
- The editor is a text input, so per CLAUDE.md it **must be a module-scope
  component with props** — components defined inside `App()` get a new identity
  every render and would drop focus on every poll.
- Follow the note-strip's remount trick (`App.tsx:2650–2652`): uncontrolled
  input, commit on blur, `key={repo + slug + currentValue}` so a value arriving
  from the poll remounts the field instead of fighting the cursor.
- **Display rule: `title ?? slug`, and when a title is set show the slug as a
  secondary chip** beside the branch chip. Identity must stay visible — session
  name, directory, "Copy path" and the statusbar are all slug-derived.

### **[rev2] Every display/search site — v1 listed two, there are eight**

| Site | File:line | Action |
| --- | --- | --- |
| Topbar name | App.tsx:2549 | `title ?? slug` + slug chip |
| Nav rows | `PlaceRow` | `title ?? slug` |
| **⌘K QuickSwitch** | App.tsx:481–494 | fuzzy-matches slug/branch/project/note **only** — a renamed place becomes unfindable by its visible name in the switcher power users live in. Add `title` to the match set **and** render it. |
| **Alpha sort** | App.tsx:1939 | orders by slug; with titles displayed the order reads broken. Sort by the displayed name. |
| Home resume rows | App.tsx:2701 | `title ?? slug` |
| "No live session for {slug}" card | App.tsx:2659 | decide — probably keep slug (it names the tmux target) |
| Context-menu hint | App.tsx:2898 | `title ?? slug` |
| Nav filter box | nav filter | must match both title and slug |

**[rev2] `Declared` is typed in TWO files** — `App.tsx:19` and
`app/src/mock/fixtures.ts:6`. Both need `title`, or the mock harness and the real
app disagree.

**[rev2] Duplicate titles** are unaddressed and that is accepted: two places may
carry the same title, and the always-visible slug chip is the disambiguator.
State it in the PR rather than adding a uniqueness constraint the store cannot
enforce.

### Explicitly deferred (write it down, don't build it)

True identity rename (dir + branch + session + store key). The honest shape is a
`worktrees rename` **CLI verb** owning all six systems with a recovery path, not
a UI button — and it must answer the Claude-history question first. Also
deferred: `title` in CLI human output, `ls --json`, and MCP. → ROADMAP at
close-out.

---

## Sequencing

Three PRs. 1 and 2 both touch the dock render, so structural first.

| PR | Scope | Touches |
| --- | --- | --- |
| 1 | space header (flex wrapper) | `App.tsx`, `App.css` |
| 2 | per-space panel memory | `App.tsx`, `settings.ts` |
| 3 | title/rename | `store.rs`, `lib.rs`, `install.ts`, `fixtures.ts`, `App.tsx`, `App.css` |

## Verification

Per CLAUDE.md, **assert layout, don't eyeball it**:

- Mock harness (`pnpm dev:mock`) + Playwright: `getComputedStyle` to prove the
  header spans the terminal **and** the dock — with the flex shape, assert
  `.space-header` width === `.space-body` width, and that it holds in all four
  nav-collapsed × dock-open combinations.
- Per-place memory: select A → open dock on Terminal at width W → select B →
  close dock → back to A → assert dock open, tab `terminal`, width W. Read it
  from computed style, not from the settings object. **[rev2]** Add the
  cross-contamination case the patch-write bug would have shipped: A open on
  Files, B switched to Terminal, back to A must still be **Files**.
- ⚠ **HMR is dead inside `.worktrees/`** — restart vite with `--force` after
  every edit; kill by `lsof -ti:PORT -sTCP:LISTEN` **plus a content grep** of the
  served file (two vite instances can hold one port); diff
  `curl -s localhost:PORT/src/App.css` against disk before debugging a change
  that "didn't apply".
- `cargo test -p worktrees-core` — `title` round-trip **plus unknown-key
  preservation** (store written by a newer app, read by an older one).
- **[rev2]** Diff `ls --json` against the SHIPPED binary (`~/.local/bin/worktrees`)
  to prove Phase 3 did **not** change CLI output.
- ⚠ **No existing automated coverage** of `ui-state.json`, `get_settings`, or
  `settings_rev` anywhere in `test/` or `app/`. Phase 2 coverage is net-new.

Gates before each PR (from `.claude/close-out.md`):

```sh
cargo build --release -p worktrees-cli   # FIRST — stale release binary breaks bats
make test && make lint
cargo test -p worktrees-core && cargo test -p worktrees-cli
cd app && ./node_modules/.bin/tsc --noEmit && cargo check -p app
```

Bootstrap this worktree first if untouched: `git submodule update --init
--recursive`, and `pnpm install` in `app/` under Node ≥ 22.13.

## Status

| Phase | State | Notes |
| --- | --- | --- |
| 0. Restore context + branch | complete | fresh branch off origin/main |
| 1. Explore architecture | complete | 3 agents; see `findings.md` |
| 2. Draft plan | complete | v1 |
| 3. Fable review | complete | 4 blocking, 6 should-fix, 5 nits |
| 4. Revise from review | complete | v2 — all 4 blocking folded in |
| 5. PR1 space header | **merged** | #110 `146998c`; review 5 filed / 0 confirmed |
| 6. PR2 panel memory | **merged** | #111 `fec2127`; review found 1 REAL bug, fixed |
| 7. PR3 place title | in_progress | #112 pushed; review running |
| 8. Close-out | pending | archive, ROADMAP, index row, fresh branch |

### Deviations from the plan, and why

- **PR1 used a flex `.space` wrapper, not a grid row-span** — the reviewer was
  right that `.filter(Boolean)` *removes* columns, so line indices shift.
- **No `.space-header` wrapper.** Planned, then dropped: the topbar IS the
  banner. The a11y argument for restoring it was filed and then refuted (inside
  `<main>` the header mapped to `sectionheader`, so no banner landmark existed
  to lose; it now maps to `banner`, a net gain).
- **`--nav-w` retire deferred** — it really is consumed (`App.css:30`,
  `tokens.css:113`), making it a three-file change unrelated to this work.
- **PR3 dropped the `ls --json` change entirely** — the CLI is live-only and the
  app already receives the whole `Declared` via `lib.rs`'s overlay.
- **PR3 ungated the whole `⋯` menu**, not just Rename: Copy path applies to the
  main checkout too. Only Remove stays `!is_main`.

## Errors encountered

| Error | Attempt | Resolution |
| --- | --- | --- |
| v1 planned a static `grid-column` span over columns that are conditionally removed (`App.tsx:2438–2444` `.filter(Boolean)`) | 1 | Replaced with a flex `.space` wrapper; no line-index math |
| v1 planned to emit `title` from `place_json`, violating the live-only `ls --json` contract (`project.rs:253,349`; `model.rs:43–44`) | 1 | Dropped — `lib.rs:270` already hands the app the whole `Declared` |
| v1 missed two `dock_*` read sites (App.tsx:1169, 2067) | 1 | Added to the switch table; they desync reading mode |
| v1's patch-writes to `place_panels` reproduced the cross-place bleed the feature exists to kill | 1 | Write the full effective triple on every panel write |
