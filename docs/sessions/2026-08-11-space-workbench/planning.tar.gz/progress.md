# Progress log

## Session 2026-08-11 — plan: the space owns its workbench

**Branch:** `ui-space-scoped-panels` off `origin/main` @ `82be263`.
Previous branch `close-out-nav-activity-age` was already squash-merged as
`c7f2a76`; `rev-list --left-right --count origin/main...HEAD` read `2 1`.

### Done

- Restored context, fetched, cut a fresh branch off `origin/main`.
- Three parallel Explore agents mapped: frontend layout, `ui-state.json`
  persistence, and the places/declared-store + rename surface. All recorded in
  `findings.md` (sections A–D) with file:line evidence.
- Read `DESIGN.md`, `ROADMAP.md`, `docs/adr/0001`, `.claude/close-out.md`, and
  the last merged session summary (2026-08-10 files-tab-visibility).
- Wrote plan v1 → fable review → **plan v2** in `task_plan.md`.

### Review outcome

Fable review returned **4 blocking, 6 should-fix, 5 nits**. I independently
verified all four blocking claims against the code before revising:

| Claim | Verified by |
| --- | --- |
| `ls --json` is live-only | `project.rs:253,349`; `model.rs:43–44` |
| app already gets `Declared` | `lib.rs:265–272` |
| two missed `dock_*` read sites | `App.tsx:1169`, `App.tsx:2067` |
| grid columns are removed, not zeroed | `App.tsx:2438–2444` `.filter(Boolean)` |
| `--nav-w` is consumed after all | `App.css:30`, `tokens.css:113` |
| prune call sites | `App.tsx:1911`, `App.tsx:2008` |

Verdict: **ship with the blocking fixes** — all four are folded into v2.

### Bootstrap (done 2026-08-11)

`git submodule update --init --recursive`, `pnpm install` under Node 22.23.2,
and `cargo build --release -p worktrees-cli` all green.

### PR 1 — space header (implemented)

Files: `app/src/App.tsx`, `app/src/App.css`, `app/src/settings.ts`.

- `.app` grid 5 cols → 4: `rail | nav | .space | rail`. The dock is no longer a
  grid track.
- New `.space` (flex column): TmuxBanner, topbar, note-strip, `.space-body`.
- New `.space-body` (flex row): `<main>` + `<aside.dock>` + the reading overlay.
- Dock sized inline `flex: 0 0 {fit.dockW}px`.
- `.reading` moved out of `<main>` into `.space-body`; inline
  `right: dockShown ? -fit.dockW : 0` replaced by CSS `inset: 0`.
- `fitLayout`'s `tight` now `mainW + dockW < MAIN_TIGHT` — the header spans both.
- `TmuxBanner` deliberately kept ABOVE the space header (app-level condition).
- Deferred: retiring the `--nav-w`/`--dock-w` effect (it is a three-file change,
  `App.css:30` + `tokens.css:113` really do consume `--nav-w`).

### PR 1 verification (measured, not eyeballed)

Mock harness on :5199 (`--force`, content-checked against the served bundle).
Playwright + `getBoundingClientRect`:

| Assertion | Result |
| --- | --- |
| grid columns | `44px 300px 1082px 44px` |
| header width == main + dock, all 4 nav×dock combos | ✅ 1082=722+360, 1382=1382 |
| right edges of topbar / dock / space-body align | ✅ all 1426 |
| no horizontal document overflow | ✅ scrollWidth == clientWidth |
| reading overlay covers `.space-body` exactly, incl. dock | ✅ 344→1426 |
| header stays visible above the overlay | ✅ topbar 0–50, note 50–83, overlay 83–815 |

**xterm console error is PRE-EXISTING.** `Viewport.syncScrollArea` reading
`dimensions` of undefined reproduced identically on a second harness (:5200)
serving the stashed pre-change code — verified by content check that :5200 had
no `space-body` and still had the old inline offset. Not caused by this PR.

### PR 1 gates — all green (2026-08-11)

| Gate | Result |
| --- | --- |
| `tsc --noEmit` | OK |
| `cargo check -p app` | OK |
| `make test` (bats) | 288 tests, all ok |
| `make lint` | shellcheck + bash-3.2 gate clean |
| `cargo test -p worktrees-core` | **207 passed** |
| `cargo test -p worktrees-cli` | 6 passed |

⚠ **Watch the tail length when reporting cargo results.** `cargo test … | tail -4`
showed `running 0 tests / ok. 0 passed`, which is the **Doc-tests** block, not the
suite. The real line (`running 207 tests`) was above the cut. Re-ran with
`grep -E "^running|^test result"` to confirm. A tail-truncated cargo run can read
as "the suite is empty" when it passed.

### PR 1 review + merge

Four-lens adversarial review (CSS/layout, React structure, behavioral
regression, a11y): **5 findings filed, 0 survived verification.** CSS-layout and
React-structure lenses found nothing at all. The a11y "landmark" findings were
refuted with real evidence — one verifier built a probe page and read Chromium's
AX tree over CDP rather than citing the spec: pre-change `<header>` inside
`<main>` mapped to `sectionheader`, so **no banner landmark existed to lose**;
post-change it maps to `banner`, a net gain. So the `.space-header` wrapper
stays dropped.

Merged as **#110** (`146998c`). ⚠ One CI job failed on `actions/checkout@v7` —
runner infrastructure, not the suite. Re-ran the failed job; all 9 checks green.

### PR 2 — per-space panel memory (implemented, gates green)

Files: `app/src/settings.ts`, `app/src/App.tsx`. **No Rust, no mock change** —
the backend is schema-blind.

- `PlacePanels {dock_open, dock_tab, dock_width}` + `place_panels` keyed
  `repo|slug` + `placeKey()` + `panelsFor()`.
- `eff = panelsFor(settings, selKey)` — **9 read sites** swapped from `settings`,
  including the two the plan's first draft missed (`filesDockShown`, which
  auto-closes reading mode, and `keyRef.filesTabOpen`, which gates ⌘⇧E).
- `updatePanels` writes the **full triple**, mirrors to globals, keeps
  `place_panels` out of `preHydration`. Stable `useCallback([])` via `selRef`.
- `dropPanels(pred)` + once-per-session sweep + drops on `remove_place` (both
  sites: `1911`/`2008` equivalents) and `remove_project`.

Gates: tsc OK · cargo check OK · 288 bats · lint clean · 207 core · 6 cli.

Harness assertions (measured, mock on :5201):

| Case | Result |
| --- | --- |
| A=Files, B→Terminal, back to A | **Files** — no bleed |
| unvisited place | inherits globals |
| A: Terminal @490px (real drag) → leave → return | Terminal, 490, open |
| B: closed → leave → return | still closed |

Persisted map held the full triple per key, no partial entries.

⚠ **BOTH console error kinds are pre-existing.** `dimensions` (xterm) *and*
`unregisterListener` (tauri event shim) reproduced on a baseline harness (:5202,
content-checked as pre-change) running the identical click sequence — 18 and 12
respectively. Neither is from PR2.

### PR 2 review — ⭐ found a REAL bug (1 confirmed of 6 filed)

**The bug: `updatePanels` stashed the full triple into `preHydration`.**
Pre-hydration `settings` is `DEFAULTS`, so a ⌘J that only meant to toggle
`dock_open` was widened to `{dock_open:true, dock_tab:"files", dock_width:360}`.
Hydration shallow-merges `preHydration` over the settings loaded from disk **and
then saves**, so the user's real `dock_tab`/`dock_width` were overwritten with
defaults and persisted. A regression: the old `toggleDock` recorded exactly one
field.

⚠ **The lesson.** I *did* reason about this trap — the comment on that very line
explained why `place_panels` must stay out of `preHydration` (shallow merge would
replace the whole map). I got the map right and then walked into the identical
problem one level down with the scalars I had just widened. **The comment
documented the hazard while the code beneath it committed it.** Guarding the
obvious instance of a hazard is not the same as guarding the hazard.

Fix (one line): stash `p` (the resolved patch), not `triple`. `triple` is still
what belongs in `place_panels` — the two invariants are exact opposites and both
are load-bearing.

Three of four lenses found it independently; two verifiers reproduced it with
real experiments (seeded `ui-state.json`, delayed `get_settings`, pressed ⌘J in
the window, watched `terminal/490` become `files/360` on disk, then applied the
one-line fix and confirmed it survived).

**I re-checked it myself against the UNFIXED code first** (`prehydration-sim.mjs`,
copied to the scratch dir):

```
stash=triple -> { dock_open:true, dock_tab:"files",    dock_width:360 }  FAIL
stash=p      -> { dock_open:true, dock_tab:"terminal", dock_width:490 }  PASS
```

That step is non-optional here — ROADMAP's zombie-children item records a
regression test that passed identically with and without its fix.

Five findings refuted, including a plausible "the prune sweep can be skipped for
a whole session": the guard returns **before** setting `prunedOnce`, so the sweep
is deferred, not lost.

Post-fix: gates green again (288 bats / 0 failing, 207 core, 6 cli), harness
re-verified (no bleed, seed inherited). Amended to `5b415e3`, pushed as **#111**.

### Next

PR 2 merge → PR 3 (`title` rename) → close-out.

### Errors

| Error | Attempt | Resolution |
| --- | --- | --- |
| `cargo test -p worktrees-core` appeared to run 0 tests | 1 | Tail truncation, not a real result — 207 passed. Report cargo with a grep, not a tail. |
