# PR view — phase 1 (brief: .planning/brief.md, spec docs/proposals/pull-requests.md)
- [x] core github.rs + fixtures + tests (mutation-checked)
- [x] app backend: project_prs (TTL cache, coalescing), remote_url via core, diagnostics gh line
- [x] frontend: settings switch, DockTab, icon, PrsPane, header chip, rail badge, polling
- [x] mock harness fixtures (groups, chip states, auth states)
- [x] check script (dockrail etc), WebKit measure, contrast
- [x] sandbox --app verification incl bare PATH
- [x] gates, CHANGELOG, PR, message (main)
- sandbox --app hand test: NOT done (needs a human); PR #455 open, reported to (main)
