# Progress
## Session 2026-09-18 (drag half)
- Branched `drag-drop-worktree-reference-drag` off a freshly fetched origin/main
  (0/0). Recovered the previous session's findings from the archive tarball.

## Build
David chose the RESOURCE URI payload over the quoted path, reversing last
session's recommendation. Built:
- `crates/worktrees-core/src/mention.rs` — `safe_uri_part`, `uri_map`, `uri_for`,
  `server_name_in`, `server_name_for`, `mention`. MOVED out of the CLI so the
  drag and `resources/list` cannot drift: the client matches a mention against
  its cached list by exact string equality, so a second implementation off by
  one character would reference the wrong place SILENTLY. The app asks the
  backend for the finished token and never builds it — the opposite of
  `dnd.ts::predictTier`, which needs a drift check precisely because it mirrors.
- `tmux::paste_to_pane` + `pane_zero` + `paste_commands`.
- `drop_reference` Tauri command; mock parity + `__mock.drops()`.
- `TermSurface` gains a `drop` PROP (it is shared with every dock shell tab, so
  hardcoding `data-drop` there would have made scratch shells targets too).
- `resolveDrop` tests the terminal BEFORE `[data-tier]` — after it, the place
  branch has already returned null and the code would be dead.
- Two-level affordance: dashed outline while any PLACE drag is live, accent
  once the drop resolves (a cross-project drag is over the same pixels and
  resolves to a reject, so it must not light up).
- `app/scripts/dropzone-check.mjs`, and `make test-frontend` — which runs ALL
  thirteen `*-check.mjs`. They existed and ran nowhere; now they gate, in CI too.

Fail-first: hardcoded `data-drop` in the shared component; the mention branch
moved after the tier early-return; the cross-project guard removed; `-p` dropped
from `paste-buffer`; `:0.0` dropped from the target. Each went red — **except
the last one at first**, which is why `pane_zero` exists: the `:0.0` was built
inline inside `paste_to_pane`, outside the reach of the argv test, so the
mutation passed the whole suite. Extracted and now caught.

The dropzone check also failed on its OWN bug first: the body slicer stopped at
`} & TermFindProps) {`, cutting the JSX off before `drop="mention"`.

Gates: core 324, cli 12, app 58, `cargo check -p app`, tsc, lint,
`make test-mcp`, `make test-frontend` 13/13, `ls --json` identical to shipped.
Real claude re-verified after the core move — and the FIRST attempt used a stale
`/tmp/wt-test-bin`, which is the "a stale binary can make it PASS" trap; redone
against a binary proven newer than `mention.rs`.
