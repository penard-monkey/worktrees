# Task plan — the DRAG half

## Goal
Drag a place row from the app's nav into a session's terminal; the session
receives an unambiguous reference to that worktree.

**David chose the RESOURCE URI over the quoted path** (2026-09-18), reversing
last session's recommendation: a drop inserts `@worktrees:place://<slug>`, which
expands to real status rather than a ~27-entry directory listing. The objections
that drove the earlier choice are weaker now that #215 shipped — staleness is
handled by the watcher, escaping by `safe_uri_part`, and the note-injection
surface turned out not to exist (`Place::declared` is always None).

Delivery is unchanged: `tmux set-buffer` + `paste-buffer -p -t <session>:0.0`,
not through xterm.

## What choosing the uri pulls in (the reasons it was rejected before)
1. **The token names the SERVER**, whose registered name the app does not know.
   Profile launches hardcode `worktrees` (`profile.rs:813-820`, and
   `--strict-mcp-config` drops the user-scope entry); otherwise it must be read
   out of `~/.claude.json` (`global_mcp_servers`, `profile.rs:1071`).
2. **Same-project only.** The server is pinned at startup and no tool takes a
   repo path, so a cross-project drop CANNOT resolve — it must be refused with
   a hint, not silently inserted.
3. **The uri must be byte-identical to what the server serves.** `safe_uri_part`
   and `uri_map` live in the CLI, which the app does not link. They MOVE to
   core, and the app asks the backend for the finished token — the frontend
   never builds it. That is what keeps this off the "frontend mirrors a core
   decision" drift list (CLAUDE.md) instead of adding to it.

## Phases
| # | Phase | Status |
|---|-------|--------|
| 1 | Decide the payload (DONE: resource uri) | complete |
| 2 | Move `safe_uri_part`/`uri_map` to core; CLI re-uses them | pending |
| 3 | Core: server-name resolution + `place_mention(repo, slug)` → the token | pending |
| 4 | Core: `paste_to_pane` (set-buffer + paste-buffer -p), bats-testable | pending |
| 5 | Tauri command + mock parity (`install.ts` must track it) | pending |
| 6 | Frontend: drop target on a node TerminalPane OWNS, resolveDrop/commitDrop | pending |
| 7 | Affordance + guards (session down, pane 0 not claude, cross-project) | pending |
| 8 | Tests (fail-first), gates, fable review, PR | pending |

## Traps already paid for (do not rediscover)
- `.term-wrap` is rendered by `TermSurface`, SHARED with every dock shell tab —
  the `data-drop` must come from `TerminalPane` as a prop.
- NEVER a `send-keys -l` fallback: `paste-buffer -p` respects the pane's
  bracketed-paste mode and so cannot type into a permission prompt; `send-keys`
  can.
- `resolveDrop` returns null for a place unless over `[data-tier]`; the new
  branch must be tested BEFORE that one. `DropTarget` is a closed union.
- The terminal only mounts when `selected.tmux_session.up`.
- A synthetic pointer drag bypasses hit-testing on the way in (harness-only).
