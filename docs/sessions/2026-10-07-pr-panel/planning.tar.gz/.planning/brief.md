# Brief: investigate + design a "pull requests" view in the app

This is an INVESTIGATION/DESIGN lane. Deliverable: a proposal at `docs/proposals/pull-requests.md`
(match the shape of the other files in `docs/proposals/`, add it to `docs/proposals/index.md`), plus
mockups (ASCII in the doc, and optionally screenshots from the mock harness of a throwaway prototype —
screenshots go in `~/.cache/worktrees/worktrees/pr-panel/`). Do NOT ship the feature. Open a docs-only
PR with the proposal and message the orchestrator `(main)` with the PR number and a short summary of your
recommendation and the open questions for David.

## What David wants
- When the project's remote is GitHub, see the PRs currently open for that project from the app,
  viewed from `(main)`.
- When a lane (place) owns a PR — its branch is a PR's head — that PR should show for that lane.
- His question: how best? Another icon on the right rail with a drawer (the rail already has Files,
  Terminal/dock, Docs, Plan, Automations)? A list? Something in the nav row? Recommend one, with reasons,
  and say what you rejected.

## Questions the proposal must answer (with evidence, not guesses)
1. **Data source.** `gh` CLI (already used? grep `lib.rs` and `worktrees-core/src/agentfiles.rs` for
   existing `gh` use) vs the REST/GraphQL API with what token. Auth states to handle: gh missing, not
   logged in, logged into a different host/account, repo private. GUI PATH (see AGENTS.md
   `fixup_gui_path`). Measure the real cost of one `gh pr list --json …` call for this repo and say what
   fields you'd fetch (number, title, head branch, draft, review decision, CI rollup, mergeable state,
   author, updatedAt, url).
2. **Detecting GitHub.** How the origin remote is parsed (ssh/https/enterprise hosts, forks where the PR
   lives on `upstream`). What non-GitHub projects show (nothing — no empty chrome).
3. **Lane ↔ PR mapping.** By the place's branch = PR `headRefName` (+ head repo owner for forks). Edge
   cases: a place whose branch changed, closed/merged PRs (show merged briefly?), several PRs for one
   branch, PRs with no place (show them in main's list; offer "open in a place"?).
4. **Freshness and cost.** Polling cadence, gated on window visibility like `useUsage`; refresh on focus
   and after a push from the app; rate limits; caching in the backend, one fetch per project serving all
   places. Where it lives: `worktrees-core` (so MCP `place_status` / CLI `ls` could show it too) vs app
   only — recommend.
5. **UI.** Where main's list lives; how a lane shows its own PR (rail badge? header chip next to branch
   status? nav row glyph like CI state?); what clicking does (open in browser via the opener plugin, see
   AGENTS.md path-permission notes; or a detail view with checks/reviews). Keep to the app's rules: no
   UI libraries, tokens from `tokens.css`, accent colours as dots/tints not text, `useEscape` for any
   overlay.
6. **Agents.** Should MCP `place_status`/`list_places` expose the PR (number, state, CI) so the
   orchestrator stops shelling `gh`? Worth it or later phase?
7. Phasing: a small phase 1 that is useful on its own, then what follows.

## Rules
- Read AGENTS.md, DESIGN.md (UI conventions) and `docs/adr/` first.
- Read-only toward GitHub: `gh pr list/view`, `gh api` GETs only. Never comment, label, merge, or
  push anything except your own docs branch.
- Mock harness on a port other than 1420; HMR is dead in `.worktrees/` (restart vite with `--force`).
  Never drive David's running app; a sandbox only by pid.
- Throwaway tmux: `tmux -L <name>` on EVERY call; never a bare `tmux kill-server`.
- Never `git worktree add`. Scratch → `~/.cache/worktrees/worktrees/pr-panel/`.
- No session URLs / Claude-Session trailers in commits or PR; keep Co-Authored-By.
