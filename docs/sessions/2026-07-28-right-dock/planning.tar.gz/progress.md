# Progress log

## Session 2026-07-27 — planning right dock (file browser + tmux panes)
- Could NOT read `_tmp/1 (1).jpeg`: macOS TCC blocks the iCloud `_tmp` symlink
  for this process (Read EPERM; `cp` "Operation not permitted" even sandbox-off).
  Design derived from user description + code.
- Mapped app layout, tmux session creation, existing backend commands. See
  findings.md.
- Key insight: app's 2nd tmux pane is ALREADY a bare spare shell (install_cmd
  empty in the app path) — dropping it is low-risk and immediately widens claude.
- Wrote task_plan.md with proposed 3-phase design + 3 gating decisions.
- User LOCKED: embedded tmux-backed terminal, editable viewer, one PR.

### Backend DONE (cargo check core + app both clean)
- lib.rs: `list_dir`/`read_file`/`write_file` (path-guarded to registered
  project roots via `guard_under_projects` + canonicalize), gitignore filtered
  via `git check-ignore --stdin -z`. `open_shell_session(session,cwd)` creates/
  reuses sidecar `<session>-term`. All registered. `kill_shell_sidecar` wired
  into close_place + remove_place.
- core ops.rs: `launch` gained `spare_shell: bool`; `cmd_new` passes true (keeps
  deps pane → bats green), `cmd_open` gained `--no-spare` flag. App open path
  (main + non-main) passes single-pane.
- core tmux.rs: `SHELL_SIDECAR_SUFFIX`/`shell_sidecar_name`/`is_shell_sidecar`;
  `session_in` skips sidecars so a bare shell can't be adopted as the AI session.
- Verified: place session = canonical exact-match first (project.rs:204), so the
  sidecar never shows as a place's session in the primary path.
### Frontend DONE
- settings.ts: `dock_open`/`dock_width`/`dock_tab` + `clampDock` + `--dock-w`.
- App.tsx: module-scope `TreeNode`/`FileTree`/`FileViewer`/`DockTerminal`;
  `dockFile` state (reset per place); `toggleDock` (⌘J) + topbar ▧ button;
  `onDockResize` (left-edge drag); 4th grid column gated on `dockShown`
  (dock_open && a place selected); dock JSX with Files/Terminal tabs.
- App.css: `.dock*`, `.filetree/.tree-*`, `.viewer*` styles (plain CSS, tokens).
- mock/install.ts: virtual FS (`seedDir`/fsChildren/fsFiles) + `list_dir`/
  `read_file`/`write_file`/`open_shell_session` cases.

### GATES ALL GREEN
- cargo build --release CLI ✅ · make test 134/134 ✅ · make lint ✅
- cargo test core (added `session_in_skips_dock_shell_sidecar`) ✅
- tsc --noEmit ✅ · cargo check -p app ✅
- Next: visual check in mock harness, then commit + PR (fable review).

## Session 2026-07-28 — multiple terminal tabs (before fable review)
- Question: was 1 shell/space; now N shells/space (indexed sidecars).
- Backend: `shell_sidecar_name(session,index)` + `shell_sidecar_prefix` +
  `shell_sidecar_index` + `session_names()`. `open_shell_session` takes index;
  new `list_shell_sessions` (restore tabs from live tmux) + `close_shell_session`;
  `kill_shell_sidecar`→`kill_shell_sidecars` (kills ALL on close/remove).
  `is_shell_sidecar` widened to `-term-<digits>`. Unit tests added.
- Frontend: `TerminalTabs` (tab strip ＋/✕, empty state, restores from
  list_shell_sessions, mounts only active); `DockTerminal` gains `index`;
  ⌘⇧T via `newTermToken` (handled before the shift guard). CSS `.termtab*`.
- Mock: index-aware open_shell_session + list/close.
- GATES green: release CLI, 134 bats, lint, core tests (7, +2 new), tsc,
  cargo check app. Playwright-verified: add(＋/⌘⇧T)/switch/close/empty-state,
  indexed names (`-term`, `-term-3`). Console errs = same xterm quirk.
- CHANGELOG updated; commit amended → 5fe4ce4; force-pushed; PR #56 body
  updated. HOLD for fable review (tomorrow).

## Session 2026-07-28 (cont) — fable review of #56 + fixes
- Ran a Fable agent adversarial review. Found real bugs (see findings.md).
  All must/should + cheap nits FIXED:
  1. BLOCKER cross-place kill: sidecar marker `-term`→`~term` (git refs can't
     contain `~` → collision-proof). tmux.rs helpers + tests updated.
  2. HIGH adopted-name leak/churn: open/list/close_shell_session now take
     repo+slug; backend derives canonical name + cwd (webview can't name/kill
     arbitrary sessions or pick cwd). Frontend keys TerminalTabs off repo+slug.
  3. HIGH kill-on-refused: sidecar teardown MOVED to core cmd_close/cmd_rm
     (success path) → also fixes CLI-side leak. App-layer kill removed.
  4. MED read_file unbounded alloc: File::open + take(cap+1).
  5. MED stale-save clobber: read_file returns mtime; write_file mtime CAS +
     atomic temp+rename (preserves mode); FileViewer conflict UI + Reload +
     auto-reload-when-clean on places:changed.
  6. MED dup-session race: open_shell_session treats "exists after create-fail"
     as success (StrictMode double-mount safe).
  7. MED dead/resurrected tabs: TerminalTabs clears tabs on session-down; core
     sweep fixes CLI leak.
  8. LOW TreeNode swallowed errors → threads onError.
  9. LOW ⌘⇧T: require meta (ctrl passes to shell), gated on palette-open.
  10. LOW cwd unguarded → backend-derived now (moot).
  Nits: clampDock in gridCols; +2 --no-spare bats tests; mock tracks sidecars
  + mtime CAS; addTab guarded during restore; git_check_ignore stdin on thread.
- GATES: release CLI ✅ · bats 136/136 (+2) ✅ · lint ✅ · core tests (5 tmux,
  incl collision-proof) ✅ · tsc ✅ · cargo check app ✅. Playwright: edit→save
  (mtime CAS), multi-terminal, `~term` marker confirmed. Console = xterm quirk.
- Next: commit fixes (distinct commit) + push → PR #56 ready for human review.

## Session 2026-07-28 (cont) — merge #56 + release v0.4.0
- main had advanced: v0.3.2 (⌘K quick switcher, #57) + per-project settings
  (.worktrees.toml, #58/#59). PR #56 was CONFLICTING.
- Merged origin/main into ui-next. Resolved 4 conflicts:
  - ops.rs cmd_new: keep spare_shell:true + main's materialize rc.
  - ops.rs close_one: main's name-bound-consent refactor + sidecar sweep on
    kill path AND nothing-to-close path.
  - lib.rs close_place: main's yes/session/needs_confirm consent flow (core
    now owns sidecar teardown).
  - App.tsx imports: keep ProjectSheet import + clampDock.
  - CHANGELOG: [Unreleased]→[0.4.0] (dock + per-project settings + single-pane);
    0.3.2 keeps quick switcher. Cargo.toml + lock 0.3.2→0.4.0.
- Gates green post-merge: core/cli/app compile · tsc · release build · 137 core
  tests · lint · 237 bats. PR CI: 9/9 green (macOS+Ubuntu).
- Squash-merged #56 → main (eb6e54e). FF'd main worktree. make release
  VERSION=0.4.0 → tag v0.4.0 → pushed. release.yml in_progress.
- DONE (pending release.yml artifacts).
