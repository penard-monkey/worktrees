# Findings — right dock / tmux panes

## Current app layout (App.tsx)
- Grid: `[--rail-w][nav_width][1fr main]`, cols set at App.tsx:1154.
  `nav_collapsed` drops the nav column (⌘B, `toggleNav`).
- **rail** (`<nav className="rail">`, ~1157): lens icons + collapse + add +
  settings gear. This is the LEFT activity rail, not what mux calls a rail.
- **nav** (`<aside className="nav">`, ~1177): places tree / lenses.
- **main** (`<main className="main">`, ~1232): topbar (identity+controls) +
  note-strip + `TerminalPane` (or empty card) + statusbar.
- `TerminalPane` (TerminalPane.tsx): one xterm, attaches to WHOLE tmux session
  via `term_open`. Rust attaches, never owns a shell. Two attaches to the same
  session name MIRROR (share active window) — relevant for embedded 2nd term.

## tmux session creation
- `ops::launch` (crates/worktrees-core/src/ops.rs:31): pane0 = ai_cmd (claude)
  or keep-shell; pane1 = install_cmd + keep-shell, via `split-window -h`
  (side-by-side). `tmux.rs:155 split_window` uses `-h`.
- **App open path passes `install_cmd = ""`** (lib.rs:415) → in the APP, pane1
  is just a bare spare shell next to claude, splitting width in half.
- CLI `new` path (ops.rs:283-300) DOES compute `detect_install_cmd` → pane1
  runs deps install there. So dropping pane1 must be scoped to the app to keep
  the CLI's install pane + bats tests green.
- Session name invariant: `<prefix>-<slug>`, `.`→`-`.

## Existing backend commands (lib.rs) relevant
- `open_terminal(cmd, session)` (lib.rs:972): opens EXTERNAL terminal app via
  `settings.terminal_cmd` (e.g. `ghostty -e tmux attach -t {session}`). Already
  wired in the place context menu (App.tsx:1420). → cheap "open a terminal".
- `open_editor(path, cmd)` (lib.rs:951): opens real editor. → file EDIT already
  covered; dock viewer can stay read-only.
- `term_open/term_write/term_resize/term_close` (lib.rs:1027+): PTY attach.
- NO file-list / file-content command exists. Both are NET-NEW for the dock.

## Constraints (CLAUDE.md)
- Commands must be `async fn` (sync freezes UI).
- Mock harness (app/src/mock/install.ts) must track EVERY lib.rs command — the
  UI is driven headlessly against it. New commands need mock impls + fixtures.
- git/tmux are shelled out on purpose (faithful port). File listing should use
  `git ls-files` + status rather than a fs-walk lib, to match .gitignore and
  the shell-out convention.
- Plugin perms in capabilities/default.json; missing perm = silent reject.
- Design tokens in tokens.css, scale off `--ui-rem`; no UI libs, plain CSS.
- macOS FS case-insensitive — watch new component filenames.

## Fable review of PR #56 (2026-07-28) — fixes in flight
BLOCKER/HIGH must-fix + should-fix + cheap nits. Verified `~` is tmux-legal
(test passed) and git refs forbid `~` → collision-proof sidecar marker.
1. BLOCKER: `-term` marker collides with real slugs (branch "long-term" →
   session `<pfx>-long-term` == sidecar of place `long`). Cross-place session
   kill. FIX: marker `~term` / `~term~N` (git refs can't contain `~`).
2. HIGH: sidecars keyed off frontend `tmux_session.name` (adopted foreign name),
   cleanup uses canonical → leak + tab churn + webview can kill any session.
   FIX: backend derives name from repo+slug; frontend passes repo+slug(+cwd).
3. HIGH: close/remove kill sidecars even on REFUSED op. FIX: cleanup only on
   success — move into core cmd_close/cmd_rm success path (also fixes CLI leak).
4. MED: read_file reads whole file before cap. FIX: File::open + take(cap+1).
5. MED: FileViewer blind last-writer-wins. FIX: mtime CAS on save + atomic
   temp+rename + reload-when-clean on places:changed.
6. MED: open_shell_session exists-then-create race (StrictMode). FIX: on
   new_session err, treat existing session as success.
7. MED: dead/resurrected dock tabs after Close; CLI never swept sidecars.
   FIX: core sweeps (see 3); frontend reconciles tabs on places:changed.
8. LOW: TreeNode swallows list_dir err as empty. FIX: thread onError.
9. LOW: ⌘⇧T before switchOpen guard + intercepts ctrl in term. FIX: require
   meta, gate on switchOpen.
10. LOW: cwd unguarded. FIX: guard_under_projects(cwd).
Nits: clamp dock_width in gridCols; --no-spare bats test; mock tracks sidecars;
addTab guard on ids!==null; git_check_ignore stdin on a thread.

## Terminal-in-dock: the hard part
- Embedding a 2nd live terminal means a 2nd xterm. Same-session attaches mirror
  each other, so to show claude in main + a shell in the dock you need either:
  a) grouped session: `tmux new-session -t <sess> -s <sess>-dock` shares the
     window list but has an INDEPENDENT active window → dock client selects a
     shell window while main stays on claude. Needs `term_open` to target a
     session/window + grouped-session create + cleanup on close.
  b) just call `open_terminal` (external app) from the dock — near-zero cost,
     not embedded.
- Recommend: P1 = files only (no tmux). P2 minimal = single pane + external
  terminal button (a). Embedded 2nd xterm (grouped session) is the stretch.
