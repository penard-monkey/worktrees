# Task Plan — Right dock: file browser + rethink tmux panes

## Goal
Add a right-side dock to the Tauri app inspired by the "mux" reference
(`_tmp/1 (1).jpeg`): browse the worktree's files and view their contents, plus
a way to open a terminal. Simplify the current two-pane tmux layout (claude +
spare shell) so claude gets full width, and move the spare shell into the dock.

> NOTE: could not read the reference image — macOS TCC blocks the iCloud `_tmp`
> symlink for this process (Read + `cp` both "Operation not permitted"). Design
> derived from the user's description + codebase. Confirm against image if the
> user can surface it (paste into chat, or copy into repo working dir).

## Design direction (proposed)
- **Right dock** = new 4th grid column, COLLAPSIBLE + persisted (like nav/⌘B).
  Default collapsed so the terminal keeps full width when unused.
  - Tabs: **Files** | **Terminal** (extensible; skip linear/etc).
- **Files tab**: tree of the worktree (git-tracked + untracked, respect
  .gitignore), lazy-expand dirs. Click file → read-only preview (mono, line
  numbers). Guards: size cap + binary detection → "Open in editor" fallback.
- **tmux panes**: app open path drops pane1 (already just a bare spare shell) →
  single pane, claude full-width. CLI `new` KEEPS its 2nd pane (runs deps
  install) — scope the change to the app so bats stays green.
- **Terminal tab**: replaces the lost spare shell. Two options (see decisions).

## Phases
- [ ] P1 — Files dock (self-contained, no tmux changes)
  - backend: `list_dir(path)` + `read_file(path, max_bytes)` async commands
  - frontend: right dock column, collapse toggle + persisted ui-state, file
    tree, read-only preview
  - mock harness: add both commands (CLAUDE.md rule)
- [ ] P2 — Single-pane tmux for app open path
  - `launch()` gains spare-shell/pane-count option; app passes single-pane,
    CLI unchanged
  - Terminal tab wired (external button first, or embedded second xterm)
- [ ] P3 — polish: keybind, tab memory, empty states, gates

## Decisions (LOCKED 2026-07-27)
1. Dock Terminal = **embedded, live, tmux-backed** 2nd xterm.
   → impl: **sidecar tmux session** `<sess>-term` (independent session in the
   worktree cwd running a keep-alive shell), NOT grouped. Simpler + honors "a
   separate terminal" mental model + "terminals ATTACH to tmux, never own
   shells". Created lazily when the Terminal tab first opens; killed when the
   place's main session closes.
2. File viewer = **editable in-app**. Plain mono `<textarea>` + save (⌘S),
   dirty indicator. NO editor lib (project ethos: no UI libs). Syntax
   highlighting deferred (would need CodeMirror). Existing "Open in editor"
   stays as the escape hatch.
3. **One PR** — dock (Files + editable viewer + embedded Terminal) + single-pane
   app session, together on this ui-next branch.

## Concrete build
### Backend (app/src-tauri/src/lib.rs) — all `async fn`, path-guarded to
### registered worktree roots (reject paths outside)
- `list_dir(path) -> [{name, path, is_dir}]` — read immediate children, skip
  `.git`, filter gitignored via `git -C <wt> check-ignore` (shell-out).
- `read_file(path, max_bytes) -> {content, truncated, binary}` — NUL-byte
  binary detect + size cap.
- `write_file(path, content) -> ()` — save.
- `open_shell_session(session, wt) -> String` — ensure sidecar `<sess>-term`
  exists (tmux new-session -d in wt, keep-alive shell), return its name.
  (or fold window/target into `term_open`.)
- single-pane: `ops::launch` gains a spare-shell/pane flag; app open path passes
  single-pane (claude only); CLI `new` unchanged (keeps install pane) → bats green.
- sidecar cleanup: when main session closes/kills, also kill `<sess>-term`.

### Frontend (App.tsx + new components at MODULE scope)
- ui-state: `dock_collapsed`, `dock_width`, `dock_tab` ("files"|"terminal").
- 4th grid column (right dock), collapsible + resizer, persisted; toggle button
  in the rail + keybind.
- `FileTree` (lazy-expand), `FileViewer` (editable textarea + save/dirty),
  dock `TerminalPane` (attaches to sidecar session).
- tokens.css: dock width var, reuse nav resizer patterns.

### Mock harness (app/src/mock/install.ts + fixtures.ts)
- Mock `list_dir`/`read_file`/`write_file`/`open_shell_session` + a fake file
  tree fixture so the dock is drivable headlessly (Playwright).

### Gates (CLAUDE.md) before PR
- `cargo build --release -p worktrees-cli` FIRST, `make test`, `make lint`,
  `cargo test -p worktrees-core`, `cd app && tsc --noEmit && cargo check -p app`.

## Phases
- [ ] P1 backend: list_dir/read_file/write_file + path guard + mock + register
- [ ] P2 backend: single-pane launch flag + sidecar shell session + cleanup
- [ ] P3 frontend: right dock column + collapse/resize/persist
- [ ] P4 frontend: FileTree + editable FileViewer
- [ ] P5 frontend: dock TerminalPane on sidecar session
- [ ] P6 polish + gates + PR

## Status: SHIPPED TO PR — HOLD for fable review (tomorrow)
- CHANGELOG [Unreleased]: Added (right dock) + Changed (single-pane app) entries.
- Commit d9a72d2 on ui-next → pushed → PR #56 (base main).
  https://github.com/penard-monkey/worktrees/pull/56
- HOLD: David runs a fable review on the diff before squash-merge (tomorrow).
- --- (verification notes below) ---
- All 6 phases done. Gates green (release CLI, 134 bats, lint, core tests +
  new sidecar test, tsc, cargo check app).
- Visually verified in dev:mock: Files tree + editable viewer (Save/Editor),
  Terminal tab embeds the `<session>-term` sidecar, main terminal single-pane.
- Screenshots: ~/.cache/worktrees/worktrees/ui-changes/dock-{files,terminal}.png
- Console error seen (xterm `dimensions` in Viewport.syncScrollArea) is a
  PRE-EXISTING headless xterm quirk — fires for the main terminal too, not a
  regression.
- NOT yet committed (user hasn't asked). Suggested finish: CHANGELOG
  [Unreleased] entry → commit on ui-next → PR → fable review → squash-merge.
