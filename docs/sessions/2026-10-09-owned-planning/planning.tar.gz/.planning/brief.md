# Brief: INVESTIGATE + DESIGN — worktrees owns the planning mechanism (opt-in)

INVESTIGATION/DESIGN only. Deliverable: `docs/proposals/owned-planning.md` (shape like the other
`docs/proposals/*.md`, row in `docs/proposals/index.md`) plus a ROADMAP.md entry listing this as an
option (link the proposal), opened as ONE docs-only PR. Do not implement. When the PR is up, message
`(main)` with the number, your recommendation in a few lines and the decisions David must make.

## David's request (his words, relayed from cdv-(main))
"worktrees should actually own the planning functionality. Something that the users of the application
could adopt. So if the user updates the app to a new version they should be offered to turn it on. It
should explain how the planning will work and if they want to adopt. They can choose to adopt per
project or as a whole. Something they check when they make/load a project in the app."

## Why now (from cdv-(main))
casa-del-valle-monorepo is the THIRD project hand-rolling the same layout:
`.planning/<topic>/{task_plan,findings,progress}.md` + `.planning/.active_plan`, plus a TRACKED
`.planning/orchestrator/task_plan.md` synced from `docs/plan/goals.md`. valleos has it on main
(`scripts/memory/sync-goals.sh` + `plan-context.sh` hooks + `.gitignore` negations); cdv's port is PR #684
in casa-del-valle-monorepo. Each repo re-implements `worktrees_core::plan`'s resolution in bash, and the
planning-with-files skill's 2.37.0 hooks only inject a ROOT `task_plan.md`, so every repo needs its own hook.
You may READ those repos (`~/workspace/valleos`, `~/workspace/casadelvalle/casa-del-valle-monorepo`,
`gh pr view 684 -R <owner>/casa-del-valle-monorepo`) to see the real shapes. Never edit them.

## The proposal must cover
1. **Opt-in UX.** Offered after an app update (use `app/src/offers.ts` — read the AGENTS.md rule on
   offers: data with a destination, no extra preconditions), per project or globally, and chosen when
   making / loading / cloning a project. A clear explanation of how planning works before adopting.
   What "off" means (today's behaviour, unchanged) and how to turn it off later.
2. **What worktrees owns**: the layout (`.planning/<topic>/…` + `.active_plan`), resolution (one
   implementation: `worktrees_core::plan`, which already mirrors the skill's `resolve-plan-dir.sh`), and
   the agent hooks (session start / prompt / stop context) shipped by worktrees instead of each repo — for
   Claude via the plugin dir worktrees already passes (`--plugin-dir ~/.local/share/worktrees/agent/<hash>/claude`),
   and say what the Codex and pi equivalents are (or that they don't exist). Relationship to the
   planning-with-files skill: replace, wrap, or coexist — recommend.
3. **`[plan] project` key** ("option A" valleos wanted): a project-level tracked plan (e.g. goals) that
   removes the tracked-copy/sync hack. Where it lives: `.worktrees.toml` is repo config — it may name
   DATA (a path), never a command (ADR 0001, `docs/adr/0001-no-repo-supplied-argv.md`); say how.
4. **Lane lifecycle integration**: what `worktrees new` writes (today `.planning/brief.md`,
   `ops::BRIEF_PATH`), what close-out archives (`.claude/close-out.md`, the global `/close-out` skill —
   which does NOT ship with the app; say whether it should), Plan dock tab, MCP `place_status.plan`.
5. **The stale-dir trap**: a June plan hijacked cdv main's Plan tab before `.active_plan` existed.
   Resolution must not pick an old topic dir by accident — propose the rule.
6. **The symlink bug cdv found**: valleos `plan-context.sh` follows symlinks, so it can inject a different
   plan from the one the tab shows. Make hook resolution and the tab resolution literally the same code
   path, with the symlink rule AGENTS.md describes (`symlink_metadata` only checks the last component;
   canonicalize and require under root — `docserver::safe_under`).
7. **Migration** for the three repos already hand-rolling it (valleos, cdv, this repo) — adopt without
   losing their existing plans; what they can delete afterwards.
8. **Phasing**: a phase 1 useful alone; open questions for David at the end.

## Rules
- Read AGENTS.md first (planning-docs section; "Before parsing a format a tool's TEMPLATE promises,
  count the real files"), `crates/worktrees-core/src/plan.rs`, `ops.rs` brief writing, `offers.ts`,
  `docs/proposals/agent-guidance.md`, `docs/adr/`.
- Docs-only. Never write `~/.claude.json`, `~/.claude/settings.json`, `~/.codex`, `~/.pi`, or any other
  project's tree. Scratch → `~/.cache/worktrees/worktrees/owned-planning/`.
- Any tmux probe: `tmux -L <unique>` on EVERY call; never a bare `tmux kill-server`. Never `git worktree add`.
- No session URLs / Claude-Session trailers; keep Co-Authored-By.
