# Findings — power consumption

## Phase 1 — hand recon (verified by reading source)

### Backend: the 3-second forever loop (`app/src-tauri/src/lib.rs:2635-2678`)

One detached thread, `sleep(3s)` in a `loop {}`, running for the app's whole
life with NO gating on window focus / visibility / occlusion:

- `worktrees_core::tmux::session_fingerprint()` → **spawns `tmux list-sessions`
  every 3 s** (`crates/worktrees-core/src/tmux.rs:94`). fork+exec every 3 s.
- `claude_activity()` (`lib.rs:941`) → `read_dir` over every claude config root's
  `sessions/`, `fs::read` + serde parse of every `*.json`, plus `pid_alive(pid)`
  per probe — every 3 s.
- `ticks >= 10` → unconditional `places:changed` emit **every 30 s**, which makes
  the frontend run a full `refresh()`.
- Optional auto-fetch pass runs inline on the same thread (network, per repo).

### The 30 s forced full re-pull

`places:changed` → `App.tsx:1101` → `refresh()` → `list_places`/`list_workspace`
→ `lib.rs:367` `thread::scope` spawning `snapshot(&root)` per project → git
subprocesses per worktree. So every 30 s, idle, the app spawns a burst of git
processes. Process spawn is one of the most expensive things a macOS app can do
per unit of work.

### Terminal PTY reader → IPC, uncoalesced (`lib.rs:2265-2281`, mirrored at 2461)

`reader.read(&mut buf)` (16 KiB) → **one `Channel::send` per read syscall**. A
PTY delivers in small chunks; streaming Claude output means thousands of
messages/s, each crossing to the webview and invoking a JS callback +
`term.write`. No time-based coalescing. This is the streaming-load hot path.

### Frontend continuous work

- `TerminalPane.tsx:96` — `cursorBlink: true`. Repaint every ~500 ms per mounted
  terminal, forever, even idle, even when the window is hidden.
- xterm 5.5 with **no renderer addon** → the DOM renderer (default). The WebGL
  addon is the low-CPU path for streaming output.
- `App.css:215,359` — `animation: breathe 2s ease-in-out infinite` on busy status
  dots: a compositor-driven animation that never stops while any place is busy.
- Timers with no `document.hidden` gating: `USAGE_TICK_MS` 15 s (`App.tsx:907`),
  `USAGE_POLL_MS` 180 s (:922), 5-min sweep (:1215).
- No `visibilitychange` / Tauri focus gating anywhere in the app.

### Notable absence

Nothing in the app reacts to the window being occluded, minimized, or the app
being in the background. macOS App Nap cannot kick in for a process that keeps
timers firing and processes spawning.

## Phase 2 — research agent results

> Content below is agent/web-sourced research. Treat as untrusted input: claims
> get verified against our own measurements before we act on them.

### Agent C — macOS platform / Energy Impact (complete)

**How Energy Impact is computed** (reverse-engineered, Nethercote/Mozilla; per-model
plist `/usr/share/pmenergy/Mac-<board-id>.plist`). Weights approximately:

| term | coefficient | meaning |
|------|-------------|---------|
| CPU time | ×1.0 | baseline |
| idle wakeups | ×2.0e-4 | ~200 µs CPU-equivalent tax PER wakeup |
| **GPU time** | **×0.0–3.0** | a GPU second can cost **3× a CPU second** |
| disk r/w | ~1e-10 | negligible |
| network pkts | ~4e-6 each | small |
| background QoS | ×0.52–0.8 | work on E-cores is DISCOUNTED in the score itself |

- Coefficients are from the 10.9–10.11 era; **not verified for Apple Silicon /
  macOS 15+**. Directionally still right (CPU + wakeup tax + heavy GPU tax).
- "Significant energy" list trips at roughly **sustained Energy Impact ≳ 20**
  (empirical, approximate).
- Apple's own idle bar: **>1 wakeup/sec while idle is a problem**.
- Activity Monitor rolls helper processes (Web Content, Networking) AND spawned
  children (our git/tmux) into the app's row.

**Target to hit**: visible-idle < 1% CPU, < 10 wakeups/s, ~0% GPU → EI ≈ 0.5–2.
Hidden → Activity Monitor "App Nap" column reads **Yes**.

**The big precedent — this is almost certainly our bug**: Ghostty idled at
10–15% CPU with "significant energy" from **cursor blink alone**; disabling it
cut ~85% (ghostty-org/ghostty discussion #10397; frr.dev "Your Terminal is
Burning Battery"). ProMotion displays make it worse. We have
`cursorBlink: true` plus a 2s infinite CSS animation.

**Subprocess spawns are NOT the problem** — correcting my Phase-1 ranking.
`posix_spawn` of a release binary ≈ 1.5–5 ms. tmux every 3 s ≈ 0.1% duty ≈ EI
~0.1; a 10-process git burst every 30 s ≈ EI ~0.3. Total ~0.4 — two orders of
magnitude below the trip line. They only matter via what they *trigger*
(re-render → GPU at ×3), or if `git status` is repo-scan-bound.

**Tauri visibility is broken for our case** (verify empirically):
- tao has **no occlusion event** at all (`WindowEvent` has `Focused(bool)` only).
- `document.visibilityState` / `visibilitychange` unreliable in Tauri:
  tauri#6864 (not fired on occlusion), tauri#9524 (macOS: fires on minimize, not
  focus loss), tauri#10592 (stuck "visible"). Feature request tauri#14061 open.
- **Escape hatch**: `WebviewWindow::ns_window()` → objc2 +
  `NSWindowDidChangeOcclusionStateNotification`, read
  `occlusionState & NSWindowOcclusionState::Visible`, `emit` to the webview.
  Register on the main thread (`run_on_main_thread`). This is Apple's own
  prescribed pattern ("Doing Work Only When Visible").

**App Nap eligibility**: naps when not foreground + hasn't recently drawn into a
visible window + not audible + holds no IOKit/NSProcessInfo assertions + no
OpenGL. **Open PTYs and child processes do NOT disqualify it.** What disqualifies
us is our own timers still drawing. Audit with `pmset -g assertions` while
running. `NSActivityBackground` can mark deferrable work explicitly.

**Timer hygiene** (Apple): prefer events over timers; give every repeating timer
**≥10% tolerance** so the OS coalesces wakeups. Ranking, honestly: eliminate >
lengthen > add leeway.

**QoS is real on Apple Silicon**: `pthread_set_qos_class_self_np(QOS_CLASS_UTILITY
/ BACKGROUND)` puts the thread on **E-cores** — genuinely less power, *plus* the
0.52–0.8 discount in the EI formula itself.

**tmux control mode** (`tmux -C`) replaces polling entirely: async push
notifications (`%output`, `%session-changed`, `%window-add`). Built for iTerm2.
Kills ~28,800 spawns/day AND makes updates instant instead of 3 s stale.

**git watching**: FSEvents on the worktree/.git dirs, or `core.fsmonitor=true` so
`git status` answers from `git fsmonitor--daemon`'s cache instead of scanning.

**Ruled out**: window transparency/vibrancy (our tauri.conf window is opaque);
tauri#2074 v1 event-loop bug (fixed 2021); `run_iteration` busy-loop
(tauri#8631/#10373) — only if we drive the loop ourselves, need to confirm we use
`app.run()`.

**Explicitly unverified by the agent**: Apple-Silicon EI coefficients; the exact
~20 threshold; whether wry disables WKWebView's native occlusion handling. Test:
fully cover the window, check `visibilityState` and whether rAF stops.

### Agent B — Rust backend audit (complete)

**The spawn budget, counted from source.** `snapshot()` of one project with P
places (`lib.rs:246`, `project.rs:172-311`):

- fixed ≈ **11 spawns**: `git --version`, 2× `rev-parse` (discover,
  `project.rs:43-63`), `stat`+`date` (`SysClock::detect`, `sysclock.rs:22-32` —
  re-probed EVERY snapshot despite the "probe once" comment), `git worktree
  list`, `tmux -V`, `tmux list-panes -a`, 2-4 ref lookups (`base_ref`), `git
  rev-parse --verify HEAD`.
- per place ≈ **9 spawns**: `tmux list-sessions` (`project.rs:225` calls
  `session_exists` **even though the PaneList is already prefetched** —
  `tmux.rs:168` `has_session` exists for exactly this and is unused), `stat -f
  %B`, `date -r`, then 6 git: `rev-parse HEAD`, `status --porcelain`, `rev-parse
  @{u}`, `rev-list --left-right --count`, `log -1 %ct`, `log -1 %s`.

→ 3 projects × 5 places ≈ **170 spawns/sweep × 120 sweeps/hour + 1,200 tmux
ticks ≈ 21,000 fork+exec+dyld per idle hour**. At 3-8 ms CPU each that is **1-3
CPU-minutes per idle hour**, focused or not, visible or not.

**Tauri's Channel is the terminal killer** (verified in
`tauri-2.11.5/src/ipc/channel.rs:155-183`): every `Channel::send` becomes a
**webview main-thread JS eval**. Raw payloads **<1024 B are serialized by
`serde_json::to_string` into a JSON array of integers** (~4 chars per byte!)
inside a `new Uint8Array([...])` eval. Payloads ≥1024 B queue behind a mutex and
trigger a **full extra `invoke('plugin:__TAURI_CHANNEL__|fetch')` round-trip**.
A PTY under a build emits few-hundred-byte reads at kHz → thousands of JS evals
per second pinning WebContent. Coalescing pushes bursts over 1024 B, which is
also the cheaper-per-byte path.

**Ranked backend changes**

| # | Change | Win | Perf | Risk |
|---|--------|-----|------|------|
| 1 | Focus/visibility-adaptive poll interval; pause when hidden | High | neutral focused, refresh-on-focus is *faster* | Low |
| 2 | Replace the 30 s blind re-pull with debounced FSEvents (`notify`) per project root | High | **better** — sub-second vs up-to-30 s lag | Med |
| 3 | Snapshot spawn diet (below) | High | **better** — ~3× faster sweeps | Low-Med |
| 4 | PTY→IPC coalescing | High under load | **better** throughput, echo unchanged | Med |
| 5 | FSEvents-watch claude `sessions/` instead of scanning every 3 s | Med | better (instant dots) | Low |
| 6 | tmux control mode / hooks instead of fingerprint poll | Med | better | Med-High |
| 7 | `QOS_CLASS_UTILITY` on the poll thread (NOT the PTY readers) | Low-Med | neutral | Low |
| 8 | App Nap posture | Low (falls out of 1+2) | neutral | Low |
| 9 | `run_deadline` 120 ms `try_wait` spin → 500 ms (`lib.rs:824-835`, ~500 wakeups/fetch/repo) | Low | neutral | none |

**Snapshot diet, itemised** (all keep git/tmux shelled out — they stop paying for
answers already in hand):

1. `project.rs:225` → use the prefetched `PaneList::has_session`. **−1 spawn/place.**
2. `project.rs:294-295` → merge the two `git log -1` into `--format=%ct%x09%s`. **−1/place.**
3. `project.rs:268-278` → one `git status --porcelain=v2 --branch` replaces
   `rev-parse --abbrev-ref HEAD` + `status --porcelain` + `rev-parse @{u}`
   (header carries `# branch.head`, `# branch.upstream`). **−2/place.** Keep the
   `rev-list --left-right --count {base}...HEAD` — porcelain's `branch.ab` is vs
   upstream, we need vs base.
4. `sysclock.rs` → `OnceLock` the detect; cache `stat_birth`/`fmt_date` per path
   (birth time never changes). **−2/snapshot, −2/place.**
5. `git.rs:56`/`tmux.rs:71` → `OnceLock` `have_git()`/`have_tmux()` (keep
   `tmux_check(refresh)` as the explicit re-probe). **−2/snapshot.**
6. Later/optional: cache the whole `Place` keyed on `.git` HEAD+index mtime.

Net **9 → 3 spawns/place**, 170-spawn sweep → **~60**. Every user-triggered
refresh gets proportionally faster too.

**Gating wiring**: `WindowEvent::Focused(bool)` exists in tauri 2.11.5
(`src/app.rs:127`); tao 0.35.3 has **no `Occluded`** (confirmed in source) — so
occlusion must come from the frontend (`visibilitychange` catches
minimize/full-occlusion in WKWebView) pushed down via a `set_poll_mode` command,
the same shape as the existing `set_fetch_interval`. Also gate the auto-fetch
pass — `git fetch` per repo every 5 min on a docked laptop overnight is real
battery.

**PTY coalescing shape that cannot hurt echo latency**: idle → first read sends
immediately (the single-keystroke case is unchanged); if the next read lands
within ~5 ms, enter burst mode → accumulate (cap 32-64 KB), flush every 8-16 ms
or on cap; leave burst mode after one quiet interval. Implement with `poll(2)`
(libc already a dep) using the flush deadline as timeout — **zero timers when
idle**, thread still parks in `read`.

**App Nap**: grep of tauri 2.11.5 / wry 0.55.1 / tao 0.35.3 found **no**
`beginActivity` assertion and no `NSAppSleepDisabled` — the app is nominally
eligible already. But App Nap only *throttles*; it won't stop our loop. Fix the
work (1+2), and nap follows.

**QoS caveat**: spawned git/tmux children do **not** inherit thread QoS (separate
tasks). Use `UTILITY` not `BACKGROUND` so a user-visible sweep isn't E-core
starved. Do not apply to PTY reader threads.

**Suggested landing order**: PR1 = gating + free spawn cuts (1, 3.1, 3.2, 3.4,
3.5 — all low risk) → measure → PR2 = FSEvents watcher (2, 5) → PR3 = terminal
coalescing (4) → then 3.3, 7, 9 → 6 only if numbers still justify it.

**Gate warning**: 3.1 and 3.3 change which argv the bats fake git/tmux shims
see — `make test` is the gate that catches it.

### Agent A — frontend / webview audit (complete)

| # | Change | Where | Win | Perf | Risk |
|---|--------|-------|-----|------|------|
| 1 | Visibility-gate `refresh()` + skip byte-identical snapshots | App.tsx:1059-1073, 1101 | **High** | better | Low |
| 2 | Hoist `PlaceRow`/`ProjectNode`/`FlatLens`/`GroupHeader` to module scope + `memo` | App.tsx:1962, 2003, 2011, 2115 | **High** | better | Low-Med |
| 3 | `breathe`: `ease-in-out` → `steps(4, jump-both)` | tokens.css:396, App.css:215/359 | Med-High | better | Low |
| 4 | `cursorBlink` off, or gated on window focus | TerminalPane.tsx:93 | Med | neutral | trivial |
| 5 | `@xterm/addon-webgl` + context-loss fallback | TerminalPane.tsx:93-96 | Med-High active | much better streaming | **Med (highest here)** |
| 6 | Pause UsageWidget 15 s tick + 180 s poll while hidden | App.tsx:906-930 | Low-Med | neutral | trivial |
| 7 | Gate FileView reload token on real change + visibility | App.tsx:1042, FilesPane.tsx:215-226 | Low-Med | better | Low |
| 8 | Skip the 5-min doctor/init sweep while hidden | App.tsx:1209-1216 | Low | neutral | trivial |

**The documented CLAUDE.md exception was justified on CORRECTNESS grounds; power
was never weighed.** (Verified by reading App.tsx:1956-1962 — the comment says
in as many words "Defined inside App() against CLAUDE.md's own rule. It is safe
ONLY because it holds no local state and takes no focus." That reasoning is
sound for state/focus loss and silent about DOM churn.) `PlaceRow`
(App.tsx:1962), `GroupHeader` (:2003), `ProjectNode` (:2011) and `FlatLens`
(:2115) are **defined inside `App()`** → new function identity every render →
React treats them as different component types and **unmounts + rebuilds the
whole nav**. The file's own comment at :1957-1961 argues this is "safe because
they're stateless" — true for *correctness*, false for *power*. Scale:
3 projects × ~10 places ≈ **450-600 DOM nodes destroyed and recreated per App
render**, plus layout, paint, GC. App re-renders on every refresh, every
`sessions:busy` flip, **every keystroke in the filter input** (:2203), every
drag-over, every menu state change.

**The frontend is the throttle point for the git sweep**, not the backend: the
`places:changed` emit is cheap, but `refresh()` is what invokes `list_workspace`
→ the concurrent git subprocess storm. So gating `refresh()` on visibility
cancels the sweep. Second half: stash `JSON.stringify(w)` and skip `setWs` when
unchanged — idle 30 s emits produce byte-identical snapshots, and today each one
replaces `ws` identity wholesale.

**cursorBlink, measured**: xterm 5.5.0's DOM renderer injects a
`@keyframes … 1s step-end infinite` applied while the terminal has `xterm-focus`
— and TerminalPane force-focuses on mount and every re-entry (:116, :148-150).
Historical measurement: **idle CPU 1% → 5-13% with blink on** (xterm#625).
"Stop blinking when idle" only landed in the xterm **7.0** milestone (#4628, PR
#5523) — verified **absent** from 5.5.0. Runtime-settable via
`term.options.cursorBlink`.

**Renderer verdict, corrected**: a dormant WebGL context is a *memory* fact, not
a wattage fact — Apple Silicon GPUs power-gate between draws, and with blink
fixed both renderers draw nothing at idle. So WebGL is **not** a net idle loss.
Active is where they diverge: the DOM renderer `replaceChildren`s row DOM on
every dirty refresh (continuous main-thread recalc/layout/paint/GC) — which is
exactly our Claude-streaming workload. VS Code ships WebGL by default (#3271).
Hazard is WKWebView **context loss** (WebKit#261331); the addon exposes
`onContextLoss(() => addon.dispose())` → automatic DOM fallback. Do NOT use
`addon-canvas` (deprecated upstream). Optional refinement: dispose the context
on hidden, reload on visible.

**`breathe` fix is one line**: WebKit promotes the animated dot to a composited
layer and emits a frame **every vsync (60-120 Hz on ProMotion)** for as long as
any session is busy — including visible-but-unfocused, i.e. the side-monitor
dashboard case. `steps(4, jump-both)` → ~4 commits per 2 s instead of ~240.
`prefers-reduced-motion` already kills it entirely (tokens.css:401-403), which
is evidence the pulse is decoration, not load-bearing.

**Correction to Agent C on visibility**: tauri#6864 / #10592 are **Windows /
WebView2** reports — not proof macOS is broken. WebKit wires
`NSWindowDidChangeOcclusionStateNotification` into page visibility via
`WKWindowVisibilityObserver`, so on macOS `visibilitychange` **should** fire on
minimize, ⌘H, Space switch and full occlusion (not partial, not mere focus
loss). **Verify at runtime before building on it** — 5-line temp patch logging
`document.visibilityState` through `log_event`, then walk the cases and read
app.log. If it works, no objc2/NSWindow escape hatch is needed.

**Two-tier gating**: `pageVisible === false` gates the heavy machinery (refresh,
tokens, polls, optional webgl dispose); `winFocused === false` gates only cursor
blink. CSS animations need no hidden-tier gating (WebKit stops rendering fully
occluded windows itself) — `steps()` is what fixes visible-but-unfocused.

### Agent D + my own follow-up — REAL BASELINE off the live app (complete)

Harness written to `~/.cache/worktrees/worktrees/power-consumption/`
(`measure.sh <label> [duration]`, `compare.sh <a> <b>`, appends to `runs.csv`;
bash-3.2 + shellcheck clean, no `timeout` dep). powermetrics path needs sudo and
is **untested** — its awk column parse is best-effort, so it always dumps the raw
coalition row to `logs/*.pm.txt`.

**Agent D measured only the main process. I extended it to the WebKit helpers —
that changes the accounting**, because Activity Monitor rolls all four into one
Energy Impact row (and weights GPU time up to ×3):

| process | CPU time | elapsed 14:42:50 | % of one core |
|---|---|---|---|
| `worktrees.app/MacOS/app` (95021) | 26:11.54 | | **2.97 %** |
| `com.apple.WebKit.WebContent` (95039) | 3:38.68 | | 0.41 % |
| `com.apple.WebKit.GPU` (95037) | 1:59.53 | | 0.23 % |
| `com.apple.WebKit.Networking` (95038) | 0:10.09 | | 0.02 % |
| **total** | **31:59.8** | | **3.62 %** |

Plus git children (see below), whose CPU lands in `git`'s own rows but is
attributed to the app in the Energy tab: ~0.3-0.8 %. **Real sustained draw ≈ 4 %
of a core, 24/7.** The GPU helper burning 2 CPU-minutes with the window mostly
not even frontmost is the animation/blink signature.

**Live behaviour observed (read-only, app untouched):**

- **~1 git spawn per second while completely idle** — a 150 s timestamped watch
  caught bursts of **20-45 concurrent `git` processes every ~30 s**, 142 spawns
  in 150 s, all direct children of the app. Confirms the 30 s blind sweep, and
  confirms it runs with the app **not frontmost** → zero visibility gating, as
  predicted.
- Per-5s %CPU oscillates 0.2 % idle → **5-11 % during bursts**; threads 56 → 88.
- **41 zombie children, stable — a previously unknown bug.** Unreaped
  subprocesses; count held at 41 across a 10-minute gap, so it is bounded, not
  growing. Near-zero power but a real process-table leak (and it means those
  children's CPU is never even accounted to us).
- **15 idle `/bin/zsh -l` PTY shells** still parented to the app (dock scratch
  shells never cleaned up), each with a live reader thread — 16 PTY reader
  threads total. Memory/fd cost, not power.
- `sample 95021`: every thread parked in `__psynch_cvwait` / `read` / `kevent`.
  **Nothing spins.** The cost is all real work, not a busy-loop.
- Idle wakeups/s measured ≈ **0.00** → the wakeup term is NOT our problem;
  CPU + GPU time is. De-prioritises timer-leeway/QoS tuning.

**Measurement protocol**: 120 s window (captures exactly 4 git bursts; 45 s gave
±10 % spread), 3 repeats, median. Scenarios: `baseline` (app quit), `idle-fg`,
`idle-bg` (fully occluded ≠ minimized), `idle-min`, `stream`. Machine must be
quiet for `machine_cpu_pct`/`pkg_mw` to mean anything — per-process numbers
tolerate noise.

### MEASURED RESULTS (PR1 set) — exact, not sampled

**Method that finally worked.** ps-sampling undercounts badly (the same app read
158 spawns/120 s at 1 Hz and 255/60 s at 5 Hz), and keeping a GUI window visible
while driving shell commands is a losing fight with the window manager. Instead:
a PATH shim of counting wrappers around `git`/`tmux`/`stat`/`date`, run against
`worktrees ls --json` — the CLI executes the identical `snapshot()` path. Exact,
reproducible, focus-independent.

⚠ The shim does NOT work against the app: `fixup_gui_path()` (lib.rs:2545)
prepends the login-shell PATH and keeps the inherited one only as a trailing
fallback, so the real git wins. Measure the engine via the CLI, not the GUI.

**One snapshot of the worktrees repo (8 worktrees + main):**

| command | v0.9.0 | new | why |
|---|---|---|---|
| `git rev-parse` | 20 | 2 | porcelain v2 absorbed `--abbrev-ref HEAD` + `@{u}` |
| `git log` | 18 | 9 | merged `%ct` + `%s` |
| `tmux list-sessions` | 9 | 0 | prefetched PaneList |
| `git status` | 9 | 9 | — |
| `git rev-list` | 9 | 9 | — |
| `stat -f` / `date -r` | 9 / 9 | 9 / 9 | per-process caches don't show in a one-shot CLI run |
| rest | 6 | 6 | — |
| **total** | **91** | **55** | **−39 %** |

**Steady state** (three `ls()` calls in ONE process, so the caches show):

```
snapshot 1: 50    snapshot 2: 32    snapshot 3: 32
```

v0.9.0 has no caches, so it pays **91 every snapshot, forever**.
→ **91 → 32 = 65 % fewer subprocesses** in the app's actual repeat-poll regime.

**Correctness: `ls --json` output is byte-identical to v0.9.0** (verified by
diff). Getting there caught a real regression the test suite missed —

> **The upstream trap.** `rev-parse @{u}` reports only an upstream that
> RESOLVES; porcelain v2's `# branch.upstream` reports the CONFIGURED one even
> when its remote-tracking ref is gone (branch deleted on origin, never
> fetched). That silently turned `"upstream": null` into
> `"upstream": "origin/fix/remove-place-delbranch"` for one worktree. Fix at no
> cost: git emits `# branch.ab` only when the upstream resolves well enough to
> count ahead/behind, so gating the field on `has_ab` restores the old answer
> without a second spawn. **Nothing in bats or the 205 unit tests covered this**
> — only the output diff against the shipped binary did.

**Visibility gating: CONFIRMED WORKING, and the Agent A vs Agent C contradiction
is settled.** The sandbox app's log shows clean transitions:

```
2026-08-07 17:57:03Z [info] ui: window hidden
2026-08-07 17:57:40Z [info] ui: window visible
```

WKWebView **does** fire `visibilitychange` on macOS — Agent A was right that
tauri#6864/#10592 are Windows/WebView2 reports. **No objc2/NSWindow escape hatch
is needed.** Spawns went to 0 while hidden and resumed on the visible edge.

**Also confirmed**: the zombie leak is real and starts immediately — 3 zombies
at 3 minutes of uptime, 4 shortly after, 41 after 14 h.

### ZOMBIE LEAK — investigated, NOT fixed, deliberately dropped (2026-08-07)

**Status: open. Revisit when the count climbs again.** Change was written, then
reverted at David's call. Nothing committed.

**What was assumed and was WRONG**: that `term_close` (`lib.rs:2309`) and
`kill_shell` (`lib.rs:2360`) leak because they call `child.kill()` with no
`wait()`. That reasoning is right for a plain `std::process::Child` — verified,
kill+drop leaves a `Z` — but these are `portable_pty` children, and its
`ChildKiller::kill` for `std::process::Child`
(`portable-pty-0.9.0/src/lib.rs:340-373`) is NOT a plain kill:

1. sends **SIGHUP** (not SIGKILL),
2. then polls `try_wait()` up to 5 times with 50 ms gaps — **`try_wait` reaps**,
3. returns Ok the moment the child is gone.

So the common path already reaps, which is why the "obvious" leak isn't one.

**The real hole, still there**: if the child outlives that ~200 ms grace period,
the code falls through to `std::process::Child::kill` (SIGKILL) and returns
**without a final wait**. That child is never reaped. Narrow, but real.

**Could not reproduce the actual leak.** Four attempts, all reaped cleanly:
plain `sleep` via PTY; `sh -c 'trap "" HUP; sleep 30'` (ignores SIGHUP, so it
*should* hit the SIGKILL path); enumerating every child of the process rather
than probing one pid; and the same via a standalone example outside the test
harness.

⚠ **A test was written and nearly shipped that passes IDENTICALLY with and
without the fix.** Only checking whether it fails on the old behaviour caught
it. Removed — a test that cannot fail is worse than no test. If anyone retries
this, verify the guard fails on the unfixed code FIRST.

**Observed reality**: v0.9.0 instance at 14 h uptime had 41 zombies and 15
accumulated dock shells; another had 3 at ~3 min. Fresh v0.9.1 had **0 at 8:50**
with 1 zsh + 1 tmux child. So the trigger correlates with open/close cycles that
can't be driven without the GUI — or with something not yet found.

**Live check** (if this climbs, there's a reproduction):

```sh
pgrep -f "worktrees.app/Contents/MacOS/app" | head -1 \
  | xargs -I{} sh -c 'ps -axo ppid,pid,stat | awk "\$1=={} && \$3 ~ /Z/" | wc -l'
```

### END-TO-END ENERGY, release vs release (user quit v0.9.0, new bundle run)

Same workspace, same method, same machine. Machine was actually QUIETER for the
new run (8.28 % busy vs 19.56 % for the baseline), so if anything this
understates the machine-load advantage the baseline had.

| metric | v0.9.0 | new build | change |
|---|---|---|---|
| CPU % (top avg) | 3.19 | **1.80** | **−44 %** |
| CPU % (ps delta) | 3.30 | 1.91 | −42 % |
| top POWER (energy impact) | 3.22 | **1.91** | **−41 %** |
| child spawns / 120 s | 159 | **92** | **−42 %** |
| idle wakeups/s | 0.73 | 2.34 | up, but both trivially low |
| zombies in window | 3 | 0 | — |

**Backgrounded (window verified hidden for the entire window):**

| metric | v0.9.0 | new build | change |
|---|---|---|---|
| CPU % | 3.19 | **0.10** | **−97 %** |
| top POWER | 3.22 | **0.10** | **−97 %** |
| child spawns / 120 s | 159 | **1** | **−99 %** |
| idle wakeups/s | 0.73 | 0.02 | −97 % |

The v0.9.0 baseline is legitimately comparable to the *hidden* scenario: it was
captured while the app was NOT frontmost (I was driving the terminal), and
v0.9.0 has no visibility gating anywhere in its code, so its hidden behaviour is
its visible behaviour. That is precisely the bug.

At POWER 0.10 backgrounded, the app cannot plausibly appear in "Apps Using
Significant Energy" (empirical trip line ≈ 20) again.

**Still running, as expected**: the single tmux spawn in the hidden window is the
backend 3 s poll loop (`session_fingerprint`), which is NOT yet gated — the 1 Hz
sampler just misses most of its sub-millisecond spawns. That remains the next
backend item, and it is now the dominant residual.

**A methodology trap worth remembering: app.log timestamps are UTC, measure.sh
labels are local.** Cross-referencing them is the only way to know what window
state a measurement actually ran under — and the first "hidden" run, which
appeared to show MORE work than visible (257 spawns, 2.88 % CPU), turned out to
have the window flapping visible→hidden five times plus real user interaction
(`zsh x3` = places opened, a doctor run mid-window). **Discarded as invalid, not
reported.** The hidden scenario was re-run with a self-validating script that
greps app.log for any `window visible` transition inside its own measurement
window and fails itself if it finds one.

**Non-findings** (checked, clean): no `backdrop-filter`, no `will-change`, no
blur, no infinite animation besides `breathe` + xterm's cursor keyframes;
`pop`/`reading-in` are one-shot; the resize rAF (:1345-1353) is correctly
coalesced; `sessions:busy` is already change-gated backend-side; markdown lexing
and `tokenize` are already memoized on string value.
