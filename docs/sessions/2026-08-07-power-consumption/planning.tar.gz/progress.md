# Progress log

## Session 2026-08-07 — power consumption

- Started on branch `power-consumption` (clean, off v0.9.0).
- Phase 1 recon done by hand (greps + reads), see findings.md.
- Phase 2: launched 4 fable research agents (frontend, backend, macOS platform,
  measurement harness).
- Agent C (macOS platform) reported → findings.md. Headline: Energy Impact
  weights GPU up to ×3, so a perpetual animation dominates; Ghostty had the
  identical bug (cursor blink → "significant energy", −85% when disabled).
  Subprocess spawns are ~EI 0.4 — NOT the headline, correcting my recon.
- Agent B (Rust backend) reported → findings.md. Headline: ~21,000 process
  spawns per idle hour (1-3 CPU-min/hr); Tauri's `Channel::send` JSON-array-
  encodes raw payloads <1024 B into a JS eval, one per PTY read syscall.
- Verified by hand: `lib.rs:2756` uses `.build().run(cb)`, NOT `run_iteration`
  → the tauri#8631/#10373 busy-loop bug does not apply. `libc` already a
  workspace dep (so `poll(2)` + `pthread_set_qos_class_self_np` are free);
  `notify` is NOT a dep — FSEvents work would add one.
- Agent A (frontend) reported → findings.md. Headline: PlaceRow/GroupHeader/
  ProjectNode/FlatLens are defined INSIDE `App()` → the whole nav (450-600 DOM
  nodes) is unmounted and rebuilt on every App render, including per keystroke
  in the filter box. App.tsx:1956-1961 documents the exception but justifies it
  on correctness grounds only (no local state, no focus) — DOM churn was never
  weighed. Also: xterm#625 measured idle CPU 1 % → 5-13 % from cursorBlink
  alone, and "stop blinking when idle" only landed in xterm 7.0 (we're on 5.5).
- Agent A CONTRADICTS Agent C on visibility: tauri#6864/#10592 are Windows /
  WebView2 reports, not macOS. WebKit wires occlusion→visibility via
  `WKWindowVisibilityObserver`, so `visibilitychange` should work here. **Settle
  this empirically first** — it decides whether we need an objc2/NSWindow
  escape hatch at all. 5-line temp patch logging `document.visibilityState`
  through `log_event`, then walk minimize / ⌘H / Space switch / full occlusion /
  partial occlusion and read app.log.
- Agent D (measurement) reported → findings.md. Harness at
  `~/.cache/worktrees/worktrees/power-consumption/` (`measure.sh`, `compare.sh`,
  `runs.csv`, `logs/`) — verified present after the outage.
- **I extended Agent D's measurement**: it covered only the main process. Adding
  the three WebKit helpers changes the accounting (Activity Monitor rolls them
  into one row and weights GPU ×3) — total 3.62 % of a core, and the GPU helper
  had burned 2 CPU-minutes with the window mostly not frontmost.
- Phase 4 synthesis delivered. Scope question put to David — **not answered**;
  session paused by a power outage before the pick.

## Session resumed 2026-08-07 (post-outage)

**Post-reboot baseline** (fresh app PID 2890, `idle-postreboot`, 120 s):

```
cpu %            3.19   (ps delta 3.30% — agrees)
top POWER stat   3.22
idle wakeups/s   0.73
children         159 in 120s = 158 git + 1 tmux  → ~1.3 git spawns/sec IDLE
zombies          3 (app 3 min old; this is how the 41 accumulated)
threads          42   rss 118 MB
```

Earlier, at 3m35s uptime: 11.80 s CPU = **5.5 % of a core**. The problem
reproduces post-reboot. Machine was at 19.6 % busy (my own work) — per-process
numbers tolerate that, `machine_cpu_pct` from this run is meaningless.

⚠ **Harness caveat found**: the child counter polls `ps` at 1 Hz, so it
UNDERCOUNTS short-lived spawns. `tmux list-sessions` is sub-millisecond and only
1 was caught in 120 s, though the code path runs it per place per snapshot. Git
processes live longer so they're caught more often — but 158 is still a floor,
not the true rate. Exact counts need `sudo eslogger exec`. Do not read the
tmux-vs-git ratio from this run.

**Scope decision**: David said "get started" without picking; taking my
recommendation (PR1+PR2). Every item in it is a subset of the wider scopes, so
nothing is wasted if he widens later.

### Changes made so far (branch `power-consumption`)

- `project.rs` `place_json`: canonical session check now answers from the
  prefetched `PaneList` (`has_session`) instead of its own `session_exists`
  shell-out. **−1 tmux spawn per place per snapshot.** Comment above it
  corrected — it claimed "no per-place tmux shell-out" while line 225 was doing
  exactly that.
- `project.rs`: new `last_commit()` merges the two `git log -1` calls (`%ct` and
  `%s`) into one `--format=%ct%x09%s`. **−1 git spawn per place per snapshot.**
  `commit_epoch` kept — `ls_human` still uses it.

- `project.rs` `status_v2()`: ONE `git status --porcelain=v2 --branch` replaces
  three spawns — `rev-parse --abbrev-ref HEAD`, `status --porcelain`,
  `rev-parse @{u}`. **−2 git spawns per place per snapshot** (the biggest
  remaining per-place cut). Semantics pinned to the old three, including unborn
  HEAD (v2 reports the branch-to-be via `# branch.head`; we key off
  `# branch.oid (initial)` and keep the old "detached" answer, because
  `init_repo`/`create_initial_commit` make that a state the app really sees).
- `sysclock.rs`: `detect()` now probes BSD-vs-GNU **once per process** via
  `OnceLock` — its own doc comment already said "probe once, then reuse" but
  `Project::discover` re-ran it every snapshot. Plus a birth-epoch cache keyed
  on **(path, dev, ino)** — dev+ino because `rm foo && new foo` recreates the
  same path as a different directory and a path-only key would serve the dead
  one's date forever — and a `fmt_date` cache keyed on epoch. `fs::metadata` is
  used only to build the key; emitted values still come from the shelled-out
  `stat`/`date`, so bash byte-compat is untouched.
- `App.tsx` `useWindowAwake()`: new two-signal visibility primitive
  (`pageVisible` from `visibilitychange`, `winFocused` from window focus/blur).
  Logs every transition through `log_event` — whether WKWebView really fires
  `visibilitychange` on occlusion is the one open question the test suite can't
  answer, so it is answerable from app.log on a real build.
- `App.tsx` `refresh()`: bails when the serialized workspace is unchanged. Idle
  polls return byte-identical payloads (verified — no time-varying fields in
  `ProjectView`/`Place`; age is computed frontend-side), so this kills the
  30-second no-op re-render of the whole tree.
- `App.tsx` `places:changed` listener: **the throttle point.** Hidden → record
  `pendingRefresh` and return, so the git sweep never runs for a window nobody
  is looking at. A second effect fires the deferred refresh on the visible edge.
- `App.tsx`: usage widget's 15 s tick and 180 s poll, and the 5-minute doctor/
  init sweep, all stop while hidden and catch up on return.
- `TerminalPane.tsx`: cursor blink now follows the WINDOW, not the element.
  xterm's own gate is the `.xterm-focus` class, which never dropped here because
  `useTerm` force-focuses on mount and re-entry and element focus survives OS
  window deactivation. Module-scope `liveTerms` set + window listeners.
- `App.css`: `breathe` → `steps(4, jump-both)` at both sites (busy status dot,
  busy project badge).

### Gates run (all green, with all of the above applied)

- `cargo build --release -p worktrees-cli` — clean, no warnings
- `cargo test -p worktrees-core` — 205 passed
- `make test` (bats) — 286 passed on the pre-porcelain set; re-run in flight
- `make lint` — shellcheck + bash-3.2 gate clean
- `app/node_modules/.bin/tsc --noEmit` — clean
- `cargo check -p app` — clean

### Deferred, with reason

- `OnceLock` on `have_git()`/`have_tmux()` (−2 spawns/snapshot): **would break a
  real feature.** `lib.rs:2578-2582` `tmux_check(refresh)` calls `have_tmux()`
  before and after specifically to detect the user installing tmux mid-session.
  Needs a cache with explicit invalidation on that path; low value, real risk.
- **The nav hoist (PR2's big item) — deliberately NOT batched with this set.**
  `PlaceRow`/`GroupHeader`/`ProjectNode`/`FlatLens` must ALL move to module
  scope together: hoisting the leaf alone achieves nothing, because a redefined
  `ProjectNode` unmounts its whole subtree regardless of how stable `PlaceRow`
  is. Between them they close over ~30 values (sel, drag, dragOver, settings,
  health, suggest, collapsed, newFor, confirmRm + ~15 callbacks), so doing it
  properly means threading explicit props and `useCallback`-stabilising the
  handlers — a few hundred lines in a 2700-line file, invisible to bats, and
  only assertable through the mock harness.
  Reason to hold it back: it lands in the same measurement window as everything
  above, and a regression would be unattributable. Ship + measure this set
  first, then do the hoist as its own change with its own before/after.
- Backend poll-loop gating (`lib.rs:2635`, the 3 s tmux fingerprint + claude
  probe scan): the frontend gate already cancels the expensive half (the git
  sweep), so this is the smaller remaining piece. Needs a `set_poll_mode`-style
  frontend→backend push, same shape as the existing `set_fetch_interval`.

## Session end state (2026-08-07, first half)

- Branch `power-consumption`: clean, **zero commits, no code touched**.
- Nothing lost to the outage. Planning files + harness are on disk.
- Resume instructions and the four scope options are at the top of
  `task_plan.md`. Re-take the baseline first — the captured one belongs to a
  now-dead app instance (see the ⚠ note there).
