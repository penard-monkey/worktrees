# Task plan — cut worktrees.app power draw on macOS

## STATUS 2026-08-07 (post-outage session)

**PR1 is done and verified.** Engine: **91 → 32 subprocesses per snapshot
(−65 %)** in the repeat-poll regime, `ls --json` byte-identical to v0.9.0.
Visibility gating confirmed working on a real WKWebView build. All gates green
(bats 286, core 205, lint, tsc, cargo check). **Nothing committed** — the user
has not asked for a commit.

Next decision (open): get a release-vs-release ENERGY number before investing in
the nav hoist, since the hoist targets render churn that is still unmeasured.
Getting that number requires quitting the installed v0.9.0 and running the new
bundle at `target/release/bundle/macos/worktrees.app`.

Remaining, in rough priority: nav hoist (PR2) · zombie reap · backend poll-loop
gating · FSEvents (PR3) · PTY→IPC coalescing + WebGL (PR4).

## ⏸ Earlier pause note (power outage) — superseded by the status above

**State**: all research complete (4 fable agents, results in findings.md). Live
baseline captured. **No code changed. Branch `power-consumption` is clean, zero
commits.** Nothing was lost to the outage — planning files and the measurement
harness both live on disk.

**Blocked on**: David picking a scope. The question was put and not yet
answered. The four options, unchanged:

1. **PR1+PR2, measure first** *(my recommendation)* — sudo baseline run, then
   visibility gating + snapshot dedupe + free spawn cuts + nav hoist/memo +
   `breathe` steps() + cursorBlink. No new deps, low risk, should land the bulk
   of the ~4 %. Re-measure, report before/after, then decide on the rest.
2. **Everything, staged into 4 PRs** — adds the FSEvents watcher (`notify` dep)
   and PTY→IPC coalescing + WebGL. Biggest win; two new deps; WebGL is invisible
   to the bats suite and needs a `docs/…-manual-checks.md` entry.
3. **Cheapest cuts only** — free spawn cuts + `breathe` steps() + cursorBlink off
   + zombie reap. Near-zero risk, no architecture change.
4. **Just measure properly first** — sudo powermetrics across all 5 scenarios,
   attribute the 4 % to specific causes, report before touching code.

**⚠ The captured baseline is NOT re-usable after the reboot.** It was taken from
one app instance with 14:42:50 uptime (PID 95021) and 41 accumulated zombies.
CPU-time totals restart at zero on relaunch, and zombie count starts at 0 and
climbs. **Re-run the baseline before comparing anything**:

```sh
# app must be running and left alone for the window
~/.cache/worktrees/worktrees/power-consumption/measure.sh idle-fg 120
# with powermetrics (the headline number):
sudo ~/.cache/worktrees/worktrees/power-consumption/measure.sh idle-fg 120
```

Keep the old numbers only as an order-of-magnitude "before" (≈4 % of a core,
~1 git spawn/sec idle) — the shape is what matters, not the digits.

**First action on resume**: re-read findings.md, confirm the app is running,
re-take the baseline, then ask David for the scope pick.

## Goal

The Tauri app shows "significant energy impact" in macOS Activity Monitor even
when idle. Find and remove the sources of continuous CPU/wakeup work, with
changes that also make the app FASTER (lower latency terminal, fewer redundant
git sweeps) — never slower.

Success = measurable drop in idle Energy Impact / wakeups-per-second
(powermetrics), no regression in the gates, terminal throughput same or better.

## Phases

| # | Phase | Status |
|---|-------|--------|
| 1 | Recon — map every periodic/continuous work source | complete |
| 2 | Research fan-out (fable agents): frontend, backend, macOS platform, measurement | complete |
| 3 | Baseline measurement on this machine (idle + streaming) | partial — live "before" captured, harness needs a sudo run |
| 4 | Synthesize ranked option list + recommendation to user | complete — awaiting scope pick |
| 5 | Implement (PR1 set) | **complete — all gates green** |
| 6 | Re-measure, report before/after | blocked: needs the new build actually running |
| 7 | Nav hoist (PR2) as its own change + measurement | pending |

## Gates, with the full PR1 set applied (all green)

`cargo test -p worktrees-core` 205 passed · `make test` (bats) **286 passed,
exit 0** · `make lint` clean · `tsc --noEmit` clean · `cargo check -p app` clean
· release CLI builds warning-free · app bundle builds
(`target/release/bundle/macos/worktrees.app`; the updater-*signing* step fails
without `TAURI_SIGNING_PRIVATE_KEY`, which is expected for a local build and
does not affect the bundle).

⚠ Do NOT run the bundle's binary to probe it — it is the GUI entry point, so
`.../MacOS/app --version` LAUNCHES a second instance rather than printing a
version. Did that once; killed PID 28632/28638.

## Baseline (measured, app up 14:42:50)

App + WebContent + GPU + Networking = **3.62 % of one core sustained**, plus
~1 git spawn/sec idle (bursts of 20-45 every 30 s) → **≈4 % of a core, 24/7**.
41 zombie children. Idle wakeups ≈ 0 (so the wakeup term is not the problem —
CPU and GPU time are).

## Proposed staging (each stage independently shippable + measurable)

- **PR1 "stop working when nobody is looking"** — visibility/focus gating +
  snapshot dedupe + the free spawn cuts (prefetched PaneList, merged `git log`,
  OnceLock SysClock/have_git/have_tmux). Low risk, no new deps.
- **PR2 "stop remounting the nav"** — hoist PlaceRow/GroupHeader/ProjectNode/
  FlatLens to module scope + memo; `breathe` → `steps()`; cursorBlink gated.
- **PR3 "event-driven"** — FSEvents watcher (`notify` dep) replaces the 30 s
  blind sweep + the claude probe scan.
- **PR4 "terminal"** — PTY→IPC coalescing; optional `@xterm/addon-webgl`.
- **Bug, any stage**: reap the 41 zombies.

## Constraints (from CLAUDE.md)

- git/tmux stay shelled out — do not switch to libraries.
- Tauri commands must be `async fn`.
- Mock harness (`app/src/mock/install.ts`) must track every lib.rs command.
- No UI component libraries; a pure parser/addon is allowed (xterm addons are
  renderers, decide explicitly).
- Gates before PR: release build, `make test`, `make lint`, cargo tests, tsc +
  `cargo check -p app`.

## Decisions

- Research via 4 parallel fable agents (user asked for fable).
- Measurement uses `powermetrics` (sudo) + Activity Monitor Energy Impact;
  baseline BEFORE any edit.

## Errors Encountered

| Error | Attempt | Resolution |
|-------|---------|------------|
| — | — | — |
