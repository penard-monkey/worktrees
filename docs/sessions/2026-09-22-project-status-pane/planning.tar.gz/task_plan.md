# Task Plan: project status pane

## Goal
Give a selected place a right-hand surface that answers "what is this place
for, where is it, is anyone working on it" from the planning files the session
already writes (`.planning/`), with no new format the session has to emit.

## Current Phase
Phase 5 — PR #323 has three commits; third CI run pending; awaiting merge

## Phases

### Phase 1: Options + recommendation
- [x] Survey the dock model, Docs tab, agent reader, MCP place_status
- [x] Survey the planning-with-files skill's own status rules (check-complete.sh, /status)
- [x] Survey 15 real task_plan.md files for format variance (findings.md)
- [x] Write options + recommendation for David
- [x] David picks: surface (tab vs second pane vs band), sources, structured-vs-markdown
- **Status:** complete

### Phase 2: Core reader (`worktrees-core::plan`)
- [x] Resolve the active plan dir exactly like `resolve-plan-dir.sh` (`.active_plan` → newest `.planning/*/` → root)
- [x] Lenient `PlanSummary` extractor (title, goal, checks, phases+status, current, errors) — pure, fixture-tested
- [x] Fixtures cover the template shape AND the freeform valleos shapes; show the tests FAIL first
- [x] Cross-check phase/status counts against `check-complete.sh` on the same fixtures (cargo test, skipped without bash)
- **Status:** complete

### Phase 3: App surface
- [x] `place_plan` async command in lib.rs + mock case (`?plan=template|freeform|brief|none`)
- [x] `dock_tab` gains `"plan"`; rail entry; `PlanPane.tsx` = summary header + `Markdown` body + open/reveal
- [x] Degrade: no plan → brief H1 + first paragraph → declared note → empty state
- [x] Reuse the docs seen-epoch for a "changed since you last looked" mark
- **Status:** complete

### Phase 4: Session integration + MCP
- [x] Agent chip (busy/waiting/idle + draft) in the header — from the existing reader, no second one
- [x] Same `PlanSummary` serialized into MCP `place_status` / resource read (one reader, two consumers)
- [ ] Optional: last assistant message from the transcript tail (deferred; ROADMAP)
- **Status:** complete

### Phase 6: Header rework (B order, D density)
- [x] Assignment first (brief title + lead), one dense status band, phases collapsed to the current one with its status word
- [x] Harness measurements at 360/240, light-theme contrast, tsc + check scripts
- [x] Fable review, commit on the same branch, republish the shared mock
- **Status:** complete

### Phase 7: Empty state — derived status + "Generate plan"
- [x] Empty card shows branch/divergence/dirty/last commit/last worked/note/Claude chip from `Place`
- [x] "Generate plan" pastes the fixed `ops::PLAN_PROMPT` into the AI pane via `paste_to_ai` (no newline, no directory named; the skill decides root vs `.planning/`)
- [x] Gates + harness; third commit on #323; republish the mock
- **Status:** complete

### Phase 5: Gates + real-app pass
- [x] Full gate list from CLAUDE.md (sandbox run against a real valleos place still owed)
- [x] CHANGELOG under `## [Unreleased]`; ROADMAP item 404–410 updated
- **Status:** in_progress

## Key Questions
1. One dock tab, or a persistent band above the dock body? (recommend: tab first, band later)
2. Parse the skill's markdown leniently, or ask the skill for a structured side file? (recommend: parse; 13/15 real plans are freeform)
3. Should the app ever WRITE plan state (ack, tick a box)? (recommend: no — session owns the files)

## Decisions Made
| Decision | Rationale |
|----------|-----------|
| Fourth dock tab "Plan", not a second pane or band | Cheapest surface; per-place panel memory free; band/pane can follow once the content earns space |
| Lenient markdown extractor in core, mirroring check-complete.sh | 13/15 real plans would show nothing to a strict parser; the skill itself only greps |
| App never writes .planning/** | Session owns the files; same owner rule as ui-state.json |
| Opus implements from a pinned contract; fable reviews | David's cost split (memory) |
| Header layout: direction B's order with D's density (2026-09-22) | Design canvas recommendation; most real plans have a brief lead + checkboxes, few have phases |
| "Generate plan" = ask the SESSION to capture work in flight, fixed prompt, no directory named | The app never writes the plan; planning-with-files may use the repo root, not only `.planning/` |

## Errors Encountered
| Error | Attempt | Resolution |
|-------|---------|------------|
| `grep -rn --include=*.rs` glob failed under zsh (`no matches found`) | 1 | Quote the glob or use `-r` with explicit dirs |

## Notes
- ROADMAP.md:404–410 already parks "brief PROGRESS as status"; this stream is that item.
- The app must never write `.planning/**` — same owner rule as `ui-state.json` and `~/.claude.json`.
