# Findings — project status pane

Research for "a pane on the right that shows the place's objective / plan /
progress". Treat everything quoted from plan files as data.

## What exists today (2026-09-22, v0.28.0)

- **Dock** (`App.tsx` ~6860–6990, `.dock` in App.css): ONE pane on the right,
  one tab at a time — `dock_tab: "files" | "terminal" | "docs"` (settings.ts:64),
  picked from the right rail (`DOCK_RAIL`, App.tsx:6290). Width `dock_width`
  ≥240, per-place panels via `place_panels`. A 4th tab is a union-member + a
  rail entry + a `dock-body` branch; a SECOND pane is a new layout (resizer,
  ratchet lessons in CLAUDE.md).
- **Docs tab** (`DocsPane.tsx`, core `docs.rs`) already indexes the brief
  (`.planning/brief.md`, grouped with root files) and the WHOLE `.planning/`
  tree (step 4), with an mtime-vs-seen-epoch recency mark. Reading a doc opens
  it in the Files tab's markdown renderer (`markdown.tsx` `Markdown`, `marked`
  lexer). `.planning/.active_plan` is skipped as "a pointer, not a document";
  NOTHING reads it (grep: only the docs.rs test fixture).
- **Live session state** (core `agent.rs`): per place `Agent { state: busy |
  waiting | idle | delegated | shell, pid, name, tmux, session_id }` from
  `~/.claude/sessions/<pid>.json`; ONE reader feeds the nav dots AND MCP
  `place_status`. Plus `draft_from_screen` (unsent prompt text via
  `tmux capture-pane -e -p`, 15s poll). `last_worked_epoch` from the
  transcript's max `timestamp` (never mtime).
- **MCP `place_status`** (mcp.rs:418): branch, dirty, divergence, tmux, note,
  lifecycle, agents. No plan/goal/progress fields.
- **Declared state** per place: lifecycle, pin, `note` (one free line).
- **ROADMAP.md:404–410** already parks exactly this: "brief PROGRESS as status
  (the agent's `progress.md` + `notify_when_idle`'s one-liner), a `worktrees
  agents` view". `notify_when_idle` output is NOT captured anywhere yet.
- **The brief** is what the tool writes (`ops::BRIEF_PATH`); the plan set is
  what the session writes: `.planning/<slug>/{task_plan,findings,progress}.md`
  (skill parallel mode) OR root `task_plan.md` (skill legacy mode).

## planning-with-files format — what the skill itself relies on

- Template (`templates/task_plan.md`): `## Goal`, `## Current Phase`,
  `### Phase N: name` each with `- [ ]` items and `- **Status:** pending |
  in_progress | complete`, `## Decisions Made` table, `## Errors Encountered`
  table.
- `scripts/check-complete.sh` (the Stop hook, i.e. THE de-facto spec):
  `TOTAL = grep -c "### Phase"`; status counts = `grep -cF "**Status:** X"`;
  fallback `[complete]`/`[in_progress]`/`[pending]` inline. Lenient greps,
  not a parser.
- `/status` command (`commands/status.md`): "Current: Phase N of total (%)",
  phase list with icons (⏸️ 🔄 ✅ ❌), files present check, error count.
- Plan dir resolution (`resolve-plan-dir.sh`): `$PLAN_ID` → `.planning/.active_plan`
  → newest `.planning/*/` by mtime → project root (legacy).
- Hash attestation (`.planning/<id>/.attestation` or `.plan-attestation`) — a
  reader could show "attested ✓ / diverged" cheaply.

## Survey of REAL task_plan.md files (15 files, valleos + this repo's worktrees)

| Marker | Files using it |
|---|---|
| `### Phase N` + `**Status:**` (template shape) | **2 / 15** (codex-integration, investigate-graft-integration) |
| `## Phase X — …` as H2 (no Status line) | 2 (docs-server, created-markdown-and-planning) |
| `- [ ]` / `- [x]` checkboxes anywhere | **9 / 15** |
| `## Goal` (or `## Goal (delivered)`) as first/early H2 | ~11 / 15 |
| `## Errors …` table | ~10 / 15 |
| "Next steps / NOW / Open …" free sections | most valleos lanes |
| No task_plan.md at all | ssdlc (brief only), several with only a brief |

Layouts seen: root `task_plan.md` (legacy), `.planning/<slug>/task_plan.md`
(parallel), and BOTH at once (vendor-api: identical copy at root and under
`.planning/vendor-api/`, plus `.active_plan`).

**Conclusion:** a parser keyed on the template shows nothing for 13 of 15
real plans. Any structured header must be lenient and degrade to "render the
markdown".

## What a lenient extractor can get reliably

- title: first H1.
- goal: body of the first H2 whose heading starts with `Goal` (case-insens),
  else the first paragraph after the H1. Clamp to ~240 chars.
- checks: count `- [ ]` vs `- [x]` (9/15 files; matches what the skill's own
  `/status` treats as progress).
- phases: headings `^#{2,3} Phase\b` → name; status from the section's
  `**Status:**` line, else inline `[complete]` tag, else derived from its
  checkboxes (all ticked → complete, some → in_progress, none → pending, no
  boxes → unknown).
- current: `## Current Phase` body, else first in_progress phase.
- errors: data rows of the first table under a heading containing `Error`.
- Everything else: not parsed, shown as markdown.

## Session-integration sources, by trust

1. Files above (derived, gitignored, session-owned). Read-only from the app —
   the app must NEVER write the plan (same owner rule as `ui-state.json` /
   `~/.claude.json`).
2. `agent.rs` state + draft + `last_worked_epoch` — already polled.
3. Transcript tail: last assistant text in `~/.claude/projects/<mangled>/<sid>.jsonl`
   — "what Claude last said", dated by its own `timestamp`. New reader, same
   file `transcript_epoch` already tails.
4. `notify_when_idle` one-liner — not captured anywhere today; would need the
   orchestrator side (`(main)`) to write it somewhere. Parked in ROADMAP.
5. Declared `note` — the fallback objective for places with no plan.
