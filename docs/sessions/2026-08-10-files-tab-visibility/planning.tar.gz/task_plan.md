# Task plan — Files tab missing files

## Goal
The app's FILES tab does not list every entry that exists on disk at the
worktree root. Find the root cause in the listing pipeline (Rust command →
frontend tree) and produce a fix plan.

## Evidence (from _tmp screenshots, 2026-08-10 05:00)
Same place: `casa-del-valle-monorepo / audit-and-financials`
(`~/workspace/casadelvalle/casa-del-valle-monorepo/.worktrees/audit-and-financials`,
branch `finanzas-investor-pack`).

Shell `ls` in that worktree lists 26 entries. The FILES tab shows the tracked
set plus dotfiles, but is **missing** these four that `ls` shows:

- `findings.md`
- `progress.md`
- `task_plan.md`
- `node_modules/`

…while it DOES show gitignored-looking entries (`_tmp`, `.redesign-shots`,
`old-plans`, `patches`). So "gitignored files" are partly shown — the filter is
not a simple all-or-nothing.

## Phases
| # | Phase | Status |
|---|-------|--------|
| 1 | Capture screenshot evidence into findings.md | complete |
| 2 | Fable agent A: backend listing command (Rust) | complete |
| 3 | Fable agent B: frontend Files tab consumption | complete |
| 4 | Reproduce against the real worktree, confirm root cause | complete |
| 5 | Decide the UX fix with the user | complete |
| 6 | Implement + verify in the harness | complete |
| 7 | Full gates + PR | complete — #104 squash-merged as aa2ff49 |

Chosen fix: show gitignored entries by default (dimmed), with a one-time
migration for installs that persisted the old default. See progress.md.

## Root cause (confirmed by reproduction, not just reading)
Not a listing bug. `list_dir` does a real `read_dir` and then hides entries
that `git check-ignore` flags, unless `files_show_ignored` is true — and that
setting defaults to false and was false when the screenshots were taken
(`ui-state.json`, mtime 05:03 vs screenshots 05:00). The four "missing" entries
are exactly the four gitignored ones. Everything I thought was an ignored entry
that survived (`_tmp`, `old-plans`, `patches`, `.redesign-shots`) is tracked.

The defect is that the tab withholds entries with no visible sign it is doing
so, behind an unlabeled `◌` toggle that defaults to off.

## Decisions
- Investigation delegated to fable agents (user request).
- No code changes until root cause is confirmed by reproduction, not by
  reading alone. → done; reading alone would have been enough here, but the
  reproduction is what killed my wrong premise about `_tmp`/`old-plans`.

## Errors Encountered
| Error | Attempt | Resolution |
|-------|---------|------------|
| — | — | — |
