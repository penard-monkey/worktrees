# Findings — Files tab missing files

## 1. Screenshot evidence (2026-08-10 05:00, `_tmp/Screenshot 2026-08-10 at 05.00.44.png` + `…05.00.51.png`)

Both screenshots are the same app window, same selected place
(`casa-del-valle-monorepo → audit-and-financials`, branch
`finanzas-investor-pack`). One shows the FILES dock, the other the TERMINAL
dock running `ls` in the worktree root — a direct A/B.

### Terminal `ls` (ground truth, 26 entries)
```
_tmp                       findings.md          pnpm-lock.yaml
AGENTS.md                  infra                pnpm-workspace.yaml
apps                       integration-plan.md  progress.md
CLAUDE.md                  mocks                README.md
data                       node_modules         scripts
design-system              old-plans            task_plan.md
docker-compose.demo.yml    package.json         tsconfig.base.json
docker-compose.worktree.yml  packages
docker-compose.yml         patches
docs
```
(`ls` without `-a`, so dotfiles are absent from this list — not evidence of
anything.)

### FILES tab
Directories: `.claude .design .dmux-hooks .githooks .github .junie .opencode
.redesign-shots apps data design-system docs infra mocks old-plans packages
patches scripts`
Files: `.env.example .gitattributes .gitignore .gitleaks.toml .gitleaksignore
.npmrc .nvmrc .vercelignore .worktree-prefix .worktrees.toml _tmp AGENTS.md
CLAUDE.md docker-compose.demo.yml docker-compose.worktree.yml
docker-compose.yml integration-plan.md package.json pnpm-lock.yaml
pnpm-workspace.yaml README.md tsconfig.base.json turbo.json`

### Delta — on disk but NOT in the tab
- `findings.md`
- `progress.md`
- `task_plan.md`
- `node_modules/`

### Notes that constrain the hypothesis
- The tab is NOT hiding all ignored files: `_tmp` (a symlink to iCloud) and
  `old-plans` / `patches` / `.redesign-shots` are listed.
- `turbo.json` appears in the tab but not in the `ls` output → the two views
  were captured against the same dir, so `turbo.json` must exist; `ls` output
  in the screenshot is column-wrapped and the entry may be off-frame. Do not
  build a theory on that one.
- The missing markdown trio are exactly the planning-with-files artifacts,
  which that monorepo gitignores. `node_modules` is gitignored too. So the
  filter drops SOME ignored entries and keeps others.

## 2. Code investigation (two fable agents, backend + frontend)

### Verdict: not a listing bug. The tab is doing exactly what it was told.

`list_dir` does a real `read_dir` (`app/src-tauri/src/lib.rs:2241`) — the
listing is NOT derived from git output. One level, no pagination, no cap, no
truncation. Only hardcoded skip is `.git` (`lib.rs:2244`).

Then one subprocess, `git -C <dir> check-ignore --stdin -z`
(`lib.rs:2278-2283`), and:

```rust
if show_ignored.unwrap_or(false) {
    for e in &mut entries { e.ignored = ignored.contains(&e.path); }  // dim
} else {
    entries.retain(|e| !ignored.contains(&e.path));                   // hide
}
```
(`lib.rs:2253-2259`)

Failure is fail-open: a git spawn/wait error yields an empty ignored set
(`lib.rs:2286, 2299`), so a broken git call would show MORE, never less.

Frontend applies **zero** filters. `FilesPane.tsx:130` invokes
`list_dir({ path, showIgnored })` and renders `entries.map(...)` raw, keyed on
`e.path`; subdirs the same at `:63`. Ignored rows are only *dimmed*
(`App.css:838-840`, no `display:none`). `showIgnored` comes from
`settings.files_show_ignored` (`settings.ts:104`, **default false**), toggled
by the middle `◌` button in the dock header (`App.tsx:2754-2764`, title "Show
gitignored files (build output, working notes)"). The other two header buttons
are `↻` refresh (`App.tsx:2746`) and the layout cycle (`App.tsx:2765`).

### The premise in my own evidence was wrong
I assumed the tab was keeping some ignored entries (`_tmp`, `old-plans`,
`patches`, `.redesign-shots`) while dropping others. It isn't — those are all
**tracked**, so `check-ignore` (which consults the index) never flags them.
`_tmp` is a tracked symlink, mode `120000`; that monorepo's `.gitignore`
ignores only `_tmp/*` and `_tmp/**` with the comment "Track the symlink, never
the contents".

Proved by hand against the live worktree — output is exactly the four missing
entries and nothing else:
```sh
W=~/workspace/casadelvalle/casa-del-valle-monorepo/.worktrees/audit-and-financials
printf '%s\0' "$W"/findings.md "$W"/progress.md "$W"/task_plan.md "$W"/node_modules \
  "$W"/_tmp "$W"/old-plans "$W"/patches "$W"/.redesign-shots "$W"/turbo.json \
  | git -C "$W" check-ignore --stdin -z | tr '\0' '\n'
→ findings.md progress.md task_plan.md node_modules
```

And the toggle was off when the screenshots were taken:
`~/Library/Application Support/net.casadelvalle.worktrees/ui-state.json`
(mtime 05:03, screenshots 05:00) contains `"files_show_ignored": false`.

### Stale-listing ruled out
`FileTree` keeps the last good `entries` on a failed re-list
(`FilesPane.tsx:131-145`, commit 5536d26) but paints an error note above the
tree, so a silent stale listing can't happen. Re-list triggers: `places:changed`
while visible (`App.tsx:1266`), hidden→visible edge (`:1280`), `↻` (`:1290`),
tmux re-check (`:1245`), and any `showIgnored` flip (effect dep,
`FilesPane.tsx:75,134`). Staleness would also drop entries by creation time,
not carve out precisely the gitignored set.

### So the real defect is discoverability, not correctness
Nothing tells you entries are being withheld. The tab looks like a filesystem
listing, the count of hidden entries is never surfaced, and the control is an
unlabeled `◌` glyph in a three-icon row that defaults to off.

### Side observation (cosmetic, unrelated)
`e.file_type()` at `lib.rs:2247` does not follow symlinks, so `_tmp` — a
symlink to a directory — renders with a file icon and is not expandable.

