# Progress

## Session 2026-08-10 — "Files tab is missing files"

### What it turned out to be
Not a missing-files bug. `list_dir` reads the directory for real and then drops
whatever `git check-ignore` flags, unless `files_show_ignored` is on — and it
defaulted **off**. The four "missing" entries were exactly the four gitignored
ones; the toggle was off in `ui-state.json` at the time of the screenshots.
Full trace in findings.md.

Two fable agents (backend / frontend) investigated in parallel and independently
reached the same conclusion. Both were right that the code was behaving as
designed; the reproduction is what killed my own wrong premise (that `_tmp` and
`old-plans` were ignored-but-shown — they are tracked).

### Decision
David chose: **show ignored by default, dimmed** — the tab should mirror the
filesystem out of the box.

### Changed
| File | Change |
|------|--------|
| `app/src/settings.ts` | `files_show_ignored` default `false` → `true`; new `settings_rev` field + `SETTINGS_REV = 1`; `migrate()` re-applies changed defaults once and `loadSettings` saves when it fires |
| `app/src/App.tsx` | toggle glyph now reflects state — `◉` when nothing is withheld, `◌` when entries are hidden (the `on` tint alone was not enough to notice a filtering tree) |
| `CHANGELOG.md` | `[Unreleased] → Changed` entry |

Migration was needed, not optional: `loadSettings` merges `{...DEFAULTS, ...raw}`,
so a persisted `false` outranks the new default forever — the flip would have
been invisible to precisely the person who reported it.

### Verification (mock harness, port 5199, `--force`)
Asserted via `getComputedStyle`/DOM, not eyeballed:
- fresh settings → ignored rows present and dimmed (`node_modules`, `target`,
  `progress.md`, `task_plan.md` at `--txt-mute` `#565f89`), toggle `◉`,
  `aria-pressed=true`
- click toggle → those four rows disappear, glyph `◌`, `aria-pressed=false`
- reload with that OFF choice persisted (`rev 1`) → stays off; the migration
  does NOT re-run and clobber a deliberate choice
- seed a 0.10.0-shaped blob (no `settings_rev`, `files_show_ignored: false`) →
  reload → stored becomes `{rev: 1, show: true}`

### Gates — all run before the PR, all clean
`cargo build --release -p worktrees-cli`, `make test` (288 ok / 0 not-ok),
`make lint`, `cargo test -p worktrees-core`, `cargo test -p worktrees-cli`,
`tsc --noEmit`, `cargo check -p app`. CI: 9/9 jobs pass on both OSes.

### Review (fable, on the uncommitted diff)
No defects. It specifically could not construct a failure for the migration
against a null / `{}` / partial / already-migrated / future-rev / non-number-rev
blob, nor a debounce interleaving where the migration's save is clobbered by
stale data (each later `saveSettings` replaces the shared timer with an object
built from the already-mutated `s`). Three cosmetic fixes came out of it and
were applied: the CHANGELOG called `node_modules` a file, and `App.css:835` +
`FilesPane.tsx:55` still called the control "the ◌ toggle" when ◌ is now only
its hiding-state glyph.

One accepted consequence, called out in the PR: a 0.10.0 user who *explicitly*
toggled ignored files off gets flipped back on once — full-blob persistence
makes a deliberate `false` indistinguishable from the default `false`.

### Merged
PR #104 → squash-merged as `aa2ff49` on origin/main. `ui-next` reset onto it,
worktree clean.

### Housekeeping
Playwright MCP artifacts moved out of the repo to
`~/.cache/worktrees/worktrees/ui-changes/`; harness killed (content-checked, not
port-checked). `git status` shows only the three intended files.

### Open
- Cosmetic, untouched: `lib.rs:2247` uses `e.file_type()`, which does not follow
  symlinks, so `_tmp` (symlink → dir) renders with a file icon and cannot be
  expanded.
