# Owned planning — Phase 1 (cdv pilot)

## Goal
Ship docs/proposals/owned-planning.md §9 phase 1 as two PRs: A (core+CLI), B (Claude plugin + app).

## Current Phase
Phase A1

## Phases
### Phase A1: core — planning settings + registry fields + safe paths
- [ ] planning.rs: planning.json global, Level/Scope, effective(), setters (tracked refusal)
- [ ] registry Entry: planning / plan_path / plan_scope
- [ ] safepath: safe_under moved from docserver + safe_dir_under + show classification
### Phase A2: core — resolver
- [ ] plan::resolve public, Mode Legacy/Owned/Show, case table, PlanSummary level/topic/plan_scope/reason
- [ ] callers: app place_plan, mcp plan_json use effective mode
### Phase A3: CLI
- [ ] plan resolve [--json] (version stamp), plan hook session|prompt (budgets, cache), plan default/level setters
- [ ] cmd_new: pointer + topic dir at full; info/exclude; tracked warning
- [ ] parity test (red first), bats rows, unit tests
### Phase A4: gates, ls/MCP diff vs ~/.local/bin/worktrees, CHANGELOG, proposal clarifications, PR A, message main
### Phase B: plugin + app (separate PR)
- [ ] claude-plan plugin on own launch branch
- [ ] offers.ts planning + Settings → Planning + Add/New/Clone + PlanPane union + version compare + mock + checks
- [ ] sandbox verification, PR B, pilot steps message
