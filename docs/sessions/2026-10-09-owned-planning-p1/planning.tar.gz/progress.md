red-first: owned tests red with Owned→Legacy (4/4) and with pointer validation disabled (invalid test)
red-first: parity test red with hook on Mode::Legacy (root-layout lane: hook named .planning/orchestrator/task_plan.md via newest guess, tab said task_plan.md); green restored
red-first: plugin test red when planning_for gated on guidance enabled
red-first: offers-check red with a projects>0 precondition on planning offer
red-first: planresolve-check red with show_path dropped from the union
red-first: nits 1-3 tests red against the old behaviour
