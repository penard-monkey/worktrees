# Findings — unread completions

## How the purple dot works today (verified in source)
- `app/src/afterglow.ts`: PURE tier math. Dot keys off `workedAt(p)` ONLY —
  "never an open, never a commit" (header comment). Tier 1 = pinned 15 min,
  wears the ring (`.status-dot.done.t1` box-shadow, App.css:491); later tiers
  are inline opacity, geometric to `done_horizon_secs` (default 12h, 3 steps).
- The "pulse" is NOT an animation: t1 is a static box-shadow ring. Only busy
  and pending use `breathe`. Reason: `prefers-reduced-motion` freezes every
  animation at frame 0 (tokens.css:430), so motion has no fallback.
- App.tsx:3204 `workedAt` = max(live `sessions:done` map, `declared.last_worked_epoch`).
  App.tsx:3238 `doneOf` = 0 when busy/waiting, else `doneTier(workedAt, now, bounds)`.
  Precedence busy > waiting > done. App.tsx:5349 project rollup lights only on t1.
  Dot rendered at App.tsx:5283 (nav row) and 6013 (home Resume list) — one derivation.
- Completion source: lib.rs `completion_edges` (dwell 2 ticks) → `stamp_worked`
  (monotonic max into `.worktrees.places.json`) → emit `sessions:done {path, epoch}`.
  Startup backfill from history within `BACKFILL_WINDOW_SECS` (12h).
- "Looked at" signals available:
  - `selectPlace` (App.tsx:4028) — CONTRACT: stamps NOTHING. Arrow keys / clicks.
  - `enterPlace` (App.tsx:4051) — `touch_place` stamps `last_opened_epoch`.
  - `pageVisible` (App.tsx:1841) — WKWebView visibilitychange works (CLAUDE.md).
  - `sel` (App.tsx:2722) — currently selected {repo, slug}.
- Store: `Declared` (store.rs:50/61) has `last_opened_epoch`, `last_worked_epoch`,
  both `skip_serializing_if None`, lenient read. A new optional key is cheap and
  survives restarts. ui-state.json alternative is frontend whole-blob.

## Why "opened < worked ⇒ unread" is WRONG as-is
The common case: David is sitting IN the place while Claude works. `last_opened`
was stamped on enter, before the completion, so opened < worked even though he
watched it finish. The ack has to be "the completion was PRESENTED": place
selected AND window visible at/after completion time.

## Options (rendering)
A. **Freeze the decay until seen** (David's idea). Unread ⇒ tier 1 (ring, full)
   regardless of age; once seen ⇒ decay by REAL age (a 3h-old completion seen now
   drops straight to its real tier, no clock restart). No new vocabulary; the
   ring already means "go look" and the folder rollup already keys off t1, so an
   unread child keeps the project lit for free. Open question: does unread
   outlive the horizon? Recommend YES (mail semantics) — otherwise "unread" is
   just a longer t1.
B. **Bold the row name** (mail convention) and leave the dot honest about age.
   Strongest conventional signal, independent of the dot slot. Cost: bold widens
   text; must measure truncation at nav width; a second channel to explain.
C. **A distinct unread mark**: hollow vs filled dot, or a tiny count badge. Adds
   vocabulary; hollow-vs-filled is hard to read on 8px.
D. **Grouping/lens**: an "Unread" section on the home Resume list / ⌘K. Good as a
   companion to A, not a replacement (the nav is where the glance happens).
E. **Pulse animation** — rejected by the repo's own rule (reduced-motion freeze;
   afterglow-dot summary line 156).
F. Later: Dock badge count (tauri set_badge), macOS notification when window
   hidden, context-menu "Mark unread" / "Mark all read".

## Options (ack rule)
- Seen when `sel === place && pageVisible` — on completion event, on selection
  change, on visibilitychange. Optional dwell (~1s) so arrowing through the nav
  doesn't ack everything; mail clients ack on select, so dwell is a nicety.
- Also ack on `enterPlace` (it's a stronger "I'm here").
- NOT ack-able: reading the tmux session from another terminal. The app cannot
  see that. Accept and document; `tmux list-clients` polling is overkill.

## Options (where the seen stamp lives)
- Recommend `Declared.last_seen_epoch` in `.worktrees.places.json` beside
  `last_opened_epoch`, via a `mark_seen` command (or `touch_place` variant).
  Write ONLY when `worked > seen` (an unread becomes read) — no write storm on
  clicks, and idempotent. Survives restarts + backfill; CLI `status` can print it.
- Unread derivation: `workedAt(p) > (last_seen_epoch ?? last_opened_epoch ?? 0)`.
  Fallback to `last_opened_epoch` softens the upgrade: only places worked after
  their last enter light up once on first launch.

## Guards to extend
- `app/scripts/afterglow-check.mjs` drives the real afterglow functions — the
  unread rule should live in afterglow.ts (pure) so the check covers it.
- No fake claude: the busy→done→seen path needs the manual sandbox run
  (`app/scripts/sandbox.sh --app`), same as the rest of the afterglow.
