# Progress

## 2026-09-16 session 1
- Restored context: no prior planning files (fresh after /clear).
- Read afterglow.ts, App.tsx dot derivation/rollup/select/enter, lib.rs stamp +
  completion edge, store.rs Declared, ROADMAP + afterglow-dot session notes.
- Wrote findings.md with options A–F and the ack/stamp analysis.
- Presented assessment to David; waiting on a decision before Phase 4.
- David chose: bigger dot + second ring for unread (no bold). Brief written to
  scratchpad; Opus agent implementing on branch ui-changes-unread-afterglow.

## 2026-09-16 session 2 (Opus agent, branch ui-changes-unread-afterglow)
- Implemented the brief end to end: `Declared.last_seen_epoch` + store test,
  `mark_seen` tauri command (read-before-write, forward-only), mock case +
  fixtures (`search-index` UNREAD / new `perf-budget` SEEN; the three other
  worked fixtures gained a seen stamp so their tiers still MEAN t2/t2/t3),
  `seenEpoch`/`isUnread`/`doneTierSeen` in afterglow.ts, App.tsx `seenPaths` +
  `unreadOf` + `ack` + the 1s dwell effect + enterPlace ack + rollup title,
  `.status-dot.done.unread` (10px dot, -1px margin, ::after ring at inset -6px),
  Settings hint line, CHANGELOG, extended afterglow-check.
- afterglow-check shown RED first (23 failures on a flipped `isUnread`, 3 more
  on the two new static mirrors), then green.
- Harness (chromium, port 1477): row heights 43px === 43px, dot column 14px,
  dot centres identical (44px from row left for both), nav-scroll
  scrollWidth 299 === clientWidth 299, ring 22×22 unclipped, 2px gap, ring
  contrast Δmax 67.8–130.2 across six themes on both row backgrounds.
  Ack verified: 300ms pass-through does not write, 1.5s dwell writes exactly
  one `mark_seen`, already-read places write nothing.
- STILL OWED: the real-app sandbox run (busy→done→seen with a live claude).
- Fable reviewed the agent's commit: backend forward-only stamp, pure rule in
  afterglow.ts, dwell effect keyed on primitives, ::after ring — no defects found.
- Rebased onto origin/main (89d27fe; CHANGELOG ordering conflict, kept both).
  Re-ran ALL gates on the rebased tree: bats 335/0, lint 0, core 299, cli 7,
  app lib 48, tsc/check 0, afterglow/zoom/race/dnd/remote/ctxmenu checks green.
- Pushed; PR #211 opened. Merge is David's call. Sandbox (real app) run of the
  busy→done→seen path still owed — no fake claude.
- David: "get latest from main and then merge". Rebased onto 59dc918 (#205),
  all gates green again (core 313 now), force-pushed, waited for CI (9/9 pass),
  squash-merged PR #211 → main 9614a57. Worktree parked on ui-changes-next.
- STILL OWED: real-app sandbox check of busy→done→seen (no fake claude).
