# Task: "unread" completions in the nav (afterglow that waits to be seen)

Started: 2026-09-16. Status: DESIGN — awaiting David's pick of an option.

## Goal
When Claude finishes in a place the user has NOT looked at since, the nav must
say so, and the signal must not decay until it has been seen. Today the purple
dot keys off `last_worked_epoch` only and decays by wall-clock age, whether or
not anyone looked.

## Phases
| # | Phase | Status |
|---|-------|--------|
| 1 | Research current afterglow / open / select paths | complete |
| 2 | Present options + recommendation to David | complete (this session) |
| 3 | Decide: seen-stamp location, ack rule, rendering | complete |
| 4 | Implement backend stamp (`last_seen_epoch`, `mark_seen` cmd, mock) | complete |
| 5 | Implement frontend: unread derivation, dot/rollup, ack on select+visible | complete |
| 6 | Guard: extend `afterglow-check.mjs` (done, shown red-first); manual sandbox run still owed | partial |
| 7 | Gates + PR | complete — PR #211 squash-merged as 9614a57 |

## Decisions
- (open) see findings.md "Options" — recommendation is Option A + declared-store stamp.

## Errors Encountered
| Error | Attempt | Resolution |
|-------|---------|------------|
| none | | |

## Decision (2026-09-16, David)
- Rendering: unread = BIGGER dot + a SECOND ring around it, held at tier 1 until
  seen; then decays by real age. Bold name rejected ("not clear enough").
- Unread outlives the horizon (assumed; mail semantics).
- Ack: place selected + window visible, after a ~1s dwell; enter acks at once.
- Stamp: `Declared.last_seen_epoch` in the declared store via `mark_seen`.
- Phase 4–6 delegated to an Opus agent from a written brief; fable reviews.
