# Investigate: "NotAllowedError" toast in the app

## What David saw
An error toast in the worktrees app (v0.33.0, WKWebView), screenshot at
`_tmp/Screenshot 2026-09-29 at 19.41.06.png` (read it):
"NotAllowedError: The request is not allowed by the user agent or the platform in the
current context, possibly because the user denied permission."
He wants to know what caused it. It is a WebKit DOMException, raised by a
permission/user-activation-gated web API — e.g. `navigator.clipboard.*`,
`Notification.requestPermission`/`new Notification`, `HTMLMediaElement.play()`,
fullscreen, `window.open` — called without a user gesture or with permission denied.

## Evidence already found (verify, don't trust)
App log `~/Library/Logs/net.casadelvalle.worktrees/app.log` (timestamps are UTC):
- `2026-09-30 00:39:25Z [error] ui: NotAllowedError: …` — immediately preceded by
  `00:39:03Z drafts: 1 (1 queued)` and `00:39:19Z drafts: 1 (0 queued)`.
- Also `2026-09-27 01:09:41Z` and `01:09:49Z`, right after `01:08:20Z drafts: 1 (1
  queued)` … `01:08:35Z drafts: 0 (0 queued)`. So it pre-dates pi (v0.33.0) — do not
  assume pi is involved.
- The window flapped hidden/visible and went fullscreen around 00:39:30–36.
At that moment David was working in the `valleos` project (a pi lane `todo-first` was
running there; Claude sessions in other places).

## Task
1. Find every call site in `app/src` of a gated web API (clipboard read/write,
   Notification, audio/media play, fullscreen, open, share, etc.) and how errors reach
   the toast (`fail()` → `ui:` log line). Find what the "drafts" feature is and what it
   does when a queued draft is delivered — the timing correlation is the lead.
2. Determine the exact trigger: which call, under which condition (no user activation
   because it runs from a timer/async continuation/visibilitychange, window not focused,
   permission not granted). Reproduce if you can — the mock harness (`pnpm dev:mock` on
   a port ≠ 1420) in a real browser, or headless Playwright WebKit (AGENTS.md: WebKit
   differs from Chrome — measure in WebKit). Do NOT drive David's running app, by name,
   AppleScript or keystrokes. The sandbox app only by PID, only if unavoidable.
3. Write up the cause with evidence (file:line, the gesture/permission rule it breaks,
   the repro). Then fix it if the fix is clear and contained: the call must either run
   inside a user gesture, or degrade silently/with a clear message instead of a raw
   DOMException toast. New test/check shown failing first. Gates per AGENTS.md
   (grep-reported), CHANGELOG `### Fixed` under `## [Unreleased]` with a bold lead
   (exactly one `[Unreleased]`, one of each `###`). Open a PR, watch CI with
   `gh run watch <id> --exit-status`, report, and STOP. If the fix is NOT clear, open no
   PR — report the findings and options and stop.

## Rules
- Codex is out of tokens: no Codex sessions.
- Another lane (`pi-phase3`) is editing `crates/worktrees-cli/src/mcp.rs`,
  `harness.rs`, `pi.rs` and app pi surfaces — stay out of those unless the cause is
  there, and say so if it is.
- Scratch in `~/.cache/worktrees/worktrees/<this worktree>/`. Keep Co-Authored-By; NO
  session URLs or Claude-Session trailers. Do not merge.
