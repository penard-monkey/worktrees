# Progress
## Session 2026-09-18
- Created planning files. Starting Phase 1 (map existing surfaces).
- Phases 1-3 complete. Verified Claude Code v2.1.276's @-mention machinery by
  strings(1) over the binary: MCP resources ARE a completion source, are fuzzy
  ranked, and are EXPANDED (resources/read inlined) on submit. Wrote the
  recommendation into findings.md. Next: fable review.
- Fable review received and VERIFIED item by item against the binary + source.
  Confirmed: slugify (ops.rs:22), menu charset regex, resourceLists invalidation
  on reconnect, mcp.rs tests bypass the stdin loop, capabilities.resources adds
  2 model tools, the "Do NOT read this resource again" framing, tmux pane0,
  TermSurface sharing .term-wrap, mock term_write returns null, profile.rs
  hardcodes "worktrees", set_note ungated, place_status = full ls() fan-out.
  Settled fable's one open item from code (C-F9: absolute-path mentions allowed
  by default; user's permissions are {}). Found C-F8 independently: the file
  mention extractor has a QUOTED form, the resource extractor does not.
  Recommendation REVISED — the two producers should NOT share a token.
- Designed the freshness mechanism. Verified: no periodic MCP ping from the
  client (so a thread is required, piggyback is not viable); handle_line already
  swallows notifications correctly (mcp.rs:135); worktree_list() is ONE git call
  (project.rs:95), which is what makes a cheap resources/list possible;
  worktree_dirs() is non-recursive (project.rs:111), which is what makes the
  poll signal immune to in-worktree file churn.

## Build (Part A: MCP resources + freshness)
Changed: `crates/worktrees-core/src/{model.rs,project.rs}` (new `PlaceRef` +
`Project::place_index`), `crates/worktrees-cli/src/mcp.rs`, and a new
`scripts/mcp-resources-check.py`. No frontend files touched.

Gates, all green:
- `cargo build --release -p worktrees-cli`, then asserted the binary is newer
  than mcp.rs before believing any result.
- `make test` → exit 0, `1..335`, 335 ok / 0 not ok (counted both halves).
- `make lint` → clean. `cargo test -p worktrees-core` → 315 passed.
  `cargo test -p worktrees-cli` → 11 passed. `cargo test -p app --lib` → 48
  passed. `cargo check -p app` → clean.
- tsc NOT run and not applicable: `git status` shows only three .rs files plus
  the new script; no TS changed.
- `diff <(~/.local/bin/worktrees ls --json) <(./target/release/worktrees ls --json)`
  → byte-identical, so `place_index` did not disturb `ls`.

Fail-first, per CLAUDE.md — five mutations, each went red, then restored green:
dropping the trailing-char trim; dropping the collision dedupe; making the watch
signal notice file mtimes inside a worktree; -32002 → -32602; listChanged
true → false.

`scripts/mcp-resources-check.py` earns its trust the way race-check.mjs does:
green against the new binary, and 8 failed expectations against the shipped
v0.24.0 one.

## Review pass on the build — every item verified before acting
Fable found 9. Confirmed live against the real binary before fixing:
- **`place://wip-2` resolved to the dir `wip-`** (probe output), because the
  naive `-N` suffix could mint a uri that reads as another dir's name — the
  exact first-match trap `uri_map` exists to close. Fixed with a two-pass
  reservation: a slug needing no sanitising always keeps its own name.
- **Non-ASCII slugs collapsed** — `функция` → `place://place`, `日本語` →
  `place://place-2`, renumbering whenever a sibling appeared. Both client rules
  admit these MID-uri; only the trailing char must be ASCII (JS `\b` is ASCII
  even under `/u`). Now preserved, with a `_` appended when needed.
- **`Place::declared` is `None` from `ls()`** (`project.rs:361`) and `Place` has
  no `note` field, so the note-capping loops were dead code AND the docstring,
  the `FREE_TEXT_MAX` comment and `reading_notes` all described a field the
  model would never see. Deleted the dead loops; capped what is actually
  present and attacker-influenced (`branch`, `upstream`, `last_commit_subject`,
  agent names); rewrote the claims to say what is true, including WHY `note` is
  deliberately absent.
- **`read_resource` was still the full `ls()` fan-out per mention** — C-F11 from
  my own design, unimplemented. Added `Project::place_one(&PlaceRef)`, which
  takes the ref so the caller's `place_index()` is not repeated as a second
  `git worktree list`.
- **The check script's push assertion was satisfiable by a notification it did
  not cause** — the deferred pre-handshake one. Now drained and asserted first
  (which pins "a change mid-handshake is not lost"), so only `beta` can satisfy
  the push. Proven: a mutated fire-once watcher now FAILS that line and passed
  before.
- Also: `-32602` for a malformed/missing uri (`-32002` described a lookup that
  never ran); the `PlaceRef` doc block was merging with `Stray`'s in rustdoc;
  the description no longer invents the word "active" for a lifecycle it did
  not compute.
- Wired `make test-mcp` into `check`; added the CHANGELOG `[Unreleased]` entry
  and a manual-check section for the `@` picker.

Fail-first for the three new assertions: naive single-pass `uri_map`,
ASCII-only charset, and `-32602` → `unwrap_or_default` each went red, then green.

One review item NOT taken: fable called the check script "not shown to fail".
It was — 8 failed expectations against the shipped v0.24.0 binary. The fair part
of that item (not wired into a gate) is fixed.

## Pre-merge review round (fable, third pass)
Verified each finding before acting, as before.
- **The debug log was 100% test pollution.** Measured: 11 lines, 7 `repo=repo`
  (the check script's fixture) and 4 `repo=wt-mcp-caps-<pid>` (a unit test);
  zero real sessions. `test/mcp.bats` drives the real binary with the real HOME,
  so `make test` added more, in CI too — and ROADMAP tells whoever removes this
  to READ the log first. `dlog` now returns early under `cfg!(test)`, bats sets
  `WORKTREES_MCP_DEBUG=0`, and the check script points the log at its own
  tempdir and ASSERTS its contents — pollution turned into the only coverage
  that path had. Quantified both ways: 4 lines without the mute, 0 with it, and
  a full `make test` now leaves it at 0.
- **Date bomb → version gate.** A date fires on whatever unrelated PR is open
  that morning and PASSES SILENTLY on a runner with no `date`. Now gated on the
  workspace version reaching 0.26.0, which fires in the release-bump PR. Writing
  it surfaced its own trap: `"0.9.0" < "0.26.0"` is FALSE lexicographically, so
  the obvious string compare would have stopped firing past minor 9 — parsed
  numerically, with a test pinning exactly that.
- **`eprintln!` panics on EPIPE** (Rust ignores SIGPIPE) and that one ran on
  every launch, so a client piping stderr and closing it would kill the server
  at startup. Now `let _ = writeln!(stderr, …)`.
- `MALFORMED params=` logged the whole model-supplied blob (up to the 8 MiB line
  cap) — clipped. `agents[].tmux` capped alongside `name`.
- Doc corrections: the reminder fires at a version, not "2026-12-15" (which was
  also off by one — `<=` fires on the 16th); manual-check step 3's `(main)` →
  `place://main` is only true when no worktree is named `main`.
- Process: fable was right that "every new test was shown to fail" had not
  covered the two debug-log tests. All of them have now been shown red — the
  version gate, the numeric compare, the rotation, the empty-override, and the
  pollution mute. One of those mutations found a WORTHLESS assertion of mine
  (`is_some()` on the empty-override case, true either way); it now compares
  against the default path and fails when the guard is removed.
