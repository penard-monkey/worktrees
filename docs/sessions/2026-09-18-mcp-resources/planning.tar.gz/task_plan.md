# Task plan — drag/drop + autocomplete worktree references

## Goal
Let a Claude session reference ANOTHER worktree by name, two ways:
1. **Drag & drop** a place row from the app's nav into a terminal/chat → the
   session gets an unambiguous reference ("bug-fixes") it can resolve via MCP.
2. **Autocomplete** — typing `@wt` / `wt:` offers a picker of worktrees to
   insert a reference.

Research + design only in this phase. Decide feasibility, pick a mechanism,
write it up. No product code until the design is agreed.

## Phases
| # | Phase | Status |
|---|-------|--------|
| 1 | Map the existing surfaces | complete |
| 2 | Enumerate mechanisms for the DROP | complete |
| 3 | Enumerate mechanisms for the AUTOCOMPLETE | complete |
| 4 | Verify the hard constraints | partial — binary-verified; claude-side manual gate outstanding |
| 5 | Write findings + recommendation; fable review | complete |

## Build phases (added after the design was agreed)
| # | Phase | Status |
|---|-------|--------|
| 6 | `safe_uri_part` + `uri_map` collision rule (C-F6) | complete |
| 7 | `resources/list` + `resources/read`, `-32002` on unknown | complete |
| 8 | Watcher thread + `emit()` + `ready` flag + `listChanged` | complete |
| 9 | Tests (4 new), each shown to FAIL first | complete |
| 10 | Gates all green; fable review | in_progress |

## Scope
Part A only (MCP resources + freshness). The drag/path-mention half is NOT in
this build — see the revised recommendation in findings.md.
