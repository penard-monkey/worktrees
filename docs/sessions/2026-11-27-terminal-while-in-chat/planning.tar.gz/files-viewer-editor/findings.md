# Files viewer → the document editor: phase 1 findings (2026-11-27)

Read on ff78c38e: `app/src/FilesPane.tsx` (SourceEditor, FileView, the draft
store), `app/src/doc/` (EditorHost, editor.ts, editortypes, loadeditor,
ideatext, ideasave, useDoc, DocumentPane, source, memory), `write_file` /
`read_file` in `crates/worktrees-api/src/files.rs`, the mock's `write_file`,
and the checks that read FilesPane.

## 1. What each side has

The document editor gives, over the textarea:
- Real undo/redo history (`history()`), with no `execCommand` workaround.
- Markdown highlighting (stage 1: headings sized, markers dimmed but shown).
- **Byte-exact line endings.** `lineBreakOf` + `EditorState.lineSeparator`
  + `savedText` keep a CRLF file CRLF, and text a person inserts takes the
  file's ending. By the HTML spec a textarea's `value` normalizes CRLF and
  CR to LF, so **today a CRLF markdown file comes back LF on its first ⌘S
  in Files** (whole-file churn in git). Not yet measured: phase 2's first
  test must show it red against the textarea.
- No autofocus unless asked (`open.focus` / `cursorNext`), which is what
  Files needs. Its keys stay in the editor: a defaultPrevented keydown stops
  at the host, so ⌘[ / ⌃B do not reach the window's chords.
- A lazy chunk behind `loadeditor.ts`, with a "could not be loaded" state.

What the Files path does that EditorHost/useDoc do NOT:
| Files path | Document pane |
|---|---|
| Explicit ⌘S / Save button; nothing is written until you save | Autosaves 800 ms after a pause, and on blur, hide and leave (`Session`) |
| `write_file` CAS on the mtime the edit STARTED from; a refusal shows "save refused" and an **Overwrite** button (`expectedMtime: null`) as a separate click | A refusal is a `conflict` banner with "Keep mine" (re-reads, then writes with `keepHistory`, which `write_file` lacks) and "Reload theirs" |
| `unsaved` tag + Discard | "Edited / Saving… / Saved" state word |
| Formatting bar (`MD_TOOLS` → `mdedit.applyMd`), ⌘B / ⌘I | none |
| Wrap on/off (`files_wrap`) | always `lineWrapping` |
| mono font, terminal size, full width | prose font, 46rem column, 40vh bottom padding |
| ⌘F: an open Find swaps in the read-only `CodeBlock` of the DRAFT (CSS Highlight API cannot paint in a textarea) | no find. `@codemirror/search` is not installed, and adding it would be a new dependency |
| `reloadToken` re-reads the BASELINE only; the draft stays on top, untouched | `watch()` events → `Session.external` → reload when clean, conflict when dirty |
| ONE draft per absolute path, module scope, shared by the dock's viewer AND the reading overlay (both mounted at once, App.tsx 11686 / 11785) | one Session per pane |
| Truncated (1 MiB) or binary reads are never editable | n/a |
| `--md-zoom` | only on Preview, never on Source, so the editor does not need it |
| scroll keeping | `useScrollKeep` only covers the `.scroll` views; the textarea is its own scroller and keeps nothing across a remount today |

## 2. Can EditorHost be reused as is? No: two small changes are needed, and the save layer must NOT be reused

- **`ideaState` always installs the frontmatter `guard`.** It makes the
  opening `---`, an `id:` line and the closing `---` read-only. Any
  ordinary markdown file with YAML frontmatter (SKILL.md, a docs page) would
  have uneditable lines in Files. `mountEditor` needs an option:
  `{ guard: false }` for Files, and probably `{ look: "source", wrap }`
  (mono font, full width, wrap toggle). That is editor.ts's API, still
  imported only by loadeditor.ts: **the boundary rule does not change.**
- The line-ending rules (`lineBreakOf`, `normalizeInserted`, `savedText`)
  are exactly what Files needs, and they are not idea-specific. Keep them.
- **CodeMirror's defaultKeymap binds Mod-i to selectParentSyntax** (from the
  CM6 docs; I could not grep it because this tree has no node_modules yet).
  The Files variant needs its own Prec.high Mod-b / Mod-i / Mod-s, and ⌘S
  must still reach `onSave` (menu-check holds a regex on FilesPane for it).
- `EditorHost`'s props are typed on `Open` but it reads only `key` and
  `focus`. Narrow it to `Pick<Open, "key" | "focus">`, a type-only change.
- `useDoc` + `Session` + `DocumentPane`: **do not reuse.** They autosave,
  their conflict recovery is "Keep mine" with history, and their change
  feed is a source's `watch`. Taking them would change the Files contract
  (an explicit save, Overwrite as its own click) and would need an owner
  decision. The plan keeps FileView's draft store, `save`, Discard and
  Overwrite as they are, and swaps only the textarea for EditorHost.
- The double mount is the hard part. Today both views render the one draft
  from the store. With CodeMirror each view holds its own state, so the
  focused editor must write `text()` into the store on every edit, and the
  other must `replace()` when the store moves under it. `replace` is a new
  state, so the hidden view loses its undo history. That is acceptable, and
  only that view loses it.
- `selection()` returns offsets into `text()`, where CRLF counts 2, while
  `insert(from, to)` takes editor positions, where CRLF counts 1. The
  formatting bar must use editor positions throughout. A new `DocEditor`
  method is cleanest (`edit(fn: (text, start, end) => {text,start,end})` in
  positions, applied as one minimal change through `spliceRange`).

Pre-existing, in both editors, not this lane's to fix (ROADMAP candidates):
- `read_file` decodes with `from_utf8_lossy`, so a non-UTF-8 markdown file is
  editable and its save writes U+FFFD over the bad bytes. The fix is a
  `lossy` flag that makes it read-only.
- `read_file` stats the mtime AFTER reading the bytes. A write in between
  gives a base mtime newer than the text, and the CAS would then pass a
  stale save.
- `write_file`'s CAS is mtime-only. The ideas got `rev` for two saves in
  one millisecond (#719); files did not.

## 3. Scope: recommend markdown only for now

Other text files would get only the editor and no highlighting:
`codeLanguages: []`, and only the markdown grammar is installed. So a .rs
file would lose CodeBlock's highlighting and gutter the moment it became
editable, which is the very trade the header refused. Doing it right means
@codemirror/lang-* packages, or a bridge from `highlight.ts` to CM
decorations, plus a gutter (`lineNumbers` from @codemirror/view, which is
already installed). Cost: about 2 to 4 days, plus new dependencies or a
highlighter port, plus a find story (@codemirror/search, a dependency).
Recommendation: markdown first, and offer "plain text files (.txt, .toml,
.json…) with no highlighting" as a later, separate yes.

## 4. Checks that pin today's behaviour

- `mdedit-check.mjs`: evaluates FilesPane verbatim under React/DOM stubs. It
  renders `SourceEditor` and asserts a `<textarea>` (wrap attribute, ⌘S, ⌥,
  toolbar pointerdown, the execCommand splice). Rules 1 to 6 (truncated,
  base mtime + re-base, in-flight keystroke, Overwrite only after a refusal,
  one draft across two views, Find falls back to the draft) stay valid and
  must keep passing. Rules 7, 9 and 10 are textarea-specific and get
  rewritten against the new editor seam (a stubbed `DocEditor`). The stub
  harness would need EditorHost/loadeditor stubbed, since it cannot run
  CodeMirror.
- `menu-check.mjs`: a regex on FilesPane for `k === "s") { e.preventDefault();
  e.stopPropagation(); onSave();`. It must find the new ⌘S, or be updated in
  step.
- `scrollkeep-check.mjs`: slices FileView, covering the `.scroll` views (stub
  read clamp). It is unaffected if the editing branch stays outside `.scroll`.
  It should not be asked to cover CM.
- `usage-check.mjs`: `files.fmt.*`, `files.save`, `files.discard`,
  `files.overwrite` data-track keys. Keep them.
- `editor-boundary-check.mjs`: passes unchanged if FilesPane imports only
  `./doc/EditorHost` (which imports loadeditor). The bundle half needs
  `pnpm build`. Watch that EditorHost reaching FilesPane does not make the
  editor chunk static.
- `ideas-text-check.mjs`: drives `textExtensions` under node. Add the
  `guard: false` variant there, plus a frontmatter file edited freely.
- Mock `write_file`: CAS mirrored already, no change.
- Browser: `ideas-browser.mjs` / `documents-browser.mjs` drive the editor in
  Chromium + WebKit. A new `files-editor-browser.mjs` should cover
  type → ⌘S → bytes, CRLF, refusal → Overwrite, and two views on one draft.

## 5. Plan

1. Install (`git submodule update`, `nvm use`, `corepack pnpm install`). Then
   write the CRLF test and SHOW it red on the textarea (mock + Playwright
   WebKit: open a CRLF .md, type, ⌘S, compare bytes).
2. editor.ts: `mountEditor(parent, hooks, opts?)` with `guard` (default true)
   and `look: "doc" | "source"` + `wrap`. Ideas pass nothing and are
   unchanged. Extend ideas-text-check for `guard: false`.
3. editortypes / editor.ts: `edit(fn)` for the formatting bar in editor
   positions, as one minimal change (undo-able); Mod-b / Mod-i keymap hooks;
   Mod-s → `hooks.save?.()`.
4. EditorHost: narrow `open` to `{key, focus}`. Let it take `opts`, with a
   per-variant class and testid (`files-editor`), because `ix-editor` is
   `position: absolute; inset: 0`, which fits the viewer body only if that
   body is positioned.
5. **(risky)** FileView: replace `SourceEditor`'s textarea with EditorHost.
   The `held` text comes from `draft?.text ?? read.content`. `edited` →
   `putDraft` (the same `onEdit` rule: typed back to the disk text clears
   it). Store moves from the OTHER view → `replace()`. A new read while
   clean → `replace()`, keeping the caret, and the scroll position is
   checked in WebKit, since `setState` may reset it. Keep `save`, Discard,
   Overwrite, the `unsaved` / `save refused` tags and the Find fallback
   exactly as they are.
6. **(risky)** Formatting bar → `edit(applyMd)`, keeping caret and selection
   behaviour and the toolbar's preventDefault on pointerdown. Map
   `mdedit`'s offsets to editor positions on CRLF files.
7. Checks: rework mdedit-check rules 7/9/10 against a stubbed editor and show
   each new rule red on the old file. Update menu-check's regex only if ⌘S
   moves. Add files-editor-browser.mjs (Chromium + WebKit).
8. Gates: tsc, every `*-check.mjs` from the repo root, `pnpm build` then
   editor-boundary-check. Then the FilesPane header comment, CHANGELOG
   `[Unreleased]`, and a commit.

Risky: step 5 (two live views over one draft; a reload under a clean editor
keeping its place in WebKit) and step 6 (the CRLF offset mapping). Step 2
touches every idea's editor, but only behind a default that keeps it as it
is.
Size: about 1.5 to 2.5 days. It is not "reuse as is": EditorHost needs two
small API additions, and the save layer stays Files' own.

## Phase 2 hold (2026-11-27): the measurements asked for

**CRLF loss: real, measured.** I ran it in the mock harness (vite on :1491, Playwright 1.63, Chromium and WebKit). I wrote `"# Title\r\n\r\nOne line.\r\nTwo line.\r\n"` with `__mock.editFile`, opened README.md in Files → Source, typed `x` at the end, pressed ⌘S, and read the result back with `read_file`.
- Both engines saved `"# Title\n\nOne line.\nTwo line.\nx"`: every `\r\n` became `\n`.
- The probe is `~/.cache/worktrees/worktrees/files-viewer-editor/crlf-probe.mjs` (`PLAYWRIGHT_MODULE=… URL=http://localhost:1491 node crlf-probe.mjs`).

There is a second, smaller bug on the same path. `onEdit` clears the draft when the text is typed back to `read.content`. A CRLF file's textarea value never equals its CRLF content, so after any edit "unsaved" can never clear by undoing it.

**Keymap: confirmed, against the installed packages.**
- `@codemirror/commands` 6.11.1's `defaultKeymap` binds `{ key: "Mod-i", run: selectParentSyntax, preventDefault: true }`.
- Nothing in commands, view, language, lang-markdown or state binds `Mod-b`.
- So in CodeMirror ⌘I would select the parent syntax node and never reach a bold/italic handler. ⌘B would pass through to the window's sidebar chord, unless the Files wrapper takes both first (a React `onKeyDownCapture` runs before CM's contentDOM listener).

**Double mount: measured.** With Files → Source open and Expand pressed, there are 2 `.viewer` and 2 `.srcedit` mounted at once in both engines. The dock's copy stays laid out under the overlay.

**Smallest fix that keeps the textarea.**
- Name the file's separator on read with `lineBreakOf`. It is pure, in `doc/ideatext.ts`, and importing it from FilesPane does not touch the editor boundary.
- Give the textarea the LF form, and compare drafts against it. The `onEdit` "typed back to disk" test then uses `toLF(read.content)`, which fixes the second bug as well.
- In `save`, send `sep === "\r\n" ? draft.replace(/\n/g, "\r\n") : draft`. Adopt that converted string as the new `read.content`.
- A file a textarea cannot round-trip at all is excluded from `editable` the way `truncated` is, with a tag saying why. That is a lone `\r`, or a mix of CRLF and LF lines: `lineBreakOf` answers `\n` for them, and the textarea would still rewrite their `\r`. The test is `content.includes("\r") && lineBreakOf(content) === "\n"`.

Cost: about 15 lines in FilesPane, plus a new mdedit-check rule run against the real file. The rule: a CRLF read saves CRLF, a mixed one is not editable, and typing back clears the draft. It goes red on today's file. Add the probe above as a browser check in both engines.

Nothing was changed in the repository for the swap: `git status` is clean, and nothing is committed.
