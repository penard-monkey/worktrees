# Files viewer: use the document editor we added for ideas and plans

Briefed by the place `terminal-while-in-chat` (tmux session `worktrees-terminal-while-in-chat`), on the owner's ask of 2026-11-27. Report back there with `SendMessage` when you stop.

## The owner's words

> "the files viewer isn't using the new editor we added for ideas and plans. We should look into that. That can be its own lane."

## What is true today (checked on main at ff78c38e)

- The dock's Files tab (`app/src/FilesPane.tsx`) edits ONE kind of file: a markdown file's Source view, in a plain `<textarea class="srcedit">` (around line 698) with a hand-made formatting bar (`MD_TOOLS`, `spliceRange`, `document.execCommand`), saved with ⌘S through `write_file`, whose compare-and-swap on mtime keeps it from overwriting what an agent just wrote. The file's header comment (lines 1-22) explains why it was a textarea: no editor library was admitted then.
- Since then CodeMirror 6 was admitted into the main app (AGENTS.md, "CodeMirror 6 is the THIRD admitted exception", owner's decision of 2026-11-24). It is imported by ONE module, `app/src/doc/editor.ts`, reached only through `app/src/doc/loadeditor.ts`'s dynamic import; `app/src/doc/EditorHost.tsx` is the React host that ideas, plans and a workspace's memory use. `app/scripts/editor-boundary-check.mjs` holds the boundary.
- So the Files viewer and the document pane are two editors for markdown, and the Files one is the older, weaker one.

## Goal

A markdown file edited in the Files viewer (dock, and the full-pane reader `FileView` with `expanded`) uses the same editor as ideas and plans, through `EditorHost` / `loadeditor.ts`, and keeps everything the textarea path guarantees today.

## Phase 1: look, then report (stop here first)

Read `FilesPane.tsx`'s editing path end to end, and `app/src/doc/` (EditorHost, editor.ts, loadeditor.ts, ideatext.ts and whatever the document pane wraps around them: save, conflict, draft handling). Then write `.planning/findings.md` and send me a short report that answers:

1. What does the document editor give that the textarea lacks, and what does the textarea path do that the document editor's host does not (the mtime compare-and-swap and its "overwrite anyway" second click, the dirty marker, ⌘S, the formatting bar, wrap on/off, `--md-zoom`, ⌘F find, scroll keeping across a reload, `reloadToken` re-reads while an agent writes the file, no autofocus so the terminal keeps focus)?
2. Can `EditorHost` be reused as is, or does it assume an idea/plan document (its save path, its line-ending and protected-range rules in `ideatext.ts`)? Line endings matter: a file on disk must stay byte-for-byte what was typed, CRLF files included.
3. Should the scope stay "markdown only", or should other text files become editable now that there is a real editor? Give a recommendation and its cost; do NOT build past markdown without the owner's yes.
4. Which checks pin the current behaviour (`app/scripts/*-check.mjs` that slice `FilesPane.tsx`, `scrollkeep-check.mjs`, `editor-boundary-check.mjs`, the mock in `app/src/mock/install.ts`) and what each would need.
5. A plan in steps, with the risky ones named.

Stop after that report and wait for my go. If the answer to (2) is "reuse as is" and the plan is small, say so and I will tell you to continue.

## Phase 2: build (only after my go)

- The editor stays behind `loadeditor.ts`. No new importer of `editor.ts`, no static import of an editor package anywhere; run `node app/scripts/editor-boundary-check.mjs` from the REPO ROOT, and build (`pnpm build` in `app/`) before trusting its bundle assertions.
- Keep the save contract: `write_file` with `expected_mtime`, refusal shown, overwrite as a separate labelled click.
- Every new test or check must be shown to FAIL first against the old code.
- Verify in the mock harness in BOTH Chromium and Playwright WebKit (the app is WKWebView). HMR is dead inside `.worktrees/`: restart vite with `--force` after edits and confirm the served file has your change.
- Update the header comment of `FilesPane.tsx`, and add a CHANGELOG entry under `## [Unreleased]`.

## Rules

- Read `AGENTS.md` first; it is long and most of its traps apply here (the gates list, "Report cargo with a grep", run `*-check.mjs` from the repo root, zsh traps).
- Work only in this place's tree. Do not edit another place's tree; do not touch the user's running app, and never drive an app by name. Any throwaway tmux server uses `tmux -L <unique name>` on every call.
- Run gates and builds as `worktrees run --slot gate -- <cmd>`. First: `git submodule update --init --recursive`, then `nvm use` and `corepack pnpm install` in `app/`.
- Gates before you report done: `cd app && ./node_modules/.bin/tsc --noEmit`, `make -C <repo root> test-frontend` (or every `app/scripts/*-check.mjs` in a loop that does not stop at the first failure), and the Rust gates only if you touched Rust.
- Commit on this branch when a phase is done. Do NOT push, open a PR or merge. Do not edit `AGENTS.md`; put anything worth adding there in your report.
- Plans and notes go in `.planning/` (not committed). Scratch files go in `~/.cache/worktrees/worktrees/files-viewer-editor/`.
- Stop and report when: phase 1 is written; a gate fails for a reason you cannot explain; or the work needs a decision that is the owner's (scope beyond markdown, a change to the editor boundary rule, a new dependency).
