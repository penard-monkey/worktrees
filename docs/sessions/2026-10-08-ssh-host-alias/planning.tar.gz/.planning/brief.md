# Brief: FIX — GitHub remotes that use an SSH host alias

## The bug (found by David)
casa-del-valle-monorepo's origin is `git@github.com-penard-monkey:penard-monkey/casa-del-valle-monorepo.git`
— a standard multi-account setup where `github.com-penard-monkey` is a `Host` alias in `~/.ssh/config`:
`ssh -G github.com-penard-monkey` → `hostname github.com`, `user git`, an `identityfile`. Our remote
parsing takes the alias as the host, so the app builds `https://github.com-penard-monkey/penard-monkey/…`.
That breaks at least: the Pull requests view (#455, `worktrees_core::github::parse_remote` →
`--hostname github.com-penard-monkey`, so the project reads as not-GitHub / unauthenticated) and the
header's remote link (`github::web_base`, `remote.ts`). Find every other consumer of the remote URL too
(grep `remote_url`, `web_base`, `parse_remote`, `normalize`, `remote.ts`, clone.rs).

## Fix shape (recommendation; adjust with evidence and say why)
1. **Resolve SSH host aliases the way ssh does: `ssh -G <host>`** (prints the effective config, never
   connects) and take its `hostname`. Only for SSH-form remotes (scp-like `user@host:path` and
   `ssh://`), never for https. Cache per host per process; bounded timeout; failure → fall back to the
   literal host (today's behaviour), never an error the user sees. Validate the host string before it
   becomes argv (no leading `-`, a conservative charset) — a remote URL is user config, but treat it as
   untrusted input anyway. Read ADR 0001 (`docs/adr/0001-no-repo-supplied-argv.md`) and say in the PR
   why running `ssh -G` on a host from `.git/config` is consistent with it (it names no program and runs
   nothing remote; it is the same lookup git itself does on push).
2. **Also honour git's `url.<base>.insteadOf` / `pushInsteadOf` rewrites**: read the effective URL via
   `git ls-remote --get-url <remote>` (applies insteadOf, no network) rather than the raw config value,
   if that's not already what we do.
3. Keep one place that does this (core), used by both the PR view and the web link; the app must not
   keep a second parser that can drift (if `remote.ts` mirrors the rule, either move the decision to the
   backend or add a drift check).
4. GUI PATH: the app runs with launchd's bare PATH until `fixup_gui_path()`; `ssh` is `/usr/bin/ssh` on
   macOS — make sure it resolves in a Finder-launched app.
5. Enterprise hosts and non-GitHub hosts behind aliases should resolve the same way (an alias to
   `gitlab.com` must end up "not GitHub", an alias to a GHE host must end up that host).

## Tests
- Unit tests with a fake `ssh` (seam like `WORKTREES_GH_BIN`) for: alias → github.com; alias → GHE
  host; alias → gitlab.com; no alias (ssh -G echoes the same host); ssh missing / timeout / garbage;
  hostile host strings refused before argv. Show each red first.
- A real check on this machine is allowed READ-ONLY: `ssh -G github.com-penard-monkey` (it does not
  connect). Do not run `ssh` to connect anywhere and do not touch `~/.ssh`.
- `ls --json` / MCP output unchanged for ordinary remotes (diff against `~/.local/bin/worktrees`).

## Rules
- Read AGENTS.md first. Gates: all of them, `cargo build --release -p worktrees-cli` FIRST. Mock harness
  tracks any command change. CHANGELOG `### Fixed` under `## [Unreleased]` (count headers).
- Never drive David's running app; sandbox by pid only. Any tmux probe: `tmux -L <unique>` on EVERY call.
- Never `git worktree add`. Never edit other projects' trees (read-only `git -C … remote -v` is fine).
  Scratch → `~/.cache/worktrees/worktrees/ssh-host-alias/`.
- No session URLs / Claude-Session trailers; keep Co-Authored-By.
- Open a PR, message `(main)` with the number and gates. Don't merge — a fable review runs first.
