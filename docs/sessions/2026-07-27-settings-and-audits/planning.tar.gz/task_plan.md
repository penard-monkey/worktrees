# Task Plan: Settings pane evaluation & improvement proposal

## Goal
Evaluate the current SettingsSheet options; propose which settings to add,
change, or deliberately omit. Deliverable = evaluation + tiered recommendation
(discussion first, implementation later).

## Current state (baseline)
Settings type (app/src/settings.ts): ui_rem, term_family, term_size, theme,
density, window_w/h, nav_width, nav_collapsed, editor_cmd, lens, collapsed,
hidden_tiers, sort_mode/dir, manual_order, last_seen_version.
Pane sections (SettingsSheet.tsx): UI font, Terminal font/size, Editor cmd,
Theme, Density, Version+updates, Nav tiers, Logs, Window default.

## Phases
| # | Phase | Status |
|---|-------|--------|
| 1 | Restore context / survey settings code | complete |
| 2 | Workflow: parallel deep-read (App.tsx+TerminalPane, backend lib.rs+core, docs/philosophy, UX-comparables) | complete |
| 3 | Workflow: propose candidates via 3 lenses (minimalist / power-user / maintainer), synthesize | complete |
| 4 | Write evaluation to findings.md; present tiered recommendation | complete |
| 5 | Ctx-menu audit (user request): verify every right-click nav item end-to-end + live mock-harness run + settings tie-in | complete |
| 6 | PR1 `fix/menu-defects`: window_w/h cut, ⌘, handler, up_cmd delete, remove-project arm (both surfaces + vanish-branch fix), topbar arm leak, copyText .catch(fail) | complete — merged #41 (c00c8ca) |
| 7 | PR2 `feat/settings-tier-a`: ai-auto-resume, app-shortcuts (⌘1..N+⌘E+cheatsheet), reset-and-reveal Data section (reshow-whats-new DROPPED — shipped upstream #40) | complete — merged #42 (d0eebac) |
| 8 | PR3 `fix/silent-failures`: silent-launch-failure, foreign-session-reuse, create-selection-mismatch (slug in CmdResult), git-stderr capture | complete — merged #43 (610febb) after 1 review round (main false-adoption blocker fixed) |
| 9 | PR4 `feat/behavior-settings`: update-auto-check, restore-last-place (selection-only), external-terminal-command + open_editor sh -c retrofit | complete — merged #45 (a70e746); review fixed restore-latch guard order |
| 10 | PR5 `feat/auto-fetch`: background auto-fetch (Off/5/15/60, watcher thread, hang-hardened) + "Fetch origin" project ctx verb | complete — merged #46 (8f26010); review clean |
| 11 | PR6 `feat/remove-branch-diag-ai`: remove+branch armed pair (both surfaces, mock dirty-refusal), copy-diagnostics, ai-command phase 1 (read-only + reveal config) | complete — merged #47 (e4b5bcf); review: tuple order verified, comment fix |

| 12 | Busy-dot investigation — DIAGNOSED: dot reads tmux session_activity (=attach/keypress, NOT output), decays while Claude works. FIX: read ~/.claude/sessions/*.json probe files (status busy/waiting/idle, keyed by cwd→worktree). Both empirically verified live (CC 2.1.220). Full design in findings.md. Verdict agent died on Fable limit; Opus finished synthesis. | complete |

| 13 | PR7 `fix/busy-dot-claude-state`: dot reads ~/.claude/sessions/*.json (pid-alive guard, status busy→green blink / waiting→amber static), keyed by cwd→p.path; remove tmux session_activity source | complete — merged #49 (40a9f73) + changelog #50 (4549e43) |
| 14 | RELEASE v0.3.1: roll [Unreleased]→[0.3.1], bump 0.3.0→0.3.1, gates green, merged #51 (7d5495c), tag v0.3.1 pushed, release.yml run 30313393253 queued (watching bg) | complete pending workflow |

| 15 | PR8 `feat/quick-switch`: ⌘K command palette — fuzzy jump to any place across all projects; module-scope, frontend-only, enterPlace action, ArrowU/D+Enter+Esc, busy/waiting dots, works rail-only | complete — merged #52 (99a6326) |

## DECISIONS: global-summon-hotkey → DEFERRED to v0.3.2 (user, not now).
## v0.3.2 will bundle: ⌘K switcher (already on main) + global summon hotkey.

## TIER B COMPLETE — all 6 PRs merged (#41-#43, #45-#47). v0.3.0 + v0.3.1 RELEASED.
Worktree on fresh `settings-next` off origin/main. Remaining backlog
(findings.md): Tier C on-demand, ~35 ux-gap/polish, ⌘K palette,
origin/HEAD base detection, mock fault-injection, ai-command phase 2.

## Tier B scope notes
- system-theme-pair: DROPPED (shipped upstream #38).
- ai-command: phase 1 only; editable field + core cfg_set writer deferred.
- auto-fetch default Off; first background network actor — GIT_TERMINAL_PROMPT=0,
  ssh BatchMode, deadline, no overlap, applog (not banner) for errors.

## Execution rules (user, 2026-07-27)
- Implementation by OPUS agents (save fable tokens); fable does quick review
  before each merge. Squash-merge per repo convention.
- Gates before each PR (repo CLAUDE.md): cargo build --release -p
  worktrees-cli FIRST, make test, make lint, cargo test -p worktrees-core,
  app tsc --noEmit + cargo check -p app.

## Decisions
- Deliverable is assessment/proposal, not code (user said "think through / evaluate").
- Ultracode on → workflow orchestration for phases 2–3.
- FINAL: 21 verified candidates — A=4, B=8, C=3, omit=6 — plus 3 cuts
  (dead window_w/h, dead up_cmd, remove-project confirm fix) and 2
  feature-not-setting builds (⌘K palette, origin/HEAD base detection).
  Full report: findings.md.

## Errors Encountered
| Error | Attempt | Resolution |
|-------|---------|------------|
| (none) | | |
