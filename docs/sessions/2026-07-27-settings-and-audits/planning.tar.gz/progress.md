# Progress

## Session 2026-07-27 (settings-pane evaluation)
- Read SettingsSheet.tsx (290 ln) + settings.ts (116 ln). Baseline captured in task_plan.md.
- Launched workflow `settings-pane-eval` (run wf_ae6754ff-2bc):
  Survey (frontend / backend+core / docs / UX-comparables, parallel)
  → Propose (minimalist / power-user / maintainer lenses)
  → Merge (dedup, ≤24 candidates)
  → Verify (per-candidate adversarial check vs codebase, tier A/B/C/omit).
- Script: session workflows dir, `settings-pane-eval-wf_ae6754ff-2bc.js` (resumable).
- Workflow completed (29 agents, ~1.26M subagent tokens): 47 survey seeds →
  21 merged candidates → verified A=4 B=8 C=3 omit=6, plus 3 cut suggestions.
- Full evaluation written to findings.md; recommendation presented to user.
- User: also confirm right-click nav menu functionality before implementing.
- Launched workflow `ctx-menu-audit` (run wf_7804a1e7-195): 8 static chain
  audits + live mock-harness Playwright run + settings tie-in → merge issues
  → adversarial verify per issue. Menu inventory: place menu 14 items
  (App.tsx:948-1000), project menu 6 items (:1003-1019).
- Ctx-menu audit completed (65 agents, ~2.65M tokens, live harness ran with
  screenshots in _audit-shots/): all 20 items work happy-path; 79 raw issues
  → 54 merged → 48 confirmed (9 bug / 13 ux-gap / 26 polish), 6 refuted.
  Full section appended to findings.md.
- Key new: topbar ⋯ arm leak (pre-armed one-click remove), silent tmux
  launch failure, foreign-session adoption invisible, note-focus terminal
  steal, second unguarded remove-project surface (header ✕ :654),
  missing "Fetch origin" verb (settings-plan gap).
- User: implement all 3 PRs; opus agents do the work, fable quick-reviews
  before each squash-merge.
- DRIFT: origin/main moved #35-#40 after audits. reshow-whats-new (#40) and
  system-theme-pair (#38) ALREADY SHIPPED upstream — dropped from plan.
  All audit line refs stale; agents re-locate by grep.
- PR1 fix/menu-defects: opus agent implemented 6 fixes, all gates pass
  (bats 134, lint, core tests, tsc, cargo check). Fable review clean
  (checked arm-key namespacing, ⌘ guard chain, CSS tokens, serde flatten).
  Merged as #41 (c00c8ca). Agent notes: bats submodules needed init;
  pnpm install needed nvm Node v24 (pnpm floor > v22).
- PR2 feat/settings-tier-a: opus agent running (ai-auto-resume,
  ⌘1..N/⌘E shortcuts + cheatsheet, settings_info cmd + Data section w/
  onReset clearing React mirrors).
- PR2 merged #42 (d0eebac): ai_auto_resume (bidirectional ctx override),
  ⌘1 Home/⌘2-4 lenses (reveal-not-toggle via selectLens)/⌘E, cheatsheet,
  settings_info cmd + Data section (reveal + armed reset preserving
  last_seen_version, resets lens/collapsed mirrors). Review: clean; noted
  keydown deps include unmemoized fail (pre-existing churn pattern, ok).
- PR3 fix/silent-failures: opus agent IMPLEMENTED all 4 fixes (working tree,
  NOT committed). All gates green: cargo build --release, make test (134,
  exit 0), make lint, cargo test -p worktrees-core (8, +2 new PaneList tests),
  tsc --noEmit, cargo check -p app.
  Fix1 (loud launch): tmux::new_session→Result<pid,String> (stderr on fail);
    launch()→i32, ui.error+rc1 on new-session fail, "Session ready" only on
    success; propagated through cmd_new/cmd_open + lib.rs (main) branch.
  Fix2 (adopt foreign session): place_json falls back to worktree_session
    when canonical down; PERF: added tmux::PaneList (ONE list-panes -a per
    snapshot, prefetched in ls(), reused per place) — net tmux shell-outs per
    3s refresh UNCHANGED (+1 constant, was 0 adopted lookups; NOT +N).
  Fix3 (slug in CmdResult): Project::resolve_new_slug (pub core helper mirrors
    cmd_new: strip_origin+slugify+holder-reuse); CmdResult.slug Option<String>
    (serde skip-none); new_place resolves pre-op; runCmd now returns CmdResult
    |null; createPlace uses r.slug ?? old-derivation; mock returns slug; both
    TS CmdResult types updated.
  Fix4 (git stderr): git::git_status_captured (success→raw byte passthrough to
    stdout/stderr = byte-identical for bats; fail→Err(stderr)); swapped at 3
    cmd_new worktree-add sites + 3 do_switch sites; switch_fail emits git's
    real reason first. CaptureUi.error already collected → reaches app.log.
- PR3 review round 1 — BLOCKER found + fixed: Fix2's adoption fallback
  false-matched for MAIN (worktree dirs nest under main_root, so
  session_in(main_root,…) prefix-matched every worktree pane → main read UP
  off a worktree's session whenever main was down + any worktree up; would
  attach main's terminal to the wrong session). Patch: session_in gains
  exclude_under param (skips path==excl or under excl/); place_json passes
  Some(wt_root) for is_main; ops::launch same guard when wt==p.main_root via
  new tmux::worktree_session_excluding (worktree_session delegates None —
  close_one unchanged, guarded by slug!="(main)"). +1 unit test (worktree
  pane excluded / genuine main subdir adopts / no-exclusion unchanged /
  .worktrees-backup boundary). All 5 gates re-run green: build, make test
  (134, exit 0), lint, cargo test -p worktrees-core (9), tsc + check -p app.
- PR3 merged #43 (610febb) after review round 2 approved the exclusion patch.
- ALL THREE PRs SHIPPED: #41 menu defects, #42 Tier-A settings, #43 silent
  failures. Remaining backlog lives in findings.md: Tier B (remove-deletes-
  branch as armed actions, background-auto-fetch + Fetch-now verb, external
  terminal cmd, restore-last-place, copy-diagnostics, ai-command phase 1,
  update-auto-check), Tier C, ~35 confirmed ux-gap/polish items, feature
  builds (⌘K palette, origin/HEAD base detection), mock fault-injection.
- Worktree back on branch fix/silent-failures (merged); _audit-shots/ still
  untracked at repo root (new CLAUDE.md says scratch → ~/.cache/worktrees/).
- Session effectively complete; /close-out available when user wants.
- User approved fixing ALL Tier B → phases 9-11 (3 PRs, same opus/fable loop).
  Scope notes: system-theme-pair dropped (upstream #38); ai-command phase 1
  only; auto-fetch default Off + hang-hardening mandatory.
- PR4 feat/behavior-settings merged #45 (a70e746). Review fix (fable, inline):
  restore-latch reordered — restoredOnce now latches at launch regardless of
  toggle, so enabling restore_last mid-session can't yank selection. Agent
  work otherwise clean: update_auto_check in effect deps (pre-hydration timer
  cancel), open_terminal single-quotes {session} via tmux::sq (parens in
  (main)), open_editor → sh -c "$0" policy.
- Upstream drift mid-flight again: #44 (docs-only session archive) landed
  between #43 and #45 — no code overlap, no action.
- PR5 feat/auto-fetch: opus agent running (shared hardened fetch fn,
  AtomicU64 interval + set_fetch_interval sync, watcher pass w/ overlap
  guard, Git section select, fetch_origin ctx verb + mock cases).
- NEXT: review PR5 → merge → PR6 feat/remove-branch-diag-ai (armed remove
  pair both surfaces + mock dirty-refusal, copy-diagnostics, ai phase 1).
- PR5 merged #46 (8f26010), review clean (inline pass can't stack; git -C
  tolerates any repo path; update_cli precedent covers blocking-in-async).
- PR6 merged #47 (e4b5bcf): armed remove pair both surfaces + mock dirty
  refusal (error banner headlessly reachable at last), offline diagnostics
  (cli_binary tuple order verified path-then-version), ai phase 1 read-only
  + parent-dir reveal fallback. Review: one stale comment word fixed inline.
- TIER B DONE. 6 PRs total this session: #41 #42 #43 #45 #46 #47.
- Worktree now on fresh branch settings-next @ origin/main; old `settings`
  branch deleted (was never pushed with unique work).
- RELEASE v0.3.0: changelog rolled (opus draft, fable review), version bumped,
  gates green, merged #48 (180b965), tag v0.3.0 pushed from detached
  origin/main HEAD. release.yml run 30284096812 queued; watching in bg.
- NEXT: Tier C user-value discussion (global-summon-hotkey,
  session-startup-command, debug-logging).
- v0.3.0 RELEASED: release.yml run 30284096812 succeeded. Assets verified:
  CLI x4 (darwin/linux, aarch64/x86_64), signed app bundles x2 + .sig,
  latest.json, checksums.txt. Users update in-app (Settings → Version) or
  via install.sh.
- Tier C discussion delivered: recommendation = build ⌘K palette (feature,
  not Tier C) → summon hotkey self-promotes to B; debug-logging waits for
  first real support moment; startup-command likely never (create-once
  session model resists it).
- BUSY-DOT (Q on green dot): investigated (workflow wf_8b094193-ca1, 3 parallel
  reports + Opus synthesis after Fable-limit killed the verdict agent).
  DIAGNOSIS: dot read tmux #{session_activity} = client attach/keypress, NOT
  Claude output → decayed while Claude worked. Empirically proven (2 busy
  sessions 434-477s stale activity).
  FIX (PR7, merged #49 40a9f73): read ~/.claude/sessions/<pid>.json probes
  (status busy→green blink / waiting→amber static / idle→none), keyed by
  cwd==place.path, PID-alive liveness (NOT updatedAt age — rewritten on
  transitions only, empirically stale-while-busy). libc dep, --warn amber
  token per theme, session_activity removed from core. Live Playwright
  validated all 3 surfaces; fable(opus) reviewed diff + screenshot before merge.
  Changelog [Unreleased] entry added (PR #50, 4549e43).
- Model switched Fable→Opus mid-task (Fable limit). Worktree on settings-next-2
  @ origin/main. v0.3.0 shipped; busy-dot fix is post-release, in next cut.
- v0.3.1 RELEASED: release.yml run 30313393253 succeeded. All 10 assets up
  (CLI x4, signed app bundles x2 + .sig, latest.json, checksums.txt).
  Busy-dot fix now live; v0.3.0 users see it in Settings → Version.
  Release cut from clean release/v0.3.1 branch (settings-next-2 had diverged
  from a leftover remote branch — deleted the stale remote). Worktree now on
  settings-next-3 @ origin/main.
- SESSION ARC COMPLETE: eval → 2 audits → 7 PRs (#41-43,45-47,49) → 2 releases
  (v0.3.0, v0.3.1). Backlog in findings.md: ⌘K palette (next best build),
  Tier C on-demand, ~35 polish, origin/HEAD base detection, mock fault-injection.
- PR8 feat/quick-switch (⌘K palette) merged #52 (99a6326). Frontend-only:
  module-scope QuickSwitch, fuzzy subsequence rank (slug-biased, recency
  tiebreak, empty→recent), Arrow/Home/End/Enter/Esc, busy/waiting dots,
  chord-guard while open, works rail-only, reuses enterPlace+allPlaces.
  Live Playwright validated all interactions; fable(opus) reviewed diff +
  ranked screenshot + token resolution before merge. Changelog [Unreleased]
  entry included in the PR (atomic). Shortcuts cheatsheet updated.
- Global summon hotkey now self-promotes to buildable (its prerequisite —
  the switcher — exists). Worktree on settings-next-4 @ origin/main.
- Unreleased since v0.3.1: ⌘K switcher (next release candidate).
