# Findings: settings-pane evaluation (workflow wf_ae6754ff-2bc, 29 agents)

## Baseline (verified in code)
- `app/src/settings.ts` — persisted Settings; several fields set outside the sheet
  (lens, sort_mode/dir, manual_order, collapsed, nav_collapsed, last_seen_version).
- `app/src/SettingsSheet.tsx` sections: UI font, Terminal font/size, Editor cmd,
  Theme, Density, Version/updates, Nav tiers, Logs, Window default + nav width.
- Persistence: ui-state.json via get/set_settings (opaque serde_json::Value
  passthrough, lib.rs:249-260) — frontend-only settings are nearly free;
  mock get/set_settings generic (install.ts:209-212).

## Headline defects found (fix regardless of new settings)
1. **window_w/window_h is a DEAD setting** — sheet inputs save values nothing
   applies (no set_size anywhere; tauri.conf.json hardcodes 1280×820). CUT.
2. **⌘, is a shipped lie** — gear tooltip advertises "settings (⌘,)"
   (App.tsx:744) but only ⌘B has a handler (App.tsx:528-538).
3. **up_cmd is dead schema** — store.rs:34 declares it, App.tsx:17 types it,
   nothing writes/executes/displays it. DESIGN.md:172 reserves it for infra.up.
4. **remove-PROJECT has no confirmation** (App.tsx:654,1016→363-368) while
   remove-place two-click-arms. Fix: same two-click arm, unconditionally —
   not a confirmation-toggle setting.
5. Env-configured users diverge: WORKTREES_AI_CMD etc. never reach the GUI
   (fixup_gui_path repairs PATH only, lib.rs:813).

## Tiered candidates (verify verdicts, value/fit 1-5, cost)

### Tier A — add in this settings iteration
| key | value/fit/cost | essence |
|---|---|---|
| ai-auto-resume | 4/4/low | Toggle "Resume Claude conversation on open" (default ON). Backend done: open_place takes fresh:Option<bool> (lib.rs:363); wire at App.tsx:386 + boolean. Add "Open with resume" ctx item for both-direction override. No AI-cmd anchor in sheet — place near Editor command. |
| app-shortcuts | 4/5/low | Implement dead ⌘, + add ⌘1/2/3 lens switch + ⌘E open-in-editor (all wiring exists). FIXED bindings + read-only cheatsheet table — no rebind system, no persistence. Don't list ⌘K (switcher doesn't exist yet). Decide ⌘1-on-active-lens semantics (changeLens toggles nav). |
| reset-and-reveal-settings | 3/5/low | New "Data" section: Reveal ui-state.json (needs ~12-line settings_info cmd mirroring log_info + mock case) + Reset-to-defaults (two-click arm; preserve last_seen_version; route through updateSettings AND reset mirrored lens/collapsed React state via onReset). ~60 lines. |
| reshow-whats-new | 2/5/low | Button in Version section reusing get_changelog (backend+mock 100% done). No auto-show opt-out toggle. Gotchas: changelogBetween empty when seen==current (need current-section helper); check whatsNew scrim z-index above settings sheet. |

### Tier B — agreed direction, schedule soon
| key | value/fit/cost | essence |
|---|---|---|
| remove-deletes-branch | 4/3/med | Expose existing del_branch (lib.rs:680-695; UI hardcodes false). SIMPLIFIED shape: no setting — two armed actions "Confirm remove" / "Confirm remove + branch". Safe: force:false → `git branch -d` only deletes merged. Mock must model del_branch (install.ts:160). |
| system-theme-pair | 3/4/low | Theme=System: pick light+dark themes (resolveTheme hardwires Tokyo pair, settings.ts:21-25). 2 keys + 2 conditional selects. Gotcha: termVersion bump checks only patch.theme (App.tsx:307) — include new keys or terminal keeps stale colors. |
| background-auto-fetch | 3/4/med | Off / 15min periodic `git fetch --prune` per project main_root in watcher thread — fixes stale "behind" in Attention lens. MUST: GIT_TERMINAL_PROMPT=0, ssh BatchMode, deadline, no overlap, emit places:changed. Needs new command + AtomicU64 (settings blob unreadable from watcher). |
| external-terminal-command | 3/4/low | {session} template → "Open in terminal app" ctx item, hidden until configured. Precedent chain = editor_cmd. Don't split_whitespace — substitute then `sh -c`. "Copy attach command" (App.tsx:958) already covers 80%. |
| restore-last-place | 3/4/low | Startup toggle (default off). CRITICAL: selection-only (setSel) — must NOT enterPlace/open_place, else auto-resumes Claude on reboot. Fire once after hydration + first ws load. |
| copy-diagnostics | 3/4/low | Button in Logs: versions, GUI-resolved PATH, git/tmux locations, effective ai_cmd/prefix, theme, 200 log lines → clipboard. Must be async fn; offline (don't reuse check_update); theme appended frontend-side. |
| ai-command | 2/4/med | Expose ai_cmd/ai_resume_arg (shared CLI config file). Phase 1 cheap: read-only effective value + reveal-config (NOT open-path — permission missing). Phase 2: editable — needs comment-preserving cfg_set writer in core + get/set_ai_config cmds + mock. |
| update-auto-check | 2/4/low | Checkbox "Check for updates at launch" (default on) gating the unconditional 3s check (App.tsx:254-257, curl to GitHub). Gotcha: boolean in launch-effect deps so cleanup cancels pre-hydration timer. |

### Tier C — revisit on demand
- global-summon-hotkey (3/3/med): sequenced behind unbuilt quick-switcher; alone it's just focus-window (Raycast covers). Needs global-shortcut plugin + capabilities + capture widget.
- session-startup-command (2/3/med): pane1 already auto-runs install; sessions create-once so manual one-time typing suffices. If built: core config key `startup_cmd`, NOT app-only setting; don't hijack up_cmd (reserved for infra.up).
- debug-logging (2/4/low): Normal|Debug segmented in Logs; AtomicBool via set_settings. Scope to run_op args+elapsed (core git.rs hookless); log fingerprint changes not 3s ticks (1MB rotation churn). Add on first real "turn on debug" support moment.

### Omit — rejected with replacement actions
- **quick-switch-hotkey**: build the FEATURE (⌘K palette, hardcoded, frontend-only — enterPlace/matchPlace/allPlaces all exist), reject the binding setting. Palette at module scope (remount rule); focus via termFocus token; independent of nav visibility.
- **new-worktree-create-defaults**: install never blocks (async in pane 1, Ctrl-C opt-out); fetch is minimal + load-bearing. CLI flags cover niche. If ever: form checkboxes w/ last-used, never settings rows.
- **terminal-scrollback**: xterm buffer is placebo (attach = alternate screen); tmux history-limit set post-creation misses window 0; ~/.tmux.conf already applies (app never overrides). Doc line, not setting.
- **default-base-branch**: wrong shape (global knob for per-repo fact). Zero-knob fix: prepend `git symbolic-ref --short refs/remotes/origin/HEAD` to default_base() (project.rs:324-333) + keep probe fallback + bats case; fix "default: main" placeholder lie (App.tsx:174).
- **session-prefix**: global prefix collides sessions across repos ("teamx-main" ×2); per-repo .worktree-prefix already serves power users (DESIGN.md:224). Cheap alt: read-only session-name display (snapshot.prefix reaches frontend unused, App.tsx:37).
- **idle-window-days**: 7d default matches "this week" mental model; grouping-only stakes; density pain served by collapsed-idle + hideable tiers + lenses. If ever: invoke arg with detents, update DESIGN.md table same PR.

## Proposed pane reorganization (from merge + verify placements)
1. **Appearance**: theme (+ System light/dark pair), density, UI font
2. **Terminal**: font family/size (scrollback deliberately absent)
3. **Sessions & Commands**: editor cmd, AI command (effective value + resume toggle), external terminal cmd
4. **Behavior**: startup (restore last place), update auto-check, nav tiers
5. **Version**: existing + What's-new button
6. **Logs**: existing + copy-diagnostics (+ later debug toggle)
7. **Data**: reveal settings file, reset to defaults
Cut: Window default inputs (dead). Keep: nav width (works).

## Notable architecture facts (reusable)
- Settings blob is backend-opaque → frontend-only settings cost ~0 backend/mock.
- Watcher thread (lib.rs:875-893): 3s tmux fingerprint, 30s safety re-emit — can't read settings blob; needs dedicated command + atomic for any tunable.
- CLI config (~/.config/worktrees/config): ai_cmd, ai_resume_arg, prefix. cfg_get exists, NO writer. App exposes none of these.
- App never passes: del_branch/force (remove), base (switch), --ai/--no-install/--no-fetch (new) — capability surface exists, UI doesn't.
- tune_session order trap: new_session → tune → split means session-scoped tmux options miss window 0.

---

# Ctx-menu audit (workflow wf_7804a1e7-195, 65 agents, live harness run)

## Bottom line
All 20 menu items (14 place, 6 project) WORK end-to-end on the happy path —
verified statically (full chains frontend→lib.rs→core→mock) AND live in the
mock harness via Playwright (screenshots in _audit-shots/). Menu infrastructure
sound: CtxMenu module-scope, closeCtx clears armed confirmRm on every ctx
dismissal path, z-order correct, live ctxPlace derivation + vanish-guard works.
48 issues confirmed after adversarial verify (9 bug / 13 ux-gap / 26 polish),
6 refuted. Item status: 60 traced; works=all core verbs; partial/broken listed
below.

## Bugs (9) — each verdict includes a fix sketch (see workflow output)
1. **topbar-arm-survives-popover-close** — ⋯ "Remove place…" armed state
   survives popover dismissal (menu-catch :945, ⋯ toggle :849, Copy path :852
   only setMenu(null); no Esc). Reopen ⋯ → pre-armed one-click destructive
   remove. Violates App.tsx:370-372 invariant. Fix: closeMenu() clearing both.
2. **silent-launch-failure** — tmux new-session failure invisible end-to-end:
   ops.rs:56-64 no else-branch, prints "Session ready", exit 0; app path
   (--no-attach) shows nothing; Enter no-ops silently. Fix: else→ui.error+rc 1.
3. **foreign-session-reuse-invisible** — launch adopts non-canonical session
   (ops.rs:37-43) but snapshot up-check is canonical-name-only
   (project.rs:190-191) → place reads down, TerminalPane never mounts, Enter
   "does nothing" repeatedly. Fix: place_json falls back to worktree_session.
4. **copy-silent-failure-no-feedback** — copyText swallows clipboard errors
   (App.tsx:395-398 + inline :852); verified live (unfocused doc → stale
   paste). All 5 copy surfaces; zero success feedback. Fix: .catch(fail).
5. **note-focus-terminal-steal** — Edit note… on non-selected live place:
   TerminalPane post-term_open term.focus() beats 60ms note focus → keystrokes
   go INTO THE SHELL. Fix: guard term.focus() when activeElement is input.
6. **create-selection-mismatch-on-reuse** — frontend re-derives slug
   (App.tsx:487) ≠ core (origin/ strip, holder-reuse) → selection lands on
   nothing, pane blanks. Fix: return final slug in CmdResult.
7. **git-stderr-never-captured** — git_status inherits stdio (git.rs:34-36);
   3 cmd_new failure paths return 1 with NO ui.error; banner shows info lines
   that read like success. Fix: captured git_status_ui variant.
8. **github-url-branch-not-percent-encoded** — lib.rs:635; '#'/'%' in branch
   breaks URL. Fix: escape % then #.
9. **mock-remove-place-parity** (dev-scoped) — mock ignores dirty-refusal +
   del_branch/force; 4 dirty fixtures pass headless, fail prod.

## UX-gaps (13, most impactful first)
- **remove-project-no-confirm-both-surfaces** — ctx item :1016 AND header ✕
  :654 (second surface the settings eval missed). Arm both (proj|root key).
- **success-output-discarded** — runCmd drops output when ok: reuse/switch
  warns, rm scope lines never shown. Fix: notice toast for ok-with-output.
- **silent-branch-steal-on-name-collision** — cmd_new switches existing
  worktree to new branch, warn discarded → create silently repurposes a place.
- **dirty-error-cli-flag-in-gui** — refusal says "pass --force"; GUI has no
  force. Fix: second-stage "Force remove" arm on refusal detect.
- **ctx-menu-live-item-shift** — 3s poll restructures OPEN menu (up-gated rows
  appear/vanish under cursor; clamp deps [x,y] never re-clamp). Worst case:
  click lands on already-armed Confirm remove. Fix: snapshot Place into ctx.
- **popover-catch-native-contextmenu** — sort/⋯ catches lack onContextMenu +
  Esc; native WKWebView menu leaks. No app-global contextmenu suppressor.
- **no-eof-signal-to-frontend** — out-of-band detach → TerminalPane frozen
  indefinitely (fingerprint unchanged). Fix: emit term:eof after reader loop.
- **note-save-blur-only-loss** — Enter/Escape dead on note input; unmount
  mid-type loses text; inconsistent w/ switch input (Enter commits :885).
- **lifecycle-no-explicit-unset** — "Close" IS the reset (falls through to
  derived) but UI never says so; ✓ Close + "active" badge contradiction.
  Fix: lib.rs maps closed→None + relabel.
- **open-on-github-label-and-deeplink** — label hardcodes GitHub, backend
  host-generic; non-github hosts lose branch deep-link. Rename "Open remote".
- **editor-cmd-no-quote-parsing** — split_whitespace can't do spaced paths;
  conflicts with planned sh -c policy for external-terminal-command.
- **no-fetch-now-verb** — NEW settings-plan gap: background-auto-fetch is
  Off-default but no manual "Fetch origin" verb exists anywhere; add project
  ctx item sharing the Tier B fetch command (same PR).
- **mock-cmdresult-never-fails** — no mock CmdResult can return ok:false →
  entire error-banner pipeline untestable headlessly. Fix: fault-injection
  hook (?fault param / magic slug).

## Polish (26) — grouped
- Enter family: no in-flight guards (double-submit banner race in New form);
  touch_place err unlogged; fresh item dead when ai_cmd≠claude (needs
  resume_available signal — also gates planned ai-auto-resume toggle); no
  "Restart fresh" composite verb.
- Copy attach: missing `=` exact-match sigil (tmux prefix-match hazard the
  codebase guards elsewhere); hidden when down — add "Copy session name"
  (serves as the session-prefix read-only alternative from settings eval).
- Declared state: detail-header pin/lifecycle NOT gated is_main (ctx is);
  Edit note… denied for main in ctx while note-strip allows it (move out of
  gate); note write on every blur (no dirty check); pin double-click race;
  pinned:false persisted forever.
- Menus: remove label inconsistency ("Remove worktree…" vs "Remove place…");
  project vanish-branch skips confirmRm clear (latent trap); rclick-other-row
  two-step; zero keyboard/ARIA semantics + Escape double-fire w/ New form;
  clamp measures during scale(0.98) frame (~1.5px overflow, live-verified),
  no max-height/resize re-clamp; no refocus on reopen same-key form; no
  "Switch branch…" ctx item (sole mutating verb absent; editNote precedent).
- Integrations: origin-only remote (no fallback); misleading "No origin
  remote" for exotic remotes; dash-branch typo surfaces as "Unknown flag".
- Mock drift: open_place drops fresh; github_url static/never-null; set_note
  whitespace; open_editor never rejects; open_path accepted but ACL-rejected
  in prod (known bug class — make mock throw); xterm dispose rAF TypeError
  (StrictMode dev-only; fix: defer dispose one frame).

## Refuted (6) — do NOT act on
term-close-never-waits (portable-pty reaps w/ SIGHUP grace loop);
reveal-selects-not-opens (canonical macOS reveal semantics);
main-loses-new-from-branch (empty base IS main);
mock-new-place base drop (consequence-free); mock-switch guardless +
mock-reconcile-frozen (harness-wide happy-path design, covered by
fault-injection item instead).

## Settings-plan cross-check (tie-in agent)
- ai-auto-resume: CONFIRMED cheap — single wire point App.tsx:386; all Enter
  surfaces inherit toggle free; fresh:Option<bool> covers both directions.
  Must add resume_available/ai_is_claude signal (see polish) + mock fresh.
- remove-deletes-branch: must edit BOTH surfaces (ctx :991-996 + topbar
  :853-855) + mock del_branch, or surfaces diverge.
- external-terminal-command: sibling item after :958, same up-gate; adopt
  sh -c policy AND retrofit open_editor to match (one quoting policy).
- remove-project fix must cover ctx item + header ✕.
- Keep hardcoded (confirmed): copy/reveal/close verbs, pin/lifecycle/note,
  Open on GitHub (rename only), new-worktree form.
- restore-last-place: correctly no menu tie (selection-only).

---

# Upstream drift check (2026-07-27, before implementation)
origin/main moved 57c8b5b → 0d72eab (#35-#40) AFTER both audits:
- **reshow-whats-new: ALREADY SHIPPED** (#40 — onShowNotes prop, "Release
  notes" button in Version section, manual flag, formatted ReleaseNotes).
  DROP from PR2.
- **system-theme-pair: ALREADY SHIPPED** (#38 — theme_light/theme_dark +
  pair selects + normalizePair). DROP from Tier B.
- Still present on origin/main: window_w/h dead setting, ⌘, missing (keydown
  handles only ⌘B, now ~:619), topbar arm leak, remove-project no-confirm.
- ALL audit line numbers stale (App.tsx shifted ~90 lines; nav gained Home,
  busy-dots). Implementers must re-locate by grep, not line refs.

---

# Busy-dot investigation (workflow wf_8b094193-ca1 + Opus verification)

## Q1: Is the green dot working as intended? NO — wrong signal.
Current impl (upstream #38): watcher thread (lib.rs:1112-1153) reads tmux
`#{session_activity}` (core tmux.rs:45), keeps sessions within a 10s window
(BUSY_WINDOW_SECS=10), emits `sessions:busy` (Vec<session_name>, change-gated);
frontend keys a Set on `p.tmux_session.name`, `.status-dot.busy` blinks via the
`breathe` animation (App.css:241). So it DOES blink — but off the wrong input.

ROOT CAUSE (empirically verified on tmux 3.6a, this machine): `#{session_activity}`
updates on **client attach / user keypress**, NOT on pane output. Two live
actively-working sessions showed session_activity 434–477s STALE while their
Claude spinners ran ('Osmosing… 2m17s'), one with a client attached. A detached
pane printing every 1s left session_activity frozen while `#{window_activity}`
advanced. → the dot decays ~10s after you last touch a session even while Claude
keeps working (the reported dropout), lights on shell-pane typing, is
session-granular (can't tell pane0 claude from pane1 shell), and never lights a
working session you don't have attached.

## Q2: Can we make it track "Claude actively working"? YES — decisively.
Claude Code exposes per-session state natively (verified live, CC 2.1.220):
- `claude agents --json` → `status: busy|idle|waiting` (+ `state` for background,
  `waitingFor`) keyed by `cwd`, `--cwd` filterable. pid 33086 (ui-changes) = "busy".
- `~/.claude/sessions/<pid>.json` probe files → `{pid, cwd, status, waitingFor,
  updatedAt, ...}`, one per live session, written live by Claude Code itself.
  54547.json = status "waiting", waitingFor "dialog open", updatedAt current.
`cwd` maps 1:1 to worktree dirs (pane0 launches `-c <wt>`). This is the source of
truth the ecosystem converged on (craftzdog's tmux manager migrated hooks →
`claude agents --json`; pbauermeister/claude-busy-monitor reads the probe files).

Signals ranked (all empirically checked here):
| signal | tracks working? | working-vs-waiting? | no-attach? | cost |
|---|---|---|---|---|
| session_activity (today) | NO (attach/keypress) | no | no | 0 |
| window_activity (1-word swap) | yes, but shell-pane too | no | no | 0 |
| jsonl mtime | yes but stalls 90s–5.5m on long think | no | yes | low |
| **probe files ~/.claude/sessions/** | **yes (authoritative)** | **YES** | **yes** | **low (fs read)** |
| `claude agents --json` | yes (authoritative) | YES | yes | med (subprocess/3s) |
| capture-pane regex (ccmanager) | yes | yes | yes | med (N captures) |
| caffeinate child ps | yes | no | yes | low |
| hooks → state file | yes | YES | app-created only | med (ships hook) |

## Recommended design (probe files, low cost, fits the 3s watcher)
- New lib.rs helper: read `~/.claude/sessions/*.json`, collect canonical `cwd`s
  where `status == "busy"` AND `updatedAt` fresh (<60s, guards crashed-session
  stale files). App-only (dot is app-only); keeps core/bats surface untouched.
- Watcher (lib.rs:1144) swaps `session_activity` filter → busy-cwd set; emit
  `sessions:busy` payload as Vec<canonical worktree path> (was session names).
- Frontend: `isBusy(p) = busyPaths.has(canonical(p.path))` (was p.tmux_session.name);
  rollup badge + Home row same swap. Blink CSS unchanged (already breathes).
- Non-claude ai_cmd → no probe file → no dot (correct: dot means "Claude working").
- Old Claude Code w/o probe files → empty set → no dots (graceful; no-dot > wrong-dot).
- Mock: install.ts emits paths instead of names.
- OPEN DESIGN Q: busy-only (green blink) vs also a distinct "needs input" state
  (waitingFor → amber, not blinking). Ecosystem tools all split the two; matches
  user's "actively doing things" if we keep green=busy only and add amber later.
- Fallback contract: if probe format ever breaks, `claude agents --json` is the
  documented equivalent (subprocess, slower cadence acceptable).

## CORRECTION (empirical, before implementing)
Probe-file `status` values seen live: busy / idle / waiting (waitingFor
"permission prompt"|"dialog open") / shell / None(stale). `updatedAt` = epoch
MILLIS. KEY: the file is rewritten on status TRANSITIONS, not continuously — the
two live `busy` files had updatedAt 84s & 285s old while genuinely working
(95052.json = this very session). So a "fresh within 60s" guard is WRONG (drops
long-running busy sessions). Liveness guard MUST be PID-alive (libc::kill(pid,0)),
NOT updatedAt age. Stale files are dead-pid leftovers (not cleaned on crash);
kill(pid,0)==ESRCH filters them. User chose: green blink = busy, static amber =
waiting (needs input); idle/shell/None → no dot.
