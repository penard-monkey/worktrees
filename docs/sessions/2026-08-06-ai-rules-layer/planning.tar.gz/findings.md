# Findings — AI rules layer

_Source: recon workflow `wf_36bc4aab-830` (6 recon + 2 adversarial reviews + synthesis, fable, 2026-08-01). Claims carry file:line or command evidence; treat unverified markers as unverified._

# AI Rules Layer — recon synthesis (findings)

Status: recon + adversarial review complete. This file is the durable record; everything below is
evidence-anchored (file:line in this repo, a command run locally, or official docs). Items marked
**UNVERIFIED** must be resolved by the Phase-2 spike before the materializer is built.

Local environment: claude **2.1.220** (native binary via @anthropic-ai/claude-code npm wrapper),
tmux **3.6a**, macOS (APFS case-insensitive).

---

## 1. Settled decisions

| Question | Decision |
|---|---|
| Rules delivery | `--append-system-prompt-file <snapshot>/rules.md` — never inline argv, never a worktree CLAUDE.md, independent of the config-dir swap |
| MCP delivery | `--mcp-config <snapshot>/mcp.json`; add `--strict-mcp-config` when inherit-global-MCPs is OFF; inherit=ON → materializer merges global mcpServers from ~/.claude.json into snapshot mcp.json |
| Settings/model | `--settings <snapshot>/settings.json` (+ `--model` if set) |
| Swap mechanism | Route A (CLAUDE_CONFIG_DIR) primary, **gated on the auth spike**; Route B (flags-only: + `--setting-sources`, `--add-dir` skillhost) is the pre-planned fallback. Rules + MCP channels identical under both |
| Env injection | Resolver returns `{ env, cmd, match_word }`; env composed **inside the sh -ic string**; NO `tmux new-session -e` in v1; profile flags placed AFTER the resume arg |
| Adoption/resume | `adopt_ai_word`, `ai_is_claude`, `session_in` preference read `match_word`, never the launch string |
| Probes | `claude_dir_for` + activity scan take the effective config dir (fallback `$HOME/.claude`) in the same change that sets CLAUDE_CONFIG_DIR |
| CLI parity | worktrees-core owns profile resolution (reads profiles.json) → `worktrees open` is profiled identically to the app |
| Storage | `profiles.json` sibling file in app config dir, backend serde-typed; contains profiles + root→profileId assignments + default_id. Never in ui-state.json, never in .worktrees.toml. Exports always exclude .credentials.json/oauthAccount |
| Staleness | Immutable per-launch snapshot dirs (GC'd); skills COPIED not symlinked; badge = profile `updated_at` (stamped by save_profile) vs launch record — frontend-side, no new polling, **no materialized-dir hashing** (claude writes into its config dir at runtime, hash never clears) |
| MCP server | `worktrees mcp` subcommand, stdio, rmcp 3.x, deps in worktrees-cli only; v1 tools = read-only + metadata-write; repo-write/destructive + run_gates = v2 |
| Skill store | v1 = local-path installs + inherit-global toggle; git-URL (sha-pin, picker, diff review) = v2; bare skills only, no plugins |
| Adapter | Struct boundary + if-branch in v1 (`match_word == \"claude\"` → adapter, else launch unmodified); trait extracted when a second tool exists |
| Export/import | v1 = reveal profiles.json/dir in Finder; structured import/export = v2 |

## 2. The exact launch recipe (target grammar)

Current pane0 (ops.rs:85, 105-109; tmux.rs:223-232):

```
tmux new-session -d -s <session> -c <wt> -P -F '#{pane_id}' \
  'exec \"${SHELL:-/bin/sh}\" -ic '\''<ai_cmd>; exec \"${SHELL:-/bin/sh}\"'\'''
```

Target profiled composition inside the -ic string (Route A):

```
CLAUDE_CONFIG_DIR='<snapshot>' claude [<resume_arg>] \
  --settings '<snapshot>/settings.json' \
  --mcp-config '<snapshot>/mcp.json' [--strict-mcp-config] \
  --append-system-prompt-file '<snapshot>/rules.md' [--model <m>]
```

Route B replaces the env var with: `--setting-sources project` (drops user-scope skills — verified
user:1→0 in debug.log — and user settings) `+ --add-dir <snapshot>/skillhost` (its `.claude/skills/`
carries profile skills; --add-dir skill loading is docs-cited, **UNVERIFIED locally**).

Rules of the grammar:
- First word after env assignments stays `claude` → `pane_current_command` = claude → adoption intact.
- `match_word` carried separately in the resolver struct; env never string-prefixed into `ai_cmd`.
- Profile flags go AFTER the resume arg (three bats assertions pin adjacency of ai word + resume arg:
  test/open.bats:86, test/new.bats:270, test/misc.bats:430).
- Snapshot paths must be space/quote-free; still route through `tmux::sq` (tmux.rs:107-109).
- Everything is re-resolved on every launch (relaunch path ops.rs:92-135) — restart-proof by design;
  nothing needs to survive a tmux server restart.

Verified flags on claude 2.1.220 (`claude --help` + live tmux interactive probes):
`--settings` (file or inline JSON), `--setting-sources`, `--mcp-config <files...>`,
`--strict-mcp-config`, `--append-system-prompt[-file]`, `--system-prompt[-file]`, `--agents`,
`--plugin-dir`, `--model`, `--add-dir`, `--bare`. None carry the \"(only works with --print)\" marker.
`--append-system-prompt` interactive since v1.0.51 (official CHANGELOG); `-file` variant clarified
interactive in v2.1.69. Empirically: appended marker visible in-session and **survives /clear**;
coexists with project CLAUDE.md (both load — memory docs: files concatenate, never override);
system prompt is \"Unchanged; not part of message history\" across compaction (context-window docs).
Hostile rules content (quotes/backticks/$()/newlines) verified intact via the file variant.

## 3. Launch path anatomy (file:line anchors)

- UI entry: App.tsx:1446-1456 `enterPlace` → invoke `open_place`; terminal mounts separately
  (App.tsx:2220 → TerminalPane.tsx:57 `term_open`).
- open_place: app/src-tauri/src/lib.rs:433-464. `(main)` slug → ops::launch directly with
  resolve_ai_cmd(None); worktrees → ops::cmd_open [slug, --no-attach, --no-spare] (+`-r` when
  claude history exists). Auto-resume gated on `ai_is_claude()` (lib.rs:469-474).
- ops::cmd_open: crates/worktrees-core/src/ops.rs:507-576; ops::cmd_new: ops.rs:386-404.
- ops::launch: ops.rs:84-143; pane0 built at ops.rs:85, 105-109. **No send-keys, no respawn-pane
  anywhere**; spare shell = plain split-window (tmux.rs:234-236).
- Attach: app spawns `tmux -u attach-session -t <session>` in a portable_pty PTY
  (lib.rs:1699-1706); close = detach only (lib.rs:1756-1767).
- ai_cmd resolution: flag > $WORKTREES_AI_CMD > $WORKTREES_CLAUDE_CMD (deprecated) > user config
  `ai_cmd` (~/.config/worktrees/config.toml, legacy kv fallback) > \"claude\"; literal \"none\" → plain
  shell. config.rs:111-131 (resolve_ai_cmd_from), 181-186. **No project tier today**; the prefix
  chain (config.rs:150-170) is the precedent for adding one, incl. `*_from` pure-function tests.

### The ai_word trap (three synced sites)

`ai_word = basename(first whitespace-separated word of resolved ai_cmd)`, duplicated deliberately:
- ops.rs:86-90 (launch)
- project.rs:511-520 (adopt_ai_word)
- lib.rs:469-474 (ai_is_claude)

`session_in` (tmux.rs:178-206) snapshots `list-panes -a -F '#{session_name}\\t#{pane_current_path}\\t#{pane_current_command}'`
(tmux.rs:140-145) and prefers a pane whose cwd is under the wt AND `cmd.contains(ai_word) || cmd == \"node\"`
(tmux.rs:198; substring, not exact); else first matching pane wins (tmux.rs:201-205).

Consequences (verified by code-reading):
- `CLAUDE_CONFIG_DIR=x claude` as the ai_cmd string → ai_word = `CLAUDE_CONFIG_DIR=x` → adoption
  degrades to first-pane fallback AND ai_is_claude()=false → auto-resume silently disabled. Same
  for `env ...` prefixes and wrapper scripts. **Fix = the resolver struct, not string games.**
- Appending flags is safe (that's how `-r` works today).
- The `cmd == \"node\"` case means any node process cwd'd in the worktree is preferred as the AI pane.
- Mixed provenance: an unprofiled terminal-launched claude in the same worktree is adopted and
  displayed as the place's session — UI needs an adopted-unprofiled indicator.

### HOME-anchored probes that go blind under a swap

- `claude_dir_for(dir)` = `$HOME/.claude/projects/<dir with non-alnum → '-'>`; has_session = any
  `*.jsonl` inside. project.rs:544-560, 540-542, 215-216; model.rs:38-39; consumed at lib.rs:439-441
  and surfaced in ls --json (`claude_session_present`/`claude_session_dir`, App.tsx:2390).
- Busy/waiting activity dots scan `$HOME/.claude/sessions/<pid>.json`: lib.rs:671-716 (esp. 709-716).
Both must take the place's effective config dir (fallback $HOME/.claude) in the same PR that sets
CLAUDE_CONFIG_DIR. Note ls --json emits claude_session_dir → CLI must be profile-aware too.

### tmux env facts

- `new-session -e VAR=val` exists on installed tmux 3.6a (man page) and persists in the session env —
  but the fake shim has no `-e` case, min-version floor unaudited, and **UNVERIFIED** whether pane0's
  initial process inherits it. Not needed: env inside the -ic string is baked into the process.
- `set-environment -t` only affects panes created AFTER it runs — useless for pane0; stale-badge flow
  must be kill+relaunch, never env mutation.
- Client-process env does NOT reliably reach panes (server-socket delivery; update-environment list
  only) — medium confidence, man-page based.

## 4. Test harness constraints

- bin/worktrees:8-13 shim prefers target/release (build first or bats fails mysteriously).
- Fake tmux: test/helpers/common.bash:107-157. Logs argv; new-session writes `cwd=`/`cmd0=` into
  $TMUX_STATE/<session>; split-window appends `cmd1=`. Assertion hooks tmux_pane0_cmd/tmux_pane1_cmd
  (192-193). Arg parser cases ONLY -t/-s/-c/-d/-h/-P/-F/-L/-f (113-123) — an added `-e` is swallowed
  as positional args and corrupts cmd0 for every session-creating test.
- Pane0-shape pinning tests: misc.bats:364-372 (-ic + ai word), 404-422 (ai=none → exact pane0, no
  -ic), 424-431 + 433-441 (adjacency + sq escaping); open.bats:25-47, 82-86, 89-95; new.bats:258-286.
  Three adjacency assertions (open.bats:86, new.bats:270, misc.bats:430) break if anything sits
  between the ai word and the resume arg.
- real-tmux.bats:1-60 counts panes/sessions only — pane_current_command's real value while claude
  runs under sh -ic is **UNVERIFIED** (expected \"claude\", or \"node\" for npm installs; code
  special-cases both).
- **No fake-claude shim exists.** CI can assert pane0 grammar, env composition, and snapshot dir
  contents; everything claude-side needs the manual checklist gated on `claude --version`
  (behaviors are version-gated: plugin name prefixing changed 2.1.216, background: needs 2.1.218).

## 5. CLAUDE_CONFIG_DIR — what's proven, what's not

**Proven (empirical, claude 2.1.220 + official docs):**
- Relocates the whole user scope: settings.json, skills/, plugins/ (installed_plugins.json + cache),
  .claude.json (user MCPs + onboarding/trust), projects/, sessions/, backups/. Docs
  (code.claude.com/docs/en/claude-directory): \"every ~/.claude path on this page lives under that
  directory instead\"; env-vars doc: intended for \"running multiple accounts side by side\".
- macOS auth landmine: fresh config dir = logged out (`auth status` loggedIn:false); keychain entry
  `Claude Code-credentials` is not seen. Symlinking ALL of ~/.claude in doesn't fix it (rules-delivery
  probe — that probe never planted .credentials.json, so the two recons are reconcilable).
- Escape hatch A: `.credentials.json` INSIDE the config dir IS read — fake token flipped
  loggedIn:true and was sent/refresh-attempted. **Real-token session + refresh-rotation UNVERIFIED**
  (the top spike item — rotation could log the user's normal claude out). Symlinked credentials file
  UNVERIFIED.
- Escape hatch B: `CLAUDE_CODE_OAUTH_TOKEN` (from `claude setup-token`) works with any config dir
  (authMethod \"oauth_token\") but scope = user:inference only → **disables Claude-in-Chrome and
  claude.ai connectors** (observed in debug.log; this user uses both).
- Fresh dir triggers interactive onboarding (tmux capture: theme picker → login screen). Pre-seed
  .claude.json with hasCompletedOnboarding, theme, oauthAccount + a per-WORKTREE trust entry
  (exact projects{} key shape **UNVERIFIED** — replicate from ~/.claude.json in the spike).
- Managed scope stays at /Library/Application Support/ClaudeCode regardless. Invalid settings.json is
  silently ignored in -p mode (help text) — don't rely on claude to surface materializer bugs.
- Project-scope config (.claude/settings.json, .claude/skills/, .mcp.json in the worktree) STILL
  loads under a swap — **a profile is not a sandbox against repo-committed config**.
- Skills: `$CLAUDE_CONFIG_DIR/skills/<name>/SKILL.md` loads (planted probe counted user:1);
  `--setting-sources project` drops user-scope skills (user:1→0). Skill dirs and settings.json are
  hot-watched → live sessions mutate immediately on edit → snapshot immutability is mandatory.
- History: transcripts live under the active config dir's projects/ → profile switch orphans prior
  conversations from -r/auto-resume; surface in the picker UI.

**UNVERIFIED spike list:** real-token auth + rotation; symlinked .credentials.json; trust-key shape;
$CLAUDE_CONFIG_DIR/CLAUDE.md loaded as user memory; user-scope mcpServers relocation
(`claude mcp list` under swap); --add-dir skill loading; dangling skill symlink behavior;
concurrent claude writers on one .claude.json; interactive /login target under a custom dir.

## 6. worktrees MCP server

- Core is ready: every op takes `&mut dyn Ui`; CaptureUi declines confirms and reports
  can_confirm()=false → guarded ops return EXIT_NEEDS_CONFIRM=4 (ui.rs:26-35, 117-143; diag.rs:35).
  The app's run_op/CmdResult wrapper (lib.rs:311-357) is the tool-call template. cmd_rm refuses
  dirty worktrees without --force and refuses when cwd is inside the target (ops.rs:774-815).
- rmcp 3.1.0 = official SDK (modelcontextprotocol/rust-sdk), released 2026-07-31, implements MCP
  2026-07-28 with back-compat; protocol just moved versioning to per-request `_meta` + mandatory
  `server/discover` — do not hand-roll. Pin `rmcp = \"3\"`; expect ~one migration/year. MSRV +
  binary-size delta on 4 targets **UNVERIFIED** (spike). tokio exists only in the app tree today.
- Stanza (docs + live ~/.claude.json inspection):
  `{\"mcpServers\": {\"worktrees\": {\"type\": \"stdio\", \"command\": \"<abs path>\", \"args\": [\"mcp\"], \"env\": {}}}}`
  written to snapshot mcp.json. Resolve `command` at every materialization — app: probe+candidates
  logic lib.rs:762-778; CLI: current_exe(). No binary → materialize without stanza + warning.
- Claude Code sets CLAUDE_PROJECT_DIR in each stdio server's env (docs) → pin repo scope at startup,
  no repo param on any tool. Output cap 25k tokens (warn 10k); per-server `timeout` field exists.
- **UNVERIFIED:** whether --mcp-config stdio servers bypass the .mcp.json Pending-approval flow
  (strongly implied, not stated) — probe with `timeout 60 claude -p --mcp-config ... --strict-mcp-config`.
- v1 tools: list_places, place_status, session_status, doctor (readOnlyHint) + set_note/set_pin/
  set_lifecycle (store::edit, mirroring lib.rs:282-300). Test by piping JSON-RPC into the binary
  under the bats fake shims (core shells out → harness intercepts free).

## 7. Skill store

- Contract: skill = dir with SKILL.md (YAML frontmatter; spec requires name 1-64 lowercase/digits/
  hyphens matching dir name + description ≤1024; Claude Code is laxer — all optional, command comes
  from dir name for user/project skills). Resources via relative paths; ${CLAUDE_SKILL_DIR} at runtime.
- Symlinked skills PROVEN to load (user's own ~/.claude/skills is nearly all symlinks into
  ~/.agents/skills and they load in live sessions) — but v1 copies into snapshots for freeze semantics.
- Live watch: SKILL.md edits reach live sessions without restart (docs \"Live change detection\") —
  the reason snapshots must be immutable.
- Plugins are a superset (plugin.json: skills/mcpServers/commands/agents/hooks) with a
  version-pinned cache layout; Anthropic pins plugin installs by gitCommitSha
  (~/.claude/plugins/installed_plugins.json) — precedent for v2 sha-pinning. v1: bare skills only.
- Validation (v1, local-path): frontmatter parses; lowercase name rules (also dodges APFS
  case-insensitivity — Settings.tsx/settings.ts precedent); case-insensitive collision check vs
  store + inherited globals; reject symlinks inside the tree; size/file-count caps; loud warnings on
  `hooks:`, `allowed-tools:`, `disallowed-tools:`, `context: fork`, and any scripts/ dir. Store
  never executes installed content. Skill descriptions load at session start for ALL enabled skills
  (progressive disclosure tier 1) — even never-invoked skills can steer the model.
- Backend estimate (full store incl. git): 4.5-6.5 focused days; v1 local-path subset is well under.

## 8. App plug points

- Config dir files: ui-state.json (lib.rs:243-247; opaque blob, frontend-owned, debounce-overwritten
  wholesale settings.ts:217-224 — never put backend-written data here); projects.json precedent
  lib.rs:170-186; settings_info reveal pattern lib.rs:255-261 / SettingsSheet.tsx:200-213.
- SettingsSheet: CATS array SettingsSheet.tsx:16-26, nav 237-248, one `{cat === id && ...}` block per
  category from 251. Add `{id:\"ai\", label:\"AI profiles\"}` after \"commands\". get_ai_config
  (lib.rs:887-918) is the existing read-only AI surface — extend it to show the composed launch line.
- ProjectSheet = the component pattern (module scope + props — inner components remount every render):
  fetch-on-open, refresh-in-finally, arm-then-confirm destructive, errors → note()/log_event,
  null-tolerant for unmocked commands (ProjectSheet.tsx:118-233). Profile picker = new `.setting`
  section; per-root maps precedent: init_dismissed/collapsed (settings.ts:54-72).
- New command checklist: `#[tauri::command] async fn` (sync freezes UI) + generate_handler! entry
  (lib.rs:2134-2185, currently 44 commands) + **stateful mock case in app/src/mock/install.ts**
  (sessionStorage-backed like MOCK_SETTINGS_KEY, install.ts:40,463-479) — hard rule, Playwright
  drives the UI through the mock. No capability changes for app-own commands.
- Capabilities (app/src-tauri/capabilities/default.json:8-14): core/opener/dialog/updater/process.
  opener:default has reveal-item-in-dir (reveal parent if path may not exist) but NOT open-path;
  missing permissions reject invokes SILENTLY. **UNVERIFIED:** dialog:default covering the SAVE
  dialog (only open is used today) — needed for v2 export; fallback = fixed dir + reveal.
- Stale badge placement: topbar controls next to .live-badge (App.tsx:2158-2160), echo in statusbar
  sb-facts (2240-2243). Data already in state: tmux_session.{name,up}, claude_session_present,
  busyPaths/waitingPaths (1069-1079), declared.last_opened_epoch (touch_place lib.rs:301-305).
  **No profile probing in the 3s poll thread** (same rule that keeps doctor off the hot path,
  lib.rs:922-928).
- File naming: distinct basenames only (ProfilesSheet.tsx, never Profiles.tsx + profiles.ts).

## 9. Design notes for DESIGN.md

- Profiles introduce a THIRD state category: app-declared (profiles.json), alongside derived
  (git/tmux) and repo-declared (.worktrees.places.json). Name it explicitly.
- Full-replace fork-and-diverge trap: consider \"Duplicate from default\" + optional
  \"inherit default rules\" concat toggle (file concatenation at materialization — NOT a merge engine).
- Non-claude ai_cmd and possibly the `(main)` place: grey/hide picker + badge (a stale badge on a
  codex pane would be a lie). (main) participation = open user question.
- Document in the profile editor: profiles do not sandbox repo-committed .claude/ config; switching
  profiles starts fresh history for the place.

---

## Auth spike — run 1 results (2026-08-01, hand-run by the user, claude 2.1.220)

Setup: `CLAUDE_CONFIG_DIR=<scratch cfg>` with a keychain-copied `.credentials.json`,
pre-seeded `.claude.json` (hasCompletedOnboarding + theme + oauthAccount +
`projects[<wt>].hasTrustDialogAccepted`), launched interactively in tmux with
`--append-system-prompt-file <cfg>/rules.md`.

**VERIFIED:**

| # | Question | Result |
|---|---|---|
| 1 | Does a copied `.credentials.json` authenticate an interactive session? | **YES** — session reached the prompt and answered. No re-login. |
| 2 | Do the onboarding/trust pre-seed keys skip all dialogs? | **YES** — zero dialogs, straight to prompt. The seed shape in §"first launch" is correct. |
| 3 | Does `--append-system-prompt-file` work *together with* the swap? | **YES** — `SPIKE-MARKER-7734` returned verbatim. |
| 4 | Do user-scope MCP servers relocate with the config dir? | **YES, isolated** — `/mcp` → "No MCP servers configured". Global servers absent. Confirms inherit-global-MCPs must be done by MERGING into the snapshot `mcp.json`, exactly as planned. |
| 5 | Do user-scope skills relocate? | **YES, isolated** — `/context` listed only built-in skills (dataviz, claude-api, update-config, …). None of `~/.claude/skills`. Built-ins are baked into the binary and cannot be removed by any profile. |
| 6 | Does user memory relocate? | **NO — memory is `$HOME`-anchored.** `/context` showed `~/.claude/CLAUDE.md` (12 tok) and `~/.claude/RTK.md` (369 tok) loaded despite the swap. |

**Finding 6 is the surprise and it constrains the product**: a config-dir swap
isolates MCP and skills but NOT user memory. The user's global `CLAUDE.md`
(and anything it `@`-imports, e.g. RTK.md) loads in every profiled session.
A profile can therefore ADD rules but cannot SUPPRESS the user's global rules
via the swap. No supported suppression mechanism is known — `--setting-sources`
governs settings, not memory. Open sub-question for run 2: does a `CLAUDE.md`
placed *inside* the config dir load as well (additive), or is it ignored?

**NOT YET ANSWERED — the decisive refresh-rotation test.** Run 1's step 4 hit a
harness bug: the script called `timeout`, which does not exist on macOS (no
coreutils), so both probes exited 127 without running, and the verdict logic
misread rc≠0 as an auth failure. **The printed "ROUTE A IS DEAD" verdict was
false and carries no information.** Script now uses a bash-3.2 `run_probe`
helper and aborts loudly on rc=127 instead of concluding. Re-run required.

## Auth spike — run 2 (2026-08-01): NO VERDICT, plus three real findings

Run 2 produced no rotation answer. Two harness bugs and a wrong binary. What it
did surface is more valuable than the test it failed to run.

### F1 — TWO claude installs; login shell resolves the stale one

```
/opt/homebrew/bin/claude  -> /opt/homebrew/lib/node_modules/@anthropic-ai/claude-code/cli.js  = 1.0.120 (Sep 2025)
~/.nvm/versions/node/v22.12.0/bin/claude                                                       = 2.1.220 (current)
```

`zsh -lic 'which -a claude'` puts homebrew first → **run 2 tested claude 1.0.120**,
so all of its output describes a year-old binary and is discarded.

**This is a product bug, not just a spike bug.** `fixup_gui_path()` resolves the
login-shell PATH at app startup, so the worktrees app launches whatever the login
shell resolves — here, 1.0.120. Consequences for the feature:
- Profiles compose flags (`--append-system-prompt-file`, `--strict-mcp-config`)
  that do not exist in older claude. Launching them against 1.0.120 fails at best,
  silently misbehaves at worst.
- **The launcher must record the resolved claude path + `--version` per session**
  (already planned for the app log) and the app should warn when the resolved
  binary is below a known floor. Add a `doctor` check for multiple claude installs
  on PATH — this will bite other users, not just this machine.

### F2 — Cherry-picking onboarding flags does not work; copy `.claude.json` wholesale

The seed set `hasCompletedOnboarding` + `theme` + `oauthAccount` +
`projects[wt].hasTrustDialogAccepted` + `hasCompletedProjectOnboarding`, and the
pane still blocked on an undocumented dialog:

```
Allow external CLAUDE.md file imports?
  This project's CLAUDE.md imports files outside the current working directory.
  External imports: /Users/davidpena/.claude/RTK.md
```

The real `~/.claude.json` project entries carry 23 keys, including
`hasClaudeMdExternalIncludesApproved` and `hasClaudeMdExternalIncludesWarningShown`.
Enumerating them by hand is a losing game — claude adds gate flags across versions,
and each unknown one is a tmux pane frozen on a dialog with no error surfaced.

**Materializer design change (supersedes the cherry-pick plan):** copy the user's
real `~/.claude.json` wholesale into the snapshot, then `del(.mcpServers)` (the
profile owns MCP via `--mcp-config`), `del(.projects)` (drop other repos), and add
one trust entry for the target worktree. Every accepted-terms / onboarding /
warning-suppression flag is inherited automatically, including future ones.

Note this also confirms **the external-imports dialog is triggered by the user's
own `~/.claude/CLAUDE.md` importing `~/.claude/RTK.md`** — consistent with run 1's
finding that user memory is `$HOME`-anchored and loads under the swap.

### F3 — Both false verdicts were the script's, and why

| Run | Printed | Actual cause |
|---|---|---|
| 1 | "ROUTE A IS DEAD" | `timeout` does not exist on macOS → both probes rc=127, never executed |
| 2 | "ROUTE A IS DEAD" | profiled rc=1 = **terms-acceptance gate** (not auth); original rc=137 = **SIGKILL from the script's own 90s watchdog** because `claude -p` inherits stdin and blocks on an open TTY |

Fixes applied: probes redirect `</dev/null`; a `classify()` function distinguishes
TIMEOUT / HARNESS_BUG / TERMS_GATE / AUTH_FAIL / OK; the verdict table refuses to
conclude anything from a probe that did not run. **Rule for this spike: a nonzero
exit code is not evidence of an auth failure.**

### Restructured spike — Test A first, and it may delete the whole problem

The rotation risk exists only if worktrees must COPY the token. On macOS claude
stores credentials in the keychain under a **fixed service name**
(`Claude Code-credentials`) that has no relationship to the config dir. If claude
still reads the keychain under `CLAUDE_CONFIG_DIR`, worktrees never touches
credentials at all — no copying, no rotation risk, no secret handling.

- **Test A** (`bash auth-spike.sh`) — swap with NO credentials planted.
  Credential-free, agent-safe. If it authenticates, Route A's blocker is gone.
- **Test B** (`--planted`) — only if A fails: plant credentials, verify zero dialogs.
- **Test C** (`--rotate`) — only if B is needed: the backdated-expiry rotation test.

Recon claimed an unplanted swap yields "Not logged in", but that came from the
agent whose methodology produced the credential incident; treat it as unverified.

## AUTH SPIKE — RESOLVED (2026-08-01, claude 2.1.220). Route A is viable.

**Claude derives a per-config-dir keychain service name.** On macOS credentials
live in the login keychain, never in a file. The service name is
`Claude Code-credentials` for the default `$HOME` config, and
`Claude Code-credentials-<8 hex>` for a directory named by `CLAUDE_CONFIG_DIR`.

Evidence — `security dump-keychain` after the spike:

```
"Claude Code-credentials"            cdat 01:16:46  mdat 01:31:28   <- user's main login
"Claude Code-credentials-1fbcb801"   cdat 00:44:23                  <- run 2 scratch cfg
"Claude Code-credentials-88cf516b"   cdat 00:44:32                  <- run 2 scratch cfg
"Claude Code-credentials-ec8e0248"   cdat 01:36:55                  <- /login inside profiled session
```

This reconciles every earlier observation:

| Observation | Explanation |
|---|---|
| Test A ("no creds planted") said **Not logged in** despite a valid keychain entry existing | claude looked for `…-ec8e0248`, which did not exist yet. The unsuffixed entry is a different item. |
| `/login` **inside** the profiled session succeeded | it ran a normal OAuth flow and stored the result under the derived service name. |
| No `.credentials.json` ever appeared in the config dir | macOS uses the keychain exclusively; a *planted* file is migrated into the keychain and removed (see the 00:44 entries). |
| Relaunch under the same config dir came up **"Claude Max", no prompt** | the derived keychain entry persists. Login is one-time per config dir. |
| The user's main credential was untouched | its mdat (01:31:28) predates the profiled login (01:36:55). Separate items, no shared state. |

### Consequences — these override earlier plan entries

1. **Route A (CLAUDE_CONFIG_DIR swap) is CONFIRMED VIABLE.** Route B is dropped.
2. **worktrees never handles a credential.** No copying, no `security` calls, no
   plain-JSON tokens, no `.credentials.json` in the materializer. The product's
   credential-handling surface is **nil**. This is strictly better than every
   design considered — the earlier "copy the token into the profile dir" plan is
   deleted, along with its rotation risk.
3. **Refresh-token rotation risk: ZERO.** Profiles get their own keychain items;
   nothing a profiled session does can invalidate the user's normal login.
   **Test C is permanently moot** and is removed from the spike.
4. **Cost: one `/login` per profile, once.** First launch of a new profile shows
   `Not logged in · Run /login` in the pane; after that it persists. The UI should
   pre-empt this — mark a never-launched profile "needs one-time sign-in" rather
   than letting the pane look broken.
5. **NEW REQUIREMENT — keychain GC.** Deleting a profile must delete its derived
   keychain item, or orphaned live OAuth tokens accumulate. Three orphans already
   exist from purged scratch dirs. The derivation is an 8-hex hash of the config
   dir path; worktrees should record the service name at first launch rather than
   trying to reimplement the hash (which is undocumented and may change).
   Cleanup command: `security delete-generic-password -s "<service>"`.
6. **Profile identity is per config dir, so profile dirs must be STABLE**, not
   per-launch snapshots — a fresh snapshot dir per launch would demand a fresh
   `/login` every time. This CONTRADICTS the immutable-per-launch-snapshot design.
   Revised: the profile's config dir is stable and long-lived; only the
   rules/settings/MCP *files inside it* are rewritten at launch. Combined with the
   user's symlinked-skills decision, nothing about the dir identity changes.

### The one real limitation of Route A

User memory is `$HOME`-anchored and loads regardless of the swap. `/context` on
2.1.220 showed `~/.claude/CLAUDE.md` (12 tok) and `~/.claude/RTK.md` (369 tok)
inside a swapped session, and claude 1.0.120 additionally raised an
"Allow external CLAUDE.md file imports?" dialog naming `~/.claude/RTK.md`.

So a profile can **add** rules but cannot **suppress** the user's global
`CLAUDE.md` / its `@`-imports. No supported suppression mechanism is known
(`--setting-sources` governs settings, not memory). Document this in the profile
editor; the workaround for a true clean slate is for the user to empty their
global `CLAUDE.md` and move that content into profiles.

Still open (non-blocking, cosmetic): does a `CLAUDE.md` placed *inside* the config
dir load additively as user memory? Not needed — `--append-system-prompt-file` is
already the chosen rules channel.

## Phase 3 — storage location: DEVIATION from the recon plan

The synthesis said `profiles.json` goes in the **app config dir**
(`~/Library/Application Support/net.casadelvalle.worktrees/`, via Tauri's
`app_config_dir()`), as a sibling of `ui-state.json`. Shipped instead in
`~/.config/worktrees/profiles.json`. Reason:

That recommendation contradicts the locked decision that **worktrees-core owns
profile resolution** so `worktrees open` and the app launch identically.
`app_config_dir()` is a Tauri API; core has no `AppHandle`, so core would have to
hardcode a macOS-specific Application Support path — wrong on Linux, where the
CLI also ships. `~/.config/worktrees/` is already core's user-config root
(`config.rs:60-80`), and that module's own docstring sets the convention this
file follows exactly: *"human files are TOML, machine files are JSON."*

Two locations, split on config-vs-data:

| Path | Holds |
|---|---|
| `~/.config/worktrees/profiles.json` | declarations (small, JSON, hand-editable) |
| `$XDG_DATA_HOME/worktrees/profiles/<id>/` | materialized `CLAUDE_CONFIG_DIR` |

The materialized dirs are **data, not config**: claude writes transcripts, caches
and shell snapshots into them without bound, and burying gigabytes of history in
`~/.config` would ambush anyone who backs up their dotfiles.

⚠ `profile_dir(id)` is an IDENTITY, not just a location — the keychain service
name is derived from that path. Changing the scheme, or renaming an `id`,
silently invalidates the profile's login. Hence `id` is immutable after creation
and `name` is what the user renames.

### Node version note

`app/` requires pnpm ≥ Node 22.13; nvm's default here is v22.12.0 (which is also
where the `claude` 2.1.220 binary lives). Use v22.23.2 for `pnpm install` / `tsc`.
