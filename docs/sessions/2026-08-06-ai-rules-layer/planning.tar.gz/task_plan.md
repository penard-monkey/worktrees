# Task plan — AI rules layer (Claude profiles managed by worktrees)

## Goal

Let the user define **AI profiles** in the worktrees UI — rules text, skills, MCP
servers, settings/model — and have worktrees launch `claude` in a worktree pane
with that profile instead of the user's normal global `~/.claude` setup. Normal
terminal `claude` use is untouched.

## Amendments — user decisions after recon (2026-08-01)

These OVERRIDE the synthesis where they conflict. `findings.md` still reflects the
recon's original recommendation; this section wins.

1. **No deferrals — build the full surface on this branch.** Phases 11-13
   (git-URL skill installs, MCP repo-write/destructive tools + run_gates,
   structured export/import) move into scope. Expect a large PR; fable reviews
   before squash-merge.
2. **Skills SYMLINK into the snapshot, live-follow.** Overrides the recon's
   copy-at-launch recommendation. Consequences accepted and now design constraints:
   - claude hot-watches skills, so store edits reach RUNNING sessions immediately.
     That is the point — no restart to tweak a skill.
   - The stale badge therefore covers only rules / settings / MCP / model changes.
     It must NOT claim to cover skills. Label it accordingly in the UI.
   - Removing a skill from the store while a session is live leaves a dangling
     symlink. Spike item (7) — claude's behavior on dangling skill symlinks — is
     now BLOCKING, not informational. If it crashes or errors noisily, the store's
     remove path must refuse (or warn hard) while a session references the entry.
   - Rules/settings/MCP snapshots stay immutable per launch. Only `skills/` is live.
3. **Auth spike step 1 is run BY HAND by the user.** No agent reads the keychain.
   Script: `~/.cache/worktrees/worktrees/ai-rules-layer/auth-spike.sh`.
4. **Credential incident cleanup: rotate first, then purge.** User runs
   `/logout` + `/login`; only after that does the transcript + scratch get deleted.

5. **AUTH SPIKE RESOLVED (2026-08-01) — Route A confirmed, Route B dropped.**
   Claude derives a per-config-dir keychain service name
   (`Claude Code-credentials-<8hex>`), so each profile gets its OWN credential,
   obtained by a one-time `/login` inside the pane. Therefore:
   - **worktrees never touches a credential.** Delete every credential-copying
     step from the materializer. No `.credentials.json`, no `security` calls.
   - Rotation risk is zero; the user's main login is a separate keychain item.
   - Phase 2's hard gate is CLEARED. Phase 5 (materializer) is unblocked.
   - **Profile config dirs must be STABLE, not per-launch snapshots** — a new dir
     means a new keychain identity and a fresh `/login`. Rewrite the
     rules/settings/MCP files inside a stable dir instead. (Supersedes the
     immutable-snapshot decision; staleness still keys off profile `updated_at`.)
   - NEW: deleting a profile must GC its keychain item, recorded at first launch.
   - NEW: first launch of a profile shows `Not logged in` — the UI must label a
     never-launched profile "needs one-time sign-in" so it doesn't look broken.
6. **Global user memory cannot be suppressed.** `~/.claude/CLAUDE.md` and its
   `@`-imports load inside a swapped session (verified 2.1.220). Profiles ADD
   rules; they cannot remove the user's global ones. Document in the editor.
7. **Version floor + PATH hazard.** Two claude installs existed here; the login
   shell resolved a stale 1.0.120, which `fixup_gui_path()` would have handed the
   app. Record the resolved binary path + `--version` per session, warn below a
   floor, and add a `doctor` check for multiple claude installs on PATH.

## Locked decisions

See `findings.md` §1 for the full settled table with evidence. Headlines:

- **How is profile rules text delivered to claude?** — --append-system-prompt-file pointing at a materialized <snapshot>/rules.md. Never inline argv, never a CLAUDE.md written into the worktree, and not dependent on the config-dir swap. 'Inherit default rules' (if added) = file concatenation at materialization.
- **How are profile MCP servers delivered?** — --mcp-config <snapshot>/mcp.json on the launch line, adding --strict-mcp-config when the inherit-global-MCPs toggle is OFF. When inherit is ON, the materializer merges global mcpServers from ~/.claude.json into the snapshot mcp.json (copy semantics, consistent with the stale-badge model). Never rely on .claude.json relocation for MCP.
- **Config-dir swap (Route A) or flags-only (Route B) as the materializer mechanism?** — Target Route A (CLAUDE_CONFIG_DIR swap) as primary — it is the only mechanism that delivers the locked 'full swap' semantics cleanly (skills dir, settings, isolated history) — but it is GATED on the auth spike, with Route B (--settings + --setting-sources + --add-dir skillhost + the already-settled rules/MCP flags) pre-designed as the fallback. Rules and MCP channels are identical under both routes, so the fork is narrowed to skills + settings + history isolation.
- **How is env/flag injection done without breaking session adoption and auto-resume?** — Restructure resolution: resolver returns a struct { env: Vec<(k,v)>, cmd: String, match_word: String }. Env is composed inside the existing sh -ic string (e.g. `CLAUDE_CONFIG_DIR='<dir>' claude --settings ... --append-system-prompt-file ...`); adopt_ai_word, ai_is_claude, and session_in preference all read match_word ('claude'), never the launch string. Do NOT use `tmux new-session -e` in v1 (shim churn + version-floor audit for no benefit — env baked into the process survives detach/reattach by definition). Profile flags go AFTER the resume arg or the three adjacency assertions are updated deliberately in the same PR.
- **What happens to resume detection and busy/waiting dots under a swapped config dir?** — In the SAME change that sets CLAUDE_CONFIG_DIR, claude_dir_for (project.rs:544-560) and the activity scan (lib.rs:709-716) take the effective config dir for the place's bound profile, falling back to $HOME/.claude. This is a Phase-4 exit criterion, not a follow-up.
- **Do CLI launches (`worktrees open`) get profiles?** — Yes — worktrees-core owns profile resolution. Core gains a reader for profiles.json (app config dir path) as a new rung in the resolve chain, following the prefix-chain project-tier pattern (config.rs:150-170), so CLI and app launch identically.
- **Where do profiles live and who owns the schema?** — profiles.json — a sibling file in the app config dir, backend-typed serde structs (readable by core at launch), containing profiles, the root→profileId assignments map, and default_id, all in one exportable unit. Never inside ui-state.json, never in committed .worktrees.toml. Exports ALWAYS exclude .credentials.json / oauthAccount material.
- **How does stale detection work, given claude hot-watches its config files?** — Materialize an IMMUTABLE per-launch snapshot dir (never re-render a dir a live session references; GC old snapshots). Skills are COPIED into the snapshot, not symlinked — true freeze semantics. Staleness = profile source version (save_profile stamps updated_at; compare against the stamp recorded at launch / declared.last_opened_epoch), computed frontend-side with zero new polling. Drop the planned content-hash of the materialized dir entirely.
- **How does the built-in worktrees MCP server ship?** — `worktrees mcp` subcommand on the existing CLI binary, stdio transport, rmcp 3.x (pinned major; features server/transport-io/macros/schemars), deps in worktrees-cli ONLY (core stays sync; ops called via spawn_blocking on a current-thread runtime), scope pinned at startup to CLAUDE_PROJECT_DIR/cwd. v1 tool surface: read-only (list_places, place_status, session_status, doctor) + metadata-write (set_note/set_pin/set_lifecycle). Repo-write/destructive tools (create/remove/relaunch, confirm-token tiers) and run_gates are v2. The materializer writes the stanza {"type":"stdio","command":"<abs path>","args":["mcp"]} into snapshot mcp.json, resolving the path at materialize time (app: lib.rs:762-778 probe; CLI: current_exe()), and materializes WITHOUT the stanza + a warning if no binary resolves.
- **Skill store scope for v1?** — v1: worktrees-owned store with LOCAL-PATH installs (copied into the store, validated: frontmatter parse, lowercase name rules, case-insensitive collision check, reject internal symlinks, size cap, loud warnings on hooks:/allowed-tools:/scripts/) plus the inherit-global-skills toggle (copy non-colliding entries of ~/.claude/skills into the snapshot). Git-URL installs (sha pinning, multi-skill-repo picker, update diff-review UI) are v2 — same store.json schema with source kind field so no schema break. Bare skills only; no plugins.
- **Adapter trait now or later?** — v1 ships a struct boundary — resolve to { env, argv, snapshot_dir, match_word }, with an if-branch: match_word == 'claude' → claude adapter composes the recipe; anything else → launch unmodified (which is today's behavior already). Trait extraction happens when a second tool actually arrives; no registration machinery for codex now.
- **How does first launch avoid interactive onboarding/trust dialogs?** — The materializer pre-seeds snapshot .claude.json with hasCompletedOnboarding, theme, oauthAccount (copied from ~/.claude.json), and a per-WORKTREE trust entry added at launch time (paths differ per worktree, so this recurs per place, not per profile). Exact trust-key shape is a spike deliverable (inspect ~/.claude.json projects{} and replicate). Phase-5 exit criterion: a profiled launch reaches the claude prompt with zero dialogs.
- **Export/import in v1?** — v1 'export' = Reveal profiles.json / profile dir in Finder (opener:default already grants revealItemInDir). Structured export/import with pickers, credential scrubbing, path re-resolution, and skill re-fetch is v2 — and the dialog SAVE permission (dialog:default coverage) must be verified before wiring it.

## Phases

Phase 2 is a **hard gate**: no materializer code until the auth spike settles Route A vs B.

- [x] **Phase 1 — Recon (done)**
      Six recon lanes + two adversarial reviews complete; findings.md replaced with the synthesis below.
- [ ] **Phase 2 — Verification spike (HARD GATE, ~0.5-1 day, manual)**
      ⚠️ CREDENTIAL POLICY: step (1) as designed reads the real OAuth token out of the keychain —
      that is what tripped the security flag on 2026-08-01. Do NOT let an agent do it. Either the
      user runs step (1) by hand, or we test with a throwaway Claude account, or we skip it and
      take Route B. Everything else in the checklist is credential-free and agent-safe.
      Decides Route A vs Route B before any materializer code. Checklist: (1) real keychain blob (`security find-generic-password -s "Claude Code-credentials" -w`) → profile .credentials.json → interactive tmux session → /context + /mcp correct → ORIGINAL claude still authenticates afterwards (refresh-rotation check); (2) same with a SYMLINKED shared .credentials.json; (3) trust/onboarding pre-seed keys (replicate ~/.claude.json projects{} shape, confirm zero dialogs); (4) is $CLAUDE_CONFIG_DIR/CLAUDE.md loaded as user memory; (5) do user-scope mcpServers relocate (`claude mcp list` under swap); (6) does --add-dir load skills (Route B fallback); (7) claude behavior on dangling skill symlinks; (8) concurrent claude writers on one .claude.json. Record every result + `claude --version` in findings.md. Output: the Route decision.
- [x] **Phase 3 — Data model + storage** ✅ DONE 2026-08-01
      Profile serde structs in core (or a core-readable crate module); profiles.json in app config dir with {profiles, assignments: root→profileId, default_id}; save stamps updated_at; core-side reader keyed off the app config dir path as a new rung in the resolve chain (prefix-chain project-tier pattern, config.rs:150-170, with *_from pure-function tests). Also DECIDE and document the pane0 grammar here (env inside -ic string; profile flags after resume arg) because Phases 4-6 build to it.
- [x] **Phase 4 — Core launch surgery** ✅ DONE 2026-08-01 (adversarial review in flight)
      Resolver returns {env, cmd, match_word}; ops::launch composes env inside the -ic string; adopt_ai_word (project.rs:515), ai_is_claude (lib.rs:469), and ops.rs:86 all read match_word; claude_dir_for + claude_activity take the effective config dir (fallback $HOME/.claude); fake-tmux shim untouched (no -e) but the three adjacency assertions (open.bats:86, new.bats:270, misc.bats:430) and pane0-shape tests updated to the new grammar IN THE SAME PR. Exit: `make test` green, adoption + auto-resume verified against real tmux manually.
- [x] **Phase 5 — Materializer** ✅ DONE 2026-08-02 (adversarial review in flight)
      Render profile → immutable per-launch snapshot dir in app config dir: rules.md, settings.json, mcp.json (incl. merged global MCPs when inheriting, worktrees stanza when binary resolves), skills/ (copies: profile store skills + non-colliding inherited globals), pre-seeded .claude.json (+ per-worktree trust entry at launch), credentials per spike outcome (chmod 600). Never re-render a live-referenced dir; GC old snapshots. Record profile updated_at into the launch record for the stale badge. Exit: profiled launch reaches the prompt with zero dialogs; snapshot contents assertable in bats (pure fs, no claude needed).
- [x] **Phase 6 — Claude adapter** ✅ DONE 2026-08-02 (flag flipped; review in flight)
      Struct boundary {env, argv, snapshot_dir, match_word}; claude branch composes: [Route A: CLAUDE_CONFIG_DIR=<snapshot>] + --settings <snapshot>/settings.json + --mcp-config <snapshot>/mcp.json [+ --strict-mcp-config] + --append-system-prompt-file <snapshot>/rules.md [+ --model X] [+ Route B extras: --setting-sources, --add-dir]; resume arg composes correctly on both open_place and cmd_open -r paths; non-claude match_word → launch unmodified; per-session `claude --version` recorded in the app log.
- [x] **Phase 7 — Skill store** ✅ DONE 2026-08-02 (local + git; review in flight)
      skills-store/<name>/ + store.json manifest in app config dir; local-path install COPIES into store; validation: frontmatter parse, spec name rules (lowercase, dir-name match), case-insensitive collision check (APFS), reject internal symlinks, size/file-count caps, loud warnings on hooks:/allowed-tools:/scripts/; remove drops the entry and reports which profiles referenced it; store never executes installed content.
- [x] **Phase 8 — worktrees MCP server** ✅ DONE 2026-08-05 (hand-rolled; review in flight)
      First a spike: rmcp 3.x MSRV + binary-size/build-time delta on the 4 release targets. Then `worktrees mcp` (stdio, ~500-800 LOC in crates/worktrees-cli/src/mcp.rs): read-only tools (list_places, place_status, session_status, doctor — readOnlyHint, compact outputs under the 25k-token cap) + metadata-write (set_note/set_pin/set_lifecycle via store::edit); scope pinned to CLAUDE_PROJECT_DIR/cwd at startup; CaptureUi/run_op wrapper; tested by piping JSON-RPC into the binary under the bats fake shims. Materializer starts emitting the stanza when this lands.
- [x] **Phase 9 — UI** ✅ DONE 2026-08-05 (review in flight)
      Settings CATS entry {id:"ai", label:"AI profiles"} + editor block (module-scope component, ProjectSheet pattern, plain CSS reuse); ProjectSheet .setting section with profile <select> (+ '(global default)'); topbar profile-name chip + stale badge next to .live-badge (App.tsx:2158-2160) with statusbar echo; adopted-unprofiled-session indicator; 'switching profiles starts fresh history' note in the picker; grey-out for non-claude ai_cmd; Reveal materialized config; commands list_profiles/save_profile/delete_profile/set_project_profile/profiles_info + skill install/remove — EVERY one with a stateful sessionStorage-backed mock case in install.ts (Playwright-drivable). Distinct basenames (ProfilesSheet.tsx, never Profiles.tsx vs profiles.ts).
- [x] **Phase 10 — Gates, docs, manual checklist**
      Harness updates already landed inside Phases 4-6 PRs; this phase is: DESIGN.md section for the third state category (app-declared profile state, alongside derived/declared), 'a profile is not a sandbox against repo-committed .claude/ config' documentation, the written manual verification checklist gated on `claude --version` (config loading, onboarding skip, auth, hot-watch, MCP acceptance are untestable in CI — no fake-claude shim exists), CHANGELOG, close-out.
- [x] **Phase 11 (v2) — Git-URL skill installs** **(was v2 — now in scope)**
      Shallow clone → pin by commit sha (Anthropic's own plugin system records gitCommitSha) → multi-skill-repo picker → mandatory pre-enable SKILL.md review → update = sha diff + SKILL.md unified diff on confirm; scrubbed-env git (GIT_TERMINAL_PROMPT=0) with timeout; shallow-sha-fetch fallback path tested.
- [x] **Phase 12 (v2) — MCP repo-write/destructive tools + run_gates** **(was v2 — now in scope)**
      create_worktree/open_session/close_session/relink/provision/remove_worktree behind the profile's 'allow worktree mutations' toggle (--mutations arg in the stanza); confirm:true required for destructive (EXIT_NEEDS_CONFIRM → structured needs_confirm); run_gates needs a new gates key in .worktrees.toml first.
- [x] **Phase 13 (v2) — Structured export/import** **(was v2 — now in scope)**
      Export excludes credentials by construction; import re-resolves absolute MCP command paths and re-fetches/relinks skill-store references with defined behavior for unreachable sources; verify dialog:default covers the save dialog or use fixed-dir + reveal.

## Risks

- Auth fork (top risk): refresh-token rotation under a profile's .credentials.json copy may invalidate the user's keychain original, logging their normal claude out — untested with a real token; the shared-symlink mitigation is also unverified. The entire Route A decision hangs on the Phase-2 spike.
- Setup-token fallback is capability-degraded: CLAUDE_CODE_OAUTH_TOKEN sessions are scoped user:inference only — verified to disable Claude-in-Chrome and claude.ai connectors, both of which this user demonstrably uses. If the spike fails, the fallback degrades the primary user's own workflow.
- Silent adoption/auto-resume breakage: ai_word derivation in three synced sites + substring matching means any mis-ordered launch-string change degrades session adoption and disables auto-resume with no error anywhere; the `cmd == "node"` special case additionally makes any node process in a worktree adoptable as the AI pane.
- Blind probes: claude_dir_for (~/.claude/projects) and the activity scan (~/.claude/sessions) are HOME-anchored; forgetting the redirect in any code path silently kills resume detection and busy dots for profiled sessions.
- Live-watch vs stale badge: claude hot-watches settings and skills — any mutation of a live-referenced dir changes the session immediately; only immutable per-launch snapshots keep the badge honest. Re-materializing a shared dir at session B's launch would mutate live session A.
- First-launch hang: un-pre-seeded profile dirs sit on theme-picker/login/trust dialogs inside the tmux pane; trust entries are per-worktree-path, so this recurs on every new worktree, not just profile creation.
- Test-harness fragility: ~15 bats tests pin the pane0 string, three assert resume-arg adjacency, and the fake tmux shim parses argv positionally — grammar changes must land with their assertion updates in the same PR or the suite breaks confusingly.
- CI blindness: no fake-claude shim exists; everything claude-side (config loading, auth, onboarding, hot-watch, MCP stanza acceptance) is untestable in `make test` and claude behavior is version-gated (2.1.216/2.1.218 changes observed) — regressions ship invisibly without the manual checklist + per-session version logging.
- Not a sandbox: worktree-committed .claude/settings.json, .claude/skills/, and .mcp.json still load under a swapped config dir (verified) — repo-injected behavior will be blamed on profiles unless documented in the editor UI.
- History orphaning: transcripts live under the active config dir's projects/; rebinding a worktree to another profile hides prior conversations from -r/auto-resume.
- Mixed-provenance sessions: an unprofiled terminal-launched claude in the same worktree gets adopted and displayed by the app as the place's session; without the adopted-unprofiled indicator, the profile chip lies.
- rmcp churn + binary weight: 58 releases since 2025-03 with a breaking 3.0 in July 2026 (~one migration/year), and rmcp+tokio+schemars enter a currently-sync CLI binary on 4 release targets — size/MSRV unmeasured until the Phase-8 spike.
- Skill store = prompt-injection surface by construction: even never-invoked skills load their descriptions at session start; hooks:/allowed-tools: frontmatter can pre-approve execution — v1's local-path-only scope contains this, v2's git installs must keep the review gate mandatory.
- Absolute paths go stale: the MCP stanza's CLI path and imported profiles' command paths break when binaries move or on other machines — re-resolve at every materialization and have doctor flag dead paths.

## Open questions — need the user

- If the Phase-2 spike fails (real-token auth unsustainable under CLAUDE_CONFIG_DIR): accept Route B flags-only with its semantic deltas (shared history/todos with global claude; user-scope suppression via --setting-sources), or accept the setup-token fallback knowing it disables Claude-in-Chrome and claude.ai connectors you actively use?
- OK to sequence git-URL skill installs into v2 (a locked content item, deferred not dropped), shipping v1 with local-path installs + inherit-global-skills? Same question for structured export/import (v1 = reveal-in-Finder) and for the MCP server's repo-write/destructive tools (v1 = read + metadata only).
- Confirm core-owned profile resolution: `worktrees open` from a bare terminal applies the same profile as the app (recommended; the alternative — CLI warns 'launching unprofiled' — forks behavior).
- Skills freeze semantics: copy-at-launch (recommended — stale badge stays honest, live sessions frozen) vs symlink live-follow (store edits reach live sessions immediately; badge scoped to structural changes only)?
- Does the '(main)' place participate in profiles, or is it always unprofiled? (open_place special-cases it at lib.rs:433-464.)
- Full-replace ergonomics: want a 'Duplicate from default' button and/or an optional third toggle 'inherit default rules' (pure file concatenation, not a merge engine) to soften the fork-and-diverge trap, or strict replace with the drift behavior documented?
- Profile naming in the UI: 'AI profile' / 'Default profile' as proposed?
- MCP secrets stay plain-JSON per your call — confirm that .credentials.json/oauthAccount are the one exception, excluded from any export path forever.

## Next actions

- Run the Phase-2 spike (manual, ~half day): real keychain blob → profile .credentials.json → interactive tmux session → /context + /mcp → original claude still authenticates; then the symlinked-credentials variant; then trust-key shape, CLAUDE.md-as-user-memory, mcpServers relocation, --add-dir skills, dangling-symlink behavior. Record everything + claude --version in findings.md and stamp the Route decision.
- Write the pane0 grammar decision into findings/DESIGN notes: env inside the -ic string, profile flags AFTER the resume arg, match_word carried separately — and enumerate the exact bats assertions to update (open.bats:86, new.bats:270, misc.bats:430, misc.bats:404-441, open.bats:25-102, new.bats:258-286).
- Spike branch for rmcp: pin rmcp = "3" in worktrees-cli only, measure binary-size/build-time delta on darwin-arm64 at minimum, check rust-version in rmcp's Cargo.toml vs the repo toolchain.
- Start Phase 3: Profile serde structs + profiles.json read/write + resolver-struct design ({env, cmd, match_word}) with *_from pure-function tests, following the prefix-chain project-tier pattern at config.rs:150-170.
- Draft the manual verification checklist (claude-side behaviors untestable in CI), gated on `claude --version`, to live in docs and be re-run on claude upgrades.
- Get the user's answers to the open questions — especially spike-failure fallback preference and the v1/v2 deferrals — before Phase 5 (materializer) starts.

## Errors / incidents

| Item | Detail | Resolution |
|---|---|---|
| Recon agent credential access (2026-08-01) | `recon:claude-config-dir` ran `security find-generic-password` 12x against the real `Claude Code-credentials` keychain item while probing CLAUDE_CONFIG_DIR isolation; real token-shaped strings landed in its subagent transcript (`subagents/workflows/wf_36bc4aab-830/agent-a648950d47ad6ba68.jsonl`). Scratch dirs hold only `oauthAccount` metadata, no tokens. Keychain mtime updated same day — possible refresh rotation. | PENDING: rotate via `/logout` + `/login`, then purge transcript + scratch. Future spike prompts must forbid reading real credentials — use a throwaway account or metadata-only probes. |
