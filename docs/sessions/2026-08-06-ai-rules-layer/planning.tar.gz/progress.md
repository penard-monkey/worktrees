# Progress — AI rules layer

## Session 1 — 2026-08-01

- Branch `ai-rules-layer` off v0.6.0. Clean tree throughout — no code written yet.
- Scoped the feature with the user across two question rounds; eight design forks
  locked. Later additions: ship the worktrees MCP (yes), MCP secrets in plain
  JSON, and additive layering authorized as fallback if the swap costs a re-login.
- Ran recon workflow `wf_36bc4aab-830` — 9 fable agents (6 recon lanes, 2
  adversarial reviews, 1 synthesis), 847k tokens, 24 min. Results replaced
  `findings.md` wholesale and rewrote `task_plan.md` into a 13-phase v1/v2 plan.

### Outcomes

- Rules delivery settled: `--append-system-prompt-file` (verified interactive on
  claude 2.1.220, survives /clear, coexists with the repo's committed CLAUDE.md).
- MCP delivery settled: `--mcp-config` + `--strict-mcp-config`. Both channels work
  identically under Route A and Route B, so the swap decision no longer blocks them.
- The swap itself (Route A) is GATED on an auth spike — refresh-token rotation
  under a copied `.credentials.json` may log the user out of their normal claude.
- Two blockers found in existing code: `ai_word` is derived in three synced sites
  and substring-matched in `session_in`, so any env prefix silently kills adoption
  + auto-resume; and `claude_dir_for` / the activity scan are HOME-anchored, so a
  swap silently kills resume detection and busy dots.

### Incident

- The `recon:claude-config-dir` agent read real OAuth credentials from the macOS
  keychain (12 `security find-generic-password` calls) while probing isolation.
  Token-shaped strings are in its transcript at
  `subagents/workflows/wf_36bc4aab-830/agent-a648950d47ad6ba68.jsonl`.
  Scratch dirs contain only `oauthAccount` metadata — no tokens. Keychain mtime
  updated the same day, so a refresh rotation may have fired.
  PENDING user action: `/logout` + `/login` to rotate, then purge transcript +
  scratch. Spike prompts amended to forbid agent credential access.

### Next

- User to answer the open questions in `task_plan.md` (spike-failure fallback,
  v1/v2 deferrals, CLI parity, skills freeze semantics, `(main)` place, naming).
- Then Phase 2 spike (manual), then Phase 3 data model.

## Session 1 (cont.) — auth spike resolved

- Spike runs 1 and 2 both printed false "ROUTE A IS DEAD" verdicts — both were my
  script's bugs (macOS has no `timeout`; `claude -p` blocking on inherited stdin
  hit the watchdog and returned 137). Neither was evidence about auth.
- Run 2 also silently tested claude 1.0.120: a stale npm global under homebrew's
  node shadowed the real 2.1.220 in login-shell PATH. Product-relevant, since
  `fixup_gui_path()` resolves the same PATH.
- Run 3 (Test A, credential-free) answered it: claude derives a per-config-dir
  keychain service name. A `/login` inside the profiled pane created a separate
  keychain item and left the user's main credential untouched; relaunch under the
  same dir stayed logged in.
- **Route A confirmed. worktrees never handles a credential.** Route B dropped,
  Test C deleted, Phase 2 gate cleared.
- Design changes falling out: profile dirs must be stable (not per-launch
  snapshots), profile deletion must GC its keychain item, first launch needs a
  "one-time sign-in" affordance, and global user memory cannot be suppressed.

### Next

- Optional hygiene: 3 orphaned keychain items hold live tokens for purged scratch
  dirs. `security delete-generic-password -s "Claude Code-credentials-<hash>"`.
- Phase 3 — profile serde structs, profiles.json, `{env, cmd, match_word}` resolver.

## Session 1 (cont.) — Phase 3 complete

Added `crates/worktrees-core/src/profile.rs` (+ registered in core `lib.rs`).

- `Profile` / `Profiles` serde structs with `#[serde(flatten)] extra` on both, so
  an older build cannot clobber a newer one's keys (test asserts round-trip).
- Storage at `~/.config/worktrees/profiles.json` — NOT the app config dir; see
  the deviation note in findings.md (core owns resolution, so it must be readable
  without a Tauri `AppHandle`). Materialized dirs at
  `$XDG_DATA_HOME/worktrees/profiles/<id>/`.
- `sanitize_id` + `profile_dir` returning `Option`: a hand-edited profiles.json
  cannot aim the config dir at `../../etc`. Hostile-input test mirrors the
  existing `resolve_prefix_from` hostile-prefix test.
- `resolve_profile_id_from` pure fn: `$WORKTREES_PROFILE > assignments[repo] >
  default_id`, with `none` as an explicit chain-stopping opt-out and a dangling
  id degrading to unprofiled rather than erroring.
- `AiLaunch { env, cmd, match_word }` + `ai_word_of()` — the single source for
  the derivation currently duplicated at ops.rs:86, project.rs:515, lib.rs:469.
  Defined here; call sites get rewired in Phase 4.
- Storage mirrors `store.rs`: lenient read / strict write, dir-lock, atomic
  rename, in-process mutex.
- `remove()` returns the recorded keychain service instead of deleting it — core
  deliberately has no credential-touching code path.

Gates: release build ✓ · bats 238 ✓ · lint ✓ · core tests 148 (11 new) ✓ ·
tsc ✓ · cargo check -p app ✓. Working tree has the new module uncommitted.

### Next

- Phase 4 — core launch surgery: rewire the three ai_word sites to `match_word`,
  compose env inside the `sh -ic` string, redirect `claude_dir_for` +
  `claude_activity` to the effective config dir, update the three bats adjacency
  assertions in the same PR.

## Session 1 (cont.) — Phase 4 complete, PR open

PR #72 (draft) — https://github.com/penard-monkey/worktrees/pull/72
Commits: f5b663b (Phase 3), f2489ea (Phase 4).

Phase 4 — behaviour-preserving launch surgery:
- `ops::launch` takes `&profile::AiLaunch` instead of a bare `ai_cmd`. Env
  composes INSIDE the `sh -ic` string ahead of the command (not
  `tmux new-session -e`: the fake-tmux shim has no `-e` case, and process env
  already survives detach/reattach/server-restart).
- All three `ai_word` derivations delegate to `profile::ai_word_of`
  (ops.rs, project.rs `adopt_ai_word`, the app's `ai_is_claude`).
- `claude_session_present` → `Project::claude_session_present`, resolving the
  repo's effective config root; `claude_dir_in(root, dir)` replaces the
  `$HOME`-hardcoded `claude_dir_for`. `claude_root` threaded through
  `ls()` → `place_json_par` → `place_json`, resolved once per snapshot.
- The app's `claude_activity` scans EVERY config root, not just `~/.claude`.
  Probes carry their own cwd+pid so the union is self-describing.
- `ops::ai_launch_for` is the single seam every launch path goes through — CLI
  and app cannot diverge on which profile a place gets. Returns the plain launch
  today; the claude adapter fills env/flags in Phase 6.

Gates: release build ✓ · core tests 150 ✓ · bats 238 ok / 0 fail ✓ · lint ✓ ·
tsc ✓ · cargo check -p app ✓.

Adversarial review workflow `wf_16b45dd8-f87` in flight: 5 fable lenses
(adoption regression, probe threading, profile module, test coverage, parity)
→ per-finding refutation → ranked synthesis.

## Session 1 (cont.) — adversarial review of Phases 3+4, fixes landed

Workflow `wf_16b45dd8-f87`: 5 fable lenses → 20 candidate findings → each handed
to a separate skeptic prompted to REFUTE → 12 survived. Commit `1a4cb36`.

Must-fix (all real):
1. **`none` was claimable.** It is the unprofiled sentinel, but
   `sanitize_id("None") == "none"` passed `save()`, so a profile could own it and
   then resolve as "no profile" at every launch, silently. Now reserved in
   `save()` + `new_id_from`.
2. **`sanitize_id` kept a leading dash** while its own doc claimed it stripped
   one — `"@Work"` minted `-work`. Ids are permanent dir + keychain identity, so
   this had to be fixed before any can be minted. `config.rs::sanitize_prefix`
   carries the same false claim but is a faithful `tr -c` port → comment only.
3. **The seam was asymmetric — my bug.** Phase 4 redirected the PROBES to profile
   dirs while `ai_launch_for` still returned the plain launch. A profiles.json
   binding would make the app probe an empty dir while claude wrote to
   `~/.claude`: auto-resume stops passing `-r`, conversation appears lost, no log.
   Both sides now read `profile::launch_honors_profiles()` → flip in one commit.

Should-fix, also landed: `AiLaunch::pane0_body()` (the assignments-before-command
order was pinned by NO test — bats runs with an empty env, so reversing it passed
all 238 + 150); `claude_config_dirs_all` unions on-disk dirs so deleting a
profile mid-session doesn't kill the busy dot; `edit()` no longer downgrades
`version`; bats unsets `XDG_DATA_HOME` + `WORKTREES_PROFILE`.

Deferred (tracked): id length cap; profiled bats coverage lands WITH the adapter;
expose `profile` on `Place` for the UI when the adapter lands.

Gates: release ✓ · core 152 ✓ · bats 238/0 ✓ · lint ✓ · tsc ✓ · app ✓.
PR #72 body refreshed.

### Next

- Phase 5 — materializer: render a profile into its STABLE dir (rules.md,
  settings.json, mcp.json, skills/ symlinks, wholesale-copied .claude.json with
  mcpServers+projects stripped and a per-worktree trust entry added).

## Session 1 (cont.) — Phase 5: materializer (`397a7a2`)

Renders a Profile into its claude config dir. Nothing calls it yet — the adapter
lands in Phase 6 behind the same `launch_honors_profiles()` flag.

- Dir is STABLE (keychain identity); only the files inside are rewritten, each
  temp-then-rename because claude hot-watches the dir.
- `rules.md` (cleared rules DELETE the file, no stale rules left applying),
  `mcp.json` (globals merge only on request, never shadow the profile's own),
  `settings.json` when declared, `skills/` as symlinks (live-follow per the
  user's decision).
- `.claude.json` seeded WHOLESALE then stripped of `mcpServers` + `projects`.
  Confirmed from the real file: ~80 top-level keys, 40 project entries — and
  those entries carry `allowedTools`, so stripping also stops other repos'
  permission grants leaking into a profile.
- Re-materialization preserves what claude has since written (trust entries,
  counters), so a relaunch doesn't look like a first run.
- Missing skill / unresolvable binary → warning on `Materialized`, not an error:
  a stale reference must never strand the user with no session.
- `MatPaths` injects every filesystem location → 8 tests against real files in a
  temp dir, no env mutation (which would race under parallel test threads).
  This also answers the reviewer's earlier "storage has no test seam" gap for
  the materialization half.

Gates: release ✓ · core 160 ✓ · bats 238/0 ✓ · lint ✓ · tsc ✓ · app ✓.

Two adversarial reviewers running: correctness (JSON re-entry path, atomic-write
temp collisions, symlink TOCTOU, cfg(unix) gap, test honesty) and security
(path traversal, the two nested quoting layers, MCP stanzas as subprocess
command lines, PATH hijack in worktrees_bin, whether copying `permissions` into
a profile silently widens grants).

## Session 1 (cont.) — Phase 5 reviews landed (`8b053f1`)

Two adversarial reviewers (correctness + security). The security one found a
real regression I had introduced.

**SECURITY — trust was being invented.** materialize set
`hasTrustDialogAccepted` AND `hasClaudeMdExternalIncludesApproved` true for
every profiled worktree, before claude ever ran. That dialog is the only gate in
front of a repo's own `.claude/settings.json` hooks, `.mcp.json` and
`CLAUDE.md`; the external-imports flag additionally waves through `@`-imports
reaching OUTSIDE the repo, so a hostile cloned repo's CLAUDE.md could pull
`@~/.ssh/config` into context silently. **Enabling a profile was strictly weaker
than running claude normally** — the exact inverse of the point. Worse, the
asymmetry was self-evident: `projects` is stripped precisely so other repos'
`allowedTools` cannot leak in, and the next block granted an unreviewed repo the
strongest per-project flags available.
Now: trust is MIRRORED from the user's own `~/.claude.json` for that repo, never
invented; external-imports approval is never set at all.

Other security fixes:
- `.claude.json` seed now sweeps credential/identity-shaped keys and is written
  0600. The "worktrees never copies a credential" claim was ASSERTED; copying a
  file whose key set another vendor owns (and deliberately inheriting future
  keys) could not honour it. Now enforced by substring match + explicit identity
  list, with dropped key NAMES surfaced in warnings.
- Skill names validated as path components. `"../victim"` resolved its source to
  a real dir while planting the symlink OUTSIDE the profile dir, where the
  stale sweep (bounded to `skills/`) could never reclaim it. Ids had this
  validation; skill names came from the same file and had none.
- `worktrees_bin()` requires absolute + executable. An empty PATH component
  (which `fixup_gui_path` can emit) made `join()` yield relative `worktrees`,
  resolved against cwd — for `worktrees open` that is the cloned repo.
- Declarations whose map key ≠ their own `id` are dropped: `profiles["safe"] =
  {"id":"work"}` materialized into another profile's KEYCHAIN IDENTITY.

Correctness fixes: materialization now locks (mutex + DirLock) with unique temp
names — two launches could rename each other's half-written file into place;
weird/corrupt JSON degrades with a warning instead of failing the launch; ids
capped at 64; env var NAMES validated in `shell_prefix`; `shell_quote` made
pub(crate) so the adapter cannot interpolate `--model` unquoted.

Test honesty: the sweep guard was pinned by a DIRECTORY fixture, but
`remove_file` refuses a directory on unix regardless — it passed with the guard
deleted. Repinned with a plain file. Every new security test was verified to
FAIL with its fix reverted.

Gates: release ✓ · core 167 ✓ · bats 238/0 ✓ · lint ✓ · tsc ✓ · app ✓.

### Deferred to the import/share phase (reviewer's forward-looking finding)

A profile IS executable content: `mcp_servers` become subprocess command lines
and `settings.json` under a swapped config dir is the user-scope settings file,
where `hooks` live. Fine while the author is the user; NOT fine the day a
profile can be imported. Before import/share lands: show `command`/`args` and
`hooks` in a confirmation UI, default-drop `hooks`/`permissions` from imported
settings, and record `source: "imported"` provenance for a UI badge.

### Next

- Phase 6 — claude adapter: flip `launch_honors_profiles()`, compose
  `CLAUDE_CONFIG_DIR` + `--append-system-prompt-file` + `--mcp-config`
  [+ `--strict-mcp-config`] [+ `--model`], quote every profile-derived argument
  through `shell_quote`, and land the profiled bats coverage that only becomes
  observable once the flag is on.

## Session 1 (cont.) — Phase 6: the adapter, flag FLIPPED (`a8e6439`)

Profiles are now LIVE in both binaries. No UI yet — declare one by hand in
`~/.config/worktrees/profiles.json`.

Composed launch (claude only, when a profile resolves):

```
CLAUDE_CONFIG_DIR='<dir>' claude [-r] \
  --append-system-prompt-file '<dir>/rules.md' \
  --settings '<dir>/settings.json' \
  --mcp-config '<dir>/mcp.json' [--strict-mcp-config] [--model '<m>']
```

- Flags append AFTER the base command, so the ai-word/resume-arg adjacency the
  three bats assertions pin stays true.
- Env stays in `AiLaunch.env`, never glued to the command → `pane_current_command`
  is still `claude` → adoption + auto-resume intact.
- Every interpolated value goes through `shell_quote`; `model` is user-typed.
- `ai_cmd = none` and non-claude tools launch byte-identically to before.
- `ai_launch_for` now takes `ui` + worktree: materialization needs the worktree
  for its trust entry, and its warnings must surface rather than be swallowed.
  A failed materialization warns loudly and falls back to UNPROFILED — no
  session at all is worse, but the fallback is noisy because the user's rules
  and MCP set are not in effect. (Reviewer is being asked to argue fail-open.)

New `test/profile.bats` (8 tests) — the only tests that see a profiled launch,
since the rest of the suite runs `fake-ai` and describes the unprofiled path by
construction. Covers the swap, an ORDERED glob pinning env-before-program,
resume adjacency, real materialized files, `WORKTREES_PROFILE=none`, a
non-claude ai_cmd, and no profiles.json at all.

**Trap hit and worth remembering:** the first bats run failed mysteriously
because `bin/worktrees` prefers `target/release` and my last release build
predated the flag flip — exactly what CLAUDE.md warns about. Always
`cargo build --release -p worktrees-cli` FIRST.

Gates: release ✓ · bats 246 ✓ · lint ✓ · core 171 ✓ · tsc ✓ · app ✓.

### Next

- Phase 7 — skill store (install from local path, then git URL).
- Phase 8 — worktrees MCP server.
- Phase 9 — UI.

## Session 1 (cont.) — Phase 6 review: FAIL CLOSED (`46c573d`)

Reviewer's aggregate argument was the right one: fail-open + a warning nobody
sees + a guaranteed lock window + probes then describing the wrong root added up
to **the profile feature can quietly turn itself off**.

**Policy change: a failed materialization no longer launches unprofiled claude.**
Profiles are frequently RESTRICTIVE (`--strict-mcp-config` removing a dangerous
global server; settings carrying permission denies), so "could not apply your
profile" must never silently mean "ran without your restrictions" — while every
visible signal (pane running claude, activity dots) said it applied. It also
re-broke the seam: an unprofiled fallback writes to `~/.claude` while probes read
the profile dir, losing auto-resume. Pane now opens on a shell with the reason
printed; nothing stranded, user can run claude by hand.

Supporting fixes:
- App rendered warnings from SUCCESSFUL ops nowhere but app.log → now in the
  notice banner. Silence there read as "it worked".
- `MAT_LOCK` recovers from poisoning. App is long-lived: one panic under that
  lock turned every later launch into a failed materialization until restart —
  which, pre-fix, meant silently unprofiled.
- `DirLock` retry horizon (1.5s) could never outlast its staleness threshold
  (15s), so a SIGKILL mid-materialize broke launches for ~13.5s. Retries now
  exceed staleness; staleness → 3s.
- `~/.claude.json` (~135KB) parsed once per materialization, not three times.

Test gap closed: `--settings` was asserted ABSENT but never PRESENT — deleting
the flag passed every test, and that flag carries permission denies. The new
fail-closed bats test was verified to fail against fail-open.

Gates: release ✓ · bats 247 ✓ · lint ✓ · core 172 ✓ · tsc ✓ · app ✓.

### Carried forward to the UI phase (Phase 9)

- Assigning a profile to a repo with existing unprofiled history starts a COLD
  conversation (histories live under the config dir). Unavoidable; the
  assignment UI must say so before the user clicks.
- A never-launched profile shows `Not logged in` → label it "needs one-time
  sign-in" so it doesn't read as broken.
- Stale badge covers rules/settings/MCP/model only — NOT skills (symlinked,
  live-follow). Must be labelled accordingly.
- Profile deletion must GC its keychain item.

## Session 1 (cont.) — Phase 7: skill store (`567c06f`)

`crates/worktrees-core/src/skillstore.rs` + `worktrees skills` CLI. Manifest at
`~/.config/worktrees/skills.json`, content at `$XDG_DATA_HOME/worktrees/skills/`.
Local-path AND git-URL installs both landed (user chose no deferrals).

Framing that drove the design: **a skill is instructions the model reads, not
inert data.** An enabled skill's description loads at session start before
anything invokes it, and `allowed-tools` pre-authorises tool use — so installing
from a URL is closer to running someone's prompt than copying a file.

- Install never executes anything from the source. No build step, no
  post-install hook, `--recurse-submodules=no`, and the git path checks out
  nothing but the tree.
- Capabilities surfaced, not swallowed: `allowed-tools`, `hooks`, and executable
  files are recorded on the entry and printed at install. **A git install with
  capabilities REFUSES without `--yes`** — review happens before it lands.
- Git installs pinned to the exact commit, so an update can be a reviewable diff.
- Validation is refusal, never repair: SKILL.md + `---` frontmatter required;
  frontmatter name MUST match the directory (claude finds by directory and the
  frontmatter also names them — guessing which wins installs something under a
  name the user never read); lowercase-only names (APFS is case-insensitive, so
  `Foo`/`foo` = one dir, two manifest entries); **symlink anywhere inside is
  rejected** — the materializer links a skill into a dir claude reads, so a link
  named `notes.md` → `~/.ssh/id_rsa` would put a key where the model looks.
- Installs stage-and-swap (claude hot-watches the dir); a failed install leaves
  the previous version intact.
- `worktrees skills` runs ahead of the git guards — the store is user-global.
- Removing a skill a profile still lists is ALLOWED (a bad skill must be
  removable) but names the affected profiles.
- `StorePaths` injects both locations, so install/remove — which move and delete
  directories — are tested without touching the developer's real store.

Gates: release ✓ · bats 255 (8 new) ✓ · lint ✓ · core 190 (18 new) ✓ · tsc ✓ · app ✓.

Adversarial review running: path safety around `remove_dir_all`/`stage_and_swap`,
whether the symlink refusal is airtight (TOCTOU, hardlinks, `.git` walked but not
copied), and above all whether a capability can HIDE from the hand-rolled
frontmatter scanner — if it can, the review gate is theatre.

## Session 1 (cont.) — Phase 7 review: the gate was theatre (`+1 commit`)

Reviewer found, with a repro, exactly the failure I flagged as most important.

**Capability hiding.** claude parses frontmatter as real YAML, where
`"allowed-tools":` is the same key as the bare form. My scanner string-matched
the bare spelling → a quoted key reported ZERO capabilities → the git `--yes`
gate never tripped and `list`/`show` showed nothing, while claude still
pre-authorised the tools.

Fix: **allow-list, not deny-list.** `name` and `description` are the only keys
treated as harmless; everything else is surfaced, including keys this code has
never heard of. A deny-list can always be spelled around; an allow-list can only
be noisy, and noise is the safe direction for a review gate. Keys are also
normalised the way YAML sees them (quotes stripped, case folded, `_`≡`-`).

**Git transport execution.** `ext::<cmd>` RUNS that command during clone, before
any inspection. Not caught by the `-` screen, and whether it's permitted came
from the user's own `~/.gitconfig` — so the "never executes anything from the
source" invariant rested on config the module doesn't own. Now the
transport-helper shape is refused (anchored so IPv6 URLs aren't collateral) and
the clone pins its own protocol allow-list. Also `--recurse-submodules=no` was
the wrong spelling (git reads it as a pathspec — it never disabled anything).

Plus: fail-if-exists unique clone temp dir; `inspect` skips `.git` like the copy
does; `add --rev main /path` no longer resolves the dir to "main".

Test honesty: the quoted-key bypass regressed fully green (every test used the
bare spelling). Now covered in four spellings + end-to-end bats, verified to FAIL
against the old scanner. `staging_dirs_are_not_mistaken_for_skills` asserted
something that could not fail (`list` reads the manifest, not the store dir) —
replaced with a real leftover-dirs check.

Gates: release ✓ · bats 258 ✓ · lint ✓ · core 195 ✓ · tsc ✓ · app ✓.

### Next

- Phase 8 — worktrees MCP server (`worktrees mcp`, stdio, rmcp 3.x).
- Phase 9 — UI. Phase 10 — docs + manual checklist.

## Session 1 (cont.) — Phase 8: worktrees MCP server (`fc42cb8`)

`worktrees mcp` — stdio MCP server in `crates/worktrees-cli/src/mcp.rs`.

**The rmcp spike said don't.** Measured: CLI dep tree is 32 crates; rmcp
(server + transport-io + macros + schemars) resolves to **124**, and pulls
`tokio` into a deliberately-sync binary. rmcp shipped a breaking 3.0 in mid-2026
(~one migration/year) and the CLI ships 4 targets. What it buys is a
newline-delimited JSON-RPC 2.0 loop — and serde_json is already a dep. Core's
Cargo.toml refuses git2/gix and clap for smaller reasons.

Hand-rolled cost, measured: **+197KB** (1.91MB → 2.11MB), **zero new crates**.

Wire format was READ OUT OF rmcp's vendored source, not guessed: framing,
initialize/tools-list/tools-call shapes, annotation field names, protocol
version list (supports 2024-11-05 … 2025-11-25).

Safety shape:
- Repo pinned at startup from `CLAUDE_PROJECT_DIR`/cwd; no tool takes a repo
  path, so a model can't walk the server into another checkout.
- Mutating tools opt-in behind `--mutations`; **a tool the server didn't
  advertise can't be called**, so the flag is a gate not a hint.
- `remove_worktree` also needs `confirm: true`, and says so when missing.
- Ops run through `CaptureUi` (`can_confirm() == false`), so core's guards
  return `EXIT_NEEDS_CONFIRM` rather than reading silence as consent — relayed
  as "stopped to ask; go ask the user".
- stdout is protocol-only; human-facing output goes to stderr.

**Gate gap found and fixed:** CI ran `cargo test -p worktrees-core` only — the
CLI crate's tests ran NOWHERE. I shipped a test module with a lifetime error in
this very phase and only caught it because I looked past a grep filter. CI and
CLAUDE.md's gate list now include `cargo test -p worktrees-cli`.

Gates: release ✓ · bats 270 (12 new) ✓ · lint ✓ · core 195 ✓ · cli 5 ✓ · tsc ✓ · app ✓.

Review running, weighted toward: protocol conformance against rmcp's source
(handshake state, error-code semantics, id echoing), and **argv injection** —
`create_worktree`'s branch/base and the slug args are passed as CLI args into
core ops, so a value starting with `-` could be read as a flag.

## Session 1 (cont.) — Phase 8 review: argv injection was arbitrary RCE (`fb640f1`)

The predicted finding was real, and worse than predicted.

**`create_worktree`'s `base` reached `resolve_ai_cmd`.** Core's arg parsers are
hand-rolled: anything flag-shaped is consumed AS a flag and never fills a
positional. So `base: "--ai=touch /tmp/x; id"` set the AI command, which
`ops::launch` interpolates into `sh -ic '<ai_cmd>; exec $SHELL'` — a shell
command line. A tool advertised as "create a worktree" was **arbitrary command
execution** as the user, in the repo. `--no-attach` didn't suppress it (the
session is still created). `--name=..` also reached `git worktree add …/..`.

Why it mattered more than "the model already has Bash": an MCP server's premise
is being a NARROWER capability than a shell. Enabling `--mutations` authorises
worktree create/remove, not command execution — and a session with Bash denied
(the restrictive-profile case this branch fails closed to protect) got a shell
back through this door. The destructive tool was confirm-gated; the
code-execution one wasn't.

Fix: `safe_arg` at the MCP boundary — the only layer that knows these strings
came from a model. `--` would be tidier but core's parsers have no
end-of-options case; noted as a worthwhile second layer.

Also fixed: dropped 2024-11-05/2025-03-26 (they permit JSON-RPC batches, which
the reader would drop as notifications, hanging the client); `-32600` for a
missing method and `-32602` for malformed `tools/call` (that branch was
unreachable before); metadata tools verify the slug names a real place (
`store::edit` created ghost entries); `set_pin` refuses non-booleans; the stdin
reader is bounded.

Test honesty, again the recurring lesson: the annotation test grepped the whole
blob for `"destructiveHint":true`, so **swapping every annotation onto the wrong
tool kept it green** — verified, and it now fails on exactly that mutation. The
bats helper's `"${MCP_ARGS[@]:-}"` expanded to one empty string, so it always ran
`worktrees mcp ""` and the `--mutations` parameter was never exercised. Two unit
tests asserted against local copies of the logic instead of the code.

Gates: release ✓ · bats 275 (17 MCP) ✓ · lint ✓ · core 195 ✓ · cli 6 ✓ · tsc ✓ · app ✓.

### Carried forward

- Add a `--` end-of-options case to core's arg parsers as defence in depth.
- Phase 9 — UI. Phase 10 — docs + manual checklist.

## Session 1 (cont.) — Phase 9: the UI (`8d389d1`)

Feature is now usable without hand-editing JSON.

**Core additions, each answering a question whose consequence is invisible after
the fact:**
- `ever_launched(id)` → the "needs sign-in" tag. First launch shows `Not logged
  in · Run /login` (credential is keyed to the config-dir path). Correct, but it
  reads as broken unless said in advance.
- `has_unprofiled_history(repo)` → the cold-conversation warning in the picker.
  Nothing is deleted; unbinding brings the old conversation back.
- `info_for(repo)` → profiles + default + binding + EFFECTIVE choice +
  `env_override` (picker disabled rather than offering a choice
  `WORKTREES_PROFILE` already overrode).

**The stale badge needed a launch stamp that did not exist.** `store::Declared`
gains `profile_id`/`profile_epoch`, written by `ops::launch` ONLY in the branch
that creates a session — an attach reuses whatever the running process loaded,
so stamping there would clear a legitimate badge. Snapshot overlay derives
`profile_name`/`profile_stale`; reads profiles.json once per snapshot and does
NO per-profile filesystem probes (that path is the 3s poll).

Badge says "restart to apply" for rules/model/MCP/settings and deliberately does
NOT claim skills — those are symlinked and already reached the running session.

Skill install from URL got the CLI's review gate: preview (clone→inspect→discard,
shows full SKILL.md + capabilities) then install pinned to the reviewed sha.

Delete reports what it did NOT do: materialized dir stays (transcripts) and the
keychain item stays (worktrees never touches credentials — the invariant that
made this safe). Naming the leftovers beats pretending to clean them.

`ProfilesPanel` is MODULE-SCOPE per CLAUDE.md — nested in App() the rules
`<textarea>` would drop focus every keystroke. It's also the app's first
textarea, so App.css grew a `.setting textarea` rule.

Mock parity audited: **62/62** registered commands have a mock case; the 13 new
ones are stateful so the editor is drivable headlessly.

Gates: release ✓ · bats 275 ✓ · lint ✓ · core 199 ✓ · cli 6 ✓ · tsc ✓ · app ✓.

Review running — weighted toward: the onBlur-save/reload race (does reload
clobber a draft mid-edit?), whether a checkbox reliably fires blur (persistence
bug if not), slug-derivation mismatch between the stamp and `place_json`, and
whether the user-facing copy actually matches backend behaviour.

## Session 1 (cont.) — Phase 9 review: two real bugs

**#1 was the one I flagged as uncertain, and it was real.** Skill checkboxes
saved on `onBlur`, but WKWebView (what Tauri renders in on macOS) does not give
a checkbox focus on click — so blur never fires from normal mouse use and the
toggle died on unmount. **Chromium DOES focus it, which is exactly the engine
the mock harness runs in**, so headless driving could never have surfaced it.
The three sibling checkboxes saved in `onChange`; the skills row was the lone
blur-dependent one. Now saves immediately, like its neighbours.

**#2 the badge could lie.** The launch stamp was only ever written, never
cleared: unbind a profile, relaunch, and the badge kept naming a profile the
session demonstrably was not running — and the fail-closed path (which launches
NO claude) left the stamp claiming it was live. The create branch now always
writes the stamp, `Some` or cleared, and a failed write warns instead of
silently costing the badge. Staleness also now covers a REBIND (session running
one profile while the repo is bound to another) and a profile DELETED
mid-session (named as `<id> (deleted)` rather than vanishing).

Also fixed: every blur saved unconditionally and `save` bumps `updated_epoch`,
so clicking through fields flagged every live session stale — now dirty-checked;
`—` rendered literally in JSX text; a swallowed `profiles_info` error made
the picker claim "unprofiled" (false in the direction that matters for a
restrictive profile); `delete_profile` discarded the keychain service name core
returns FOR the caller, so the message now names what to look for, and no longer
claims transcripts for a never-launched profile; armed Delete survived a profile
switch; `has_unprofiled_history` false-positived on sibling repos; the skills
copy overclaimed (a skill's BODY reaches a running session, its description and
frontmatter are read at session start).

**Mock parity gap the audit missed:** commands were 62/62, but the new snapshot
FIELDS (`profile_name`/`profile_stale`) had no fixture, so the topbar badge was
undevelopable headlessly. Added to two fixture places, one stale.

Gates: release ✓ · lint ✓ · core 199 ✓ · cli 6 ✓ · tsc ✓ · app ✓ · bats running.

## Session 1 — feature complete (PR #72, 14 commits, still DRAFT)

All ten phases in. Phase 10 shipped DESIGN.md's "AI profiles (the third state
category)" section, a user-facing CHANGELOG entry, and
`docs/ai-profiles-manual-checks.md` — the gate CI cannot be, since the bats suite
drives fake git/tmux and there is no fake claude. CLAUDE.md's gate list points at
it: re-run on every claude upgrade.

### Left deliberately undone

- **Keychain GC on profile delete.** Core has no credential code path by design,
  and the service-name suffix is an undocumented hash of the directory path, so
  a profile cannot be mapped to its keychain item without reimplementing that
  hash. Delete now NAMES the leftovers (dir + service name when recorded)
  instead of pretending to clean them. The plan listed GC as a requirement —
  this is a deliberate deviation, flagged to the user.
- **`--` end-of-options in core's arg parsers**, as defence in depth behind the
  MCP boundary's `safe_arg`. Tracked.
- **No automated UI tests exist** in this repo at all (the "Playwright-drivable"
  harness is aspiration, not coverage). The mocks make the profiles editor
  drivable; nothing drives it yet.

### The recurring lesson, stated once

Four of the seven serious findings across this branch were things that PASSED
every gate: a test that grepped a whole blob so swapped annotations stayed
green; `--settings` asserted absent but never present, so deleting the flag
passed; a capability spelled `"allowed-tools"` that no test used; and a checkbox
whose persistence bug only exists on the engine the harness does NOT run.
**Ask what a test would fail on, not whether it passes.**
