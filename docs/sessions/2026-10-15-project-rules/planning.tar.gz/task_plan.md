# project-rules — rules pack (Phase B)
## Goal
`worktrees rules status|diff|apply` writes a managed AGENTS.md block + repo close-out skill + seeded .claude/close-out.md,
via agentfiles' plumbing commit on `agent-instructions`, local by default (--push for PR). Decisions from David 2026-10-14:
A apply default (also agent-setup fix), close-out canonical in binary (deprecate claude-skills copy — ASK before touching),
block at end, no review-before-merge, ADR 0002.
## Phases
- [x] B1 core+CLI+MCP → #488 merged (9675af1)
- [x] B2 app → #492 merged (bae7bf0)
- [ ] B3 dogfood (needs David's OK for AGENTS.md)

## 2026-10-15 — state after B3
- Merged: #496 (B3 apply, 823e923), #500 (Repair for rules rows, b2ebbee). #499 (stale close-out pointers) green, awaiting David's AGENTS.md review.
- mac-utilities 309c5d6 / saywhat 7abdc20: local `agent-instructions`, adopted as places, unpushed — David decides landing.
- valleos: refused — stale merged `agent-instructions` (PR #228) local+origin; David to delete, then apply.
- claude-skills: `retire-close-out` place, e2d012a — merge only after all repos carry the pack; then `git pull && ./install.sh` in main checkout removes the link.
- AT CLOSE-OUT → ROADMAP: drift check between projectTodos `UNCOUNTED_REPAIR` and AgentSetup's `rulesTodo`/`can` (review-500 finding 3).
- Holding; do not close out until (main) says.
