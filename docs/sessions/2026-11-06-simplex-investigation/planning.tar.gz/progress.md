# Progress
- 2026-11-04 (session start): read brief, group-chat proposal, local sources. Starting SimpleX primary-source reading.
- 2026-11-04 (cont.): primary-source reading done (versions, SMP/agent/chat/channels specs, push, iOS NSE, bot API, licences, operators, release sizes, App Store size, crates.io). No SimpleX software installed or run. Writing docs/proposals/simplex-transport.md next, then the artifact.
- 2026-11-04 (cont.): docs/proposals/simplex-transport.md written and committed (f0401f0, unsigned; no PR per brief). Artifact published privately: https://claude.ai/artifact/AUi8u3pqYoZZDPc9ZkmLVG (four inline SVG figures). Next: message worktrees-(main) with link, path, decisions; wait.
