# Findings — SimpleX as transport (evidence log, each item labelled)

Labels: READ (docs/source, with link) · MEASURED (done in this lane, no SimpleX run) · ASSUMED.

## Versions read (READ, GitHub API, 2026-11-04)
- simplex-chat: latest stable v7.0.3 (2026-09-26); v7.1.0 published 2026-11-04 as pre-release ("Safer channels: add moderators and sign every message"). default branch `stable`. License AGPL-3.0.
- simplexmq: latest stable v6.5.0 (2026-04-29); 7.1.0-beta.4 (2026-10-17). AGPL-3.0.
- simplex-chat-libs (prebuilt libsimplex for node/python): core-7.1.0.18 (2026-11-03), zips 47–55 MB per platform. AGPL-3.0.
- Docs: SMP spec v20 (2026-05-25); overview rev 4 (2026-03-09); security rev 1 (2026-03-09); agent protocol v7 (2025-01-24); push-notifications v3 (2025-01-24); channels-overview rev 1 (2026-04-28); CHAT-RELAY 2026-07-28; SECURITY.md 2026-05-25; TRANSPARENCY 2026-02-09; CLI.md 2023-01-31 (stale).

## Protocol facts (READ)
- SMP: unidirectional queues on routers; recipient creates queue; sender/recipient have distinct ids + per-queue ephemeral keys; no user ids; fixed 16384-byte transport blocks; max client message 16048 bytes (v11+). Routers hold messages until retrieved or expiry (smp-server.ini default `expire_messages_days: 21`); queue capacity → ERR QUOTA. 2-hop onion ("private routing") hides sender IP from recipient's router. Routers must not log. (simplex-messaging.md, SERVER.md)
- Agent layer: duplex = 2 queues; per-queue NaCl box + double ratchet (X3DH Curve448, SNTRUP761 PQ KEM, AES-GCM); sequential agentMsgId + prevMsgHash per queue; A_RCVD receipts; at-least-once; queue rotation. Connection link = one-time invitation or contact address, passed OUT OF BAND; attacker who sees the link can race to impersonate Bob to Alice. Max agent msg 13618 (PQ on) / 15840 bytes.
- Chat layer: JSON message ≤ 15610 bytes. Groups (p2p): no group id on servers; every member has a duplex connection with every other; inviting admin introduces/forwards; admin can MITM introductions (threat model). Roles owner/admin/member/observer (+ relay, moderator, author in channels).
- Channels (v6.5 beta, v7 multi-owner): owner holds authoritative state; relays (= CLI in --relay mode) cache+forward; identity = sha256(genesis root key); roster/admin messages Ed25519-signed; CONTENT NOT SIGNED by default (deniability); 7.1 adds opt-in `sign=on`. Public-link channels are not E2E to relays by design. Preset relays: 3 run by SimpleX Chat Ltd. Dedup by shared msg id; cross-relay difference detection "designed, not implemented".
- Security claim (security.md): "Sender deniability — neither routers nor recipients can cryptographically prove message origin." Stolen decrypted DB → can send as the user until detected.
- Audits: Trail of Bits Nov 2022 (implementation), Jul 2024 (protocol design review). SECURITY.md (2026-05-25): "scheduled implementation security assessment for June 2026" — no 2026 audit post on the blog as of 2026-11-04 (blog index lists 5 posts in 2026, none about an audit).
- Operators (Presets.hs): SimpleX Chat Ltd (simplex.im, 11 enabled SMP + 3 disabled) and Flux / InFlux Technologies (simplexonflux.com, 6 SMP, 6 XFTP). Transparency: 12 LE requests in 2025, nothing provided.
- Push (push-notifications.md + APNS.hs): iOS instant mode needs a NOTIFICATION server (ntf-server, in simplexmq) that subscribes to SMP queues and calls APNs with ITS key. Default ntf servers ntf3/ntf4.simplex.im (Commands.hs `_defaultNtfServers`). `defaultAPNSPushClientConfig` hardcodes `appName = "chat.simplex.app"`, `appTeamId = "5NN7GUYB6T"`, key from env APNS_KEY_FILE/APNS_KEY_ID — i.e. SimpleX's ntf servers push only to SimpleX's own app. push-notifications.md: ntf router "can be self-hosted in the future". Periodic mode = BGAppRefreshTask ~20 min.
- iOS app (apps/ios/README.md, spec/services/notifications.md): SwiftUI + Haskell core as static lib (nix haskell.nix cross build, `-staticlib -threaded`, mac2ios patching); main app 64 MB heap, NSE 512 KB heap; NSE starts its own Haskell runtime, opens shared SQLite (app group), decrypts, fetches messages within ~30 s. App Store size 217,131,008 bytes (MEASURED via iTunes lookup, v7.1, 2026-11-05).
- CLI (`simplex-chat`): `-p PORT` = WebSocket JSON API server; `-e` one-off command; `--relay --headless` relay mode; `-d` db prefix; data in ~/.simplex (two SQLite DBs). Release binary sizes MEASURED from v7.0.3 assets: macOS aarch64 173.3 MB, macOS x86_64 83.1 MB, ubuntu x86_64 79.5 MB (.deb 12.8 MB compressed), ubuntu aarch64 102.4 MB. Android APK 87.5 MB.
- Bot API (bots/api/COMMANDS.md): APIAddContact (one-time link), APIConnect, APIAcceptContact, APINewGroup, APIAddMember (needs admin), APISendMessages (`/_send <chatRef> [sign=on] json [...]`), events `newChatItems`. Node lib `simplex-chat@7.0.4` and Python `simplex-chat` download libsimplex at install (download-libs.js from simplex-chat-libs). TypeScript WS client deprecated. FFI: `chat_migrate_init_key`, `chat_send_cmd(_retry)`, `chat_recv_msg_wait` (Mobile.hs, SimpleX.h).
- Rust: no official crate. Third-party on crates.io: simploxide-* (a1akris, 2026-07-31; client MIT/Apache/AGPL triple, ffi-core AGPL-3.0), libsimplex-rs 0.1.0 (2026-08-19), simplex-chat 0.2.0 (2024). MEASURED crates.io API.
- Licence: AGPL-3.0 on simplex-chat, simplexmq, simplex-chat-libs, node/python packages. Trademark/assets separately licensed.

## Local (READ)
- deny.toml: licenses allow MIT, Apache-2.0(+LLVM), BSD-2/3, ISC, Zlib, Unicode-3.0, MPL-2.0 (file-scoped only); `unknown-git = deny`, crates.io only. Project MIT, ships CLI + app bundles + .deb + (iOS) App Store. worktrees-ios deny.toml: same minus BSD-2.
- AGENTS.md: "tmux and git are never bundled: the .deb Depends: tmux, git"; every spawn via childenv; T7 refusal of public bind; audit log never carries text; `agent_send` paste rule.
- group-chat.md §5.4: T1–T8 + six places; D6 Tailscale peer pairing; D12 defer transport; §8.1 phone.
- notifications.md (ios): serve calls APNs with team .p8; NSE decrypts names only; "nothing answers from a notification"; "a message arrived" deliberately NOT an event; NSE 24 MB limit; key AfterFirstUnlock.
- conn.ts: phone drives ONE host over the pinned mTLS pipe; never starts anything.
- messages.rs: 8 KiB/msg, 500/project, 7 days; `from` derived by server.

## ASSUMED
- Reading of AGPL across a process boundary (CLI over WebSocket = separate program) and of linking (= derivative) is the common reading; not legal advice.
- Latency figures (100 ms–1 s over TCP) from SimpleX docs, not measured here.
- CLI RSS not measured (would need a run → David's OK).
