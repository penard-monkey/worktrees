# Task plan — SimpleX as transport for worktrees comms (investigation lane)

## Goal
Analysis, not code: `docs/proposals/simplex-transport.md` + a private Claude
artifact; message `worktrees-(main)` with link, path, decisions. No PR.

## Phases
### Phase 1 — Read local context
**Status:** complete
- brief, group-chat.md §5.4 (T1–T8, six places), §8.1, D6/D12
- AGENTS.md serve/remote/pairing; worktrees-remote + IOS.md; messages.rs
- worktrees-ios notifications.md, conn.ts, src-tauri, deny.toml

### Phase 2 — SimpleX from primary sources (Q1)
**Status:** complete
- versions + dates (simplex-chat, simplexmq), LICENSE files
- SMP, XFTP, ntf protocol docs; relays + operators; groups; stable vs beta
- audits (Trail of Bits)
- bot API (WebSocket), TypeScript client; Haskell core as library; iOS build

### Phase 3 — Score T1–T8 and six places (Q2), integration options (Q3), @bret (Q4), iOS (Q5), trust (Q6), Tailscale vs SimpleX (Q7), verdict (Q8)
**Status:** complete

### Phase 4 — Write docs/proposals/simplex-transport.md
**Status:** complete (committed f0401f0)

### Phase 5 — Artifact (quickstart → artifact-design → artifact-diagramming), diagrams
**Status:** complete — https://claude.ai/artifact/AUi8u3pqYoZZDPc9ZkmLVG (private)

### Phase 6 — Commit on branch, message worktrees-(main), wait
**Status:** in progress — committed; messaging (main) next, then wait

## Probes
None run. Any install/run needs David's OK first (send to worktrees-(main)).
