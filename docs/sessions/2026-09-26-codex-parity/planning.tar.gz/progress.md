# Progress Log

## Session: 2026-09-23 — planning
- Branch `codex-skills-mcps` (clean, at 0a88602).
- Read the codex-support close-out summary + ROADMAP follow-ups.
- Explore agent mapped profiles / skills / MCP / instruction files per provider
  (→ findings.md "Codebase survey").
- Probed codex 0.132.0 binary strings (dump in scratchpad `codex-strings.txt`):
  `project_doc_fallback_filenames`, `external_agent_config` Claude migrator,
  `.agents/skills`.
- Wrote task_plan.md (7 phases), findings.md, this file.
- Next: Phase 2 live verification + David's decisions on the open questions.

### 2026-09-23 — David's decisions; parked
- Codex has moved to 0.156.1 (standalone, `~/.local/bin`). Re-checked the binary
  strings without running it; all features are still present.
- Decisions: stub (not symlink), the fix commits and lands in main, link skills,
  prefer Codex's importer, profiles deferred. Recorded in task_plan.md.
- PARKED: no `codex` runs until David sets up the subscription and does the
  cut-over test later this week. Resume at Phase 2's live checks.
- Follow-up decisions: AGENTS.md canonical (CLAUDE.md = `@AGENTS.md` stub);
  the fix goes on a dedicated branch + PR to main; importer only if it can be
  called from the CLI, never through the desktop app.
- 2026-09-26: ff to origin/main 1407545; spawned Codex place `codex-usage-meter` (design brief); it blocked on Codex's trust prompt (David's call). CLI probes: importer removed → manual migration; mcp add has OAuth flags.
- 2026-09-26: `codex debug prompt-input` probes: the fallback works (nested too), AGENTS.md beats the stub, skill roots are ~/.agents/skills + repo .agents/skills, symlinks followed, .claude/skills not read.
- 2026-09-26: the codex-usage-meter place WAS in the nav (David missed it; no bug). New asks: provider mark in nav rows; Codex auto mode. Flags recorded in findings.
- 2026-09-26: new ask: Codex activity in the nav. Rollouts lack completion/approval events; Codex has hooks + legacy notify (agent-turn-complete w/ cwd) → plan: launch-time -c notify.
- 2026-09-26: decided auto-review as the Codex default; repo skills bridged by symlink.
- 2026-09-26: full build started. Spawned lane B (codex-mcp-migrate, Codex) and lane C (codex-activity-nav, Claude) via MCP. Lane A here.
- 2026-09-26: Lane A core done + committed:
  - 7ed4030: launch flags (CLAUDE.md fallback, auto-review with the git common
    dir + network). Tests shown red first.
  - 7693e79: agentfiles.rs + `worktrees agent-setup`. Tests shown red first,
    including an e2e test with a bare origin and a fake gh.
  - Gates on the core commit: bats 361/361, lint ok, core 455, cli 15.
  - Verified the real pane-0 Codex argv through the release binary in a scratch
    repo; Codex TUI starts.
  - The app UI layer was delegated to an opus subagent (uncommitted, in this
    worktree) for review.
- 2026-09-26: lane A app layer committed (ec35e8d); the nav banner is limited to repo fixes (user skills only in the sheet). Fable review started. U proposal approved → build. B waiting on David's approval prompt. C PR #340.
- 2026-09-26: Fable review → 10 findings, all fixed (708822e), gates green (bats 363, core 456, cli 15, app 144). PR #341 opened, rebased on #338/#339, CI run 36271878797 queued. MISTAKE: a bats test pushed origin/agent-instructions (c2e9708) from the real repo; the tests are now pinned to the fixture. Awaiting David: keep or delete that branch.
- 2026-09-26: at David's request, deleted the stray agent-instructions branch (verified sha c2e9708 before deleting) locally and on origin.
- 2026-09-26: CI green (after a git-identity test fix), #341 squash-merged → 24b8c23. Told lane C to rebase #340.
- 2026-09-26: #340 rebased by C (gates green); Fable reviews launched for #340 and #342. B still building (no commits).
- 2026-09-26: #340 Fable review → merge after fixes (#1 stuck-green when Codex dies, since pane0 falls back to a shell; #2 exec rollouts hijack; #3 wiring tests; #4 completed_at fallback; #5 footer; #6 measure mark). Sent to lane C.
- 2026-09-26: #342 Fable review → merge after fixes (CHANGELOG header trap, Claude 'Reset unknown' regression, STALE drift check, test honesty, missing-CLI slot noise → hide slot, process group). Sent to lane U via pane.
- 2026-09-26: David picked SVG logos for the nav mark; fetched them from Simple Icons (CC0) and sent them to lane C.
- 2026-09-26: lane B opened #343; Fable review launched (focus: secrets in argv/logs, injection, config writes, conflicts with #340/#342).
- 2026-09-26: #343 review → merge after fixes (literal env values serialized/visible, add overwrite race → flock, Differs masks Unsupported, bats shim, poisoned mutex). Sent to lane B.
- 2026-09-26: #340 verified (CI green on head, changelog 1 header, logo paths verbatim, screenshot checked) and merged → c0210b4. Told U and B to rebase.
- 2026-09-26: David OK'd merging; #342 merged → bb62669. Lane B told to rebase #343; a background watcher waits for its done marker. Planned Phase 8 (messaging over the worktrees MCP) at David's request.
- 2026-09-26: Phase 8 rescoped per David: a general place↔place Claude/Codex channel, no UI.
- 2026-09-26: lane B done marker caught; #343 verified green on 959e3aa. The merge was blocked by the classifier ('Merge Without Review'); asked David.
- 2026-09-26: #343 merged → 498c982 (all 4 lane PRs in). New branch codex-skills-mcps-repair off origin/main for Phase 9 (project to-dos + Repair/upgrade + after-update offers).
- 2026-09-26: Phase 9 built by an opus subagent, verified (gates + screenshots: header badge, Repair menu, To do list, 3 after-update offers), committed d1fbc60; Fable review running.
- 2026-09-26: Phase 9 Fable review → merge after fixes (count vs relink-fixable remedy split; pending local-vs-origin; sheet load → badge; codex-skills shrink re-ask; section tag recount; pins; changelog). Sent back to the builder subagent.
- 2026-09-26: Phase 9 review fixes verified by me (bats 373, core 481, app 162, frontend all; plan-usage-check passes 3/3 here). PR #344 opened; CI watching.

## Session: 2026-09-26 — status sync (David asked for the plan docs to be current)
- task_plan.md rewritten to match reality:
  - Phases 2–6 and 6b marked complete, with the PRs that shipped them.
  - Phase 9 is PR #344 (CI running on ad3453a; David pre-approved the merge).
  - Added Phase 10 (the 0.31.0 release + David's post-update steps).
  - Phase 8 (messaging) comes after the release; Phase 7 holds docs + close-out.
  - The decisions table is corrected: plumbing, not a temp worktree; the
    importer is removed; the logos, literal-env and usage-slot calls are added.
  - Errors table updated (bats push, CI identity, classifier blocks, the
    subagent's false plan-usage failure).
- findings.md: added an Outcome section with the research threads still open.
- 2026-09-26: #344 CI 9/9 green → merged 5297f22. Asked David: release 0.31 now + Phase 8 as 0.32, or fold Phase 8 into 0.31.
- 2026-09-26: David is cutting 0.31 from main. Phase 8 started on codex-skills-mcps-messaging (off 5297f22), build delegated to an opus subagent; target 0.32.
- 2026-09-26: v0.31.0 released by (main). Phase 8 committed 5623416, rebased (CHANGELOG moved out of [0.31.0] by hand), gates re-run, live send→real Codex OK. Fable review launched.
- 2026-09-26: Phase 8 Fable review → merge after fixes. Blockers: send answers a pending approval; a leading / runs Codex builtins. Also: attribution prefix, pane ownership by path+cmd, trailing ';', prune marker race, a cache test that passes without the cache, docs overclaim, size cap, positive send bats. Sent back to the builder.
- 2026-09-26: Phase 8 review fixes in; rebased onto #346 (AGENTS.md is canonical here now); PR #348 opened; live approval-refusal verified. CI watching.
- 2026-09-26: David confirmed he approved the curl himself (send is cleared). #348 merged → 5e9d2b8 (0.32 content). Remaining: Phase 7 docs + close-out, and the 0.32 release when David wants it.
