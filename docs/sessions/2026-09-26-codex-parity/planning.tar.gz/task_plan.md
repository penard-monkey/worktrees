# Task Plan: Codex parity: instruction files, skills, MCP servers, and working alongside Claude

## Goal
Codex should work in a project as well as Claude does:
- A project with only CLAUDE.md (or only AGENTS.md) briefs BOTH agents.
- The user's skills and MCP servers reach Codex too.
- Codex activity and usage show in the app the way Claude's do.
- After an update, each project says what it needs and fixes it from right-click.
- The next step is Claude and Codex places being able to talk to each other.

## Current Phase (updated 2026-09-26)
- Phase 9 merged (#344 → 5297f22). Everything planned for 0.31 is on main.
- **0.31.0 RELEASED** (9bcb6be, tag v0.31.0), cut by David's (main) session. Phase 10 done.
- **Phase 8 merged** (#348 → 5e9d2b8), unreleased: it ships in 0.32.
- Then Phase 7 (docs + close-out).

## Shipped so far (all on main)
| PR | Merge | What |
|---|---|---|
| #341 | 24b8c23 | Codex reads CLAUDE.md (launch fallback); Codex permissions ask / **auto-review** (default) / full; `worktrees agent-setup status\|fix\|link-skills`; Agent setup section |
| #340 | c0210b4 | Codex activity dots (busy / needs input / afterglow) read from rollouts; the real Claude/OpenAI logo per nav row |
| #342 | bb62669 | Codex plan usage beside Claude in the usage meter (short-lived `codex app-server`) |
| #343 | 498c982 | Copy Claude user-scope MCP servers into Codex through `codex mcp add` (CLI + Settings → Codex) |
| #344 | 5297f22 | Project to-do badge, right-click **Repair / upgrade…**, after-update Codex offers, pushed-vs-local fix branch |

| #346 | 6151b83 | (David) ran our agent-setup Fix on THIS repo: AGENTS.md is canonical, CLAUDE.md is the stub |
| #348 | 5e9d2b8 | Place↔place Claude/Codex messaging over the MCP (report / messages / wait / send) + one shared activity reader. Unreleased → 0.32 |

## Lanes (all merged; places can be closed out)
| Lane | Place / branch | Agent | Result |
|---|---|---|---|
| A | `codex-skills-mcps` | Claude (me) + opus subagent | #341 |
| B | `codex-mcp-migrate` | Codex | #343 (merged with David's OK after the auto-mode classifier blocked it) |
| C | `codex-activity-nav` | Claude | #340 |
| U | `codex-usage-meter` | Codex | #342 (same classifier block, then David's OK) |
| Phase 9 | `codex-skills-mcps-repair` (this tree) | opus subagent, then me | #344 |

The process that worked: each lane gets a detailed brief, runs its gates, opens a PR and does not merge. A Fable pre-merge review follows, then the lane fixes the findings, then I verify CI on the head commit and the CHANGELOG header count, then squash-merge. Codex lanes cannot message back (no bus), so I poll their panes or have them print a marker; Phase 8 fixes that.

## Phases

### Phase 1: Survey what exists
- **Status:** complete (see findings.md, "Codebase survey")

### Phase 2: Verify live, then decide
- [x] `project_doc_fallback_filenames=["CLAUDE.md"]` works through `-c`, nested dirs too; AGENTS.md wins
- [x] Codex reads skills from `~/.agents/skills` and repo `.agents/skills`, not from `.claude/skills`; it follows symlinks
- [x] Codex's Claude importer is REMOVED in 0.157.1, so the migration is done manually
- [x] Auto-review in a linked worktree needs the git common dir + network (measured)
- [x] ~~Claude reading AGENTS.md natively~~: moot. The stub `@AGENTS.md` handles Claude.
- [x] ~~`docs/proposals/codex-parity.md`~~: superseded by the PR bodies of #341/#343/#344 and findings.md. Fold the useful parts into the session summary at close-out.
- **Status:** complete

### Phase 3: Instruction files (core)
- **Status:** complete in #341, with review fixes in #341 and #344.
  `agentfiles.rs` classifies dirs as claude-only / agents-only / stub / linked / diverged. The fix is built with plumbing (private index, commit-tree, create-only update-ref) on branch `agent-instructions`, then pushed with a PR opened via gh. It never touches a working tree. `pending` / `pending_on_origin` retire the offer.

### Phase 4: Skills bridge
- **Status:** complete. Repo skills: `.agents/skills/<name>` → symlink via the Fix PR (#341). User skills: `link-skills` symlinks into `~/.agents/skills` (#341, UI in Settings → Codex since #344).

### Phase 5: MCP bridge
- **Status:** complete in #343. `mcpmigrate.rs` + `worktrees mcp --migrate --ai codex [--apply …] [--json]` + Settings → Codex. Literal env values carry a warning and are never serialised; a file lock guards add vs add.

### Phase 6: App surfaces
- [x] Nav provider mark → real logos (#340)
- [x] Codex activity dots, read from the rollout `task_started` / `task_complete` / `turn_aborted` (#340). notify and hooks were ruled out: notify lacks approval/abort events, and hooks need a trust prompt.
- [x] Codex permissions setting, auto-review default (#341)
- [x] Manual repair → Repair / upgrade… (#344, Phase 9)
- [x] First-load offer: after-update offers + project badge (#344). The nav banner from #341 was removed.
- [ ] **Codex "Trust this folder?" prompt**: an app-launched Codex in an untrusted repo blocks silently (the first usage-meter lane sat on it). Detect an untrusted repo root by reading `config.toml` only, and say so. Not built yet → ROADMAP or a follow-up.
- [x] Mock harness tracks every new command
- **Status:** complete except the trust-prompt item

### Phase 6b: Codex usage in the meter
- **Status:** complete (#342). The proposal is at `docs/proposals/codex-usage.md`.

### Phase 9: Project "things to do" + Repair / upgrade (branch `codex-skills-mcps-repair`)
- [x] Per-project to-do model (`projectTodos.ts`). Each row counts only what its own button can clear (relink / re-seed / provision; config-only shown uncounted; agent-setup fix)
- [x] Header badge + right-click **Repair / upgrade… (N)** → To do list in the ProjectSheet
- [x] After-update offers: "Let Codex drive your worktrees", "Let Codex use your Claude skills" (the latter re-asks only for new skills)
- [x] Nav banner removed; `pending_on_origin` in core ("PR waiting" vs "never pushed")
- [x] Fable review (7 findings) fixed; gates green (bats 373, core 481, app 162, frontend all)
- [x] Merged → 5297f22 after CI 9/9 green on ad3453a (David approved)
- **Status:** complete

### Phase 10: Release 0.31.0 — DONE (9bcb6be, v0.31.0) (David asked 2026-09-26: "will the update path pick up codex?")
- [ ] CHANGELOG `[Unreleased]` → `## [0.31.0] - <date>`; bump workspace `Cargo.toml` + `install.sh` `SCRIPT_VERSION`
- [ ] Release PR → merge → `make release VERSION=0.31.0` from the worktree that owns `main` (the repo root), not this one (CLAUDE.md) → push the tag
- [ ] Watch release.yml (CLI ×4, signed app ×2, latest.json)
- [ ] Tell David the post-update steps:
  - update BOTH the app and the CLI (the MCP server Claude and Codex launch is the CLI binary);
  - running tmux sessions keep their old Codex launch until they are reopened;
  - Settings → Codex → MCP install (Codex has no worktrees server yet);
  - valleos will show the Repair badge (12 CLAUDE.md-only dirs + 3 repo skills). Its first real Fix against GitHub should be done deliberately.
- **Status:** pending (after #344)

### Phase 8: Claude ↔ Codex messaging over the worktrees MCP (approved 2026-09-26)
**Scope (David):** a GENERAL place↔place channel for Claude and Codex working together, not an orchestrator-only feature. `(main)` is just another place. Avoiding stalls is the first use, not the design target. No human UI.
- [ ] A durable per-project message log (not the expiring inbox): one file per message, create+rename; from / to / text / created / read / reply-to; bounded
- [ ] MCP `report(text, to?)`, where `from` is derived from the cwd, never taken as an argument
- [ ] MCP `messages(unread_only?, ack?)`
- [ ] `place_status` reports Codex activity (busy / waiting / idle + last completion) from #340's reader. One reader, shared with the nav dots
- [ ] MCP `wait(slug, until: idle|message, timeout_s ≤ 120)`
- [ ] MCP `send(slug, text)` → Codex pane via `tmux send-keys -l` + Enter. Claude places keep using SendMessage. Refuse adopted/foreign sessions; cap the length; no control chars
- [ ] Tool descriptions teach any agent to `report` when done / ask a peer, and to `wait` on a peer
- [ ] Tests red first (log bounds and concurrency, `from` derivation, `wait` timeout, `send` refusals)
- **Status:** complete. Merged #348 → 5e9d2b8 (David OK'd). Ships in 0.32.

### Phase 7: Docs + close-out
- [ ] `docs/codex-manual-checks.md` (ROADMAP item): switch round-trip, resume, adopted-session refusal, trust prompt, auto-review commit/push in a worktree, activity dots after a crash, usage meter signed-out / missing CLI, MCP migrate, agent-setup Fix against real GitHub. Re-run it on a `codex` upgrade
- [ ] CLAUDE.md: the Architecture → Agents paragraph is still Claude-only. Add the Codex facts that must survive being forgotten: the auto-review sandbox holes, `-c` forces embedded mode, rollout-derived activity, never writing Codex's config (the one exception is our own lock file beside it), and the bats cwd lesson (a test that pushes must pin cwd + origin)
- [ ] ROADMAP: close the manual-check item when written. Add: trust-prompt detection; `codex::session_present` still walks every rollout (pre-existing); two interactive Codex sessions in one cwd are ambiguous (#340)
- [ ] `/close-out`: session summary + planning tarball → `docs/sessions/2026-09-26-codex-parity/`, one PR, close the merged lane places
- **Status:** pending

## Open Questions
- None blocking.

## Decisions Made
| Decision | Rationale |
|----------|-----------|
| Never edit `~/.codex/config.toml` or `~/.claude.json` directly; go through `codex mcp add` / `claude mcp add` | CLAUDE.md rule: another tool's live state. (#343's lock file sits BESIDE config.toml and is ours) |
| Codex reads CLAUDE.md via the per-launch `-c project_doc_fallback_filenames` | No repo change needed; measured; AGENTS.md still wins |
| **AGENTS.md is canonical**; CLAUDE.md is an `@AGENTS.md` stub, not a symlink | David 2026-09-23; a tracked symlink is branch-dependent |
| The Fix goes on a **dedicated `agent-instructions` branch + its own PR**, pushed and opened via gh. It is built with plumbing, never a temp worktree (that would flash up as a stray) | David 2026-09-23/26: easy to revert on its own |
| Repo skills: `.agents/skills/<name>` → symlink to `.claude/skills/<name>`; user skills symlinked into `~/.agents/skills` | David 2026-09-26 |
| The importer is used only if CLI-callable → it is removed, so we migrate manually via `codex mcp add` | David 2026-09-23/26 |
| Literal env values in MCP servers: copyable with a warning, never preselected, argv never serialised | Orchestrator call after the #343 review; Claude already stores them in plain text |
| Codex permissions default **auto-review** + git-common-dir writable root + network | David 2026-09-26; measured in a linked worktree |
| Nav provider mark = the real logos (Simple Icons, CC0), `currentColor` on `--txt-dim` | David 2026-09-26 |
| Hide the Codex usage slot when the Codex CLI is missing | Orchestrator call after the #342 review; avoids a permanent "CLI missing" on Claude-only machines |
| Project to-dos: a badge + right-click Repair / upgrade, no per-project banner; machine-wide items are after-update offers | David 2026-09-26 |
| Messaging = a general place↔place Claude/Codex channel, no human UI | David 2026-09-26 |
| Codex profiles: deferred | David 2026-09-23 |
| Merges: David approves each (the auto-mode classifier blocks `gh pr merge` without it) | #342/#343/#344 |

## Errors Encountered
| Error | Attempt | Resolution |
|-------|---------|------------|
| `ugrep` "exceeds complexity limits" on a context grep of the codex binary | 1-2 | Python `re` on a strings dump |
| zsh `echo ===` → "== not found"; zsh does not word-split `$VAR` in `env $E` | 1 | `echo "---"`; inline env assignments |
| A new bats test ran `agent-setup fix` from the suite's cwd (THIS repo) and pushed `agent-instructions` to the REAL origin (no PR; main untouched) | 1 | Tests `cd "$REPO"`, and the fix test refuses unless origin == `$ORIGIN`. Branch deleted at David's request. Feedback filed |
| #341 CI: e2e fix test "Author identity unknown" on Linux (macOS invents an identity) | 1 | The test repo gets its own user.name/email; reproduced locally with `user.useConfigOnly=true` |
| `gh pr merge` blocked by the auto-mode classifier (#342, #343) | 1 each | Did not work around it; asked David, who approved each |
| Phase 8 rebase onto v0.31.0: the [Unreleased] entry applied CLEANLY into the published [0.31.0] section (the CLAUDE.md trap) | 1 | Moved it to a new `## [Unreleased]` above; verified `[0.31.0]` is byte-identical to main |
| Live approval probe: the first curl approval showed "You approved" ~4s after the modal appeared, while `send`'s only Enter was 8s EARLIER (per rollout timestamps). Not send: David confirmed he approved it himself | 1 | Also re-ran deliberately: send REFUSED while the approval was pending |
| The subagent reported `plan-usage-check.mjs` failing | 2 | It passes 3/3 in this tree; an environment issue on its side, not a regression |

## Notes
- Relocating CODEX_HOME would also move auth + sessions (it breaks sign-in and resume), so it is not a cheap way to give Codex profiles.
- Any `-c` override makes Codex run "embedded", without its shared background server. This predates our work (`forced_login_method`).
- Existing tmux sessions keep their old Codex launch flags until they are reopened.
- Codex saved trust entries in ~/.codex/config.toml for two scratch repos of mine (`…/sbx-probe/main`, `…/msg-probe`); tell David so he can delete them (we never edit that file).
