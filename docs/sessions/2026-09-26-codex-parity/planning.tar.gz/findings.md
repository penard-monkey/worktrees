# Findings — Codex parity for skills, MCP servers and instruction files

## Prior art in this repo
- v0.29.0 / #328 shipped Codex as a second provider: one live provider per place,
  `codex resume --last` gated on a same-cwd rollout, `codexmcp.rs` registers the
  **worktrees** MCP server through `codex mcp add|remove` (never writes Codex's
  config). Session summary: `docs/sessions/2026-09-23-codex-support/summary.md`.
- Proposal: `docs/proposals/codex-support.md`.
- CLAUDE.md rule that also applies to Codex: never read-modify-write another
  tool's config; go through its CLI.

## Local Codex install (measured 2026-09-23)
- **STALE FIRST PROBE:** the strings below were first read from 0.132.0
  (Homebrew cask, since removed). David updated to **0.156.1**, the standalone
  installer: `~/.local/bin/codex` → `~/.codex/packages/standalone/current/bin/codex`
  → `releases/0.156.1-aarch64-apple-darwin/`. Re-grepped 0.156.1 WITHOUT
  running it, and every key still exists: `project_doc_fallback_filenames` (24
  hits), `external_agent_config` (65), `ExternalConfigMigration` (17),
  `CLAUDE.md` (2), `.agents/skills` (1).
- The standalone install lives under `~/.local/bin`. Check that the app's GUI
  PATH fixup and `profile.rs:1160` discovery find it; they previously expected
  Homebrew or a VS Code/Cursor bundle.
- `~/.codex/config.toml` has only a project trust entry + `[features]`; **no
  `mcp_servers`** — so the user's Claude MCP servers are not in Codex today.
- `~/.codex/skills/` holds only `.system/` (imagegen, openai-docs,
  plugin-creator, skill-creator, skill-installer). None of the user's
  `~/.claude/skills` (close-out, find-skills, planning-with-files, sentry-cli,
  synced) are visible to Codex.

## What the Codex binary knows about (strings in 0.132.0 binary)
- **`project_doc_fallback_filenames`** config key exists (next to
  `project_doc_max_bytes`). Codex's documented behaviour: if no `AGENTS.md`
  (or `AGENTS.override.md`) in a directory, try these names instead. So
  `-c project_doc_fallback_filenames=["CLAUDE.md"]` on the launch (or in
  `~/.codex/config.toml`) makes Codex read CLAUDE.md with NO repo change.
  → Needs a live check: does `-c` on the command line work for this key, and
  is it per-directory (nested CLAUDE.md) like AGENTS.md?
- **`external_agent_config`** module in app-server
  (`app-server/src/config/external_agent_config.rs`): detects Claude config —
  `.claude/settings.json`, `settings.local.json`, `hooks.json`, `CLAUDE.md` →
  `AGENTS.md`, "repo MCP migration", skills count, plugins,
  `claude-plugins-official` marketplace. `ExternalConfigMigrationPrompts` type.
  So Codex has its OWN "migrate from Claude Code" importer (surfaced in the
  app-server / desktop app; unknown whether the TUI offers it).
  → Worth checking before building our own: if Codex already migrates, our
  "fix" may just be a pointer/launcher for it.
- Skills: Codex reads `SKILL.md` folders (same frontmatter format as Claude's)
  from `~/.codex/skills`, repo `.agents/skills` (7 hits) / `.codex/skills`.
  Formats are compatible; locations are not. A symlink or copy bridges them.
- `.claude-plugin/plugin.json` is recognised alongside `.codex-plugin/plugin.json`
  → Codex plugins can consume Claude plugin manifests (not investigated).

## Codebase survey (Explore agent, 2026-09-23)
**Short version: profiles, skills and non-worktrees MCP are Claude-only. Codex
gets the worktrees MCP server and `-c forced_login_method=chatgpt`, nothing else.**

- **Profiles** (`profile.rs:207-275`): rules, skills(+inherit_global_skills),
  mcp_servers(+inherit_global_mcp), worktrees_mcp(_mutations), model, settings.
  Materialized to `$XDG_DATA_HOME/worktrees/profiles/<id>/` (`:809-886`) and
  applied via `CLAUDE_CONFIG_DIR`, `--append-system-prompt-file rules.md`,
  `--settings`, `--mcp-config`, `--strict-mcp-config`, `--model`
  (`claude_launch`, `:488-527`). `ops::ai_launch_for` skips profiles when
  the AI word isn't `claude` (`ops.rs:105`). UI says claude-only
  (`ProfilesPanel.tsx:6, :369`).
- **Skills** (`skillstore.rs`): store in `$XDG_DATA_HOME/worktrees/skills/`,
  exposed only via profile symlinks (`profile.rs:895, 912-926`). No code
  mentions `.codex/skills`, `.agents/skills`, `~/.codex/skills`. Note from
  `docs/sessions/2026-08-10-global-skills-repo/summary.md:62`: third-party
  skills on this machine are real dirs in `~/.agents/skills`, symlinked into
  `~/.claude/skills`.
- **MCP**: Claude = `mcpsetup.rs` (`claude mcp add -s user`, reads
  `~/.claude.json`); Codex = `codexmcp.rs` (worktrees only, `codex mcp add
  worktrees --env WORKTREES_MCP_PROVIDER=codex -- <wt> mcp [--mutations]`,
  `:117`; reads `$CODEX_HOME/config.toml`). Proposal deliberately kept the two
  providers' MCP independent (`docs/proposals/codex-support.md:51-56, 106`).
- **Instruction files**: CLAUDE.md is only a docs-pane root doc (`docs.rs:86`).
  AGENTS.md: no handling. No `project_doc_fallback_filenames`.
- **Codex argv** (`profile.rs:642-664`, pinned `:1678-1682`):
  `codex -c forced_login_method=chatgpt [resume --last] ['<BRIEF_OPENER>']`,
  pane 0 via `exec $SHELL -ic '<cmd>; <keep>'` (`ops.rs:271`). Session
  `<canonical>~agent~codex` (`tmux.rs:21-28`).
- **Hooks for a "fix" surface**:
  - `add_project` (`lib.rs:414-423`) has NO onboarding step — a first-load
    prompt needs a new hook (or piggy-back on the `init.rs` "Not configured"
    banner, `App.tsx:3984`).
  - Doctor (`lib.rs:2850`, `diag::Finding`, closed `Code` enum `diag.rs:50`,
    no fix/action field `diag.rs:182`); background sweep every 5 min
    (`App.tsx:3960`).
  - **ProjectSheet fix buttons** ("Relink files"/provision/init,
    `ProjectSheet.tsx:134, 200, 418-432`) — best existing home for a manual
    "Repair agent setup".
  - `offers.ts` — one-click suggestions that route to a settings panel.

## CLI probes (2026-09-26, codex-cli **0.157.1** — auto-updated from 0.156.1)
Help and feature listings only; no sessions started. Full dump in scratchpad
`codex-cli-help.txt`.
- **Importer: no CLI path.** `codex features list` lists `external_migration`
  as **removed**; `external_agent_memory_import` is *under development*, off.
  No subcommand mentions import or migrate (other than `migrate-rollouts`, which
  only converts Codex's own legacy sessions). → Per David's rule, we **migrate
  manually** through `codex mcp add`.
- **`codex mcp add` flags**: `<NAME> (--url <URL> | -- <COMMAND>...)`,
  `--env K=V` (stdio only), `--bearer-token-env-var VAR` (HTTP only),
  **`--oauth-client-id`, `--oauth-client-registration auto|cimd|dcr`,
  `--oauth-resource`** (new vs our earlier table → OAuth HTTP servers CAN be
  added, then the user signs in with `codex mcp login <name>`), `--enable/--disable
  <FEATURE>`, `-c`. There is still no header flag.
- **The first launch in a repo stops at a "Trust this folder?" prompt** that applies to the
  REPO ROOT and is saved to Codex's config. The `codex-usage-meter` place sat
  on it. An agent launched by the app (or through MCP `create_worktree`) blocks
  until a human answers. The app could detect this (the repo root is not a
  trusted `[projects]` entry in `config.toml`, read only) and say so, instead of
  showing a silent pane. → candidate for Phase 6.

## Live prompt probes — `codex debug prompt-input` (2026-09-26, 0.157.1)
This subcommand renders the prompt Codex would send WITHOUT calling the model,
so it is the safe way to test instruction and skill discovery. It was run in a
scratch git repo under the scratchpad (`probe-repo`).
- **The CLAUDE.md fallback works through `-c`**: with no flag, 0 CLAUDE.md markers
  appear. With `-c 'project_doc_fallback_filenames=["CLAUDE.md"]'`, run from `sub/`,
  BOTH the root and `sub/` CLAUDE.md load, so it walks repo root → cwd the way
  AGENTS.md does.
- **AGENTS.md wins per directory.** With AGENTS.md (canonical) and CLAUDE.md
  `@AGENTS.md` (stub) both present, plus the fallback flag, only AGENTS.md
  loads; the stub is not read. So the stub fix and the launch flag coexist with
  no duplication.
- **Skill roots**: `~/.agents/skills` (r0) and `~/.codex/skills/.system` (r1),
  plus repo `.agents/skills`. **Repo `.claude/skills` is NOT read.** Symlinked
  skill dirs ARE followed.
- Consequences for David's skills:
  - `find-skills` and `planning-with-files` already work in Codex, because they
    are real dirs in `~/.agents/skills`, with `~/.claude/skills` linking TO them.
  - `close-out` (a link into ~/workspace/claude-skills), `sentry-cli` and
    `synced` (real dirs in `~/.claude/skills`) are INVISIBLE to Codex.
  - Bridge: symlink each missing `~/.claude/skills/<name>` into
    `~/.agents/skills/<name>`. That is a shared cross-agent folder, not Codex's
    config, and it matches how this machine already works.
  - Repo-level: a repo's `.claude/skills/*` needs `.agents/skills/*`. This belongs in
    the instruction-file fix PR. A tracked symlink is branch-dependent (see CLAUDE.md), so
    the choice between a link and a copy is still open.

## Codex permission modes (`codex --help`, 0.157.1, 2026-09-26)
- `-a, --ask-for-approval on-request|never`
- `-s, --sandbox read-only|workspace-write|danger-full-access`
- **`--approve-for-me`**: "Route approval requests through automatic review using
  the workspace-write sandbox". This is the closest match to Claude's auto mode (a
  reviewer decides; it is not a blanket yes).
- `--dangerously-bypass-approvals-and-sandbox`: no prompts and no sandbox (the
  `--dangerously-skip-permissions` analogue).
- `--full-auto` is no longer in the help.
- **Worktree trap to verify**: a linked worktree's git dir is
  `<main>/.git/worktrees/<name>` plus the shared `<main>/.git/objects`, which sit
  OUTSIDE the worktree. A `workspace-write` sandbox may therefore refuse `git
  commit`. Workspace-write also has no network by default (`gh`, `git push`, cargo
  fetch). The fixes to check: `-c sandbox_workspace_write.writable_roots=[<common git
  dir>]` and `sandbox_workspace_write.network_access=true`.
- Claude side: `~/.claude/settings.json` has no permissions/defaultMode keys,
  so David's Claude auto mode is not set through config the app passes.

## Nav provider indicator
- The provider is shown ONLY in the main pane's `.agent-label` (`App.tsx:~6915`,
  "Claude"/"Codex" + `.agent-model`). Nav rows carry no provider mark, so a
  Codex place looks like any other in the list.

## Codex activity (busy / waiting / done) — 2026-09-26
The nav's busy/waiting dots and the unread afterglow are Claude-only today: they come
from `claude_activity()` reading `~/.claude/sessions/<pid>.json`. The app already
tails Codex rollouts, but only for the model label (`codex::latest_rollout`,
`rollout_model`, `lib.rs::codex_models_moved`).
- **Rollouts are a weak activity source.** Counting event TYPES only (no content)
  over the 8 newest rollouts: `task_started` appears 5 times, but there is **no
  `task_complete`/`turn_complete` record** and no approval-request record. So "done" and
  "waiting on you" cannot be read back from the file; busy would be a guess.
- **Codex has Claude-style hooks** (binary strings): `SessionStart`,
  `UserPromptSubmit`, `PermissionRequest`, `Stop`, plus `hooks.json`,
  `.codex/hooks`, and "persisted hook trust" (`--dangerously-bypass-hook-trust`).
  These give exact busy (prompt submitted), waiting (permission request) and done
  (stop) signals.
- **Legacy `notify`**: `agent-turn-complete` payload with `thread-id`, `turn-id`,
  `cwd`, `input-messages`, `last-assistant-message`; `approval-requested` also
  exists. `notify` is a config key, so `-c 'notify=[...]'` ON THE LAUNCH can
  deliver turn-complete events to a worktrees helper WITHOUT writing Codex's
  config. That fits the never-write-their-config rule.
- To probe next: can hooks be supplied per launch through `-c` (no hooks.json
  write, no trust prompt)? Does `notify` fire `approval-requested` in 0.157.1? Use
  the payload's `cwd` to key on place path, the way the Claude dots do.

## Auto-review in a linked worktree — LIVE (codex exec, 0.157.1, 2026-09-26)
Scratch repo: `~/.cache/worktrees/worktrees/codex-skills-mcps/sbx-probe`.
- `--approve-for-me` on its own, in a linked worktree: `echo > file` works, but
  **`git add` and `git commit` fail with exit 128, "index.lock: Operation not
  permitted"**. The index lives in `<main>/.git/worktrees/<name>/`, outside the
  sandbox, and auto-review did not escalate it.
- Adding `-c 'sandbox_workspace_write.writable_roots=["<git common dir, realpath>"]'`
  makes the commit succeed.
- Network is blocked by default: `git ls-remote https://github.com/...` fails
  ("Could not resolve host"). `-c sandbox_workspace_write.network_access=true`
  makes it succeed.
- → The auto-review launch is `--approve-for-me -c
  sandbox_workspace_write.writable_roots=["<common>"] -c
  sandbox_workspace_write.network_access=true`.

## Lane reports and end-to-end launch (2026-09-26)
- Lane C (live turns): **the rollout DOES record `task_started` /
  `task_complete{completed_at}` / `turn_aborted`**. My earlier 8-file sample
  had none, probably because those turns never completed. `notify` fires only
  `agent-turn-complete`: no `approval-requested`, and nothing on an Esc
  interrupt. Hooks passed through `-c` stop on a "Hooks need review" trust
  prompt. → Lane C reads activity from the rollout and adds no notify helper.
- The release-binary `worktrees new … --ai codex` pane-0 command, verified:
  `codex -c forced_login_method=chatgpt -c 'project_doc_fallback_filenames=["CLAUDE.md"]'
  --approve-for-me -c 'sandbox_workspace_write.writable_roots=["<main>/.git"]'
  -c sandbox_workspace_write.network_access=true`. The TUI starts cleanly.
- The Codex startup warning "Running without the shared background server:
  command-line configuration overrides (-c …) requires embedded mode" comes
  from ANY `-c`, so it was already caused by `forced_login_method` before this
  branch. The effect: app-launched Codex sessions don't join Codex's shared
  app-server daemon (`codex agents`). This is pre-existing, not a regression.
  Revisit only if something needs that daemon.

## Nav provider mark — logos (David 2026-09-26)
- David chose real logos over the text glyphs (✻ / >_). The source is Simple
  Icons v16.32.0 (CC0-1.0), 24×24 single-path monochrome: `claude.svg` (the
  spark) and `openai.svg` (the blossom, which Codex uses). Copies are in
  `~/.cache/worktrees/worktrees/codex-skills-mcps/logos/`.
- They render as a filled `currentColor` variant in icons.tsx, on `--txt-dim`,
  with no brand colour (the hue stays in the activity dot). The marks remain
  trademarks of Anthropic and OpenAI and are used only to label which agent is
  live. Sent to lane C (#340).

## Outcome (2026-09-26)
Everything above was acted on. #341, #340, #342 and #343 are merged; #344 is in
CI. What each finding became is in task_plan.md's "Shipped so far" and Phase
sections. Open research threads that remain:
- Detecting Codex's trust prompt (an untrusted repo root blocks an app-launched
  agent silently).
- Whether hooks can ever be supplied per launch without the "Hooks need review"
  prompt. If yes, they would give exact busy/waiting/done signals.
- Codex's `account/rateLimits/updated` notification (#342 polls instead).
