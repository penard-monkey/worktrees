# plan-exclude-eager — write `/.planning/` to info/exclude the moment a project goes Full

## The bug
Settings → Project → Planning says: "`.git/info/exclude` gains `/.planning/` if git does not already
ignore it." That is false at the moment the user reads it. `planning::set_*` (`planning.rs` ~:250-273)
only edits `~/.config/worktrees/projects.json`. The ONLY caller of `planning::ensure_planning_excluded`
(`planning.rs:280`) is `ops::write_plan_pointer` (`ops.rs:666`), i.e. `worktrees new`. David set Full on
anime-song-remover and nothing was written. Worse: (main)'s own session at Full can write
`.planning/orchestrator/` before any place exists, untracked and not ignored, so a `git add -A` in (main)
commits it.

## Do
1. When a project's level becomes Full — from the app's Planning panel (`app/src/PlanningPanel.tsx` →
   its tauri command in `lib.rs`) AND from `worktrees plan level full` — call `ensure_planning_excluded`
   right after the registry write, against that project's git common dir and main root. Put it in ONE
   core function both callers use (not twice). Keep the `worktrees new` call as a backstop.
2. Global default → Full: decide whether to sweep every registered project that inherits it. Recommend
   in the PR; if you do sweep, skip projects whose `.planning/` is tracked (TRACKED_REFUSAL case) and
   never fail the setting on an unreachable repo — report, don't refuse.
3. Report it: the CLI prints the same "planning: added /.planning/ to .git/info/exclude" line; the app
   shows it in the panel's result (or the hint switches to a "done" state). Make the hint text true:
   if git already ignores `.planning/`, say so instead.
4. Session launch at Full in (main) (`planning_for`, `ops.rs:107`) is a cheap third place to ensure it —
   consider it, so a project set to Full before this release is healed on its next launch. Recommend.
5. Tests: core unit test (scratch repo under $TMP, guarded helper, never `git -C ""`) that setting Full
   writes the line once, is idempotent, skips when `.gitignore` already covers it; a bats test for
   `worktrees plan level full`. SHOW each RED first. Tests must never touch the real
   `~/.config/worktrees/` — use the existing registry path seams.

## Rules
- Read AGENTS.md first. Gates: all of AGENTS.md's, `cargo build --release -p worktrees-cli` FIRST.
- CHANGELOG: one bullet under `### Fixed` in `## [Unreleased]` (create only if absent; count headers).
- Never drive David's running app. tmux only as `tmux -L <unique>` on EVERY call. Never `git worktree add`.
  Scratch → `~/.cache/worktrees/worktrees/plan-exclude-eager/`.
- No session URLs / Claude-Session trailers; keep Co-Authored-By. AGENTS.md edits need David's OK (ask in your report, don't commit them).
- Open a PR, SendMessage `worktrees-(main)` with the number, your recommendations on 2 and 4, gates. Don't merge — a fable review runs first.
