# Implementation brief — sync damage: detect between syncs, heal on every edge, stop the backup-dir noise

Repo: /Users/davidpena/workspace/worktrees/.worktrees/sync-macs, branch
`sync-macs-doctor-heal` (already checked out; diff against `origin/main`). Do NOT
commit — the diff gets reviewed first.

Read FIRST: CLAUDE.md top to bottom (gates + every trap; it has grown since the
sync sessions), then the code this touches:
- `crates/worktrees-core/src/sync.rs` — `heal_excluded_deletions`,
  `healable_repos`, `checkout_paths`, `heal_report`, `post_pull`,
  `exclude_patterns`, `excluded_path`, `unstaged_deletions`, and how
  `sync_one` (CLI) / `sync_apply` (app API) call `post_pull` on pull success.
  Also `hub_copy_finding` (~line 323) — the doctor-finding idiom to copy.
- `crates/worktrees-core/src/ops.rs` `cmd_doctor` (~1458) — where
  `hub_copy_finding` is wired (~1508).
- `crates/worktrees-core/src/diag.rs` — `Code`, `Finding`, severities, the
  slug table (~line 270).
- `crates/worktrees-core/src/store.rs` — `exclude_app_state` (~line 120) and
  its tests (~353, ~385).
- `test/sync.bats` — the #146 heal tests (last ~74 lines) show how the bats
  fake-git harness exercises the heal; mirror their technique.

## Motivation (David, 2026-08-28)

Field incident: 8 of 10 linked worktrees on the origin Mac carried walls of
unstaged `deleted: docs/sessions/*/planning.tar.gz` — the #146 damage class
(excluded-but-tracked files absent from the working tree), dating from the
pre-0.16 era. Nothing ever noticed: the heal only runs on the NEXT successful
pull of that project, so old damage sits invisible in parked worktrees
indefinitely. Also `<project>/.worktrees-sync/` (pull backups) shows as `??` in
git status forever.

Design stance: **sync repairs, doctor detects.** Doctor stays read-only (it is
a report; `relink` is the applier — keep that split).

## Scope

### 2. Doctor: detect skipped-file damage

- New `Code` variant (suggest `SyncSkippedFiles`, slug `sync-skipped-files`;
  match the naming already in the table). Severity: **Warning** — the blobs are
  safe in `.git`, the tree still functions.
- New pure-ish fn in sync.rs (next to `hub_copy_finding`), e.g.
  `skipped_files_finding(root: &Path, extra_excludes: &[String]) -> Option<Finding>`:
  reuse `healable_repos` + `unstaged_deletions` + `excluded_path` — do NOT
  reimplement the match. One finding per project (not per file): count + up to
  a few sample paths (follow `DELETE_SAMPLE`/`HEAL_SAMPLE` precedent), and the
  remedy in the message: any `worktrees sync push|pull` of this project heals
  it automatically (true once §3 lands).
- Wire into `cmd_doctor` beside the hub-copy finding. Doctor knows the
  project's config — pass the same extra excludes the sync path would use (see
  how sync resolves `[sync]` extra excludes from config; if doctor has no
  config in hand, resolving with empty extras is acceptable ONLY if you say so
  in the report — prefer plumbing the real ones).
- Where does the finding surface in the app? `grep` `app/src` for doctor slugs
  / findings rendering. If the app renders findings generically, no app work.
  If any TS mirror of the slug table exists, update it AND its drift-check
  script. State which case you found.

### 3. Heal on every sync edge, not just successful pulls

Today `post_pull` runs only after a successful pull. Extend, keeping ONE
implementation:

- **Before push**: run the heal (heal only — no mirrored-state note; that note
  is pull-specific) on the local tree before the transfer, so a damaged tree
  can't keep confusing its owner and every sync op becomes a repair point.
  Same quiet-under-`--json` rule. It runs after the hub-copy guard (a refusal
  must still spawn/mutate nothing).
- **After a FAILED pull**: the transfer erroring must still run the heal
  (repair what it can; the interrupted state is exactly when damage lingers).
  Keep the existing rule inverted: a heal failure never masks the transfer
  error — the transfer's error stays the exit/CmdResult.
- Both CLI (`sync_one`) and app API (`sync_apply`) paths — they must not
  drift; extract a helper if needed rather than duplicating call sites.
- Careful with preview/dry-run: `--dry-run` and preview must stay
  side-effect-free. Heal fires only on real apply paths (push apply, pull
  apply success AND failure).

### 4. `.worktrees-sync/` stops polluting git status

- Add `"/.worktrees-sync/"` to the `missing` list in `exclude_app_state`
  (store.rs). Read its doc comment first — the rationale (machine-local state
  the tool wrote; `info/exclude` not `.gitignore`; never hides tracked files)
  applies verbatim. Extend the existing tests; note the known ROADMAP gap
  (existing stores never re-run this) is OUT of scope.
- Add `/.worktrees-sync/` to THIS repo's `.gitignore`, next to the
  `/.worktrees/` dogfooding entries, with a one-line comment matching the
  file's voice.

### CHANGELOG

`[Unreleased]` entries for all three (user-visible voice, match existing
entries' style).

## Non-goals

- No new CLI subcommands, no `doctor --fix`, no manifest/schema changes, no
  version bump, no app UI beyond what §2's grep dictates.
- Existing bats tests must stay untouched-green except where a new heal edge
  legitimately adds output lines — if an existing assertion must change, flag
  it prominently in the report with the reason.

## Tests (red-first, every one)

Every new test must be shown red first (break the thing under test or
mutation-prove it, per CLAUDE.md), then green. Record each proof in the report.

- Unit (sync.rs): `skipped_files_finding` — damage ⇒ Warning finding with
  count; clean tree ⇒ None; excluded-pattern non-match (a tracked deletion NOT
  matching the excludes) ⇒ None.
- Unit (store.rs): `exclude_app_state` writes `/.worktrees-sync/`; idempotent
  on re-run (extend the existing test shapes).
- bats: (a) doctor reports the finding on a damaged tree and exit code follows
  Warning semantics (check what Warning maps to before asserting); (b) push
  heals the damaged tree before transferring; (c) a pull whose rsync FAILS
  (make the fake rsync exit non-zero) still heals and still reports the
  transfer failure as the outcome. Follow the #146 bats technique for
  constructing damage.

## Gates (in this order, with the freshness + pipeline traps from CLAUDE.md)

```
cargo build --release -p worktrees-cli   # FIRST, then [ target/release/worktrees -nt crates/worktrees-core/src/sync.rs ]
make test > /tmp/bats.log 2>&1; echo $?; grep -cE '^not ok' /tmp/bats.log
make lint
cargo test -p worktrees-core   | grep -E "^running|^test result"
cargo test -p worktrees-cli    | grep -E "^running|^test result"
cargo test -p app --lib        | grep -E "^running|^test result"
cd app && ./node_modules/.bin/tsc --noEmit && cargo check -p app
```
(Use `make -C` / absolute paths — the Bash cwd persists between calls.)
If any app/src TS file is touched, also run the relevant `app/scripts/*-check.mjs`.

## Final report

Raw data only: files touched + line counts, every gate's real output (grep'd
per the rules), each red-first proof (what was broken, what went red, restored),
the §2 app-surface answer, deviations with reasons, punted items.
