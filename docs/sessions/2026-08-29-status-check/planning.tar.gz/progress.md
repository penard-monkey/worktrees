# Progress

## Session 2026-08-29 — status-check design think-through
- Created planning files. No prior plan existed (fresh after /clear).
- Captured live `worktrees ls --json`; analyzed 11 places by hand → findings.md.
- Spawned Explore agent to map header badges / data model / context menu /
  modal patterns / lifecycle / claude integration / Tauri commands.
- Explore results folded into findings.md (header badges, data model, patterns,
  claude plumbing). Checked tmux activity (polluted) + claude-dir mtime (real).
- Design proposal delivered to David: header simplification, status-check modal
  (3 tiers: facts-only / +claude one-shot / chat deferred). Awaiting direction.

## Session 2026-08-29 (cont) — spec phase
- David: spec it out, build through Tier 1; confirmed ↓behind = noise, remove
  from header/rows (survives only in modal facts + JSON).
- Anchor workflow (6 agents) verified all code refs. Big corrections: NO fake
  git shim (bats = real git + throwaway repos); doctor runs core op IN-PROCESS;
  lifecycle must not be optimistically patched (App.tsx:2065-2068); fail-closed
  ai_launch_for detectable via match_word != "claude". Reports saved in
  scratchpad anchor-raw-*.md.
- Wrote spec-status-check.md (root, untracked): PR A ui-header-calm,
  PR B ui-status-check (health.rs + `worktrees status` + place_health +
  StatusSheet), PR C ui-ask-claude (headless claude -p, cache in
  Declared.extra.status_report).
- Adversarial verify workflow (3 skeptics) done: 1 blocker + 2 case-breakers +
  ~10 anchor drifts — all folded into spec (details in findings.md).
- David mid-turn ×2: pins/tiers not useful; nav click auto-opens sessions
  (remove), Lifecycle ▾/Close unused, simplify first. Confirmed mechanism:
  PlaceRow onClick → enterPlace → touch_place + open_place (App.tsx:2795,
  2247-2257). Added PROPOSED: PR A0 ui-click-select, A2.5 topbar de-clutter,
  Open questions (pin aging, tier regroup, select→check→act).
- Spec final at spec-status-check.md. Order A0→A→B→C. David: yes to all four,
  start A0. Spec marked LOCKED (pin aging folded into PR A as A2.6; tier
  regroup deferred).

## Session 2026-08-29 (cont) — A0 implementation
- Opus agent implemented A0 on branch ui-click-select @ 3c19fd8 (off fresh
  origin/main, NOT pushed). 74+/2- across App.tsx/App.css/CHANGELOG.
- All gates green (bats 318, core 254, cli 7, app-lib 42, tsc, cargo check,
  lint via `nix shell nixpkgs#shellcheck` — shellcheck not installed locally;
  pnpm install ran under Node 26, not the pinned 22.23.2 — worked).
- Headless harness verification: click spawns nothing / dblclick + ▸ fire one
  open_place each / row width provably constant (.row-slot grid stack) /
  Resume rows unchanged.
- Fable review of the diff: APPROVED. Checked: closeCtx clears confirmRm on
  select; .row-slot visibility swap; PendingRow "creating…" out of scope of
  the hide rule; --dur-fast token exists; navdrag skips buttons; hidden
  button out of tab order.
- Outstanding before merge: hover feel in the real app + sandbox.sh --app
  pass (mock-timing rule). Noted: app/scripts/record-readme.py,
  record-profiles.py, shoot-profiles.py click .row to enter — need dblclick
  when media is regenerated (→ ROADMAP or PR A).

## Session 2026-08-29 (cont) — PR A implementation
- shellcheck installed via brew (0.11.0, same as nix served — no drift).
- Opus implemented PR A on ui-header-calm @ f49540f, STACKED on
  ui-click-select @ 3c19fd8. Rebase at PR time:
  `git rebase --onto origin/main 3c19fd8 ui-header-calm` (after A0 merges).
- All gates green; 33/34 harness assertions (1 failure proven pre-existing:
  xterm 'dimensions' page error on base). Deviations all sound: fixture NOW
  rebased to wall clock (frozen epoch was drifting), main fixture aged 45d +
  behind:2 (proves exemptions), "Close session" label, closeFromMenu wrapper,
  .row.stale declared before .row.sel (selected row never dim), record
  scripts → dblclick. SPEC DRIFT FOUND: the ⋯ popover's Remove uses a
  RemoveDialog now, no arm pattern — B4's remove action should open that
  dialog, not arm.
- Fable review: APPROVED (App.tsx + css + fixtures + scripts + changelog all
  read). Awaiting David: real-app pass, then squash-merge A0 → rebase A →
  merge A.
- Next: PR B stacked on ui-header-calm.

## Session 2026-08-29 (cont) — PR B + C
- PR B done: ui-status-check @ cf7ca7d (stacked on f49540f). +1458/-1.
  Red-then-green at BOTH levels (13 unit tests 10-red vs stub; status.bats 7/7
  red vs shipped 0.18.0 binary). All gates green (core 267 now). Harness 6/6 +
  verdict colors vs tokens; agent caught+fixed its own React duplicate-key
  ("none" collided with ProjectSheet's) via console check.
  Real CLI on everything-settings: active (Entered 1h ago — correct);
  aged +20d via WORKTREES_STATUS_NOW → work-at-risk with all three reasons.
  Deviations accepted: HealthFacts.base field; resolve_place actually REFUSES
  main (spec was wrong — used close_one's resolution shape); true_unpushed
  falls back to not_on_base_total on @{u} failure (configured≠resolving
  upstream); upstream reason gated on ahead>0; cold/active get blurbs; mock
  ports assess faithfully; ago duplicated in StatusSheet (cycle avoidance).
  NOTE: current main HAS `worktrees sync` — verify-skeptics read the old
  checkout; no collision (status is a flat arm).
  Fable review: APPROVED (health.rs full read; ops/lib/common.bash hunks;
  StatusSheet + mock skim). Not run: sandbox.sh --app pass (B5 item, manual).
- PR C launched: ui-ask-claude stacked on cf7ca7d. Corrections baked into the
  brief: ai_word_of guard (not match_word), exec in sh -c line, empty-stdout
  = Err, place_dir for (main), share place_health's in-process parse, mock
  1500ms delay + declared write-through, manual-checks §11 + prose fix.
- PR C done: ui-ask-claude @ 906fd54. +570/-14. Red-then-green (45 app-lib
  tests, 2 shown failing against a deliberately-wrong guard). All gates green.
  Harness: no-auto-run / in-page 250ms spinner sampling / cache-on-reopen /
  permanent error branch on spike-graphql / layout via getComputedStyle.
  Deviations accepted: empty-ai_cmd checked FIRST (ai_word_of("") defaults to
  "claude" — test documents it); single onReport callback (ordering lives in
  App); pre-cached report on legacy-migration fixture; local `fresh` state so
  a 90s answer survives the place vanishing from ws.
  Fable review: APPROVED (full backend hunk read).
- ALL FOUR PRs done + reviewed. Stack: 3c19fd8 → f49540f → cf7ca7d → 906fd54.

## Session 2026-08-29 (cont) — merge train (David: "run the merge train")
- Surprise at preflight: origin/main +2 (app-zoom #169 + close-out #170,
  touching App.tsx/SettingsSheet/settings/install.ts/CHANGELOG). A0 rebased
  onto it first; only CHANGELOG conflicted.
- Merged: #171 (click-select) → #172 (header-calm) → #173 (status-check) →
  #174 (ask-claude). FULL gates after every rebase, 4× green. CHANGELOG was
  the only conflict, 3 times (A0, B, C) — merged both [Unreleased] sides.
- Branches deleted local+remote; worktree parked on ui-next (stale idle base —
  close-out will cut the fresh one).
- Still owed (manual): sandbox.sh --app pass on main; manual-checks §11.
