# Task Plan: worktree status-check design (think-through)

## Goal
Design (not yet implement) a right-click "Status check" for a place → modal with
worktree health (fresh/stale/zombie, abandon-or-resume guidance). Explore a
non-interactive claude layer for richer summaries. Also: audit the place header
statuses (name, "live", git status, "Active") — user doesn't know why two
status badges exist.

Deliverable this session: a design assessment for David to react to. No code
until he picks a direction.

## Phases

### Phase 1: Recon — status: complete
- [x] Live `worktrees ls --json` snapshot captured (see findings.md)
- [x] Explore agent: header badges, data model, context menu, modals,
      lifecycle, claude integration, Tauri commands → findings.md digest

### Phase 2: Analysis — status: complete
- [x] Health signals derivable now: created/last-commit epochs, activityAt,
      dirty, ahead-vs-base, upstream, claude-dir recency (cheap add)
- [x] Header: "live" duplicated (tmux_session.up twice), "ACTIVE" =
      lifecycle_effective; redundant whenever session is up

### Phase 3: Design proposal — status: complete
- [x] Status-check modal: facts + verdict heuristic + action buttons
- [x] Claude non-interactive layer: `claude -p` one-shot, cached in
      Declared.extra; chat deferred
- [x] Tidiness: on-demand only; status check bridges to existing (unused)
      lifecycle states

### Phase 4: Deliver design assessment — status: complete
- [x] Presented; David: "spec it out, at least go with Tier 1", behind = noise.

### Phase 5: Spec (spec-status-check.md) — status: complete
- [x] Anchor workflow (6 agents) → verified refs; corrections in findings.md
- [x] Draft: PR A header calm-down / PR B status verb+modal / PR C ask-claude
- [x] Adversarial verify workflow (3 skeptics) → 1 blocker (fail-closed guard
      via ai_word_of, not match_word), broken parked bats case, invented
      `sync` verb, (main) pull-indicator loss, ~10 anchor drifts — ALL folded
- [x] David mid-turn: pins/tiers not useful; click auto-opens sessions —
      remove; Lifecycle ▾ + Close unused — simplify first
- [x] Added PROPOSED sections: PR A0 (click selects, Enter opens — root cause
      of "everything active"), A2.5 (topbar de-clutter), Open questions
      (pin aging, tier regroup, select→check→act). Order: A0→A→B→C.

### Phase 6: David's confirmation — status: complete
- [x] 2026-08-29: yes to all four (A0, A2.5, main-keeps-↓, pin aging now /
      tier regroup deferred). Start with A0. Spec updated to LOCKED.

### Phase 7: Implement A0 (ui-click-select) — status: complete
- [x] Opus implemented @ 3c19fd8, all gates green, headless checks pass
- [x] Fable reviewed the diff: approved

### Phase 8: Implement A / B / C (stacked) — status: complete
- [x] PR A ui-header-calm @ f49540f (on 3c19fd8) — approved
- [x] PR B ui-status-check @ cf7ca7d (on f49540f) — approved
- [x] PR C ui-ask-claude @ 906fd54 (on cf7ca7d) — approved

### Phase 9: Merge train — status: complete (2026-08-29)
- [x] origin/main had moved (+2: app-zoom #169/#170) — A0 rebased onto it first
- [x] #171 ui-click-select · #172 ui-header-calm · #173 ui-status-check ·
      #174 ui-ask-claude — all squash-merged, full gates green after EVERY
      rebase (4×: bats 0 not-ok, core 254→267, cli 7, app-lib 42→45, tsc,
      lint, cargo check)
- [x] Conflicts: CHANGELOG.md only, three times (parallel [Unreleased]
      sections) — merged keeping both sides each time
- [x] Branches deleted local + remote; worktree parked on ui-next

### Phase 10: Still owed (manual, David) — status: pending
- [ ] Real-app pass on main: sandbox.sh --app (click-select feel, row ▸ hover,
      ⋯ Close, StatusSheet, one real Ask Claude run)
- [ ] docs/ai-profiles-manual-checks.md §11 (6 checks — fail-closed + timeout
      are the load-bearing pair)
- [ ] ROADMAP at close-out: pre-existing harness xterm 'dimensions' error;
      record-scripts media regen note

## Decisions
- User explicitly wants ON-DEMAND check, never automatic.
- behind = noise on worktree rows; (main) keeps ↓ (only pull indicator).
- A0 must land before B (last_opened_epoch honesty).

## Decisions
- User explicitly wants ON-DEMAND check, never automatic.

## Errors Encountered
| Error | Attempt | Resolution |
|-------|---------|------------|
| (none) | | |
