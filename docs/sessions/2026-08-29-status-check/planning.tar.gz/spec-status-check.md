# Spec: worktree status check

PR briefs, implemented in order: **A0 (click-select) → A (header calm-down)
→ B (Tier 0 status modal) → C (Tier 1 "Ask Claude")** — A0 un-poisons the
signals B reads (see A0's SEQUENCING note). Written for an implementing
agent that does NOT re-explore — every claim carries a file:line anchor,
verified 2026-08-29 against branch `ui-next` @ 8187519, then adversarially
re-checked by three independent reviewers (all findings folded in).

2026-08-29, David confirmed: A0, A2.5, the (main)-keeps-↓ exception, and
pin aging (now A2.6) are ALL LOCKED. Tier regrouping stays deferred until
A0 has been lived with. Implementation starts with A0.

## Decisions locked with David (2026-08-29)

- Status check is ON-DEMAND only. No automatic scans, no ambient nagging.
- `↓behind` is noise on WORKTREE rows — it leaves the topbar, the nav-row
  glyphs, and the attention lens for them. Exception: `(main)` keeps its ↓
  (it is the app's only pull indicator — see A2's ⚠). Behind survives as a
  fact inside the status modal and in `ls --json` (schema untouched). The
  verdict heuristic NEVER counts behind as sickness.
- `↑ahead` stays everywhere — divergence from the base is the signal.
- Build through Tier 1 (headless `claude -p` report). Tier 2 (chat) deferred.

## Conventions for every PR (from .claude/close-out.md + memory)

- Branch off a FRESHLY FETCHED `origin/main`; verify with
  `git rev-list --left-right --count origin/main...HEAD`. Branch names below;
  this tree's idle base is `ui-next` — never share it with another worktree.
- Squash-merge. PR title = conventional prefix + plain-English outcome
  sentence, lower-case, em-dashes fine (see `git log --oneline` for style:
  "feat(app): ⌘F finds — in the terminal, and in the file you have open").
- Commits: keep `Co-Authored-By`, NO Claude-Session trailers or session URLs.
- CHANGELOG `[Unreleased]` entry per PR — user-voice prose, bold lead
  sentence, wrapped ~80 cols (style: CHANGELOG.md:1-30). It ships in the
  binary (include_str!) as "What's new" — write for end users.
- Gates, in this order (CLAUDE.md — release build FIRST, stale binary can
  make bats falsely PASS):
  ```sh
  cargo build --release -p worktrees-cli
  make test            # redirect to log; check $? AND grep -cE '^not ok'
  make lint
  cargo test -p worktrees-core     # report via grep -E "^running|^test result"
  cargo test -p worktrees-cli
  cargo test -p app --lib          # check/build do NOT compile mod tests
  cd app && ./node_modules/.bin/tsc --noEmit && cargo check -p app
  ```
- New tests must be shown to FAIL first (break the thing, watch red, restore).

---

# PR A0 — click selects, Enter opens (LOCKED 2026-08-29)

Branch: `ui-click-select`. The root cause of "everything reads active":
`PlaceRow`'s `onClick={() => enterPlace(repo, p)}` (App.tsx:2795), and
`enterPlace` (App.tsx:2247-2257) does `setSel` + fire-and-forget
`touch_place` + `runCmd("open_place")` — every idle click SPAWNS a tmux
session (with the AI profile in it), stamps `last_opened_epoch`, and drifts
the place to "active". Eleven sessions up in the real workspace today, most
from browsing.

Proposed:
1. New `selectPlace(repo, p)` = `setSel` + `setMenu(null)` + `closeCtx()`
   only — no touch, no open. PlaceRow onClick uses it. Double-click =
   `enterPlace` (kept as-is).
2. Explicit open affordances (mostly already exist): topbar `Enter` button
   when session down (App.tsx:3191), empty-state "Enter to start"
   (App.tsx:3276), ctx-menu Enter (App.tsx:3531). Home resume-rows
   (App.tsx:3315) KEEP click-to-enter — "Resume" is their contract.
   Add: a small `▸` enter button on the nav row, visible on hover/selected
   (David: "the open button visible" on lower tiers) — enter-btn styling
   exists.
3. `touch_place` then fires only on real Enter → `last_opened_epoch`
   becomes an honest "I was there" signal (B1's activity max depends on
   this — see the ⚠ there).
4. Selecting a session-down place shows the existing down-state topbar
   (Enter button) + files pane; nothing spawns.

Consequences: sessions exist only when asked for → "active" regains
meaning, the Active/Idle tiers get their signal back, battery stops paying
for browsing (ROADMAP:85's 3s-loop cost scales with session count).
SEQUENCING: this lands FIRST — B's heuristic and the tier rethink both
read signals this PR un-poisons.

# PR A — header calm-down

Branch: `ui-header-calm`. Frontend-only; no backend, no schema changes.

## A1. Remove the duplicated "live" badge

"live" renders twice, both driven by `tmux_session.up`:
- status-cluster badge — App.tsx:3144
  `{selected.tmux_session.up && <span className="s ok" title="tmux live">…live</span>}`
- controls `.live-badge` — App.tsx:3157 (doubles as the Close affordance)

Delete the status-cluster one (line 3144). Keep the controls one.

## A2. Drop `↓behind` from every render site — EXCEPT `(main)`

⚠ The exception exists because for `(main)` the base ref IS `origin/main`
(project.rs:517-528; the place_json comment even says "(main) degenerates to
the classic pull counter", project.rs:365) — its ↓ is the app's ONLY
"you need to pull" indicator. Worktree rows lose ↓ (noise); main keeps it
(actionable).

Complete site list (verified sweep — these are ALL of them):

1. **Topbar** App.tsx:3146:
   `{(selected.ahead || selected.behind) && <span className="s ab" …>↑{ahead} ↓{behind}</span>}`
   → `{(!!selected.ahead || (selected.is_main && !!selected.behind)) && <span className="s ab" title="vs the base branch">…}`
   rendering `↑N` when ahead, plus `↓N` only when `is_main && behind`.
2. **Nav-row glyphs** — `glyphs()` App.tsx:206-216: the behind push at
   App.tsx:211 becomes `if (p.is_main && p.behind) g.push({ cls: "g-behind", … , title: \`${p.behind} to pull\` })`.
   Keep g-ahead. (Sole render site is PlaceRow App.tsx:2814-2818, all lenses.)
3. **Attention lens** — `hasAttention` App.tsx:144:
   `const hasAttention = (p: Place) => !!p.dirty || !!p.ahead || !!p.behind;`
   → `… !!p.dirty || !!p.ahead || (p.is_main && !!p.behind)`. Update the rail
   title App.tsx:2978 ("Attention — dirty / ahead-behind / broken" →
   "dirty / unpushed / unpulled main / broken").
4. **CSS** — keep `.g-behind` (App.css:407 — still used by main rows) and
   `.status-cluster .ab` (App.css:508).
5. **Hint text** — SettingsSheet.tsx:396 "Keeps ahead/behind counts fresh."
   → "Keeps the divergence counts fresh." (auto-fetch still moves the base
   ref; behavior unchanged).
6. **Stale comments** (fix while there): the status-cluster comment
   App.tsx:3140-3141 and the `MAIN_TIGHT` doc comment settings.ts:310-314
   both claim the badges are "duplicated in … the status bar" — false (the
   statusbar App.tsx:3281-3295 shows only branch + tmux facts). Reword to
   "duplicated in the nav row".

Do NOT touch: `type Place` behind field (App.tsx:43), mock fixtures
(mock/fixtures.ts:24-25), backend — the data stays; only worktree rendering
goes.

## A2.5 Topbar de-clutter (LOCKED 2026-08-29 — David: "lifecycle button… never used, neither the close")

- Remove the `Lifecycle ▾` popover (App.tsx:3202-3216) from the topbar
  entirely. Lifecycle actions remain in the ctx menu (App.tsx:3568-3576)
  and gain a home in the StatusSheet action row (B4) — the status check is
  where a lifecycle decision has context.
- Move `Close` (App.tsx:3181-3188, with its armed-kill variant) into the
  `⋯` popover (App.tsx:3222-3247), keeping the arm/confirm pattern and the
  `hdr|`-style key rules (App.tsx:73-88). Ctx-menu Close (App.tsx:3540-3547)
  unchanged.
- Topbar reduces to: name/branch · dirty · ↑ · live badge (or Enter) ·
  profile badge · pin · ⋯.

## A2.6 Pin/row aging (LOCKED 2026-08-29)

Pins keep POSITION; age still shows. In PlaceRow (App.tsx:2786+):
- Frontend const `STALE_DAYS = 14` (mirrors B1's STALE_SECS — keep the two
  in sync by comment reference).
- `const stale = !p.is_main && (Date.now() / 1000 - activityAt(p)) > STALE_DAYS * 86400;`
  (`activityAt` App.tsx:1582 is already computed per row; rows re-render on
  every poll refresh so the class stays fresh). `(main)` never dims — it is
  the anchor, not a cleanup candidate.
- Add `" stale"` to the row className; CSS (near the row rules,
  App.css:~380-412): `.row.stale .row-name { color: var(--txt-mute); }` —
  one rule; the ★ prefix lives inside `.row-name` (App.tsx:2809-2811) so
  the pin dims with the name. `row-age` stays at full color (it is the
  explanation).

## A3. Lifecycle chip only when it says something the dot doesn't

App.tsx:3147: `<span className={"life " + selected.lifecycle_effective}>…`
→ wrap: render only when `selected.lifecycle_effective !== "active"`.
idle / closed / saved / archived / abandoned keep rendering (CSS per state
already exists, App.css:509-516; `.life.closed` intentionally has base
styling only).

## A4. Acceptance (assert in the mock harness via DOM/getComputedStyle — never eyeball, CLAUDE.md)

Run against `pnpm dev:mock` on a non-1420 port; kill/verify the server per
CLAUDE.md (lsof -sTCP:LISTEN + grep served file for a CODE token the edit
added, not a comment).
- Place with tmux up: topbar contains exactly ONE element with text "live";
  no `.life` element present.
- Non-main fixture with `behind > 0, ahead = 0`, clean: no `↓` anywhere in
  its nav row or topbar; place absent from the attention lens.
- MAIN fixture with `behind > 0`: `↓N` still present in its nav row and
  topbar; main present in the attention lens.
- Fixture with `ahead > 0`: `↑N` present in nav row and topbar; present in
  attention lens.
- Fixture with declared lifecycle "saved" + tmux up: `.life.saved` chip
  present (sticky states still show).

CHANGELOG (Changed): "**The place header stopped saying things twice.**
One live badge, no ↓-behind noise — behind-the-base counts still live in
the status check (see below) but no longer clutter every row…" (write final
user-voice text at PR time).

---

# PR B — Tier 0: `worktrees status` + StatusSheet modal

Branch: `ui-status-check`. One verdict computed in core; CLI `--json` is the
schema; the app parses the same struct (doctor pattern, lib.rs:1787-1845) so
CLI and app can never disagree.

## B1. Core: `crates/worktrees-core/src/health.rs` (new module)

Register `pub mod health;` in core's lib.rs. Serde structs (Serialize +
Deserialize — the app deserializes them):

```rust
pub const SCHEMA_VERSION: u32 = 1;
pub const STALE_SECS: i64 = 14 * 24 * 3600;

#[derive(Serialize, Deserialize, Clone, Debug)]
pub struct HealthFacts {
    pub slug: String,
    pub branch: Option<String>,
    pub created_epoch: Option<i64>,
    pub last_commit_epoch: Option<i64>,
    pub last_commit_subject: Option<String>,
    pub last_opened_epoch: Option<i64>,   // declared: last real Enter (touch_place)
    pub last_worked_epoch: Option<i64>,   // declared: claude finished a task
    pub claude_last_epoch: Option<i64>,   // newest *.jsonl mtime in claude_session_dir
    pub dirty_files: u32,
    pub ahead: i64,                       // vs base ref — existing semantics
    pub behind: i64,                      // fact only, NEVER sickness
    pub upstream: Option<String>,
    pub tmux_up: bool,
    pub lifecycle_effective: String,
    pub note: Option<String>,
    pub title: Option<String>,
    pub not_on_base: Vec<String>,         // `git log --oneline base..HEAD`, cap 20
    pub not_on_base_total: u32,           // real count (list may be capped)
    /// `git rev-list --count @{u}..HEAD` when an upstream exists; None when
    /// there is no upstream (then ALL not_on_base commits are machine-local).
    pub true_unpushed: Option<u32>,
    pub maybe_merged: u32,                // `git cherry <base>` '-' lines (patch-id)
}

#[derive(Serialize, Deserialize, Clone, Debug)]
pub struct Report {
    pub schema_version: u32,
    pub verdict: String,                  // "active" | "parked" | "at-risk" | "cold"
    pub reasons: Vec<String>,             // ordered, most important first
    pub facts: HealthFacts,
}

/// Pure and deterministic: `now` injected (store::reconcile-test style,
/// store.rs:196+), dates rendered through the injected `fmt_date` so unit
/// tests pass a trivial closure (e.g. `|e| e.to_string()`).
pub fn assess(f: &HealthFacts, now: i64, fmt_date: &dyn Fn(i64) -> String)
    -> (String, Vec<String>)
```

Heuristic — exactly this, in this order:
1. `activity = [last_commit_epoch, last_opened_epoch, last_worked_epoch, claude_last_epoch, created_epoch].flatten().max()`
   ⚠ created_epoch and last_opened_epoch are IN the max on purpose: a fresh
   worktree cut from a month-old base has an old HEAD commit date and would
   otherwise read cold on day one; a place you Entered 3 days ago was
   touched 3 days ago.
   ⚠⚠ last_opened_epoch is only honest AFTER PR A0: today `enterPlace`
   fire-and-forgets `touch_place` on every nav CLICK (App.tsx:2253), so
   browsing stamps it. A0 must land before B, or B ships with
   last_opened_epoch excluded from the max and a TODO to re-add it.
2. `has_unique_work = dirty_files > 0 || ahead > 0`
   ⚠ `ahead` counts commits not on the BASE, not unpushed commits — a
   branch fully pushed to its own origin/feat-x still reads ahead>0
   (project.rs:357-373; pinned by test/json.bats:106-121). The REASONS must
   respect that distinction; the verdict deliberately does not (unmerged
   work needs a decision either way).
3. Verdict:
   - `active` — `activity.map_or(false, |a| now - a < STALE_SECS)`
   - `at-risk` — stale && `has_unique_work`. Reasons (each only when true,
     this order):
     - "N commit(s) not on <base>, newest from <date>: <subject>"
     - "M uncommitted file(s)"
     - upstream == None →
       "no upstream — this work exists nowhere but this machine";
       upstream Some && true_unpushed > 0 →
       "K of them not pushed to <upstream>";
       upstream Some && true_unpushed == 0 →
       "all pushed to <upstream> — safe, but not on <base>"
     - "K commit(s) match patches already on <base> (patch-id — unreliable
       across squash merges)" — only when `maybe_merged > 0`
   - `parked` — stale && !has_unique_work && tmux_up. Reason (exactly one):
     "clean and nothing ahead of the base — this worktree holds no unique
     work; behind N is just the base moving."
   - `cold` — stale && !has_unique_work && !tmux_up.
4. `behind` never generates a reason on its own; `activity == None`
   counts as stale. The four verdict branches above are total (active
   short-circuits first; the other three partition stale by
   has_unique_work × tmux_up).
5. Date rendering: gather passes `&|e| clock.fmt_date(e)` (sysclock has
   `fmt_date(epoch)` and `ago(epoch, now)` — sysclock.rs; ago buckets
   0m/3h/5d/2w).

Claude-dir newest mtime (new helper, health.rs or project.rs — no existing
one, materialize.rs:333 `mtime_ns` is private/per-file): std::fs::read_dir
over `claude_session_dir`, max `metadata().modified()` of `*.jsonl` entries,
epoch secs. This is NOT a bash-parity path — plain std::fs is fine (no
sysclock shell-out needed).

Unit tests (`mod tests`, bottom of health.rs, style of store.rs:196+ —
long `///` rationale comments, fixed `now`, `fmt_date = |e| e.to_string()`):
- one per verdict;
- behind-is-not-sickness: `behind: 99, ahead: 0, dirty: 0`, stale → parked,
  and the ONLY reason is the single parked sentence;
- boundary: activity exactly `now - STALE_SECS` → stale;
- no-activity-at-all → stale;
- fresh-worktree-off-old-base: old last_commit_epoch, recent created_epoch
  → active (the ⚠ in step 1);
- pushed-but-unmerged: upstream Some, true_unpushed 0 → at-risk with the
  "safe, but not on <base>" reason, NOT the machine-local one;
- at-risk reason ordering (not-on-base first).
Show them fail first: implement `assess` as `("active", vec![])` stub,
watch red, then implement.

## B2. Core + CLI: `worktrees status <name> [--json]`

New op `pub fn cmd_status(p: &Project, ui: &mut dyn Ui, args: &[String]) -> i32`
in ops.rs, following `cmd_doctor` (ops.rs:1463) exactly:
- Manual flag loop: `--json` (plus `WORKTREES_JSON=1` env override, same as
  ops.rs:1488); unknown `-*` → `ui.error` + return 1; exactly ONE positional
  place name required (unlike doctor — a health report is per-place;
  missing name → `ui.error("usage: worktrees status <name> [--json]")`, 1).
- Resolve the name the way close/open/rm do — `resolve_place` (ops.rs:1134):
  it gives the bare-`main` → `(main)` alias (unquoted parens are shell
  syntax errors, so `worktrees status main` must work) and the
  registration gate for free. Unregistered / unknown → ui.error, return 1
  (an unregistered place has None git facts; mapping them to 0 would
  fabricate a clean "parked" — refuse instead).
- ONE `now`, resolved once at the top and threaded into BOTH
  `store::reconcile` and `health::assess` (otherwise lifecycle and verdict
  disagree about time):
  `WORKTREES_STATUS_NOW` env override (parse i64) else
  `sysclock::now_epoch()`. Document in the op's doc comment as a test seam,
  not user surface, and ADD IT to the `unset WORKTREES_…` line in
  test/helpers/common.bash's setup (that list exists exactly to stop leaked
  env vars from warping the suite).
- Gather:
  - `let ls = p.ls();` (typed LsJson, model.rs:50-57) → find the resolved
    Place by slug. This reuses ALL existing derived facts (ahead/behind vs
    `p.base_ref()`, status_v2, last_commit, claude_session_dir) with zero
    new git plumbing.
  - `let store = store::read_lenient(&p.main_root);` → `Declared` for slug:
    `last_opened_epoch`, `last_worked_epoch`, `note`, `title`, and
    `store::reconcile(decl, tmux_up, now)` for `lifecycle_effective`
    (CLI's ls emits live-only lifecycle — model.rs:45-47 — so recompute
    here with declared merged, same as the app does at lib.rs:273).
  - Extra git, only when ahead > 0 (runner: `git::git_out(dir, &[...])`,
    git.rs:35 — trimmed stdout Option; `Some("")` = empty success,
    distinguish from None; failure → 0/empty, never an error):
    - `git log --oneline <base_ref>..HEAD` → `not_on_base` lines cap 20,
      `not_on_base_total` real count.
    - `git cherry <base_ref>` → `maybe_merged` = lines starting `- `.
    - when `upstream` is Some: `git rev-list --count @{u}..HEAD` →
      `true_unpushed = Some(n)`; else None.
  - claude newest-mtime helper from B1.
- Emit: `let (verdict, reasons) = health::assess(&facts, now, &|e| clock.fmt_date(e));`
  then
  - `--json`: ONE compact line via `ui.plain(&serde_json::to_string(&report)…)`
    — the doctor template (`emit_report`, ops.rs:1860-1864).
  - human: verdict header via `ui.header`, reasons via `ui.info`, facts as
    aligned `ui.plain` lines.
- Exit codes: 0 = report emitted (any verdict — a report is not a gate),
  1 = usage/unknown/unregistered place. No exit-2 tier (that's doctor's
  findings contract, diag.rs:206-213 — not applicable).

Wire-up:
- main.rs dispatch (main.rs:79-108) is a flat match with NO subcommand
  nesting and no existing `status` (or `sync`) verb: add
  `"status" => ops::cmd_status(&project, &mut ui, rest),` as a plain
  sibling of the `"doctor"` arm (after the git guard — status needs a
  Project, unlike the pre-guard `skills` arm).
- USAGE text in main.rs: add
  `worktrees status <name>              health verdict for one worktree (--json)`.

bats — new `test/status.bats`. **Real git, no shim** (test/helpers/common.bash:
git is real; only tmux/docker/AI are faked; you produce scenarios with real
commits — and the fake tmux DOES register sessions, so a `new` without
`--no-tmux` reads `tmux_up = true`). Template: test/json.bats:106-121
(divergence test) + its helpers (json.bats:17-27: `field()`,
`assert_valid_json` — those parse `ls --json` places; for the single-object
`status --json` write a small local python assert instead). Cases —
⚠ every staleness case must export `WORKTREES_STATUS_NOW=<commit_epoch + 15d>`;
without it a just-made commit reads `active`:
1. at-risk: `run_wt new feat-x --no-tmux`, commit in the worktree, don't
   push, STATUS_NOW forward → output contains "not on"; `--json` verdict
   == "at-risk", `not_on_base_total` == 1, and (no upstream) the
   machine-local reason present.
2. parked: `run_wt new feat-y` WITHOUT `--no-tmux` (fake tmux → up), clean,
   advance origin/main (json.bats:106 pattern), STATUS_NOW forward →
   verdict "parked"; `reasons` is exactly the single parked sentence
   (assert the array length + content, NOT grep-absence of the word
   "behind" — the parked sentence itself contains it).
3. cold: same as 2 but `--no-tmux` → verdict "cold".
4. active: fresh commit, no STATUS_NOW → verdict "active".
5. usage: `run_wt status` (no name) → status 1; `run_wt status nope` → 1.
6. `assert_valid_json`-style parse of the --json line.

## B3. Tauri: `place_health` command

Clone `doctor` (lib.rs:1787-1845) — in-process, NOT a subprocess:

```rust
#[tauri::command]
async fn place_health(repo: String, slug: String) -> Result<HealthReport, String>
```
- `Project::discover` (applog on failure, doctor:1809-1811 pattern),
  `CaptureUi::default()`, `ops::cmd_status(&project, &mut ui, &[slug, "--json".into()])`,
  parse last JSON line: `ui.lines.iter().rev().find_map(|l| serde_json::from_str::<worktrees_core::health::Report>(l).ok())`.
- `HealthReport { code: i32, report: Option<health::Report>, error: Option<String> }`
  — code-1-no-report path mirrors DoctorReport's error field (never
  swallowed; applog "warn").
- `async fn` (CLAUDE.md hard rule). Register in `generate_handler!`
  (lib.rs:3526-3596, append inside the bracket list).

## B4. Frontend: `StatusSheet.tsx` + menu entries

New `app/src/StatusSheet.tsx` at module scope with props (CLAUDE.md:
components inside App() remount every render). Template: ProjectSheet.tsx
(header comment ProjectSheet.tsx:6-16 explains the sheet pattern; reuse its
classes: `.scrim`, `.settings-sheet`, `.settings-h`, `.settings-body`,
`.setting`, `.hint`, `.ctrl sm` (+ `danger armed`), `.ver-actions`,
`.dx-row`-style rows or new `.hs-*` classes).

Props:
```tsx
export function StatusSheet({ open, repo, slug, placeName, onClose,
  onEnter, onLifecycle, onRemove }: { … })
```
Callbacks are handed in from App (the sheet never invokes lifecycle/remove
itself — App already owns those flows and their refresh semantics).

State + fetch: `report / checking / err` like ProjectSheet.tsx:119-131;
`refresh` invokes `place_health` — **tolerate `null`** (mock returns null
for unmocked commands, install.ts:1182-1184; ProjectSheet.tsx:146-147 notes
this). Errors → inline `err` + `invoke("log_event", …)` (note() pattern,
ProjectSheet.tsx:135-138). Own Escape-close effect (ProjectSheet.tsx:182-187).
Re-check button (ProjectSheet.tsx:283-288 pattern).

Content, top to bottom:
1. Verdict banner — colored per verdict via existing tokens:
   active `--ok`, parked `--txt-dim`, at-risk `--warn`, cold `--txt-mute`.
   Reasons as rows beneath.
2. Facts table (`.ver-row`-style label/value): created (render
   `created_epoch` with `ago()` App.tsx:150-158, or a local date via
   `new Date(epoch * 1000).toLocaleDateString()`), last commit + subject,
   last claude work (`claude_last_epoch`/`last_worked_epoch`, whichever
   newer, via `ago()`), dirty files, `↑ahead` vs base, "base moved:
   N commits (informational)" for behind, upstream (or "none — nothing
   pushed"), note.
3. Commits not on base: mono list (`.update-log` pre block is fine),
   capped 20 with "…and K more"; when `maybe_merged > 0` add the patch-id
   caveat line verbatim from reasons.
4. Action row:
   - Enter → `onEnter` (App's enterPlace).
   - Abandon / Archive → `onLifecycle(label)`; App implements as
     `mutate(invoke("set_lifecycle", { repo, slug, label }))` — ⚠ NO
     patchDeclared for lifecycle (App.tsx:2065-2068: lifecycle_effective
     is reconciled server-side; the ctx menu already obeys this at
     App.tsx:3573).
   - Remove worktree… → local two-click arm (`armed` state like
     ProjectSheet.tsx:131), then `onRemove(alsoBranch: false)`.
   - Copy branch → clipboard (App.tsx:3589 pattern).

Mounting (App.tsx, next to ProjectSheet at :3481-3493):
```tsx
const [statusSheet, setStatusSheet] = useState<{repo: string; slug: string} | null>(null);
<StatusSheet key={statusSheet ? statusSheet.repo + "|" + statusSheet.slug : "none"}
  open={!!statusSheet} … onClose={() => setStatusSheet(null)} … />
```
Keyed remount per target (ProjectSheet's `key={projSheet ?? "none"}` trick).
DOM order = z-order (App.tsx:3510 comment): mount BEFORE the ctx menus.

Openers:
- Place ctx menu (App.tsx:3528-3609): new item — ⚠ OUTSIDE the
  `!ctxPlace.is_main` block (App.tsx:3559-3584): `(main)` must get the item
  too (the CLI accepts it and main is where behind survives as a fact).
  Put it in the unconditional region next to "Open on GitHub" /
  "Copy path" (App.tsx:3585-3589):
  `onClick={() => { closeCtx(); setStatusSheet({repo: ctx.repo, slug: ctxPlace.slug}); }}` —
  label "Status check…". `closeCtx` MUST be called (it clears armed
  confirmRm, App.tsx:2228-2241).
- Topbar `⋯` popover (App.tsx:3222-3247): same item.

Type widening (App.tsx:33-54): add `created_epoch?: number | null;`,
`last_commit_subject?: string | null;`, `upstream?: string | null;` — all
already in the backend JSON (model.rs:19-48), currently dropped at the TS
boundary. Mirror in mock/fixtures.ts.

Mock harness (install.ts, giant switch at :500): add `case "place_health"`
returning a canned report derived from the fixture place (verdict per its
ahead/dirty), so the sheet is drivable headlessly. The mock resolves
instantly — that hides refresh-timing bugs (CLAUDE.md); nothing here
mutates ws, so instant is acceptable for B.

## B5. Acceptance

- CLI: bats green (shown red first); `worktrees status everything-settings`
  on the real workspace names the 1 unpushed commit and says at-risk.
- App: mock harness — open sheet from ctx menu, assert verdict text +
  facts rows via DOM; assert `↓`-free everywhere (A still holds).
- Real-app pass (CLAUDE.md: mock hides timing): `app/scripts/sandbox.sh --app`,
  open status check on a real stale worktree.
- Full gate list. CHANGELOG (Added): user-voice entry ("**Right-click a
  worktree → Status check.** A verdict — active, parked, work-at-risk, or
  cold — with the receipts…").

---

# PR C — Tier 1: "Ask Claude" in the StatusSheet

Branch: `ui-ask-claude`. One-shot headless report; never automatic; not a chat.

## C1. Backend: `ai_status_report(repo, slug)` (async command, app-only)

There is NO existing headless-claude path in the repo (verified — every
launch goes through tmux via ops::launch, ops.rs:153/196). This command is
the first; it reuses the profile seam and bypasses the pane.

Flow:
1. `Project::discover`; resolve the place path via `p.place_dir(&slug)`
   (project.rs:416-423 — it special-cases `(main)`; `wt_root.join(slug)`
   does not).
2. Build the launch exactly as interactive entry does — the one seam,
   CLAUDE.md/ops.rs:80-91: `let ai = ops::ai_launch_for(&p, &mut ui, &wt_path, &worktrees_core::config::resolve_ai_cmd(None));`
   (signature: ops.rs:92, takes &Project + &mut dyn Ui + wt + ai_cmd).
3. **Guard** — on the COMPOSED command's first word, NOT `ai.match_word`:
   ```rust
   if ai.cmd.is_empty() || worktrees_core::profile::ai_word_of(&ai.cmd) != "claude" {
       return Err("status report needs the claude CLI — profile failed to prepare, or ai_cmd is not claude".into());
   }
   ```
   ⚠ `ai.match_word` is USELESS here: the fail-closed branch of
   ai_launch_for (ops.rs:139-145) returns a `printf '…' >&2` sentinel cmd
   but keeps `match_word: plain.match_word` — i.e. still "claude" (that
   branch is only reachable AFTER the match_word=="claude" early return at
   ops.rs:102). `ai_word_of(&ai.cmd)` (profile.rs:522, pub) yields "printf"
   for the sentinel, the real tool word for a non-claude ai_cmd, and
   "claude" for both plain and profiled launches — one check, both cases.
   For a nicer message, distinguish: `ai.match_word == "claude"` but word
   != claude ⇒ "your AI profile could not be prepared — see the app log".
4. First run `place_health`'s gather in-process (ops::cmd_status via
   CaptureUi, B3 pattern) to get the Report — the prompt embeds its JSON.
5. Compose prompt (pure helper `fn status_prompt(report_json: &str, path: &str) -> String`, unit-tested):
   - the health Report JSON verbatim;
   - "You are reporting on the git worktree at <path>. The JSON above is
     its measured state. If task_plan.md, findings.md, progress.md or
     ROADMAP.md exist there, read them. Answer in under 250 words:
     (1) what was this worktree for, (2) what state did the work end in,
     (3) recommend exactly one of: resume / push-then-abandon / abandon,
     with one line of justification. Do not run commands; the git facts
     are already in the JSON."
6. Spawn: compose `let line = format!("exec {} -p {} --max-turns 12", ai.cmd, worktrees_core::tmux::sq(&prompt));`
   then `run_deadline` (lib.rs:811-852 — piped, drained, hard deadline; the
   documented pattern for anything that could hang) with 180s:
   ```rust
   let mut cmd = std::process::Command::new("/bin/sh");
   cmd.args(["-c", &line]).current_dir(&wt_path);
   for (k, v) in &ai.env { cmd.env(k, v); }   // CLAUDE_CONFIG_DIR — profile.rs:509
   let out = run_deadline(cmd, 180)…;
   ```
   ⚠ The `exec` is load-bearing: run_deadline kills only its DIRECT child
   (single-pid kill, no process group). Without exec that child is `sh`,
   and a timed-out `claude` survives as an orphan, burning turns and
   keeping any profile-spawned MCP servers alive. `exec` makes sh replace
   itself with claude, so the deadline kill lands on claude.
   `sh -c` because `ai.cmd` is a composed, shell-quoted flag string
   (claude_launch, profile.rs:477-518) — do NOT use `shell_prefix()`
   (that's the tmux path's env-inlining; Command::env is the right layer
   here, per profile.rs:445-455 env-vs-cmd separation). stdin is null in
   run_deadline — fine: the prompt travels as an argument, print mode
   doesn't read stdin. PATH is already login-shell-fixed
   (`fixup_gui_path`, lib.rs:3349-3372, runs before any handler).
   Flags rationale (nothing in-repo pins these — first use): `-p` = print
   mode; `--max-turns 12` bounds tool loops; omit `--output-format` (text
   is the -p default). Headless denies tools needing approval — reads are
   allowed, Bash is not, which is why the prompt forbids commands and
   pre-supplies git facts.
7. On success (exit 0 AND non-empty trimmed stdout): trim, then
   `store::edit(&repo, &slug, |d| { d.extra.insert("status_report".into(), serde_json::json!({ "text": text, "epoch": sysclock::now_epoch(), "verdict": verdict })); })`
   (store::edit — store.rs:178-193, locked + atomic; `extra` flatten
   round-trips unknown keys by design, store.rs:23-78 + tests
   `worked_stamp_round_trips_beside_unknown_keys` store.rs:222 and
   `title_round_trips_beside_note_and_unknown_keys` store.rs:249 — no
   schema surgery, and NOT ui-state.json, which is frontend-owned
   whole-blob per CLAUDE.md). Do NOT touch `last_worked_epoch` (that is
   the afterglow's stamp).
8. Return `{ text, epoch }`; failure paths — ALL Err, all applog'd (error
   convention, lib.rs doctor/update_cli patterns):
   - timeout → Err("claude timed out after 180s");
   - non-zero exit → Err with trimmed stderr tail;
   - exit 0 with EMPTY stdout → Err with the stderr tail (this is a real
     path — never treat empty output as a report or cache it).

Register in generate_handler. Unit tests (app `mod tests`, lib.rs:3617,
run via `cargo test -p app --lib`): `status_prompt` composition (embeds
JSON, contains the three questions, forbids commands), and the
ai_word_of-based guard as a pure helper — including the fail-closed
`printf` sentinel case (a launch with match_word "claude" but a printf
cmd must be rejected).

## C2. Frontend

- `Declared` type (App.tsx:20-31): add
  `status_report?: { text: string; epoch: number; verdict?: string } | null;`
  (extra-flattened → appears as a plain key on declared JSON).
- StatusSheet gains a "Claude's read" section under the facts:
  - cached `declared.status_report` → render text (pre-wrap) +
    "as of {ago(epoch)}" + "Re-run" button;
  - none → "Ask Claude" button + hint "runs your repo's AI profile
    headless — ~30–90s".
  - running state: button disabled, "Asking Claude…" (spinner class
    already exists in the sheet family); on resolve, call
    `patchDeclared(repo, slug, { status_report: {text, epoch, verdict} })`
    BEFORE the confirming refresh — status_report is a verbatim-copied
    declared field, so patchDeclared's contract allows it (App.tsx:2065-2068
    forbids it only for lifecycle). ⚠ Without the patch, a list_workspace
    sweep already in flight when the backend wrote the store can land after
    the resolve carrying PRE-write declared state and blank the fresh
    report for a poll cycle — exactly the timing class the mock cannot
    express (CLAUDE.md).
  - errors inline via the sheet's err row — never swallowed.
- The sheet needs `declared` — pass the live `Place` (or just its
  declared) as a prop from App; the keyed remount keeps it fresh.
- Mock: `case "ai_status_report"` returning canned text after
  `await new Promise(r => setTimeout(r, 1500))` — DELIBERATELY slow so the
  spinner path is exercised (CLAUDE.md: the mock's instant resolve hides
  timing bugs; this is one of the shapes it must not hide).

## C3. Testing reality

- No fake `claude` exists; bats CANNOT cover the spawn (CLAUDE.md AI-profiles
  note). Coverage = unit tests on the pure pieces + manual checks.
- Add `## 11. Headless status report` to docs/ai-profiles-manual-checks.md
  (numbered-section pattern). ⚠ The "What needs the app, and what does not"
  part at :63 is a PROSE subsection, not a table — its load-bearing
  sentence "Only §4 (the 'restart to apply' badge) needs the desktop app"
  (~:70) must be rewritten to name §4 AND §11 (ai_status_report is an app
  command, unreachable from the CLI sandbox). Checks:
  1. profiled repo → report runs under CLAUDE_CONFIG_DIR (assert via the
     profile's rules leaking into tone, or `claude --version` parity);
  2. report lands in `.worktrees.places.json` under the place's
     `status_report` and survives an app restart;
  3. unprofiled repo → plain env, still works;
  4. fail-closed profile (broken materialize) → clean "profile could not
     be prepared" error, NO spawn (the ai_word_of guard, C1 step 3);
  5. timeout path: put a claude-NAMED shim that sleeps 999s in a dir
     prepended to PATH (an `ai_cmd` wrapper with another name would trip
     the guard instead) → Err after 180s, no orphan process left
     (`pgrep -f` after);
  6. a place with no planning files still answers (prompt degrades).
- Real-app pass via `app/scripts/sandbox.sh --app` before release.
- CHANGELOG (Added): "**Ask Claude what a worktree was for.** The status
  check can hand the facts to your repo's AI profile and get back a
  three-line verdict — on demand, cached until you re-run it…"

---

## Deferred decision (revisit after living with A0)

**Tier grouping "not very useful."** Root cause is the pre-A0 auto-open:
with every click spawning a session, `bucketOf` (App.tsx:143 — pinned
overrides lifecycle; LIVE_TIERS pinned/active/idle, App.tsx:126-137)
degenerates to "Pinned + one giant Active". A0 is landing first; watch
whether Active/Idle regain meaning. If not, the fallback design is
activity-bucket grouping (Pinned / Recent / Stale / Dormant off
`activityAt`, ignoring tmux entirely).

**Select → check → act flow polish** (do with B4): consider surfacing
"Status check…" directly in the topbar for session-DOWN places (next to
Enter) so the check is one click when it matters most. B4's plumbing
supports this for free.

## Out of scope (recorded, not built)

- MCP: fold the health verdict into the `place_status` tool (mcp.rs:190) —
  natural follow-up, zero new plumbing once health.rs exists.
- `worktrees status --ai` CLI flag (headless report from the CLI) — the
  seam supports it; deferred with Tier-2.
- Workspace-wide triage sweep ("triage all my worktrees") — candidate
  Tier 1.5, one claude -p over the whole ls --json.
- Persistent chat — deferred until one-shots feel limiting.
- fs-mtime "last edited" scan of the worktree — the activity trio
  (commit / worked / claude-dir) is enough for v1.
