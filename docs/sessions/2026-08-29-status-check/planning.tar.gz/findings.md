# Findings: status-check design

## Verify-pass results (2026-08-29, 3 adversarial reviewers — all folded into spec)
- BLOCKER: fail-closed ai_launch_for keeps match_word "claude" (ops.rs:139-145
  copies plain.match_word; the printf sentinel is only reachable AFTER the
  match_word early-return). Guard must use ai_word_of(&ai.cmd) → "printf".
- run_deadline kills only the direct child → sh -c line needs `exec` or a
  timed-out claude survives as an orphan.
- exit-0-empty-stdout is a REAL claude failure shape — must be Err, never cached.
- parked verdict requires tmux_up → bats case must NOT use --no-tmux;
  every staleness case needs WORKTREES_STATUS_NOW (+ add it to common.bash's
  unset list — leaked env would warp the whole suite).
- `ahead` counts not-on-base, not unpushed (json.bats:106-121 pins it) —
  reasons must distinguish via @{u} rev-list; renamed fields not_on_base/
  true_unpushed.
- (main)'s ↓ is the app's ONLY pull indicator (base_ref for main IS
  origin/main) — kept as exception.
- "Edit note…" ctx item is inside !is_main block — status item goes in the
  unconditional region.
- There is NO `sync` CLI verb (I invented it); dispatch main.rs:79-108 flat.
- patchDeclared IS allowed for status_report (verbatim field; forbidden only
  for lifecycle, App.tsx:2065-2068) — needed to beat in-flight sweeps.
- activity max must include created_epoch (fresh tree off old base) and
  last_opened_epoch — but touch_place fires on every CLICK today
  (enterPlace App.tsx:2247-2257), so A0 must land first.

## David mid-spec redirects (2026-08-29)
- Pins: used as "keep visible"; wants them to age visually; finds
  active/pinned/dormant tiers not useful.
- Nav click auto-opens sessions ("clicking around bored → all loaded") —
  remove; want explicit open button visible on lower tiers.
- Topbar Lifecycle ▾ and Close: never used. "Simplify before we finish this
  whole work process out." Wants a view: generate check on worktree/branch
  state → then offer clean up/archive.
- Root-cause synthesis: auto-open is WHY tiers read useless (every click →
  session → "active"). A0 (click=select) un-poisons active/idle AND
  last_opened_epoch, cuts battery cost (3s loop × session count).

## Live snapshot (`worktrees ls --json`, 2026-08-29)

Per-place fields ALREADY in the JSON (no new plumbing needed for these):
- `created` / `created_epoch`
- `last_commit_epoch`, `last_commit_subject`
- `branch`, `detached`, `dirty`, `dirty_files`, `ahead`, `behind`, `upstream`
- `tmux_session {name, up}`
- `claude_session_present`, `claude_session_dir`
- `declared` (null everywhere in this project), `lifecycle_effective`
  (observed values: "active", "closed")

## This project's 11 places — health reading by hand

| place | created | last commit | ahead/behind | upstream | verdict by eye |
|---|---|---|---|---|---|
| (main) | 07-22 | 08-28 | 0/0 | origin/main | healthy |
| sync-macs | 08-16 | 08-28 | 0/1, dirty 6 | origin/main | active work |
| macbook-pro | 08-27 | 08-28 | 0/2 | origin/main | active |
| ui-changes | 08-16 | 08-16 | 0/30 | origin/main | idle base, clean |
| reorder-places-projects | 08-15 | 08-15 | 0/35 | origin/main | idle base, clean |
| ui-tweaks | 08-15 | 08-15 | 0/37 | origin/main | idle base, clean (this one) |
| bug-fixes | 08-15 | 08-15 | **1/41, no upstream** | — | 1 unpushed commit, stale |
| roadmap | 08-12 | 08-12 | 0/50 | origin/main | tmux DOWN → "closed" |
| power-consumption | 08-10 | 08-10 | 0/71 | origin/main | idle base, clean |
| ai-rules-layer | 08-07 | 08-07 | 0/82 | origin/main | idle base, clean |
| everything-settings | **08-02** | **08-02** | **1/99, no upstream** | — | **ZOMBIE: 27 days, 1 unpushed commit on `fix/remove-place-delbranch`** |

Patterns that fall out immediately:
- "Idle base" is recognizable purely mechanically: clean, ahead 0, branch is a
  `*-next` base, behind large. NOT a problem — it's a parked place by design.
- "Zombie" is: ahead>0 (unpushed work) OR dirty, AND last_commit_epoch old.
  everything-settings + bug-fixes are the only two, and both jump out.
- `behind` alone is NOISE for idle places (99 behind just means main moved).
  A health verdict must not treat behind-count as sickness by itself.
- lifecycle "closed" (roadmap) already exists as a derived state when tmux is
  down — need Explore result to confirm exact derivation.

## Missing signals (would need new plumbing)
- fs last-edit time (newest mtime under the tree) — "last touched" ≠ last commit
- tmux last-activity time (tmux has `session_activity`)
- PR state for the branch (gh) — was work merged already via squash?
- claude session recency (dir mtime of claude_session_dir is cheap proxy)

## Signal quality checks (measured 2026-08-29)
- **tmux `session_activity` is POLLUTED** — everything-settings shows activity
  ~5 min ago despite a month idle; several sessions show created=today
  (recreated by app open / status refresh). tmux timestamps reflect the APP,
  not the human. Do not use as a health signal.
- **claude session dir mtime is a REAL signal** — everything-settings' newest
  .jsonl is Aug 7 (matches actual abandonment window). Cheap: newest-mtime in
  `claude_session_dir`.
- CLI already has `worktrees doctor` — but it's FILE-DRIFT (declared
  .worktrees.toml files), a different axis. Name collision to consider:
  extend doctor vs. new verb.
- CLI has `worktrees mcp` — stdio MCP server meant for AI sessions. Ready-made
  plumbing if a claude layer wants live workspace state as tools.

## ROADMAP context
- "Stale worktree/branch cleanup" already a roadmap item (ROADMAP.md:210) —
  this feature is its UI-shaped answer. Key trap recorded there: **squash
  merges break `git branch --merged`** — "was this merged already?" needs
  PR lookup (gh) or patch-id comparison, not --merged.
- Backend has a 3s poll loop (lib.rs setup thread): `session_fingerprint()` +
  `claude_activity()` (busy→ember "afterglow" dot). So the app ALREADY tracks
  claude activity per place — likely one of the header badges.

## Explore agent results (UI map) — digest

### Header badges (App.tsx topbar :3109)
- `"live"` appears TWICE: status-cluster :3144 AND controls `.live-badge` :3157.
  BOTH driven by `tmux_session.up`. Pure duplication.
- `"ACTIVE"` = `lifecycle_effective` string, uppercased by CSS (`.life` App.css:509).
  `reconcile()` (store.rs:101-117): declared saved/archived/abandoned sticky →
  else tmux up → "active" → else opened <7d → "idle" → else "closed".
  So when tmux is up, "live" and "ACTIVE" ALWAYS co-occur → reads redundant.
  They diverge only for sticky declared states or session-down (idle/closed).
- Other badges: dirty ● count :3145, ↑ahead ↓behind :3146 (vs BASE branch, not
  @{u} — project.rs:372, deliberate).

### Data model gaps at TS boundary
- `created_epoch` + `last_commit_subject` exist in backend JSON but are DROPPED
  from frontend `type Place` (App.tsx:33-54). Free wins — just widen the type.
- No fs-mtime "last edit", no tmux attached/start-time, no stash count, no PR
  state. `last_worked_epoch` (declared, store.rs:61) = claude finished a task.
- Frontend already computes `activityAt(p) = max(worked, last_commit)` :1582 —
  the age shown on rows.

### Patterns to copy
- Ctx menu: `CtxMenu` App.tsx:221, place menu :3528-3609; "Project settings…"
  → `setProjSheet(ctx.root)` :3632 is the menu→modal pattern.
- Modal: **clone ProjectSheet.tsx** — already does invoke("doctor") → typed
  `DoctorReport` + checking/err state + Re-check button + `.update-log` pre
  block for long text. Zero new CSS (reuses .scrim/.settings-sheet).
- Typed report pattern: `doctor` cmd lib.rs:1808 runs the real CLI op in --json
  and parses the last JSON line → app and CLI can never disagree on schema.

### Lifecycle
- Declared enum (4): closed | saved | archived | abandoned (lib.rs:507).
- Effective adds derived: active / idle / closed. Never persisted.
- Declared is null for EVERY place in this project — lifecycle feature unused
  in practice. Status check is the missing bridge to it.

### Claude integration status
- Profiles/materialization/AiLaunch (profile.rs) give env+flags for the repo's
  bound profile. `claude_oauth_token()` exists (usage widget).
- **No headless `claude -p` path anywhere** — every launch goes through tmux
  interactive pane. Non-interactive = new Tauri command: build AiLaunch via
  ops::ai_launch_for, spawn with env + `-p <prompt>`, capture stdout. Bypass
  pane0_body/tmux. No bats coverage possible (no fake claude) — manual checks.
- MCP server already has `place_status` tool (mcp.rs:190) — compact per-place
  serializer, reusable as prompt payload.
- Declared struct round-trips unknown keys (`extra` flatten) — a cached AI
  report could live there without schema surgery.
