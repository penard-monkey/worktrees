# Task plan — changed-file markers in the Files tab

## Goal

The dock's Files tab tree marks every file that DIFFERS from the branch's base
— committed on this branch *and* uncommitted (staged, unstaged, untracked) —
and the marker cascades up so a collapsed directory shows that something inside
it changed.

## Constraints (from CLAUDE.md / codebase)

- One git call per place per refresh, NOT per directory. `list_dir` is called
  per open node; a per-node `git status` would be N shell-outs per reload bump.
- Tauri commands must be `async fn`.
- Path guard: any new command goes through `guard_under_projects`.
- The mock harness (`app/src/mock/install.ts`) must track every new command.
- No UI libraries; markers are plain CSS off `app/src/tokens.css`.
- Assert layout in the harness with `getComputedStyle`, don't eyeball.
- HMR is dead inside `.worktrees/` → restart vite `--force` after every edit,
  and kill by CONTENT check (`lsof -ti:PORT -sTCP:LISTEN` + grep served file).

## Phases

| # | Phase | Status |
|---|-------|--------|
| 1 | Recon: FilesPane/list_dir/core git surface | complete |
| 2 | Design decisions with user | complete |
| 3 | Backend: `changed_files` command (status ∪ diff vs base) | complete |
| 4 | Frontend: change set → `FileTree`/`TreeNode` + CSS | complete |
| 5 | Mock harness parity + harness assertions | complete |
| 6 | Gates | complete — all green (see progress.md) |
| 7 | CHANGELOG `[Unreleased]` entry | complete |
| 8 | Merge origin/main → commit → push → PR → squash-merge | complete — **PR #115 merged** as `fe27990` |

## Decisions (phase 2, from the user)

1. **Baseline = merge-base with the repo's base branch.** `<base>...HEAD`
   (three dots) with candidates `origin/main → origin/master → main → master`,
   mirroring core's `base_ref()` precedence. Not `@{u}`: a branch with no
   upstream would show nothing, and a just-merged main would show hundreds.
2. **Marker = tinted + bolded NAME**, no new column. modified → `--warn`,
   added/untracked → `--ok`, deleted → `--danger`; a changed DIRECTORY gets no
   hue, just lifted out of the folder grey (`--txt`, weight 550).
3. **Deleted paths get GHOST ROWS** — invented, dimmed, struck, inert — so a
   marked directory always has a visible cause. Includes ghost DIRECTORIES,
   since `git rm -r` takes the directory with the files.
4. **Extra: changed-count badge on directories.** No "changes only" filter, no
   auto-expand (both → ROADMAP if wanted later).

## What shipped

- `app/src-tauri/src/lib.rs` — `changed_files(root) -> ChangeSet { root, files }`,
  `ChangeKind`, `parse_status_z`, `parse_name_status_z`; 3 spawns per call
  (`rev-parse --show-toplevel`, one `diff --name-status -z <base>...HEAD`,
  `status --porcelain -z --untracked-files=all`), registered in the handler list.
- `app/src/FilesPane.tsx` — `Changes` (files/dirs/ghosts maps), `buildChanges`,
  `withGhosts`, `cmpEntries`, `CHANGE_WHY`; one fetch in `FileTree` per
  (root, reloadToken); `TreeNode` takes `changes`, renders tint + badge + ghosts.
- `app/src/App.css` — `.chg*`, `.tree-count`, `.tree-row.ghost`.
- `app/src/mock/install.ts` — `changed_files` case + `MOCK_CHANGED` fixture,
  and `new.tsx` added to the `src` listing (an untracked file exists on disk).

## Errors encountered

| Error | Attempt | Resolution |
|-------|---------|------------|
| `status_z_classifies_…` expected ` M src/App.tsx`, parser saw `rc/App.tsx` | 1 | Fixture bug, not parser: Rust `\`-line-continuation strips leading whitespace, eating the first status column. Records now built from a slice via `z(&[…])`. |
| Harness: 4 `.tree-row` clicks in ONE `browser_evaluate` left the DOM unchanged | 1 | React batches; the DOM is stale until the eval returns. One click per evaluate call. |
| Playwright MCP wrote the screenshot to the repo root, not `.playwright-mcp/` | 1 | Expected (it refuses paths outside the repo) — moved to `~/.cache/worktrees/worktrees/ui-changes/tree-markers.png`. |
