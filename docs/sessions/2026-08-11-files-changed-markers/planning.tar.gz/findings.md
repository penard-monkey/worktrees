# Findings — changed-file markers in the Files tab

## Where the tree lives

- `app/src/FilesPane.tsx`
  - `FsEntry = { name, path, is_dir, ignored?, link?, link_block? }` (line ~28).
  - `TreeNode` (line 41) — lazy per-dir `invoke("list_dir", {path, showIgnored})`
    in an EFFECT keyed on `reloadToken`; keeps last good listing on failure.
  - `FileTree` (line 149) — root listing, remounted per place via `key={root}`.
  - Row classes today: `sel`, `dir`, `ign`, `link`, `inert`; a `tree-glyph`
    per file kind + `tree-link` ↗ span. A change marker is a new span/class here.
  - `title` string is assembled from name / link target / "gitignored" — the
    change status belongs in that same list.

## Backend

- `app/src-tauri/src/lib.rs:2291` `list_dir` — read_dir + `classify_symlink` +
  ONE batched `git check-ignore --stdin -z` (`git_check_ignore`, line 2338).
  Skips `.git` by name. Sorts dirs first, then `to_lowercase()` codepoint order.
- `guard_under_projects` (line 2223) — canonicalize + containment in registered
  project roots. Every new path-taking command must call it.
- Command list to register in: line ~3106.

## Core git surface (crates/worktrees-core/src/)

- `git.rs`: `git_out(cwd, args) -> Option<String>`, `git_ok`, `git_stdin`.
- `project.rs:521` `base_ref()` — `origin/<base>` when the remote ref exists,
  else the local base branch; `default_base()` = main → master → symbolic HEAD.
  This is the ref the nav's ↑↓ divergence already uses
  (`rev-list --left-right --count {base_ref}...HEAD`, line 367).
- `project.rs:160` `status_v2()` — one `git status --porcelain=v2 --branch` per
  place gives branch/dirty_files/upstream. `dirty_files` counts UNCOMMITTED only,
  so it will NOT equal the number of marked rows (which includes committed).

## Implementation shape (decided in recon)

Union of two cheap calls, per place per refresh:
1. `git status --porcelain=v2 -z --untracked-files=all` → staged/unstaged/untracked.
   `-uall` matters: default `-unormal` collapses a new directory to `dir/`,
   which would mark the dir but leave its files unmarked.
2. `git diff --name-status -z {base_ref}...HEAD` → committed on this branch
   (three-dot = merge-base, so an unmerged main doesn't light everything).

Frontend derives ancestor dirs from the returned paths once per refresh
(`Set<string>` of absolute paths + `Set<string>` of ancestor dirs) → O(1) per
row, no prefix scan per node.

## Resolved: deleted files (was an open question)

Ghost rows, decided by the user. A deleted path has no `read_dir` entry, so the
frontend INVENTS one — dimmed, struck, inert — and invents the ghost
DIRECTORIES too, because `git rm -r tools/` leaves neither the files nor the
directory. `withGhosts` filters by NAME against the real listing, which is what
lets `buildChanges` emit a ghost at every level without knowing what still
exists on disk: anything the listing has wins.

## Gotchas found while building

- **`git status --porcelain -z` needs `--untracked-files=all`.** The default
  `-unormal` collapses a new directory into one `dir/` record: the directory
  would carry a mark and every file inside it would be unmarked.
- **Rust's `\` line continuation strips leading whitespace**, so a `-z` fixture
  written as one continued literal silently loses the ` M` / ` D` status column
  — the exact thing the fixture exists to cover. Build records from a slice.
- **Working-tree status must be applied AFTER the committed diff** in the union:
  it describes the disk the tree is about to list. A file added in a commit and
  then deleted has to come back `deleted` (a ghost row), not `added`.
- **`AD` = staged-added then removed from the worktree** → deleted, so that arm
  has to precede the plain `A` arm.
- **Paths from both commands are relative to the repo TOP-LEVEL, not to `-C`.**
  Resolved with `rev-parse --show-toplevel` + `canonicalize`, and RETURNED to the
  frontend: the ghost/cascade walk needs the same canonical anchor `list_dir`
  paths carry, and a place path can run through a symlink.
- **React batches, so the harness must click once per `browser_evaluate`.** Four
  expand clicks in one eval left the DOM untouched and read as "the tree ignored
  them".

## Cost

3 git spawns per tree refresh (toplevel + one diff + one status), for the WHOLE
tree, gated on window visibility like every other periodic cost. Compare with
what the tree already spends: `list_dir` runs one `check-ignore` per OPEN
directory per bump. The fetch lives in `FileTree`, which is unmounted while the
reader is expanded, so a full-pane read costs nothing.
