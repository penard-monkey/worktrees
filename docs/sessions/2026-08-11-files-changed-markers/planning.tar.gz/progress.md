# Progress log

## Session 2026-08-11 — changed-file markers in the Files tab

- Fresh branch `ui-next` off `origin/main` (82be263), clean tree, no prior
  planning files.
- Recon: read `app/src/FilesPane.tsx` in full; found `list_dir` /
  `guard_under_projects` / `git_check_ignore` in `app/src-tauri/src/lib.rs`, and
  `base_ref()` / `status_v2()` in `crates/worktrees-core/src/project.rs`.
- Four design decisions taken with the user (see `task_plan.md`).
- Built backend `changed_files`, the frontend change set + ghost rows + count
  badge, the CSS, and mock-harness parity.

### Verification

| Gate | Result |
|------|--------|
| `cargo test -p app --lib` | **18 passed** (7 new: both `-z` parsers, the union, real captured git bytes) |
| `cargo check -p app` | clean |
| `cd app && tsc --noEmit` | clean |
| Mock harness (`getComputedStyle`, port 1425) | every class asserted, see below |
| `make lint` | clean (shellcheck + bash-3.2 gate) |
| `cargo test -p worktrees-core` | 207 passed |
| `cargo test -p worktrees-cli` | 6 passed |
| `make test` (bats, after `cargo build --release -p worktrees-cli`) | **288 ok, 0 not ok, exit 0** |

⚠ The first bats run was piped to `tail -15`, so its exit code was TAIL's, not
make's, and a mid-stream `not ok` could have scrolled off. Re-run with full
output captured and the real exit code — that is the 288/0 above. Never read a
gate's verdict off a pipeline's exit status.

Real-git shapes checked against a scratch repo whose branch had a committed
modify + add + delete + rename and uncommitted modify + delete + untracked file
in a new directory; that exact output is now a test fixture.

Harness readings (Tokyo Night):

| Row | class | name colour | weight | extra |
|-----|-------|-------------|--------|-------|
| `src/App.tsx` | `chg chg-modified` | `rgb(255,158,100)` = `--warn` | 600 | title "modified on this branch" |
| `src/new.tsx` | `chg chg-untracked` | `rgb(158,206,106)` = `--ok` | 600 | title "untracked" |
| `README.md` | `chg chg-added` | `rgb(158,206,106)` | 600 | title "added on this branch" |
| `src` | `dir chg chg-dir` | `rgb(192,202,245)` = `--txt` | 550 | badge `3` |
| `crates` → `worktrees-core` → `src` | `chg chg-dir` at each level | — | 550 | badge `1` each (cascade) |
| `docs/old-spec.md` | `inert chg chg-deleted ghost` | `--txt-mute` | 400 | `line-through`, `aria-disabled=true` |
| `tools` (dir deleted with its file) | `dir chg chg-dir ghost` | `--txt-mute` | 400 | `line-through`, badge `1` |
| `main.rs`, `logo.png` (unchanged) | — | `--txt` | 400 | no badge |
| `App.tsx` while SELECTED | `sel chg chg-modified` | keeps `--warn` | — | selection still reads via accent inset bar + wash |

Screenshot: `~/.cache/worktrees/worktrees/ui-changes/tree-markers.png`.

### Landed

- `origin/main` merged into `ui-next` (5 commits: #110–#114). Only `CHANGELOG.md`
  conflicted — both sides had opened an `[Unreleased]`; kept both sets of entries
  under one `### Added` plus main's `### Changed`. Everything else auto-merged.
- Gates re-run ON THE MERGE RESULT: bats 288/0, lint clean, app 18, core 208,
  cli 6, tsc, `cargo check -p app`; harness re-checked (markers unchanged by
  main's per-space dock rework).
- **PR #115 squash-merged** → `origin/main` `fe27990`. All 9 CI checks passed
  (app/install/rust/test on both OSes + lint). Branch `ui-next` kept: this
  worktree is on it.

### Open / next

- Not wired to a settings toggle: markers are always on. Nobody asked for one.
- The nav's dirty count and a tree badge count DIFFERENT things (uncommitted vs
  uncommitted + committed-on-branch). Intentional, but worth a doc line.
- Deferred by decision: "changes only" filter, auto-expand to changed files.
- No PR opened yet.
