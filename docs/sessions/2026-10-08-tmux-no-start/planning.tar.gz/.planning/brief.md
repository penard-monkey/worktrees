# Brief: HOTFIX — `tmux -N` on every call that must not start a server

## Why
On 2026-10-07 at 19:24 the user's default tmux server (pid 18764, 25+ sessions across projects) lost its
socket file and a SECOND server started on `/tmp/tmux-501/default`. The old server is still alive with
every session in it, unreachable; the app then relaunched duplicates of several agents. Most likely
mechanism (tmux client source): when `connect()` to the socket gets ECONNREFUSED (a busy server's
listen backlog is full) AND the client has `CLIENT_STARTSERVER` set, tmux takes its lock, UNLINKS the
socket and starts a new server. The first new server's command was the app's
`new-session -s cdv-test-cdv-mcp`, at the exact second app.log logged `open test-cdv-mcp`.

`tmux -N` ("do not start the server", tmux ≥ 3.2; installed here: 3.7c) clears CLIENT_STARTSERVER, so
a client with it can never unlink a live server's socket. Design context: `docs/proposals/nested-lanes.md`
on PR #458 (fable review must-change #1), which plans per-project servers later — this hotfix is the
small, independent part that ships now.

## Do
1. Inventory EVERY tmux invocation in core, CLI and app (known: `worktrees_core::tmux::tmux()`
   tmux.rs:75, `tmux_available` -V tmux.rs:72, attach/switch tmux.rs:927, the app's `term_open`
   `CommandBuilder::new("tmux")` lib.rs:7728; grep for others, including shell scripts that ship, and
   any `sh -c` strings containing tmux).
2. Every call that is NOT meant to create a session gets `-N` as a global option (before the
   subcommand): list/display/capture/send-keys/kill/has/show/set/attach/switch… Only the code paths that
   deliberately create a session (`new-session`, and anything that must bring a server up) may omit it.
   Make that split structural — e.g. `tmux()` adds `-N` and a separate, named `tmux_launch()` for the
   creating paths — so a future call site gets the safe behaviour by default. Read AGENTS.md first:
   git/tmux stay shelled out; keep one wrapper.
3. Feature-detect: `-N` exists only in tmux ≥ 3.2 (README says ≥ 1.9 recommended). Parse `tmux -V`
   once (cache it), add `-N` only when supported; older tmux keeps today's behaviour. Unit-test the
   version parse (`tmux 3.7c`, `tmux 3.2a`, `tmux 3.1c`, `tmux next-3.6`, `tmux master`, garbage).
4. Think through what changes when the server is genuinely DOWN: a `-N` list/has call must keep reporting
   "no sessions" (not an error that breaks `ls`, the app poll, MCP `place_status`, doctor). Verify each
   caller's handling of the new failure text ("no server running" vs whatever -N prints).
5. **bats harness**: the fake tmux in `test/helpers/common.bash:212-306` reads the subcommand as `$1`
   BEFORE its option loop (line 224) and detects the `copy-mode -q -t X ;` prefix on `$1`/`$2` (216); a
   leading `-N` misparses every call. Teach the shim to consume leading global options (-N, and -L/-S
   with their argument, for the coming per-project work), and keep `$TMUX_LOG` assertions meaningful
   (47 of them grep literal argv — log the global options apart from the subcommand or strip them, your
   call, but no assertion may be weakened). Make the shim's `-V` answer a version ≥ 3.2 by default,
   and add a test with an old version that proves `-N` is omitted. `test/real-tmux.bats` uses
   `tmux -S $SOCK`, which must keep working.
6. A real-tmux test (on a PRIVATE server: `tmux -L <unique>` or `-S` on every call): start a server,
   remove its socket file, then run our non-launch path → it must NOT start a new server (and the old
   one is recoverable with `kill -USR1 <pid>`). Show it red without the fix first.
7. CHANGELOG `### Fixed` under `## [Unreleased]` (count headers).

## Rules
- AGENTS.md gates, `cargo build --release -p worktrees-cli` FIRST.
- NEVER touch the user's default tmux server or its sessions: every probe uses `tmux -L <unique>` or
  `-S <path>` on EVERY call; never a bare `tmux kill-server`; never `kill` a tmux pid you did not start.
  There are TWO live default-ish servers right now (pids 18764 and 31080) — leave both alone.
- Never drive the user's running app. Never `git worktree add`. Scratch → `~/.cache/worktrees/worktrees/tmux-no-start/`.
- No session URLs / Claude-Session trailers; keep Co-Authored-By.
- Open a PR, message `(main)` with the PR number, gate results and the real-tmux witness. Don't merge —
  a fable review runs first.
