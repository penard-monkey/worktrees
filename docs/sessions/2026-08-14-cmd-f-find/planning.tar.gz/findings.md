# Findings — ⌘F find

## Codebase recon (phase 1)

### Terminal
- `app/src/TerminalPane.tsx` — one `useTerm` hook serves both `TerminalPane`
  (tmux, `tmuxTransport`) and `ShellPane` (owned pty, `shellTransport`).
  Returns only `hostRef`; the xterm instance lives in `termRef` inside the hook.
  To add find, `useTerm` must also hand back the search addon.
- Deps installed: `@xterm/xterm@^5.5.0`, `@xterm/addon-fit@^0.10.0`. **No
  `@xterm/addon-search`** — must be added (`pnpm add`, Node ≥ 22.13 / nvm
  22.23.2 per CLAUDE.md).
- `.term-host { flex: 1; min-height: 0; ... }` (App.css:769), `.dock-body
  .term-host { border-radius: 0 }` (804). It is a flex child with no
  `position`, so a find overlay needs a new positioned wrapper (`.term-wrap`)
  rather than being anchored on `.term-host` itself.
- `ResizeObserver` on the host re-fits + resizes the pty. An **absolutely
  positioned** find bar avoids triggering it; a flow-layout bar would refit the
  grid on every open/close.
- Only the ACTIVE dock shell tab is mounted (`ShellPane key=…:active:…`,
  App.tsx:891) — one find target per dock, not one per tab.

### File viewer
- `app/src/FilesPane.tsx` → `FileView` (line 434). Body is one of:
  `ImageView` | `CodeBlock` (code, and md/SVG in Source mode) | `Markdown`
  (md preview) | binary placeholder | `loading…`.
  Scroll container is `.scroll` (App.css:963, `overflow: auto`), inside
  `.viewer-body` (961). `bodyRef` already exists on `.viewer-body` and is used
  for in-document anchor scrolling — reusable as the find root.
- `CodeBlock` (`CodeView.tsx`) renders a gutter column + `<pre class="code-text">`
  of tokenized spans. Gutter is `aria-hidden` but its digits ARE text nodes —
  a DOM text walker must skip `.code-gutter`, or every line number becomes a
  false hit when searching for a digit.
- Markdown is rendered from `marked` tokens (`markdown.tsx`), so source offsets
  do NOT map to the preview DOM. This is the reason to search the rendered DOM
  (Highlight API) rather than the source string.
- Image / binary views have nothing to search → ⌘F should no-op there.

### Keyboard
- One global `keydown` on `window` (App.tsx:2440-2516). Order matters:
  ⌘⇧T, then Escape-leaves-reading, then ⌘⇧E, then a `!(meta||ctrl) || repeat ||
  shift || alt` gate, then ⌘K, then a `switchOpen` swallow, then ⌘B/⌘J/⌘,/⌘digit/⌘E.
- Meta chords already fire **past** the embedded terminal (⌘K, ⌘J, ⌘B, ⌘,), so
  ⌘F will too. Only ctrl chords need the `.term-host` passthrough guard.
- Escape precedence today: reading mode exits on Escape unless the settings
  sheet or ⌘K palette is open. **A find bar must be added above reading mode**
  in that chain, or one Escape dismisses the reader while the find bar (which
  the user is looking at) survives.
- The listener is registered once and reads live state through `keyRef` — new
  ⌘F state must go through `keyRef`, not the dependency array, to keep that.

### Constraints / risks
- **xterm only holds what it received.** A tmux attach replays the visible
  screen, not tmux's history — so terminal find covers the session's output
  *since attach* (xterm default scrollback = 1000 lines), not tmux copy-mode
  history. Worth stating in the bar's title text; consider raising `scrollback`.
- CSS Custom Highlight API: Safari 17.2+ (macOS 14.2+). `tauri.conf.json` sets
  no `minimumSystemVersion`, so an old-macOS user would lack it — hence the
  `window.getSelection()` fallback for the active hit.
- CLAUDE.md: HMR is dead inside `.worktrees/` — restart vite with `--force`
  after every edit, and verify what the server SERVES
  (`curl -s localhost:PORT/src/App.css`) before debugging a change that
  "didn't apply". Kill the harness by content check, not `lsof -ti:PORT`.
- CLAUDE.md: the mock resolves instantly and hides timing bugs — run the real
  app (`app/scripts/sandbox.sh --app`) before calling this done.

## Build notes (phases 2–7)

- `@xterm/addon-search@0.15.0` is the version for xterm 5.5 (`peerDependencies:
  {"@xterm/xterm": "^5.0.0"}`). 0.16.0 declares no peer range at all and targets
  the 5.6/6.0 line — do not bump it without checking the terminal still renders.
- **The addon's decorations are gated behind `allowProposedApi: true`.** Without
  it `registerDecoration` throws, and only on the first ⌘F — the terminal itself
  is completely fine until someone searches. It also threw from inside an
  effect, which unmounted the whole pane; every addon call now goes through
  `guard()` and lands in the app log instead.
- Load the addon AFTER `term.open(host)`.
- `.term-wrap` exists because xterm sizes the pty from `.term-host`'s box: a
  find bar inside the flow there would refit the grid on every open. Asserted:
  `.xterm-screen` stays 704×690 / 46 rows with the bar up.
- The file viewer's bar is a STRIP (`position: static`) between header and body,
  not an overlay — nothing to refit there, and a floating bar would cover the
  first lines of the file. It is outside `.viewer-body` because the body is the
  search root and would otherwise offer the bar's own "3/12" as a match.
- CSS Custom Highlight API is present in the harness Chromium; the
  `window.getSelection()` fallback is only for an old WKWebView and has NOT been
  exercised.
- Routing must not key on `focusin`: every terminal calls `term.focus()` when it
  mounts, so a focus rule is decided by mount order — opening the dock's
  Terminal tab silently took ⌘F away from the main pane. `pointerdown` +
  `keydown` in the capture phase are the only marks; the capture phase matters
  because App's own keydown is a bubble listener on the same window and has to
  read a mark that is already up to date.
- Escape belongs on the `.findbar`, not the `<input>` — clicking `Aa` or `›`
  moves focus to that button, and Escape from there did nothing.

## Harness traps hit (both already in CLAUDE.md, both cost time anyway)

- Two vite instances held :5199; `pkill -f vite` left the old one listening and
  the new one died with "Port 5199 is already in use", so the page kept being
  served the PRE-edit module. `kill -9 $(lsof -ti:5199 -sTCP:LISTEN)` is the fix.
- Grepping the SERVED file for a comment proves nothing — esbuild strips
  comments. Grep for code (`loadAddon(search)`, `term-wrap`), not prose.
- A vite started with `nohup … &` inside a Bash tool call gets SIGTERM'd (exit
  143) when a later call's process group is cleaned up. Its death mid-session
  looked exactly like a ⌘F bug: React Fast Refresh reset App's state and the
  app "went Home". Start it with the tool's own `run_in_background` instead.
