# Progress — ⌘F find

## Session 1 — 2026-08-14

Branch `ui-next`, worktree `ui-tweaks`, started clean and level with
`origin/main` (`git rev-list --left-right --count origin/main...HEAD` → `0 0`).

### Built

| File | What |
|------|------|
| `app/src/Find.tsx` (new, 300 lines) | `FindBar` (shared UI), `findColors()`, `useFileFind` (DOM walk → Ranges → CSS Custom Highlight API) |
| `app/src/TerminalPane.tsx` | `SearchAddon`, `allowProposedApi`, `guard()`, new `TermSurface` shared by `TerminalPane` + `ShellPane`, `.term-wrap` |
| `app/src/FilesPane.tsx` | `FindInFile` strip between the viewer header and body |
| `app/src/App.tsx` | `findOn`/`findToken`, `lastSurface` tracking, `findTarget()`, ⌘F chord, teardown effects |
| `app/src/App.css` | `.term-wrap`, `.findbar` (float over a terminal / strip in the viewer), `::highlight()` rules |
| `app/src/tokens.css` | `--find-hit` / `--find-on` / `--find-on-ink` × 6 themes |
| `app/src/SettingsSheet.tsx` | shortcuts list: ⌘F, plus the missing ⌘J / ⌘⇧E / ⌘⇧T |
| `CHANGELOG.md` | `[Unreleased]` entry |
| `app/package.json` | `+ @xterm/addon-search@0.15.0` |

### Verified in the mock harness (Playwright, port 5199)

| Check | Result |
|-------|--------|
| ⌘F on the main tmux pane | bar in `.term-wrap`, `position: absolute`, field focused |
| terminal search "a" | `1/8`, 9 xterm decorations |
| ⏎ / ⇧⏎ | 1/8 → 2/8 → 1/8 |
| Esc from the terminal bar | bar gone, 0 decorations, focus back on `.xterm-helper-textarea` |
| opening the bar does not refit the pty | screen 704×690, 46 rows — identical before and after |
| ⌘F in the dock Files viewer | bar is `.viewer > .findbar`, `position: static` (a strip, not an overlay) |
| markdown preview search "worktree" | `1/6`; DOM occurrences 6; `CSS.highlights` 6 + 1 active |
| step to 6/6 | `.scroll` scrollTop 851 of 1194 — the hit was revealed |
| gutter exclusion, search "1" | `1/3` (code only) not 8 (with the line numbers) |
| match across syntax spans, `members = ["crates` | 1 hit, `startContainer !== endContainer` |
| match case | "WORKSPACE" → "no results" with `Aa` on |
| switching file with the bar open | query kept, count recomputed for the new file |
| ⌘⇧E reader | ⌘F targets the reader, exactly 1 bar in the document |
| Esc in the reader's bar | closes the bar, reader survives; second Esc leaves the reader |
| dock Terminal tab | ⌘F targets the mounted shell (`1/2`) |
| ⌘F while the ⌘K palette is open | swallowed, 0 bars |
| ⌘F twice | one bar, field re-focused (does not toggle shut) |
| light theme (`tokyo-day`) | screenshots read correctly, amber wash + dark ink on the active hit |

Screenshots: `~/.cache/worktrees/worktrees/ui-tweaks/find-{term,file}-{dark,light}.png`.

### Gates — all green

```
cargo build --release -p worktrees-cli   ok (binary newer than store.rs, checked)
make test                                exit 0, 288 ok, 0 "not ok"
make lint                                exit 0
cargo test -p worktrees-core             208 passed
cargo test -p worktrees-cli              6 passed
cargo test -p app --lib                  29 passed
tsc --noEmit                             exit 0
cargo check -p app                       ok
node app/scripts/race-check.mjs          ALL GREEN, exit 0
```

### Still open

- **`app/scripts/sandbox.sh --app` has NOT been run.** CLAUDE.md is explicit
  that the mock's instant invokes hide timing bugs, and this change touches
  per-place state and the terminals. The mock's xterm also holds three lines of
  canned banner — nothing that exercises find over real scrollback.
- Image/binary viewers accept ⌘F and answer "no results". Harmless, slightly
  sloppy; could be suppressed by kind.
- Terminal find covers only what xterm received since attach (stated in the
  field's tooltip). Raising xterm's `scrollback` from the default 1000 would
  widen it; not done.

## Session 1 — review round (fable)

Fable reviewed the full diff. One must-fix, four should-fix, seven nits. All
applied except the one that needs the real app.

| # | Finding | Action |
|---|---------|--------|
| 1 (must) | ⌘F read `lastSurface` from a **render-time snapshot** in `keyRef`. Interactions that change no React state (clicking into a terminal, clicking the open file's text) leave it stale, so the bar opens on whichever surface last re-rendered. | `findTarget({ ...keyRef.current, last: lastSurface.current })` — read the ref live at keydown. |
| 2 | Theme switch left match highlights in the OLD theme's hex: the addon re-highlights only when the term or case/regex/wholeWord changed — `_didOptionsChange` never looks at `decorations`. Verified in the vendored source. | New effect on `termVersion`: `clearDecorations()` (drops the cached term) then re-search. |
| 3 | A dock Terminal tab with no mounted shell (session down) was still a ⌘F target, and sticky — every further ⌘F picked it again and the main pane was unreachable. | `dockOk` gates the terminal case on `mainTermUp`. |
| 4 | `findOn === "main"` was never cleared when the session went down, so the NEXT session's terminal mounted with a find bar already open. | Effect on `selected?.tmux_session.up`. |
| 5 | `var()` inside `::highlight()` is unproven on WKWebView — if it does not resolve, file matches paint with no background while the count still says "3/12". | **Open — for the sandbox run.** Fallback if broken: per-theme literal hex in `[data-theme=…] ::highlight(...)`. |
| 6 | Enter committing an IME composition stepped to the next match. | `e.nativeEvent.isComposing` guard. |
| 7 | The case-fold length guard made the whole search case-sensitive if the file held one length-changing char (`İ`). | Replaced with an escaped `RegExp` over the ORIGINAL text; the guard is gone. |
| 8 | The no-Highlight-API fallback left the last match selected after closing. | `unpaint()` clears the selection on that path. |
| 9 | Esc while reading with find open but focus OUTSIDE the bar closed the reader instead of the find. | App closes find first — except inside `.term-host`, where Escape is the user's (vim). |
| 10 | Opening the reader over an open dock find left that bar and its highlights painted behind the overlay. | Effect closes a dock find when `reading` goes true. |
| 11 | Narrow dock crushed the find field. | `max-width` on the bar, `min-width: 5ch` + `flex: 0 1 auto` on the field, `flex: none` on the buttons. |
| 12 | Terminal count past the highlight cap read "0/2000". | Renders `2000+`. |

### Found while verifying the fixes

`opts` was a dependency of the live-search effect, so ANY theme change gave it a
new identity, re-ran the effect and `findNext` **advanced the user one match**.
Confirmed in the harness (1/8 → 2/8 on a theme switch) and fixed by moving
`opts` behind a ref; the effect now depends on `query`/`caseSensitive`/`epoch`.
Re-checked: theme switch now holds position at 2/8.

### Re-verified in the harness

| Check | Result |
|-------|--------|
| click dock terminal (no re-render) → ⌘F | bar in the dock, not main |
| literal search `.` in README | `1/18` = 18 literal dots, not 1051 chars (regex escaping) |
| ⌘⇧E with a dock find open | dock bar closed, 0 bars, nothing left painted |
| Esc in the reader, focus on the body | find closed, reader survived |
| Esc with focus in `.term-host` | bar **stays** — Escape reached the terminal |
| theme switch (tokyo-day, nord) with find live | all 9 decorations re-created, `--find-hit` = the new theme's, position held |

### Gates re-run — all green

`cargo build --release -p worktrees-cli`; `make test` exit 0, 0 `not ok`;
`make lint` exit 0; core 208; cli 6; app --lib 29; `cargo check -p app`;
`tsc --noEmit` exit 0; `race-check.mjs` exit 0.

### Honest note on finding #1

The fix is a strict improvement and follows from the code, but the harness could
**not** be made to demonstrate the original failure: the mock polls
`list_workspace` on a timer, so a render lands within a second of any click and
refreshes the snapshot before ⌘F can catch it stale. A deliberate probe that
restored the snapshot still routed correctly for that reason. Treat #1 as
reasoned, not regression-tested.

## Session 1 — shipped

Sandbox (`app/scripts/sandbox.sh --app`) run by David: works. `var()` inside
`::highlight()` DOES resolve on WKWebView — finding #5 is closed, no per-theme
hex fallback needed.

`origin/main` had moved 2 commits ahead (#129 markdown reading size, #130 its
close-out), touching CHANGELOG.md, App.css, App.tsx and FilesPane.tsx — the same
files. Branched `ui-cmd-f-find` off `ui-next`, committed, rebased onto
origin/main, resolved three conflicts (all additive):

- `CHANGELOG.md` — both `[Unreleased]` entries kept.
- `App.tsx` top — `ZOOM_KEYS` and `findTarget`/`Surface` side by side.
- `App.tsx` `keyRef` — union of both field sets (`mdPreview`/`mdZoom` +
  `dockShown`/`dockTab`/`mainTermUp`/`findOn`).
- `FilesPane.tsx` `FileView` — one destructure with both prop sets.

Checked for real interference rather than trusting the merge: ⌘F is not in
`ZOOM_KEYS`, and markdown zoom is a CSS variable on `.scroll`, so it never
replaces text nodes — the find Ranges survive a zoom. Confirmed in the harness:
zoom to 110% with find live keeps 6 hits + 1 active, count unchanged.

All gates re-run green ON the rebased tree (bats 288/0, core 208, cli 6, app 29,
tsc, cargo check, race-check).

**PR: https://github.com/penard-monkey/worktrees/pull/131** — squash-merge.
