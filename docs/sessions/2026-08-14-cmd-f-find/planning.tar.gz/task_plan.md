# Task plan — ⌘F find (terminal + file viewer)

## Goal

⌘F opens a find bar on whichever surface has the user's attention:

- **terminal** — main tmux pane and dock shell tabs; search the xterm buffer,
  next/prev, match count, highlight all + active hit.
- **file viewer** — dock Files viewer and the ⌘⇧E reading overlay; search the
  **currently open file** only (no cross-file search), covering code view,
  markdown preview, markdown/SVG source.

Escape closes the bar and returns focus to the surface it came from.

## Surfaces and routing

| # | Surface | Component | Renders |
|---|---------|-----------|---------|
| 1 | main terminal | `TerminalPane` (App.tsx:3115) | tmux attach |
| 2 | dock shell tab | `ShellPane` inside `TerminalTabs` (App.tsx:891) | owned pty |
| 3 | dock file viewer | `FileView` via `FilesPane` (App.tsx:3222) | code / md / svg |
| 4 | reading overlay | `FileView` expanded (App.tsx:3268) | same |

⌘F target resolution, first match wins (evaluated in App's global keydown):

1. `reading` overlay open → surface 4
2. dock open **and** `document.activeElement` inside `.dock` →
   surface 3 (`dock_tab === "files"`) or surface 2 (`terminal`)
3. main tmux session up → surface 1
4. otherwise → no-op

Opening is driven by monotonic **tokens** (existing repo idiom: `focusToken`,
`addToken`) — `findMainToken`, `findDockToken`, `findReadToken` in App.

## Decisions

- **Terminal find = `@xterm/addon-search`** (official xterm addon, same family
  as the `addon-fit` already in use — not a UI/component library, so it does
  not violate the "no UI libraries" rule). Gives `findNext`/`findPrevious`,
  `onDidChangeResults` (`resultIndex` / `resultCount`) and decorations.
- **File find = CSS Custom Highlight API** over the rendered viewer body, not
  render-time `<mark>` injection. One implementation covers code view, markdown
  preview and SVG source; zero changes to `highlight.ts`, `CodeView.tsx`,
  `markdown.tsx`; no React reconciliation of thousands of spans per keystroke.
  Fallback when `CSS.highlights` is missing: select the active hit via
  `window.getSelection()` (paints natively), no all-hits tint.
- **One `FindBar` component at module scope** (App() -internal components
  remount every render — CLAUDE.md), shared by both kinds of surface.
- Find state is **local to each surface**, not global. Nothing persists to
  `ui-state.json`.
- No new Tauri commands → **no `mock/install.ts` changes needed**.

## Phases

| # | Phase | Status |
|---|-------|--------|
| 1 | Recon — read the four surfaces, CSS anchors, keydown routing | complete |
| 2 | Add `@xterm/addon-search` (0.15.0, peer `@xterm/xterm ^5.0.0`) | complete |
| 3 | `FindBar` component + CSS (tokens.css ×6 themes, App.css) | complete |
| 4 | Terminal find — `TermSurface`, both panes, `.term-wrap` overlay | complete |
| 5 | File find — `useFileFind` (Highlight API) + viewer strip | complete |
| 6 | App routing — ⌘F chord, `lastSurface`, one bar app-wide | complete |
| 7 | Verify — harness (Playwright) + `getComputedStyle` assertions | complete |
| 8 | Verify for real — `app/scripts/sandbox.sh --app` | complete (David) |
| 9 | Gates | complete (all green) |
| 10 | Fable review + fixes | complete (1 must, 4 should, 7 nits) |
| 11 | Rebase onto origin/main (#129/#130) | complete |
| 12 | PR #131 | open, awaiting squash-merge |

## Gates (CLAUDE.md)

```sh
cargo build --release -p worktrees-cli   # FIRST
make test
make lint
cargo test -p worktrees-core
cargo test -p worktrees-cli
cargo test -p app --lib
cd app && ./node_modules/.bin/tsc --noEmit && cargo check -p app
```

Frontend-only change ⇒ the Rust gates should be untouched, but run them
anyway. Report cargo with `grep -E "^running|^test result"`, never `tail`.

## Errors encountered

| Error | Attempt | Resolution |
|-------|---------|------------|
| `You must set the allowProposedApi option to true` (addon-search `registerDecoration`) | 1 | `allowProposedApi: true` on the `Terminal`. Only fires when you SEARCH, so it survived every check that did not press ⌘F. |
| Same throw unmounted `TermSurface` (React error boundary warning) | 1 | `guard()` wraps every search-addon call; failures go to the app log instead of taking the terminal down. |
| ⌘F routed to the dock while the user was in the main pane | 2 | Routing keyed on `focusin` was wrong — every terminal calls `term.focus()` on mount, so mount order decided it. Now `pointerdown` + `keydown` (capture) only. |
| Escape did nothing when focus sat on a find-bar button | 1 | Key handler moved from the `<input>` to the `.findbar` container. |
| "⌘F sent the app Home" | 1 | Not real: the vite harness had been SIGTERM'd, and React Fast Refresh reset App's state. Reproduced clean after restarting the server. |
| `git stash push` → `error: could not write index` | 1 | Abandoned the stash; probed the baseline by temporarily removing `loadAddon(search)` instead, restoring from a copy. |
