# Findings

## Problem
New worktree from the app → tmux session with 2 panes (claude + plain shell). Reopen → 1 pane. (David says "windows" — technically panes: `split-window -h`.)

## Root cause
- `ops::launch` (ops.rs:84) takes `spare_shell`; when true it splits pane1 next to the AI pane (ops.rs:123-126). Design comment: CLI `new` keeps the spare pane (deps install there); the APP is supposed to be single-pane — scratch shell lives in the dock's Terminal tab.
- App `open_place` (lib.rs:462) → `cmd_open` with `--no-spare` → single pane. Correct — why REOPEN looks right.
- App `create_place` (lib.rs:385) → `cmd_new` with only `--no-attach`. `cmd_new` has NO `--no-spare` flag and hardcodes `launch(..., spare_shell=true)` at ops.rs:404 ("`new` always keeps the spare shell — that's where deps install"). → the 2-pane session on NEW.

## Wrinkle: install_cmd
- `cmd_new` auto-detects install (ops.rs:386 `detect_install_cmd`: pnpm/yarn/npm lockfiles etc.) and launch runs it in pane1 (`{install_cmd} && echo '✓ deps ready'; exec $SHELL`). Comment in launch: "An install_cmd is only ever passed WITH the spare shell."
- So a naive `--no-spare` on cmd_new would silently DROP auto-install for app-created worktrees (cmd_open already passes install_cmd="" always).
- Options: (A) single pane, install runs in pane0 before the AI starts; (B) single pane, skip auto-install (dock shell for manual install); (C) keep spare pane only when an install_cmd exists.

## Decision (David 2026-07-30)
Option B — app-created worktrees: single pane, NO auto-install. `cmd_new` gains `--no-spare` (parity with `cmd_open`) which also drops install_cmd; app `create_place` passes it. Claude starts instantly; deps install manually in the dock Terminal tab. CLI default unchanged (spare pane + auto-install stay). When `--no-tmux`/no-spare skips a detected install_cmd, surface the hint (`then: <install_cmd>`) so it isn't silently lost.
