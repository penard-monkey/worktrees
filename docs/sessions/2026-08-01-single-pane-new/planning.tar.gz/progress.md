# Progress

## Session 2026-07-30 (workstream 2: 2-pane new worktree)
- Phase 1 complete — root cause: app create_place → cmd_new hardcodes spare_shell=true (ops.rs:404); open_place already passes --no-spare. Second "window" = split pane1 (install shell).
- David chose Option B: app new = single pane, no auto-install (manual via dock Terminal tab); CLI unchanged. Suppressed install_cmd must surface as `then:` hint.
- Phase 2 in progress — opus agent implementing (cmd_new --no-spare, create_place arg, bats split-window assertions, CHANGELOG). Fable reviews on completion.
