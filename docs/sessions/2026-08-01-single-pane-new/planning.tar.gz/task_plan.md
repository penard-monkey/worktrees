# Task Plan: new worktree spawns 2 tmux windows (claude + terminal)

## Goal
Opening a NEW worktree creates a tmux session with 2 windows — one running claude, one plain terminal. Reopening an existing one doesn't. Expected: single window (dock owns scratch shells now; tmux sidecar era is over). Find where the second window comes from, fix, verify.

## Phases

### Phase 1: Reproduce + locate — status: complete
- [x] Second "window" = second PANE: launch() splits when spare_shell=true (ops.rs:123)
- [x] app open_place → cmd_open --no-spare (single pane, why reopen fine); app create_place → cmd_new which HARDCODES spare_shell=true (ops.rs:404)
- [x] Wrinkle: pane1 is where cmd_new's auto-detected install_cmd runs

### Phase 2: Fix (opus agent) — status: complete
- [x] cmd_new --no-spare → launch(spare_shell=false), install_cmd dropped + `then:` hint
- [x] app new_place pushes --no-spare (comment ties to open_place parity)
- [x] bats: 3 new tests (default splits; --no-spare single pane + no split-window; install hint)
- [x] CHANGELOG Fixed entry; README flag table gained --no-spare (was undocumented even for open)

### Phase 3: Verify + fable review — status: complete
- [x] Gates green (agent): release build, bats 241 ok, lint, core 137, tsc + cargo check
- [x] Fable reviewed full diff; independently re-ran make test (241 ok) + make lint (clean)
- [ ] Real repro on David's mac: app "New" → 1 pane (needs real app run — his call)

## Status: DONE — uncommitted on next, awaiting David: commit + PR (NO Claude-Session trailer per vault rule)

## Decisions
- (none yet)

## Errors Encountered
| Error | Attempt | Resolution |
|-------|---------|------------|
