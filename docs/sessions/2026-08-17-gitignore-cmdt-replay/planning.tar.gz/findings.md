# Findings — gitignore seeding

## Is gitignoring the places file / .worktrees dir the intended default? YES

- This repo's own `.gitignore` ignores `/.worktrees.places.json` and
  `/.worktrees/` ("app declared-store / worktrees created while dogfooding
  THIS repo in the app").
- `crates/worktrees-core/src/sync.rs:46`: "ferrying gitignored state and
  `.git` itself is the whole point" — the sync feature assumes the store is
  gitignored and moves it out-of-band.
- DESIGN.md: store is `$MAIN_ROOT/.worktrees.places.json`, sibling to
  `.worktrees/`; per-repo, per-machine declared state.

## Code map

- `app/src-tauri/src/lib.rs:475` `create_project` — mkdir + `init_repo`.
  Fresh dir guaranteed empty (refuses existing target).
- `app/src-tauri/src/lib.rs:524` `init_repo` — `git init` if needed, then
  `first_commit` if `!has_commits`, then `add_project`. Also a standalone
  tauri command (add-existing-dir-that-isn't-a-repo flow).
- `app/src-tauri/src/lib.rs:553` `first_commit` — `commit --allow-empty -m
  "Initial commit"`. `--allow-empty` still commits anything staged, so
  `git add .gitignore` before it Just Works.
- `app/src-tauri/src/lib.rs:542` `create_initial_commit` — unborn-HEAD repo
  the user owns; do NOT seed files here.
- `crates/worktrees-core/src/store.rs:180` `edit()` — read-under-lock →
  merge → atomic write. Create-vs-update distinguishable: `read_strict`
  returns `Ok(Store::default())` on NotFound; check `path.exists()` before
  write (simplest signal) for the exclude hook.
- `store_path` (store.rs:94) canonicalizes repo → exclude hook must use the
  same canonicalized base, else symlinked paths diverge.

## Traps for implementation

- bats fixtures use fake git shims; `.git` may not be a real dir → exclude
  write must silently skip when `<repo>/.git` is not a directory. Pure fs, no
  git subprocess → no spawn-count drift (`spawn-count.sh` unaffected).
- `cargo test -p app --lib` — app tests only run via `test`, not
  check/build. Gates list in CLAUDE.md; stale release binary trap: rebuild
  release BEFORE bats.
- New tests must fail first (break code, watch red, restore).
- `.git/info/` may not exist in odd repos → create dir best-effort.
- Exclude semantics: `.git/info/exclude` never hides tracked files, so a user
  who deliberately committed places.json is unaffected. Appends must be
  idempotent (check line presence first).
