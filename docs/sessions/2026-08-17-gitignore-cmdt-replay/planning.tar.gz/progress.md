# Progress

## Session 2026-08-17 (evening)

- Context: David created `~/workspace/does-it-end` via the app; git status
  shows untracked `.worktrees.places.json` on a `main*` with no commits'
  worth of hygiene. Asked: shouldn't the app gitignore its own state by
  default, and seed planning-with-files docs too?
- Investigated create_project/init_repo/first_commit + store::edit paths;
  confirmed gitignored-by-design intent (see findings.md). Wrote task_plan.
- Recorded two feature reminders in task_plan (⌘T new shell tab; files-tab
  right-click menu) for ROADMAP sweep at close-out.
- Spawning opus implementation agent with detailed brief (per David's
  opus-implements/fable-reviews split). Branch: `bug-fixes-gitignore-seed`
  off freshly fetched origin/main.

- Hand-fixed `~/workspace/does-it-end`: committed same `.gitignore` the app
  fix will seed (commit 8f1ca4e). Tree clean; places.json now ignored.

- Opus agent delivered commit 7befe4a on `bug-fixes-gitignore-seed`; every
  new test proven red-then-green; agent also live-verified semantics against
  real git in a scratch dir (seeded repo + exclude-only repo both clean).
- Fable review: approved. Nits waived (shadowed `info` var in
  exclude_app_state; app test rolls own tempdir). Caveat surfaced in PR:
  repos with a pre-existing store never hit the create path — no migration,
  deliberate.
- Pushed; PR #150 open, awaiting David's squash-merge.

- PR #150 squash-merged (6061685 on main). Branch bug-fixes-cmdt-files-menu
  cut off fresh origin/main (0 0 verified).
- Recon for feature pair done (facts in task_plan): ⌘⇧T exists but no-ops
  unless Terminal tab mounted; ⌘T unbound; CtxMenu extractable from App.tsx;
  open-path permission missing from capabilities.
- Second opus agent spawned with brief: ⌘T (visible→add tab, else open
  dock/switch, keep ⌘⇧T alias, update advertised chord) + files-tab
  right-click menu (Reveal in Finder / Open / Copy Path / Copy Relative
  Path, CtxMenu extracted to own module, open-path permission added).
  Harness verification required; awaiting report.

- Feature pair landed on `bug-fixes-cmdt-files-menu` (one commit). ⌘T:
  terminal visible → +1 tab; dock closed / on Files → opens the tab and stops
  (the token consumer's skip-initial guard is what makes that safe). ⌘⇧T kept
  as a silent alias; ⌘T is the advertised chord (add-button title + Settings).
  Files tab: right-click menu on tree rows via a CtxMenu extracted to
  `app/src/CtxMenu.tsx` (App.tsx keeps the `Ctx` union + state machine).
- Harness-verified on :5199 (mock): all five ⌘T cases, both menu variants,
  Escape + click-away dismissal, clipboard read back for absolute AND relative
  path, and a 27-property computed-style diff proving the files menu is
  pixel-identical to the nav's place menu. Also checked `place_panels` after a
  ⌘T write — only dock_open/dock_tab/dock_width, no frozen `files_md_zoom`.
- `relPath` added to filekind.ts + `app/scripts/relpath-check.mjs`; both new
  assertions shown RED first (dropped the `/` from the prefix test; disabled
  the root-itself case), then restored green.
- Opener open-path needed a scoped permission AND
  `requireLiteralLeadingDot: false` — see task_plan; CLAUDE.md updated.

- PR #151 squash-merged (b7d76f0). David confirmed features look good in
  sandbox, reported follow-up bug: new shell tab + close → survivor tab
  scrolled down, repeated lines of a pasted screenshot path.
- Recon (facts in task_plan phase-10 section): ring replays whole raw
  history on re-attach; unconditional pty resizes (shell_open re-attach +
  shell_resize); frontend can attach before the host is measured (safeFit
  swallows the unmeasured case, tx.open runs at 80×24 default). SIGWINCH →
  zsh prompt redraws accumulate in ring at mixed widths → replay bakes
  duplicates. Third opus agent spawned on `bug-fixes-shell-replay`:
  reproduce empirically first (pty capture + headless replay), then fix
  (no-op resize suppression + never-attach-unmeasured), fail-first tests,
  full gates. Awaiting report.

- Shell-replay agent landed. KEY CORRECTION from evidence: ring accumulation
  alone is harmless (8 redraw copies replay as ONE clean prompt at recording
  width — ESC[J erases work); the whole bug is WIDTH MISMATCH at replay
  (1 column off = residue; 174-col ring at 80 cols = 4 stacked copies,
  cursor row 19 — David's screenshot exactly). Unmeasured-attach path proven
  reachable in harness (fit() returns early, doesn't throw — safeFit's catch
  never sees it).
- Fix: attach waits for measured host (rAF loop, 1s bound); RO ignores
  unmeasured host; shell_resize gated on gen; backend Shell remembers
  PtySize, drops same-size requests (next_pty_size). Replay-then-resize
  order deliberately kept. 3 fail-first proofs. Not fixed by design:
  polluted rings, genuine layout change while detached (age out via 256K cap).
- Reviewed, approved. Rebased onto 4d3a491 (#152 landed mid-flight, no file
  overlap); tsc + app 37 tests re-run green. PR #153 open.

### Test results (agent-run gates, all green — PR #150 round)

- release build fresh; bats 314 ok / 0 not-ok; lint clean
- worktrees-core 251 passed; worktrees-cli 7 passed; app --lib 35 passed
- tsc --noEmit + cargo check -p app clean
