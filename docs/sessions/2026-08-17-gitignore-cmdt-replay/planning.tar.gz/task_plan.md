# Task Plan — seed .gitignore for new projects + exclude app state in existing repos

## Goal

A project created by the app (`create_project`) must not start life with a dirty
`git status`. `.worktrees.places.json` (and `.worktrees/`) are per-machine state
— this repo's own `.gitignore` ignores both, and `sync.rs` exists precisely to
ferry gitignored state between machines. So:

1. **New projects** (app → `create_project` → `init_repo`): seed a `.gitignore`
   before the bootstrap commit and include it in that commit. Entries:
   `/.worktrees.places.json`, `/.worktrees/`, plus David's planning-with-files
   docs `/task_plan.md`, `/findings.md`, `/progress.md`. Create only if absent —
   never touch an existing `.gitignore`.
2. **Existing repos** (add-existing flow, CLI): when `store::edit` creates the
   places file for the first time, best-effort append `/.worktrees.places.json`
   and `/.worktrees/` to `<repo>/.git/info/exclude` (per-machine, never
   committed, never hides a *tracked* file — safe even if someone deliberately
   commits the store). Skip silently when `.git` isn't a directory (bats fake
   fixtures, non-git dirs).

## Phases

| # | Phase | Status |
|---|-------|--------|
| 1 | Investigate flows (create_project/init_repo/first_commit, store::edit) | complete |
| 2 | Write brief, spawn opus implementation agent | complete |
| 3 | Agent: implement + tests (fail-first proof) + full gates | complete — commit 7befe4a, all gates green |
| 4 | Fable review of diff | complete — approved, 2 style nits waived |
| 5 | Push + PR after review | complete — PR #150, squash-merged (6061685) |
| 6 | Recon ⌘T + files context menu; write brief | complete |
| 7 | Agent: implement both features + gates (branch bug-fixes-cmdt-files-menu) | complete — all gates green, harness-verified |
| 8 | Fable review of diff | complete — approved, no findings |
| 9 | Push + PR | complete — PR #151, squash-merged (b7d76f0) |
| 10 | Recon shell-replay duplicate-lines bug; write brief | complete |
| 11 | Agent: reproduce + fix + gates (branch bug-fixes-shell-replay) | complete — commit rebased to f48cd12, all gates green |
| 12 | Fable review, push + PR | complete — approved; PR #153 open, awaiting David |

## Shell-replay bug (phases 10–12) — David's repro + recon facts

Repro (David, sandbox, 2026-08-17): new dock shell tab, closed it → the
surviving tab sat scrolled down full of repeated lines
`_tmp/Screenshot 2026-08-17 at 22.56.15.png` (likely a path he'd pasted at the
zsh prompt while testing the new Copy-relative-path menu).

Recon:
- Backend ring (`SHELL_RING` = 256K, lib.rs ~3613) stores the shell's RAW byte
  history; every re-attach (`shell_open` on existing key, ~3687) replays the
  WHOLE ring into a fresh xterm, then `sh.master.resize(...)` unconditionally.
- `shell_resize` (~3789) also resizes unconditionally — no last-size compare.
- Frontend (TerminalPane.tsx ~145-178): `safeFit()` swallows
  "renderer not measured yet", then `tx.open(term.cols, term.rows)` — an
  unmeasured host attaches at default 80×24; the ResizeObserver corrects it a
  beat later. Each real size change = SIGWINCH = zsh redraws the pending
  prompt line = more bytes appended to the ring, at whatever width was current.
- Replay renders history produced at mixed widths into one fixed-width xterm —
  cursor-up/overwrite sequences land wrong → duplicates baked into scrollback.
- pty traps (CLAUDE.md): drain the master or the child wedges; `process_id()`
  returns reaped pids; portable-pty kill() = SIGHUP.

## Implementation notes (the brief lives in progress.md phase-3 entry)

- `first_commit` is shared with `create_initial_commit` (existing repo, unborn
  HEAD — user's own dir, don't write files there). Seed only inside `init_repo`,
  inside the `!has_commits` branch, then `git add .gitignore` so the existing
  `commit --allow-empty` picks it up (`--allow-empty` permits empty; it still
  commits staged files).
- `init_repo` on a dir that already has commits: skip seeding entirely.
- store.rs exclude write: only on the create path (read_strict → NotFound),
  once per repo; pure fs, no git subprocess → no spawn-count drift.
- New tests must be shown to FAIL first (CLAUDE.md rule): break the code path,
  watch red, restore.

## Errors Encountered

| Error | Attempt | Resolution |
|-------|---------|------------|
| (none yet) | | |

## Feature pair (phases 6–9) — recon facts

- **⌘⇧T already exists**: App.tsx:3550 bumps `newTermToken` (App.tsx:1874);
  Terminal tab consumes it (~887) but NO-OPS unless mounted/visible. ⌘T is
  unbound. Feature = ⌘T from anywhere: force dock open + terminal tab, then
  add shell. Keep ⌘⇧T as silent alias; ⌘T becomes the advertised chord
  (termtab-add title App.tsx:925, Settings shortcuts list SettingsSheet.tsx
  ~546).
- **CtxMenu component exists** (App.tsx:226, `.ctxmenu` + `.menu-catch`) but
  is module-scope in App.tsx. Files tab = FilesPane.tsx (760 lines, TreeNode
  rows ~140-260, already imports revealItemInDir + openUrl).
- Clipboard pattern: navigator.clipboard.writeText (App.tsx:2896).
- `opener:default` grants open-url + reveal-item-in-dir; **open-path NOT
  granted** — missing permission rejects invoke silently
  (app/src-tauri/capabilities/default.json).
- **open-path needed TWO fixes, not one** (found by reading the plugin source,
  not by guessing): `opener:allow-open-path` bare allows nothing —
  `is_path_allowed` = fs-scope AND "an allowed entry names a path", so the
  permission needs the object form with `"allow": [{"path": "**"}]`. And `**`
  still rejects any path with a DOT component under glob's
  `require_literal_leading_dot` (true by default on unix) — i.e. every
  `.worktrees/...` path — so tauri.conf.json now sets
  `plugins.opener.requireLiteralLeadingDot: false`. Proven with a standalone
  glob probe, since the mock cannot enforce a scope. Written up in CLAUDE.md.

## Deferred / follow-ups (sweep into ROADMAP.md at close-out)

- (swept 2026-08-17, commit 642c270 on bug-fixes-shell-replay: exclude
  migration for pre-existing stores; real-app open-path click. The original
  ⌘T + context-menu reminders shipped in #151 — nothing to park for them.)
