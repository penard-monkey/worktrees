# Editable agent guidance (brief: .planning/brief.md)

## Decisions
- Editable: the SKILL only. HEAD (MCP instructions, 247-char one line, guard_bin's probe) and
  rules_text stay shipped: one text shared with the MCP floor.
- Storage: ~/.config/worktrees/guidance/SKILL.md (user text) + SKILL.base.json {version, hash, text}
  (the shipped text the edit was based on). Saving text == shipped deletes both (= reset).
- stale = edit exists && base.hash != shipped hash (or base unknown). Offer fingerprint = shipped hash.
- invalid override (no frontmatter name: worktrees / unreadable) -> shipped + reported.
- diff via `git diff --no-index -U1000000` → FileDiffDto → DiffView. merge via `git merge-file -p`.

## Phases
- [ ] core guidance.rs: store, effective skill, status fields, diff/merge, tests red-first
- [ ] CLI guide: --default, status line; bats
- [ ] app: commands, mock, panel editor + diff + stale banner, offer + offers-check
- [ ] docs proposal section, CHANGELOG, gates, PR, CI
