# Push notifications, host half
Brief: .planning/brief.md. Contract: worktrees-ios docs/design/notifications.md (+ PushShared.swift, errors.ts).
## Phases
- [ ] 1 storage (devices.rs push record, scrub on revoke/disable, list strips, SecurityFields.push_security)
- [ ] 2 rows + ok flag + budgets + audit details
- [ ] 3 seal + payload + key import + contract fixtures
- [ ] CHECKPOINT message to worktrees-(main)
- [ ] 4 planner (scripted clock), service thread, h2 transport + fixture, dry-run
- [ ] 5 CLI (`serve push …`), mock/ipc tables, CHANGELOG, deny, gates
- [ ] 6 PR, CI green on head SHA, message (main)
