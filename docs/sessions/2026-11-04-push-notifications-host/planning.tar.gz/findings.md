# Findings
- Phone also decodes kind `test` (not in doc). `agent` is display name ("Claude"). `reason` is SHOWN as a body: human words.
- Phone maps body errors starting `bad-args` to its own words; other body errors are shown raw.
- ERR.denied === "denied" exact. rate/busy exact.
- h2 not in lock; ring direct (ChaCha20-Poly1305, ES256) so RustCrypto chacha20poly1305 unnecessary.
- rustls in CLI graph has no tls12 feature; every config names TLS13 explicitly, so enabling feature does not widen them.
- DeviceRecord deny_unknown_fields: a push field makes an OLDER build refuse the whole file (downgrade). Flag at checkpoint.
- (main) decided 2026-11-04: separate 0600 store keyed by device id; DeviceRecord unchanged; drop on events + boot sweep (red first); unreadable => send nothing, log, device access untouched; security allowance in that file with console's act audited, NOT SecurityFields; TLS 1.3 only (no tls12), measured by (main); chain USERTrust; trust failure logs distinct reason; sound = one obvious constant; report release-note facts at end.
