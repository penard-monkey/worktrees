# Progress
- PR #612 open, head 76e01e5.
- OPEN for close-out: Podman (behind `docker`) broke when the disk filled; David repairs it. Never run docker/podman again in this lane. (main) removes my volumes once it is back: `docker volume rm wt-push-target wt-push-registry`
