# Task: Emoji rendering breaks terminal UI when Claude responds in tmux

## Goal
Find root cause of garbled terminal output (overlapping text, mangled phase
numbers) when Claude Code prints emoji (✅ 🔄 📋) inside tmux, viewed in the
app's terminal. Propose fixes. (Diagnosis task — no fix applied until asked.)

## Evidence
`_tmp/Screenshot 2026-08-17 at 14.06.40.png` — `/planning-with-files:status`
output: "Phase 15 DBacklo A(quick fixes" ← should be "Phase 5: Backlog QA
(quick fixes …". Lines overlaid at ±1 column per leading emoji.

## Phases
- [x] Phase 1: Understand app terminal stack — xterm.js 5.5, FitAddon only,
      default Unicode 6 widths (TerminalPane.tsx:114)
- [x] Phase 2: tmux 3.6a, Homebrew, linked against utf8proc → emoji width 2
- [x] Phase 3: Reproduced widths empirically (cursor_x probe + node wcwidth)
- [x] Phase 4: Hop = tmux→renderer. tmux says 2, xterm says 1, per emoji
- [x] Phase 5: findings.md has cause + two fix options + verification plan

- [x] Phase 6: Apply option 1 (opus agent implemented, fable reviewed diff).
      `@xterm/addon-unicode-graphemes@0.4.0` + `activeVersion = "15-graphemes"`
      + `allowProposedApi: true` (required — `term.unicode` throws without it).
      Gates: tsc 0, cargo check -p app 0. NOT committed.
- [x] Phase 7: David verified in sandbox — looks good
- [x] Phase 8: Rebased onto origin/main (14 commits; upstream added SearchAddon
      to same lines — merged, allowProposedApi now shared), lockfile
      regenerated, gates re-run green (tsc, cargo check, 34 lib tests).
      Pushed `bug-fixes-emoji-width`, PR #143.

- [x] Phase 9: CI 9/9 green, squash-merged as 88c955e on main. Remote branch
      deleted (manually — gh's --delete-branch choked on main being checked
      out in the root worktree). Local branch still checked out here; fresh
      branch at /close-out.

## Status: MERGED — #143 → main 88c955e. Stream done; /close-out when ready.
Note: sandbox eyeball happened PRE-rebase; merge with SearchAddon is logically
independent (graphemes before open, search after) but a post-merge glance at
⌘F + emoji together wouldn't hurt.

## Errors Encountered
| Error | Attempt | Resolution |
|-------|---------|------------|
