# Progress

## Session 2026-08-17
- Read `_tmp/Screenshot 2026-08-17 at 14.06.40.png` — garbled
  `/planning-with-files:status` output in app terminal under tmux.
- Measured emoji widths: tmux 3.6a (utf8proc) = 2, xterm.js 5.5 default = 1.
  Full table + method in findings.md.
- Diagnosis complete; two fix options documented (unicode-graphemes vs
  unicode11 addon at TerminalPane.tsx:114). No code changed.
- Test tmux sessions (`widthtest`) created and killed; no leftovers.
- Applied option 1 via opus agent (fable reviewed diff): graphemes addon +
  allowProposedApi in TerminalPane.tsx, dep in package.json + lockfile.
  tsc + cargo check -p app both exit 0. Not committed.
- Remaining: David's visual check in sandbox app, then commit/PR at close-out.
