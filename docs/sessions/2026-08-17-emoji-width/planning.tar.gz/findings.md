# Findings: emoji garble terminal UI in tmux

## Root cause (confirmed by measurement)
Width disagreement per emoji between tmux's grid and the app's xterm.js
renderer. One column of drift per emoji; tmux's partial repaints (Claude Code's
spinner redraws constantly) then interleave old and new glyphs at offset
columns → "Phase 15 DBacklo" = two paints of "Phase 5: Backlog" overlaid ±1.

Measured widths:

| Char | tmux 3.6a (utf8proc) | xterm.js 5.5 default (Unicode 6) | Unicode11Addon | GraphemesAddon (expected) |
|------|----|----|----|----|
| ✅ U+2705 | 2 | 1 | 2 | 2 |
| 🔄 U+1F504 | 2 | 1 | 2 | 2 |
| 📋 U+1F4CB | 2 | 1 | 2 | 2 |
| ⚠️ U+26A0+FE0F | 2 | 1 | 1 (26A0=1, FE0F=0) | 2 |
| ⚠ bare U+26A0 | 1 | 1 | 1 | 1 |

- tmux measurement: `tmux new -d -x80; send-keys "clear; printf '…'; sleep 3"`,
  then `tmux display -p '#{cursor_x}'` mid-sleep. VS16/ZWJ chars must go
  through send-keys as UTF-8 BYTE escapes (`\342\232\240\357\270\217`) —
  literal paste through send-keys mangled them (measured 0).
- xterm measurement: `node -e` with `@xterm/xterm` +
  `t._core.unicodeService.wcwidth(cp)` (needs `allowProposedApi`). Default
  `unicode.activeVersion` = 6.
- Homebrew tmux links `/opt/homebrew/opt/utf8proc/libutf8proc.3.dylib`, so
  tmux widths = utf8proc's (VS16 upgrades narrow→wide).

## Why only in tmux
Without tmux, the emitting program's own width assumption drives layout and
xterm just flows glyphs — worst case slight misalignment. tmux keeps an
authoritative grid and repaints damaged CELLS with absolute cursor moves, so a
1-col disagreement turns into overlaid text on every partial repaint.
Diagnostic that proves the hop: `tmux capture-pane -p` shows clean text while
the app shows garbage.

## Fix site
`app/src/TerminalPane.tsx:114` — single `new Terminal(...)` site, only
FitAddon loaded. Fix is a two-line addon load:

```ts
import { UnicodeGraphemesAddon } from "@xterm/addon-unicode-graphemes"; // v0.4.0
term.loadAddon(new UnicodeGraphemesAddon());
term.unicode.activeVersion = "15-graphemes";
```

or the conservative variant (VS Code ships this one):

```ts
import { Unicode11Addon } from "@xterm/addon-unicode11"; // v0.9.0
term.loadAddon(new Unicode11Addon());
term.unicode.activeVersion = "11";
```

Both published for xterm 5.x. Graphemes addon matches utf8proc-tmux including
VS16 (⚠️) and ZWJ clusters; Unicode11 fixes the screenshot's plain-emoji class
but leaves VS16 sequences (Claude Code uses ⚠️) still 1-off.

## Verification plan for whichever fix
1. Node width assert (same one-liner as above, expect 2/2/2 and VS16=2 for
   graphemes).
2. Real app via `app/scripts/sandbox.sh --app` (mock has no tmux — cannot show
   this bug): attach a tmux pane, `printf '✅ Phase 5: Backlog\n⚠️ warn\n'`,
   then force partial repaints (run claude or a spinner) and compare against
   `tmux capture-pane -p`.
3. Resize check: FitAddon cols unchanged (cell width unaffected; only
   string→cells mapping changes).

## Trap: node-side width probe LIES for astral emoji (addon bug, browser unaffected)
Running the wcwidth probe for the graphemes addon under Node prints ✅=2 but
🔄=📋=1 — looks like the fix half-failed. It didn't. The addon's `_dec()`
takes the `typeof Buffer` branch under Node; `Buffer.from(b64,'base64')`
returns a POOLED buffer (byteOffset 8) and `unicode-trie.ts` does
`new DataView(data.buffer)` without the byteOffset, so `highStart` misreads
and every supplementary-plane codepoint falls to narrow. Browsers use `atob`
(byteOffset 0) — correct. To probe under Node: `delete globalThis.Buffer`
first → all emoji report 2. (Found by opus agent, verified at buffer level.)

## Residual risks
- Grapheme addon is newer (0.4.0) — exercise CJK + box-drawing (claude's UI
  borders) in sandbox before trusting.
- Any OTHER terminal attached to the same tmux session with different width
  tables (Terminal.app is notoriously wcwidth-old) re-introduces skew for that
  client only; tmux tracks widths per grid, not per client — nothing we can do
  app-side.
