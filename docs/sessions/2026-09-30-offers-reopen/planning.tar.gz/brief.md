# Offers you can come back to: reopenable release notes + a "pending setup" indicator

## What David hit (2026-09-30)
After an install/update, "What's new" shows the release notes with an offers band (e.g. set up
Claude's MCP server, Codex's, pi's). Click one offer and it takes you to that setting and the modal
closes — and there is no way to bring the band back. "Otherwise stuff just kind of disappears."
He wants: the release notes (with their offer banners) reopenable from Settings' release notes, a
small icon/button bottom-right while things are still pending, and the ability to dismiss each
manually later.

## Measured cause (verify)
- `app/src/App.tsx:~7694-7700`: `<WhatsNewModal … offers={whatsNew.manual ? [] : offers}` — the
  MANUAL reopen (Settings → What's new, `:~5157`) deliberately passes NO offers.
- `onTakeOffer` (`:~7698`) sets `last_seen_version` and closes the modal, then `takeOffer(o)` —
  so taking ONE offer ends the whole band for this release.
- Offers themselves persist correctly: `app/src/offers.ts` `pendingOffers(ctx, dismissed)` —
  an offer stays pending until its condition is satisfied or the user dismisses it
  (`offers_dismissed`, id → fingerprint, `settings.ts:~369-377`). Read offers.ts's header: an
  action is a DEEP LINK, never the act; N offers are N rows; dismissal stores a fingerprint;
  offers are machine-wide only (per-project todos live in projectTodos.ts behind the header badge).
- `App.tsx:~3715`: offers are also "badged on" Settings categories — read what already exists.
- AGENTS.md has a long, hard-won section on offers ("A suggestion's surface may not add
  preconditions of its own", offers-check.mjs guards the FEED and the render, the band is pinned
  OUTSIDE `.settings-body`). Read it before designing; do not reintroduce any of those bugs.

## Task — design, then build
1. Manual reopen shows pending offers too (the same band). Taking an offer must not make the rest
   unreachable: either keep the modal/band available, or make every entry point below reopen it.
2. A persistent, quiet entry point while any offer is pending: a small icon/button bottom-right
   (David's suggestion) with a count, opening the offers (the band, or a small popover listing the
   same rows). Gone when nothing is pending. Check the status band / footer / usage meter already
   in that corner — no overlap, no second competing badge; measure in the mock AND consider
   WKWebView (AGENTS.md: WebKit sizes buttons differently).
3. Manual dismiss per offer everywhere it is shown (it exists in the band — keep one behaviour),
   and a way to see/undo dismissed ones is a stretch goal (say whether it is worth it).
4. Keep offers.ts's rules: deep links not acts, list not panels, fingerprint dismissal, machine-wide.
   New offers from other work (e.g. the upcoming agent-guidance "worktrees skill" setup) must slot
   in with no new surface.
5. Tests: extend `app/scripts/offers-check.mjs` (feed + render for the manual path and the new
   entry point; red first on the current tree); mock harness shows the indicator with `?offers=` or
   the existing knobs; unit tests for any new logic. Gates per AGENTS.md (grep-reported).
   CHANGELOG under `## [Unreleased]` (exactly one of each ###, bold leads). Open a PR, watch CI with
   `gh run watch <id> --exit-status`, report, STOP. Do not merge.

## Rules
- Do NOT drive David's running app (by name/AppleScript/keys); mock harness on a port ≠ 1420; the
  sandbox app only by PID if real timing is needed.
- Another lane (pi-nav-dot, PR #382) touches app/src-tauri/src/lib.rs's dot poll; agent-guidance
  is a docs PR. Stay out of those areas.
- Codex is out of tokens. Scratch in ~/.cache/worktrees/worktrees/<this worktree>/.
- Keep Co-Authored-By; NO session URLs or Claude-Session trailers.
