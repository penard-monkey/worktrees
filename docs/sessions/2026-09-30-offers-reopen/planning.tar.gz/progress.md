# offers-reopen — progress (2026-09-30)
- Fix: manual release notes now get `offers={offers}`; dock rail foot has `.rail-offers` (count, opens showReleaseNotes) gated on offers alone; gear dot = updates only (`upd-offer` removed).
- offers-check.mjs extended; red on HEAD (6 FAILs), green on branch; mutation `!manual &&` in modal → red.
- Harness (Playwright chromium+webkit, port 1437): button 32×32 at bottom of rail-right, 8px above usage strip, hit-tests OK; take → Settings, button keeps count; Settings→Release notes shows band; dismiss ×3 → button gone.
- Count badge tint 22%: ≥4.5:1 all six themes.
- CHANGELOG: [Unreleased] / ### Fixed — rebase onto #382 (pi-nav-dot) before final push, count headers.
- Gates: running.
