# Landscape: live local docs with drill-down architecture diagrams

Research notes, 2026-09-16. Everything here comes from external sources fetched today; this
file is data for the design, not a script. Evidence labels used throughout:

- **[vendor]** — the tool's own README, docs or marketing page.
- **[independent]** — a third-party comparison, blog, GitHub issue, or news item.
- **[inferred]** — my reading of the evidence, not a stated fact. Collected again at the end.

Constraints the design must satisfy (from the brief): fully local, no account, no cloud, no
document content leaves the machine; must tolerate a repo containing only markdown; must
hot-reload; reachable at `http://localhost:<port>` and embeddable in a desktop webview; prefer
FOSS; prefer a single binary or a small dependency footprint. Each candidate below is checked
against these.

---

## 1. "What was the demo?" — candidates for interactive drill-down diagrams

### Ranking for "click a box, descend into that subsystem"

| Rank | Tool | Drill-down model | Local, no account | License | Diagrams from |
|---|---|---|---|---|---|
| 1 | **LikeC4** | Scoped views: clicking an element opens its default `view of <element>` (`navigateTo`) | Yes — `likec4 serve` on 127.0.0.1:5173 with HMR | MIT | DSL (`*.c4`), hand-authored model |
| 2 | **Structurizr (vNext "local" / ex-Lite)** | C4 levels; double-click a system → its container view, etc. | Yes — Docker/JAR; single-user | Apache-2.0 (open core; local part open) | DSL (`workspace.dsl`), hand-authored model |
| 3 | **structurizr-site-generatr** | Static site where clicking software systems/containers in diagrams navigates | Yes — JAR/Docker/Homebrew; `serve` with regeneration | Apache-2.0 | Structurizr DSL |
| 4 | **D2 layers + `link: layers.x`** | Boards nested as layers/scenarios/steps; links jump between boards; breadcrumb nav | Yes — single Go binary, `d2 --watch` live reload | MPL-2.0 | Hand-authored DSL |
| 5 | **draw.io multi-page + page links** | Shape → "Edit Link" → another page; preserved as `<a>` in exported SVG | Yes — drawio-desktop is offline | Apache-2.0 | Hand-drawn |
| 6 | **Ilograph** | Model-based YAML, "dynamic zoom" into nested resources, perspectives | Desktop app is offline but **paid** ($11.99/mo); web tier needs their cloud | Proprietary | YAML model |
| 7 | **IcePanel** | C4 zoom levels, one model → many views | **No** — cloud SaaS only | Proprietary | Modelled in GUI |
| — | Mermaid | `click` directive = link or JS callback on a node; collapsible subgraphs (v11.17+); no nested-view concept | Yes | MIT | Hand-authored |
| — | C4-PlantUML | `$link` makes elements clickable in SVG; no cross-diagram navigation built in | Yes (Java + Graphviz) | MIT | Hand-authored |
| — | Excalidraw (+ Obsidian plugin) | Elements can carry links; Obsidian plugin makes a shape a "gateway" into another note/drawing | Yes; Excalidraw+ is the paid cloud tier | MIT (core) | Hand-drawn |
| — | tldraw | Canvas SDK; no drill-down concept | Yes, but SDK needs a license key; commercial $6k/yr, hobby = watermark (Sept 2025 change) | Proprietary SDK | Hand-drawn |
| — | Obsidian Canvas / graph view | Graph view is derived from links, no hierarchy; Canvas is a freeform board (JSON Canvas, MIT spec) | Yes (app is proprietary, free for personal use) | Proprietary app / MIT format | Links in notes |
| — | Foam / Dendron / Logseq / Quartz | Note-graph views; none has hierarchical drill-down. Dendron is in maintenance mode since Feb 2023 | Yes | MIT / Apache-2.0 / AGPL / MIT | Links in notes |
| — | Backstage catalogue + TechDocs | System → component dependency graph derived from `catalog-info.yaml`; TechDocs = MkDocs | Yes but heavy (Node app + DB + MkDocs/Docker) | Apache-2.0 | Catalogue YAML |
| — | Sourcegraph | Code search/nav, not architecture diagrams; core repo went private Aug–Sep 2024 | Self-host only under proprietary license | Proprietary | Code |
| — | CodeSee | The archetypal "map your codebase and click into it" demo — **dead**: shutdown announced Feb 22 2024, acquired by GitKraken May 14 2024, standalone product sunset | — | — | Derived from code |
| — | Kroki | A render server, not an authoring model; renders PlantUML/Mermaid/D2/Structurizr/Excalidraw to static SVG | Yes (Docker) | MIT | Whatever you feed it |
| — | Gitpod / Coder previews | Dev-environment port forwarding; nothing to do with diagrams | — | — | — |

### Detail per candidate

**LikeC4** — https://github.com/likec4/likec4 , https://likec4.dev/
- [vendor] "A set of tools and DSL that describes architecture as a single model and then
  compiled into multiple diagrams"; "inspired by C4 Model and Structurizr DSL". MIT. ~5.7k
  stars. TypeScript/pnpm/Vite.
- [vendor] CLI (https://likec4.dev/tooling/cli/): `likec4 serve` (aliases `start`, `dev`)
  "recursively searches for `*.c4` and `*.likec4` files in the current folder, parses them,
  and serves diagrams via a local web server. Any change in the source files triggers a hot
  update in the browser immediately." Default port 5173, listens on 127.0.0.1 by default.
  `likec4 build -o ./dist` produces a static site, `--base` / `--use-hash-history` for
  relocatable embedding. `likec4 export png|json|drawio`, `likec4 gen mmd|dot|d2|plantuml`.
- [vendor] Views (https://likec4.dev/dsl/views/): a scoped view `view x of cloud.backend {
  include * }` becomes that element's default view; "clicking that element automatically
  navigates to its designated view". Views can `extends` other views; dynamic (sequence-like)
  views exist.
- [vendor] Multi-project (https://likec4.dev/dsl/config/multi-projects/): drop a
  `likec4.config.json` in each folder; projects may nest; `import { x } from 'projectA'`
  across projects; the CLI page says the dev server can "serve multiple projects at once".
- [vendor] Embedding (https://likec4.dev/tooling/vite-plugin/ , https://likec4.dev/tooling/react/):
  Vite plugin (works with Astro/Starlight), React `LikeC4View`, and generated Web Components
  (`likec4:webcomponents/*`) "to render a LikeC4 view in HTML without adding React". Third
  parties embed it in markdown sites: mkdocs-likec4 (https://doubleslashde.github.io/mkdocs-likec4/),
  EventCatalog, and an Obsidian plugin that renders ```` ```likec4 ```` fenced blocks
  (https://github.com/alisoliman/obsidian-likec4).
- Constraint check: local yes, no account, FOSS, hot reload, localhost. Footprint: Node +
  a sizeable npm tree (not a single binary). Tolerates a markdown-only repo only in the sense
  that it ignores it — it needs `.c4` files to show anything.
- Verdict: **closest match to the remembered demo that is also free and local.** It is the
  "one model, many views, click to descend" idea done as code rather than as a SaaS.

**Structurizr** — https://docs.structurizr.com/lite , https://github.com/structurizr/structurizr
- [vendor] Structurizr Lite: "free and open source version of Structurizr allows you to
  view/edit diagrams, view documentation, and view architecture decision records defined via
  a DSL or JSON workspace"; "only designed to be used by a single person". Docker image on
  port 8080 mounting a folder with `workspace.dsl`. Auto-refresh is **off by default**; enable
  via `structurizr.properties` in the data directory, after which "the diagrams/documentation/
  decision pages will automatically refresh when changes are detected"
  (https://docs.structurizr.com/lite/usage).
- [vendor] **Lite is archived (Feb 4 2026)**: "Structurizr Lite will not receive any further
  updates — please migrate to Structurizr vNext". vNext consolidates CLI + Lite + on-premises
  into https://github.com/structurizr/structurizr under Apache-2.0, "open core with closed
  extensions for enterprise features"; the Lite role is now the `local` command
  (https://docs.structurizr.com/eol , Patreon announcement 2026-02-01
  https://www.patreon.com/posts/introducing-146923136).
- [independent] Drill-down: "If you double-click on the software system, you'll navigate to the
  container diagram" (https://www.dandoescode.com/blog/c4-models-with-structurizr); "In any
  diagram that you can zoom in, you will see a + sign that will navigate to that view"
  (https://trailheadtechnology.com/tooling-for-the-c4-model-structurizr-lite/).
- Constraint check: local, no account, open source for the local part, JVM + Docker footprint,
  hot reload opt-in. Renders markdown docs + ADRs from the same folder — this is the closest
  thing to "docs site + drill-down diagrams in one process" that already exists.
- Verdict: strong second. Risk: the product is mid-transition (open core; Patreon-funded), and
  Lite's replacement is weeks-to-months old.

**structurizr-site-generatr** — https://github.com/avisi-cloud/structurizr-site-generatr
- [vendor] "Generates a static HTML websites from C4 architecture models created with
  Structurizr DSL"; "Easy browsing through the site by clicking on software system and
  container elements in the diagrams"; includes markdown/AsciiDoc documentation and ADRs;
  `serve` "monitors workspace and asset files, regenerating the site automatically";
  **"Supports multiple branches"** of a git repository (explicit list or all-branches with
  exclusions). Apache-2.0; Homebrew / JAR / Docker. Example site:
  https://avisi-cloud.github.io/structurizr-site-generatr/
- Verdict: the only tool found that natively does *docs + navigable C4 + per-branch sites* in
  one command. Diagrams are static SVG with links, not a live canvas. JVM footprint.

**D2** — https://github.com/terrastruct/d2 , https://d2lang.com/tour/composition/ ,
https://d2lang.com/tour/linking/
- [vendor] MPL-2.0. "D2 does not use an internet connection after installation, except to
  check for version updates from Github periodically." Single Go binary. `d2 --watch in.d2
  out.svg` "opens a browser window displaying the output with automatic updates".
- [vendor] Composition: layers ("a new base"), scenarios (inherit from base), steps (inherit
  from previous). `link: layers.x` on a shape jumps to a board; "the navigation bar at the top
  is clickable" to return to root/ancestors; `_` in a link refers to the parent board. The
  composition page itself says "This section's documentation is incomplete."
- [vendor] Multi-board export: "Multiple boards are packaged as 1 SVG which transitions through
  each board at the interval" — only SVG/GIF; that is the *animated* path, distinct from the
  linked-navigation path.
- Constraint check: passes everything, smallest footprint of any drill-down option.
- Verdict: the cheapest way to get "click box → next board" from text. The remembered demo was
  probably not D2 (D2's marketing centers on layout quality, not exploration), but D2 is the
  best single-binary primitive if the viewer is built rather than adopted.

**draw.io / diagrams.net** — https://www.drawio.com/docs/manual/pages/ ,
https://drawio-app.com/blog/taming-workflow-diagrams-by-linking-to-another-page-within-draw-io-2/
- [vendor] Multi-page files; "right-click on the shape, select Edit Link, and choose the page";
  renamed pages keep links. [independent, DeepWiki] SVG export preserves links as `<a
  xlink:href>` and embeds the mxfile for round-trip. drawio-desktop is Apache-2.0 and offline.
- Verdict: works and is free, but hand-drawn, not derived; `.drawio.svg` files render in any
  markdown viewer as an image, with page-links only functional in the draw.io viewer.

**Ilograph** — https://www.ilograph.com/ , https://www.ilograph.com/pricing.html
- [vendor] "model-based diagrams-as-code", "dynamic zoom", "perspectives", "pin" a resource to
  hide unrelated ones. Free web tier with unlimited private diagrams — but web = their cloud.
  "Ilograph for Desktop" is "an offline desktop app" sold separately at $11.99/month.
  Proprietary. [inferred] this is plausibly the demo David remembers: it is the one product
  whose entire pitch is zoomable, explorable, nested architecture — and it is a SaaS.
- Constraint check: fails "no cloud" on the free tier; passes only via the paid desktop app;
  fails FOSS.

**IcePanel** — https://icepanel.io/ , https://docs.icepanel.io/getting-started
- [vendor] "interactive modelling and diagramming tool that uses the C4 model", "zoom in from
  context to container to component". [independent, pricing aggregators] free tier exists;
  no self-hosted/on-prem option surfaced anywhere. Cloud-only → **ruled out**.

**Mermaid** — https://mermaid.js.org/syntax/flowchart.html
- [vendor] `click nodeId "url"` or `click nodeId callback`; requires `securityLevel: 'loose'`
  for callbacks; collapsible subgraphs since v11.17.0. No nested-view/drill concept; the
  `architecture-beta` diagram type is flat. [independent] pan/zoom is bolted on by wrappers
  (svg-pan-zoom, MkDocs plugin https://lijma.github.io/mkdocs-mermaid-zooming/).
- Verdict: fine as the *leaf* diagram inside a page; not the drill-down mechanism. But it is
  what every markdown viewer already renders, which matters for the "bare repo" constraint.

**C4-PlantUML** — https://github.com/plantuml-stdlib/C4-PlantUML
- [vendor] MIT; `$link=` on Person/System/Container/Rel yields clickable SVG. Needs Java +
  Graphviz. No automatic cross-level navigation.

**Excalidraw / tldraw**
- [vendor] Excalidraw core MIT; frames exist, nested frames were an open request (issue
  #8359). The Obsidian plugin adds element links so "that shape becomes a clickable gateway
  into the note" (https://github.com/zsviczian/obsidian-excalidraw-plugin). Excalidraw+ is the
  paid cloud tier — ruled out for content.
- [independent] tldraw relicensed Sept 2025: production use needs a paid commercial license
  ($6,000/yr) or a watermarked hobby license; "requires a license key to work in production"
  (https://tldraw.dev/sdk-features/license-key , https://finance.biggo.com/news/202509190115_tldraw_SDK_4.0_Licensing_Debate).
  Not FOSS in any practical sense.

**Obsidian and the note-graph family**
- [vendor] JSON Canvas (`.canvas`) is an MIT-licensed open spec, two arrays (`nodes`, `edges`)
  (https://jsoncanvas.org/ , https://obsidian.md/blog/json-canvas/). Obsidian itself is
  proprietary, opens any folder, renders Mermaid, has no HTTP server. Foam is a VS Code
  extension (MIT); Dendron went into maintenance mode Feb 2023 and relicensed to Apache-2.0
  (https://randomgeekery.org/post/2023/02/dendron-is-officially-in-maintenance-mode/); Logseq
  is AGPL, local, outliner-shaped markdown; Quartz is a Node SSG template with `npx quartz
  build --serve` on :8080 and hot reload (https://quartz.jzhao.xyz/).
- Verdict: graph views are *link* graphs, flat and undirected in meaning. None gives
  "descend into a subsystem".

**Backstage** — https://backstage.io/docs/features/techdocs/getting-started/
- [vendor] TechDocs = MkDocs behind Backstage, run locally or in the techdocs Docker image;
  catalogue `dependsOn` in `catalog-info.yaml` drives a dependency graph. Needs a Node app,
  a database, MkDocs, and catalogue YAML per entity. Fails "small footprint" and "bare
  markdown repo".

**Sourcegraph** — [independent] https://devclass.com/2024/08/21/sourcegraph-makes-core-repository-private-co-founder-complains-open-source-means-extra-work-and-risk/
- Relicensed from Apache-2.0 from v5.1 (June 2023), core repo made private Aug 2024, public
  snapshot archived Sep 30 2024. Not a diagram tool in any case.

**CodeSee** — [independent] https://www.crunchbase.com/acquisition/gitkraken-acquires-codesee--b5a40293 ,
https://www.gitkraken.com/press/gitkraken-acquires-codesee-launches-devex-platform
- Shutdown announced Feb 22 2024; acquired by GitKraken May 14 2024; standalone product gone.
  If the remembered demo was "a map of my repo I can click into", it was likely CodeSee, and
  it no longer exists as a product.

**Kroki** — https://docs.kroki.io/kroki/setup/use-docker-or-podman/
- [vendor] `docker run -d -p 8000:8000 yuzutech/kroki` renders PlantUML, Mermaid, GraphViz,
  D2, Structurizr, Excalidraw, BPMN and more to SVG/PNG/PDF from one endpoint. MIT. Useful as
  a local *render service* if the viewer wants to stay language-agnostic; it emits static
  images, so interactivity must be added by whatever embeds the SVG.

---

## 2. Live markdown viewers with zero per-project setup

The bar: point it at a directory that contains nothing but `.md` files, get a browsable site
at `localhost:<port>`, edits show up without restarting. Ideal shape = one static binary.

| Tool | Shape | Zero project files? | Hot reload | Mermaid | Recursive tree | Search | Content stays local | Notes |
|---|---|---|---|---|---|---|---|---|
| **mo** (k1LoW) | Go, single binary, Homebrew | Yes | Yes (watch) | Yes | Yes (tree/flat sidebar) | Yes, full-text | Yes | Multiple roots by positional args/globs; `--port` (6275) `--bind localhost`; runs in background by default. MIT. |
| **mdserve** | Rust, single binary | Yes | Yes (WebSocket) | Yes | **No** — immediate directory only | No | Yes | MIT. **Archived 2026-09-11** (v1.1.0 final). |
| **markserv** | Node CLI (npm) | Yes | Yes (WebSocket) | Partial | Partial (directory index) | No | Yes | Classic GitHub-style; needs Node. |
| **mdts** | Node CLI | Yes | Yes | Yes | Yes | Yes | Yes | Newest (Feb 2026), 20+ theme options. |
| **markdown-serve** (muquit) | Go binary | Yes | Yes (polling) | ? | Yes | ? | Yes | Pre-built binaries. |
| **grip** | Python | Yes | No | No | Partial | No | **No** — "uses the GitHub markdown API"; offline renderer is "work-in-progress" | **Ruled out** by the no-third-party constraint. |
| **docsify** + docsify-cli | Node CLI, runtime-rendered (no build) | Needs an `index.html` (`docsify init` creates it) | Yes | Via plugin | Via `_sidebar.md` | Via plugin | Yes | MIT. One HTML file away from zero-config. |
| **mdbook serve** | Rust, single binary | **No** — needs `book.toml` + `src/SUMMARY.md` | Yes | Via preprocessor | Only what SUMMARY lists | Yes | Yes | Great once configured; not "point at a folder". |
| **VitePress** | Node project | **No** — `.vitepress/config.js` + `package.json` | Yes (HMR, :5173) | Via plugin | Via config | Yes | Yes | |
| **Docusaurus** | Node project scaffold | No | Yes | Via plugin | Via config | Yes | Yes | Heaviest of the SSGs. |
| **Quartz** | Node repo template | No — you clone the template and put content in | Yes (`build --serve`, :8080) | Yes | Yes | Yes | Yes | Obsidian-flavoured (wikilinks, backlinks). |
| **Hugo** | Go single binary | No — needs config + theme [inferred] | Yes | Via theme | Via theme | Via theme | Yes | |
| **Zola** | Rust single binary | No — `zola init` creates `config.toml`, needs templates | Yes | Via templates | Via templates | Built in | Yes | Blog claims "zero config" are about dependencies, not project files. |
| **Glow / Frogmouth** | Go TUI / Python TUI | Yes | No | No | Yes | Glow yes | Yes | Terminal only; no diagrams; not embeddable in a webview. |
| **Obsidian pointed at a folder** | Proprietary desktop app | Yes | Yes (it is the editor) | Yes | Yes | Yes | Yes | No HTTP endpoint, so not embeddable. |
| **Zettlr** | Electron desktop editor (GPL) | Yes | n/a | Yes | Yes | Yes | Yes | Editor, not a server. |
| **mdx-js / Marked** | Libraries | n/a | n/a | n/a | n/a | n/a | n/a | Building blocks, not viewers. |

Sources: independent 2026 comparison at
https://zenn.dev/unhappychoice/articles/markdown-viewers-comparison?locale=en ; mo README
https://github.com/k1LoW/mo ; mdserve README https://github.com/jfernandez/mdserve ; markserv
https://github.com/markserv/markserv ; grip https://github.com/joeyespo/grip ; docsify-cli
https://github.com/docsifyjs/docsify-cli ; mdBook https://rust-lang.github.io/mdBook/guide/creating.html ;
VitePress https://vitepress.dev/guide/getting-started ; Quartz https://quartz.jzhao.xyz/ ;
Frogmouth https://github.com/textualize/frogmouth .

**Which candidates are actually "a single static binary that serves a directory with live
reload":** `mo` (Go), `mdserve` (Rust, now archived), `markdown-serve` (Go). Of these only
`mo` also has a recursive tree, full-text search, Mermaid, and multi-root arguments. Everything
else either needs Node on the path (markserv, mdts, docsify) or needs project files (mdbook,
VitePress, Hugo, Zola).

[inferred] None of the zero-config viewers has any concept of navigable diagrams beyond
rendering a Mermaid fence as a picture. That is the gap: the viewer side is solved, the
diagram side is solved (LikeC4/Structurizr/D2), and nothing joins them without a project
scaffold.

---

## 3. The multi-root problem — N worktrees, one viewer, isolate failures

Prior art found, from most to least applicable:

1. **Antora `worktrees` key** — https://docs.antora.org/antora/latest/playbook/content-worktrees/
   [vendor] Antora builds one site from many git repos and branches (a "component version"
   per branch), and its playbook `worktrees` key "makes worktrees available to be selected by
   the branches key": when a linked worktree's checked-out branch matches the branch filter,
   Antora reads the worktree's on-disk files instead of the git tree — i.e. uncommitted state
   per worktree. Values: `true`, `false`, `.` (current worktree, default), `/.` (main
   worktree), `*` (linked worktrees only), or globs. Only works for branches, not tags.
   **This is exactly David's topology** (one repo, several worktrees on different branches,
   each with its own doc state). Caveat: Antora is AsciiDoc-only, no Markdown — so the
   *pattern* transfers, the tool does not.

2. **structurizr-site-generatr multi-branch** — [vendor] generates a site "from a Structurizr
   DSL model in a Git repository. Supports multiple branches". Per-branch sub-sites from one
   command. Markdown docs included. The closest existing tool to "N branches, one docs site
   with navigable diagrams".

3. **Storybook Composition** — https://storybook.js.org/docs/sharing/storybook-composition
   [vendor] a host Storybook lists `refs: { react: { title, url: 'http://localhost:7007' } }`;
   each ref is an independent process, the host pulls its story index and iframes its canvas.
   [independent] the failure mode is well documented in issues: a ref that is still building
   at host start stays unavailable (#17696), refs that fail to fetch spin forever (#25957),
   CORS and metadata failures (#21500, #10509). Lesson: **process-per-root with a thin
   aggregator isolates crashes but needs explicit health/retry per ref, or the host shows
   spinners forever.**

4. **Docusaurus multi-instance** — https://docusaurus.io/docs/docs-multi-instance
   [vendor] the docs plugin can be instantiated N times with distinct `path`/`routeBasePath`,
   each with its own versioning. One build, one process: a broken instance breaks the build.
   Good for "N doc sets", bad for "one may be broken".

5. **mkdocs-monorepo-plugin (Spotify/Backstage)** — https://github.com/backstage/mkdocs-monorepo-plugin
   [vendor] a root `mkdocs.yml` `!include`s sub-`mkdocs.yml` files; `*include` globs; "Autoreload
   still works as usual" under `mkdocs serve`. Also single-process; no isolation claim.

6. **mdBook** — [independent] serving multiple books from one server has been an open feature
   request since 2019 (https://github.com/rust-lang/mdBook/issues/1042 , #1748) and books on
   one host "contaminate each other" (#455). The answer in practice is one `mdbook serve` per
   book on separate ports.

7. **Vercel preview deployments** — https://vercel.com/docs/deployments/environments
   [vendor] one immutable deployment per branch/PR, stable per-branch URL, each isolated by
   construction. The local analogue is "one build output per branch under one static
   server" — which is what structurizr-site-generatr's multi-branch mode produces.

Patterns that fall out:

- **Process-per-root, URL-prefix-per-root, reverse proxy in front** (Storybook shape). Failure
  isolation is free; the cost is N processes and a health model.
- **One process, one watcher per root, one in-memory site per root, error page per root**
  (Antora/monorepo-plugin shape, but with per-root error containment added). Cheaper; needs
  the renderer to be pure and per-root so a broken markdown/DSL file surfaces as *that root's*
  error, not a crashed server.
- **Build per branch to static output, serve the union** (site-generatr / Vercel shape).
  Simplest and most robust, but "live" only as fast as a rebuild; fine for docs, slower for
  a diagram you are editing.

[inferred] Because the roots are git worktrees, root discovery can come from `git worktree
list --porcelain` rather than configuration, and Antora's "match worktree by its checked-out
branch" is the right identity: a root is a branch name, not a path.

---

## 4. Deriving diagrams from code rather than hand-authoring

| Tool | Input | Output | Human-readable or hairball? |
|---|---|---|---|
| **Structurizr DSL / LikeC4 DSL** | Hand-written model | Navigable C4 views | Readable by construction — because a human curated the model. Not derived. |
| **C4-PlantUML** | Hand-written | Static SVG with `$link` | Readable; not derived. |
| **dependency-cruiser** | JS/TS import graph | `dot` (file-level), `ddot` (folder-collapsed), `archi`/`cdot` ("summarise dependencies to folders of your own choosing"), `d2`, `mermaid`, `dot-webpage` (hover-highlight HTML), `metrics`; `--collapse <depth|regex>` on any reporter | `dot` is a hairball on anything non-trivial; **`archi` with a collapse pattern is the one output people keep** [independent: Netlify blog https://www.netlify.com/blog/2018/08/23/how-to-easily-visualize-a-projects-dependency-graph-with-dependency-cruiser/]. Source: https://github.com/sverweij/dependency-cruiser/blob/main/doc/cli.md |
| **madge** | JS/TS | DOT/SVG/PNG, circular-dep list | Simpler than depcruise, same hairball at file level. https://github.com/pahen/madge |
| **dep-tree** | Python, JS/TS, Rust (beta), Go | `entropy` = 3D force-directed graph in the browser; `tree` = terminal; `check` = rules from `.dep-tree.yml`. Single binary, MIT, offline. https://github.com/gabotechs/dep-tree | The 3D view is a *health* visual ("well-organized codebases display clustered, separated nodes"), not a diagram you navigate. Impressive for five minutes. |
| **cargo-modules** | Rust crate | Module tree, internal dependency graph (Graphviz), `--acyclic` check. https://github.com/regexident/cargo-modules | Readable at module granularity; text/DOT only. cargo-depgraph / cargo-visualize do crate-level (interactive for the latter). |
| **tbls** | Live DB or `json://schema.json` | Markdown per table + ER diagram as PNG/SVG/**Mermaid**/PlantUML/DOT; MIT; single Go binary. https://github.com/k1LoW/tbls | **Genuinely wanted**: a schema ERD is the one derived diagram that is readable by default. Mermaid output drops straight into a markdown viewer. |
| **SchemaSpy** | Live DB | HTML site with Graphviz ERDs | Java; heavier; [independent] harder to scope to a table subset. |
| **DBML** | Hand-written or `sql2dbml` | `dbml-renderer -i x.dbml -o x.svg` locally (npm, https://github.com/softwaretechnik-berlin/dbml-renderer); dbdiagram.io is cloud | Readable; the renderer is a year-old npm package. |
| **OpenAPI → diagram** | OpenAPI spec | `swagger_to_uml` → PlantUML (https://github.com/nlohmann/swagger_to_uml); OpenAPItoUML (Eclipse) | Class diagrams of schemas; usually less useful than the rendered spec itself. |
| **Backstage catalogue** | `catalog-info.yaml` `dependsOn` | System/component graph | Readable because it is curated YAML, i.e. hand-authored at a coarser grain. |

[inferred] The honest split: **derived-from-code works at exactly two grains** — database
schema (tbls/dbml) and folder-collapsed import graph (depcruise `archi`, cargo-modules). Above
that, every "readable" diagram in this survey is a human-curated model (Structurizr, LikeC4,
Backstage YAML). The practical hybrid is a curated top model whose leaf views are generated
(a container box whose "drill into" target is a `tbls` Mermaid ERD or a depcruise `archi`
SVG regenerated on change). For this repo (Drizzle schema, pnpm monorepo) both generators
apply directly; `packages/db` is a natural tbls target via `json://` export.

---

## 5. The honest question: does something already do most of this?

**Mostly yes, in two pieces; nobody does the join.**

- If David's remembered demo was **Ilograph** or **IcePanel**, the answer is "that quality
  exists, but only as SaaS (or a paid desktop app), which the client-data constraint rules
  out". If it was **CodeSee**, it is gone.
- **LikeC4** delivers the *interaction* (one model, scoped views, click to descend, hot reload,
  localhost, MIT) and would be the wrong thing to rebuild. Its gap: it is not a markdown site;
  markdown lives elsewhere and embeds LikeC4 views via Vite/React/web components or a
  third-party MkDocs/Obsidian plugin.
- **Structurizr local (ex-Lite) and structurizr-site-generatr** deliver *docs + ADRs + navigable
  C4 from one folder*, and site-generatr even does *per-branch*. Their gaps: JVM/Docker
  footprint, hand-written DSL only, Structurizr's own tooling is mid-transition, and neither
  is a general "any folder of markdown" viewer — the markdown is the workspace's docs, not the
  repo's.
- **`mo`** delivers the zero-config, single-binary, live, multi-root markdown viewer, with
  Mermaid — and no notion of navigable diagrams.

The precise uncovered part is: **a zero-config viewer for an arbitrary markdown tree that (a)
renders navigable/drill-down diagrams inline (not as static Mermaid pictures), (b) serves
several git worktrees of the same repo side by side with one broken root not taking the rest
down, and (c) needs no project scaffold.** (a)+(c) together is what no tool has; (b) exists
only in Antora (AsciiDoc) and site-generatr (Structurizr-shaped).

So: building the *join* is defensible; building the *diagram engine* or the *markdown
renderer* is not.

---

## Three shapes this could take

### Shape A — "Glue existing servers behind one proxy"
Run `mo` (markdown, one instance per worktree, or one instance with N roots) and `likec4
serve` (one per worktree, or one with N `likec4.config.json` projects) as child processes;
a small front process reverse-proxies them under `/<branch>/docs/…` and `/<branch>/arch/…`,
rewrites markdown links to `*.c4` views into iframes/web-components, and shows a per-root
health page.
- Distinguishing trade-off: **zero rendering code to own, but you inherit two UIs, N
  processes, and Storybook-composition-style liveness problems.** Node is a hard dependency
  (LikeC4). Diagrams are LikeC4-shaped: hand-modelled DSL.
- Cost: days. Risk: low technically, medium in "it feels stitched".

### Shape B — "One small binary: markdown + Mermaid + D2 boards + multi-root watcher"
A single Go/Rust server (mo-like) with a per-root watcher and an in-memory site per root.
Diagrams: Mermaid for leaves; for drill-down, D2 layers rendered via the D2 library
(Go — same process) with `link: layers.x` navigation kept as in-page SVG swaps; optionally a
tiny model format (or JSON Canvas) mapping "box → page/board/repo path". Derived leaves via
shelling out to `tbls`/`depcruise` on change.
- Distinguishing trade-off: **single static binary, no Node, tiny footprint, embeddable in a
  webview — but the drill-down quality is whatever you build on top of D2's boards, and D2's
  composition docs are self-described as incomplete.** You own the join *and* the interaction
  layer.
- Cost: weeks. Risk: medium — the interaction layer is where the "demo quality" lives, and
  that is the part being rebuilt.

### Shape C — "Structurizr-shaped: DSL workspace per root, static-site-per-branch, one server"
Adopt Structurizr DSL (or LikeC4 DSL) as the architecture source, run structurizr-site-generatr
(multi-branch, docs + ADRs + navigable C4) or Structurizr `local` per worktree, and put a
markdown viewer next to it for everything that is not the workspace's docs.
- Distinguishing trade-off: **the most "finished" drill-down experience available for free
  today, with branch support built in — at the price of a JVM/Docker dependency, a
  hand-authored model, and betting on a vendor mid-reorganisation (Lite archived Feb 2026,
  open core).** Not a bare-markdown-repo tool; it wants a `workspace.dsl`.
- Cost: days to stand up. Risk: low now, medium over a year.

### Recommendation
**Shape A first, with B as the destination if A proves the workflow.** Reasoning:

1. The remembered demo's *quality* is a model-driven, scoped-view, click-to-descend canvas.
   That already exists free and local in LikeC4; re-implementing it on D2 boards (Shape B)
   spends the most effort on the part that is least novel. LikeC4's web-component export
   (`likec4:webcomponents/*`) is specifically there to be dropped into someone else's page.
2. The genuinely uncovered part — multi-worktree serving with failure isolation over a bare
   markdown tree — is small and is the same in A and B. Do it once, in the proxy/aggregator,
   using `git worktree list` for root discovery and Antora's "root = branch" identity.
3. Shape C's branch support is attractive but it is Structurizr-shaped end to end, and
   Structurizr's local story changed under everyone's feet seven months ago.
4. Node as a dependency is the real cost of A. It is already on this machine (pnpm monorepo);
   the "single binary" preference is a preference, not a constraint in the brief.
5. Migration path A→B is clean: the aggregator is the product; swapping `mo` for an in-process
   renderer, or LikeC4 for a leaner board engine, changes children, not the shape.

If a single binary with no Node turns out to be a hard requirement (e.g. shipping it to
Brandon's machine), B is the answer and D2 is its diagram primitive.

---

## What I could not verify

- **Which demo David saw.** Ilograph, IcePanel, LikeC4, Structurizr, and (historically)
  CodeSee all fit the description; nothing in this research identifies which one.
- **LikeC4 dev-server behaviour when one of several projects has a parse error** — the
  multi-projects page says nothing about isolation; the CLI page only says it can "serve
  multiple projects at once". Also unverified: whether the dev server UI switches projects in
  one page or serves them at separate paths.
- **LikeC4 fenced blocks in `.md`** are rendered by the third-party Obsidian plugin; I did
  not confirm that the LikeC4 CLI/Vite plugin itself parses ```` ```likec4 ```` fences in
  markdown files.
- **D2 board links in plain `d2 --watch` output** — the docs say the navigation bar "is
  clickable" and `link: layers.x` jumps between boards, but not whether that works in a
  static `out.svg` opened outside the watch server / playground.
- **Structurizr vNext `local` command specifics** — port, auto-refresh default, and whether
  the double-click navigation of Lite survived unchanged. The GitHub page gave only "Use
  Structurizr local via the pre-built Docker image". The Lite behaviour (auto-refresh off by
  default; double-click to descend) is verified for Lite, assumed for vNext.
- **Structurizr Lite's license**: docs say "free and open source"; the GitHub page fetch
  reported "MIT license"; the vNext repo is Apache-2.0. I did not open the LICENSE files.
- **Hugo** needing a config file and theme to render anything is from memory, not fetched.
- **`markdown-serve` (muquit)** details beyond "Go, binaries, polling live reload, recursive"
  — Mermaid and search support not checked.
- **`mo` last-release date** — the README fetch showed activity but no date; the Zenn article
  (2026) calls it "newest, fastest development".
- **structurizr-site-generatr `serve` with multiple branches simultaneously** — multi-branch
  is documented for `generate-site`; whether `serve` watches N branches at once is not.
- **Storybook composition's official failure semantics** — the docs page says nothing; the
  behaviour above is reconstructed from GitHub issues.
- **IcePanel has no self-hosted option** — absence of evidence across pricing pages and
  aggregators, not a vendor statement.
- **Ilograph desktop app requiring an account** — pricing page shows it as a paid product;
  whether it phones home was not established.
- Every "readable vs hairball" judgement in section 4 is opinion informed by the linked
  posts, not a measured comparison.
