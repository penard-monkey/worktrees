# Host recon — `worktrees` v0.23.1 (read-only, 2026-09-16)

Subject: `/Users/davidpena/workspace/worktrees` at `29671fc` (release v0.23.1).
Every `file:line` below is relative to that repo root. Nothing in it was modified.

Read for orientation: `CLAUDE.md` (636 lines), `DESIGN.md` (569 lines, "design
locked 2026-07-20" with reversal banners), `docs/index.md`, `docs/adr/0001`,
`docs/proposals/project-settings.md` (headers), the dock/viewer session archives
(`docs/sessions/2026-07-28-right-dock`, `2026-07-29-right-panel`,
`2026-08-03-files-viewer`, `2026-08-09-files-tab-refresh`,
`2026-08-11-space-workbench`, `2026-08-14-markdown-zoom`, `2026-09-05-ui-overhaul`).
Then code: `app/src/App.tsx` (6570 lines, the whole shell in one component),
`app/src-tauri/src/lib.rs` (6195 lines, every command), `app/src/FilesPane.tsx`,
`app/src/markdown.tsx`, `app/src/settings.ts`, `crates/worktrees-core/src/{model,store,project,agent,provision,projcfg}.rs`,
`crates/worktrees-cli/src/mcp.rs`, `tauri.conf.json`, `capabilities/default.json`,
`.github/workflows/{ci,release}.yml`, `Makefile`, `.claude/close-out.md`.

Where I say **unverified** I did not run the app; I read source only.

---

## 1. The app's shell

### Window layout

One window, "main" (`app/src-tauri/tauri.conf.json:12-21`, 1280×820, min 900×560,
`dragDropEnabled: false`). The React root is `<App/>` rendered bare, no error
boundary above it (`app/src/main.tsx:10-15`; ROADMAP.md:736-742 records that gap).

`App()` (`app/src/App.tsx:2712`) renders a CSS grid with **four columns**
(`App.tsx:5525-5530`, fallback rule `App.css:33-46`, `--rail-w: 44px` at
`tokens.css:118`):

```
rail(44) | nav (pinned only) | .space  minmax(0,1fr) | rail-right(44)
```

- **Left rail** `<nav className="rail">` (`App.tsx:5547-5578`): one destination
  button (Places), a spacer, optionally the usage meter (`5574`), add-project
  (`5577`), settings (`5578`).
- **Nav / Places sidebar** `<nav className="nav">` (`5598-5667`): the place tree
  grouped by lifecycle tier. Pinned = a grid column; unpinned = an absolutely
  positioned overlay that never resizes the terminal (`settings.ts:132-141`,
  `App.css:42-45`).
- **`.space`** (`5676`): TmuxBanner (`5679`), the space header `<header className="topbar">`
  (`5683`, place identity + branch chip + controls), then `.space-body` (`5873`),
  a flex row holding:
  - `<main className="main">` (`5874`): `TerminalPane` attached to the place's
    tmux session when up (`5878`); otherwise a "No live session" card with the
    status check body (`5896-5920`); with no place selected, the Home
    "briefing" (`5966-6011`).
  - `<aside className="dock">` (`6019-6135`): **this is the right panel**. Only
    when `dockShown && selected && sel`.
  - the reading overlay `.reading` (`6145-6171`, CSS `App.css:1707-1716`): ⌘⇧E
    puts the dock's open file over terminal + dock together (`FileView expanded`).
- **Right rail** `<nav className="rail rail-right">` (`6175-6195`): the only
  control for the dock. It maps `DOCK_RAIL` (`5512-5515`), exactly two entries:

  ```ts
  const DOCK_RAIL = [
    { key: "files"    as Settings["dock_tab"], icon: <Icons.Folder size={17} />,         title: "Files" },
    { key: "terminal" as Settings["dock_tab"], icon: <Icons.SquareTerminal size={17} />, title: "Terminal" },
  ];
  ```
  Clicking the active icon collapses the dock (`pickDockTab`, `4847-4852`); the
  buttons are disabled with no place selected or when the window is too narrow
  (`6181`, `dockEligible`/`dockFits` at `3663-3668`). Session
  `2026-07-29-right-panel` D1: the rail is permanent by decision.

The dock is **not a grid column** — it is a flex sibling of `<main>` inside
`.space-body` so the space header crowns both (`App.tsx:5517-5524`,
`docs/sessions/2026-08-11-space-workbench/summary.md:38-55`). Width is
`flex: 0 0 ${fit.dockW}px` (`6020`); `fitLayout` (`settings.ts:429-446`) with
`DOCK_MIN = 240` (`394`), `MAIN_MIN = 420` (`391`), degrade order shrink dock →
drop dock → nav. Changing the dock width is a SIGWINCH to the tmux pty
(CLAUDE.md:229-249), which is why xterm host sizing has three hard-won rules
(CLAUDE.md:196-228).

### What lives in the dock today

`dock-tabs` is a **title, not a tab strip** (`App.tsx:6022-6025`:
`{eff.dock_tab === "files" ? "Files" : "Terminal"}`), plus Files-only header
controls (refresh ↻, show-ignored ◌/◉, changed-only ◇/◆, layout A/▤/▥;
`6027-6086`). `dock-body` (`6088-6133`) is a ternary:

- `eff.dock_tab === "files"` → `<FilesPane root={selected.path} … reloadToken={placesToken} … />`
  (`6090-6119`; component in `app/src/FilesPane.tsx:822`).
- else → `<TerminalTabs key={repo|slug} … />` (`6121-6131`; component at
  `App.tsx:829`, renders `ShellPane`s from `TerminalPane.tsx:519`).

### Per-place panel memory

`dock_tab` is typed `"files" | "terminal"` in two places: `PlacePanels`
(`app/src/settings.ts:49-75`, the per-place record) and the flat `Settings`
(`settings.ts:151-153`). `panelsFor(settings, "repo|slug")` (`84-105`) overlays
`place_panels[key]` on the globals; a never-visited place starts with the dock
closed (`90-104`). `eff` is what the UI must read for anything dock-related
(`App.tsx:2853-2860`). Optional fields there must stay optional or the seed
freezes (CLAUDE.md:470-479). The whole record is persisted whole-blob by the
frontend to `ui-state.json` (`settings.ts:1-5`, `lib.rs:637-671`).

### How a new panel gets added — there is no registry

Hard-coded, all in `App.tsx` and `settings.ts`. A third dock tab means, at
minimum:

1. Widen the union `dock_tab: "files" | "terminal"` in both `PlacePanels`
   (`settings.ts:51`) and `Settings` (`settings.ts:153`). Existing
   `ui-state.json` records stay valid (the union only widens).
2. Add an entry to `DOCK_RAIL` (`App.tsx:5512-5515`) with an icon from
   `app/src/icons.tsx` (inventory: ListTree, TriangleAlert, PanelRightClose/Open,
   FolderPlus, Folder, SquareTerminal, Settings, Pin, Ellipsis, ChevronDown/Right,
   GitBranch, X, Plus, Import, Check, ArrowUpDown, Search, Folder16, Home — Lucide
   geometry hand-copied, `icons.tsx`; a "book" icon would be a new path).
3. Extend the `dock-title` ternary (`6025`) and the `dock-body` ternary (`6089`).
4. `findTarget` (`App.tsx:165-178`) decides which surface owns ⌘F and already
   special-cases `dockTab === "terminal"`; `keyRef.dockTab` (`4865`) mirrors it.
5. `data-track` on the rail button (`6187`) must be a **fixed vocabulary token**
   — `usage.ts` resolves clicks to a closed key set and `valid_token` in lib.rs
   refuses anything else (DESIGN.md:486-494; `2026-09-05-ui-overhaul` item 4).
6. The mock harness `app/src/mock/install.ts` must gain any new command arm —
   it tracks every handler in lib.rs and unknown commands only `console.warn`
   (`install.ts:5-7`, `1727-1728`; CLAUDE.md:147-149).
7. Any new dialog/popover calls `useEscape` (`app/src/useEscape.ts:1-28`,
   CLAUDE.md:135-144); components live at module scope (CLAUDE.md:145-146).

No plugin seam, no tab registry, no lazy-loaded panels. The ⌘J toggle
(`toggleDock`, `4856-4858`) and ⌘⇧T (`5060-5065`) both assume the two-tab model.

---

## 2. The frontend stack

`app/package.json:13-33`:

| Dependency | Version | Role |
|---|---|---|
| react / react-dom | ^19.1 | UI. No router, no state library — everything is `useState` inside `App()` (`App.tsx:2713-2850`) |
| @tauri-apps/api | ^2 | `invoke`, `Channel` (`App.tsx:2`), `listen` (`App.tsx:3`) |
| @tauri-apps/plugin-{dialog,opener,process,updater} | ^2 | folder picker, `openUrl`/`revealItemInDir`/`openPath`, relaunch, self-update |
| @xterm/xterm + addon-fit/search/unicode-graphemes | 5.5 / 0.10 / 0.15 / 0.4 | terminals |
| marked | ^18.0.7 | **lexer only** |
| vite 7, @vitejs/plugin-react 4.6, typescript ~5.8 | dev | build |

Build: `vite.config.ts` — port 1420 strictPort, `src-tauri` ignored by the
watcher (`16-31`); `pnpm build` = `tsc && vite build` (`package.json:9`);
`tauri.conf.json:5-10` `devUrl http://localhost:1420`, `frontendDist ../dist`.
Mock harness: `VITE_MOCK=1` installs a fake `__TAURI_INTERNALS__` before `App`
imports (`main.tsx:6-9`, `mock/install.ts:1-7`, 82 command arms).

Styling: plain CSS. `App.css` (2240 lines) + `tokens.css` (432 lines; six
themes as `[data-theme]` maps, `settings.ts:10-17`; everything scales off
`--ui-rem`, terminal off independent `--term-*`). Rule: **no UI/component
libraries and no editor**; a pure parser whose output is rendered by hand is
allowed, and `marked` is the one instance (CLAUDE.md:488-493;
`2026-08-03-files-viewer` D2).

### Markdown renderer — yes, bundled

`app/src/markdown.tsx`: `marked.lexer(src, {gfm:true, breaks:false})` (`289`)
→ hand-built React nodes, no `innerHTML`, no sanitizer (`1-10`). Handles
headings with GitHub-style slug ids (`49-54`, `136-143`), paragraphs, fenced code
via `CodeBlock` (`152-160`, fence alias table `252-269`), blockquotes, tight/loose
lists + task checkboxes (`169-190`, `240-248`), GFM tables (`192-212`), hr,
links through `safeHref` (`37-46`: only `#`, relative, or http(s) get an href;
everything else is inert text), images via a `renderImage` callback (`113-116`).
**Raw HTML is rendered as literal text** (`117-119`, `217-218`). Recursion cap
`MAX_DEPTH = 40` (`60`) plus a try/catch around the lexer (`287-293`). Memoized
(`277-304`). Consumers: `FilesPane.tsx:664` and `StatusSheet.tsx:408` (Claude's
"read" of a place). ROADMAP.md:744-750 lists known gaps (7 entities, no slug
dedupe, no footnotes).

### Syntax highlighter — yes, hand-rolled

`app/src/highlight.ts`: single-pass scanner, 15 grammars (`52-152`: ts, rust,
python, go, ruby, clike, json, yaml, toml, ini, shell, css, scss, xml, sql, diff),
"deliberately approximate" (`1-12`). Rendered by `CodeView.tsx` (`CodeBlock`,
gutter + `<pre>`). Shiki/lowlight were rejected for size (`2026-08-03` D3).

### Diagram library — none

Nothing for mermaid/graphviz/plantuml anywhere (grep of `app/src`, `package.json`,
all session archives). `filekind.ts:8` knows five kinds:
`markdown | image | code | text | binary`. A ```` ```mermaid ```` fence goes
through `fenceLang` (`markdown.tsx:269`) → `""` → plain `CodeBlock`. SVG files
are treated as images: rendered via `read_file_base64` into a `data:` URI
`<img>` (`FilesPane.tsx:404-415`, `630`, `641-644`; `filekind.ts:135`), which is
not clickable and cannot follow `<a>` inside the SVG. Inline SVG in markdown is
an `html` token → literal text.

### Iframe / webview embedding — none

No `<iframe>`, `<object>`, `<embed>`, `WebviewWindow` anywhere in `app/src`
(grep). Outbound links leave the app through `openUrl` (plugin-opener):
`App.tsx:4108` (GitHub URL), `FilesPane.tsx:600`. Remote images in markdown are
refused with a placeholder (`FilesPane.tsx:617`). Every byte the viewer shows
arrives over IPC: `read_file` (1 MiB cap, NUL → binary; `lib.rs:3514-3547`)
and `read_file_base64` (4 MiB cap; `3554-3560`), both behind
`guard_under_projects` (`3070-3082`: canonicalize, must exist, must be under a
registered project root).

### Refresh model

No filesystem watcher. `placesToken` (`App.tsx:2982`) bumps on the backend's
`places:changed` event (`3119-3123`) and on the dock's ↻ (`3142`), gated on
`document.visibilityState` (`3120`). `FileView` re-reads on it
(`FilesPane.tsx:546-557`) and the tree re-lists (`2026-08-09` session). The
backend emits `places:changed` when the tmux session set changes or every 10
ticks of a 3 s loop (`lib.rs:4876-4882`), i.e. **≤30 s latency for a disk
edit**. `notify` is not in `Cargo.lock` (0 hits); ROADMAP.md:490-499 proposes an
FSEvents watcher and notes "same watcher would replace the claude probe-dir scan".

---

## 3. The place model

### Core (`crates/worktrees-core`)

`Project` (`project.rs:16-22`): `{ main_root, git_common, wt_root, prefix, clock }`
discovered from cwd via `git rev-parse --git-common-dir` (`52-72`).
`wt_root = <main_root>/.worktrees` (`69`); `place_dir(slug)` = `main_root` for
`(main)` else `<wt_root>/<slug>` (`429-433`); tmux session =
`<prefix>-<slug>` with `.`→`-` (`74-76`).

`Place` (`model.rs:20-48`, schema v1, field order is a byte-for-byte contract
with the old bash): `slug, path, is_main, registered, branch, detached, dirty,
dirty_files, ahead, behind, upstream, created(_epoch), last_commit_epoch,
last_commit_subject, tmux_session{name,up}, claude_session_present,
claude_session_dir, install_cmd, stack (reserved, always null: 41-42),
declared (null from the CLI), lifecycle_effective`. `LsJson` (`66-75`) wraps
`{schema_version, repo, prefix, places_file, places[], strays[]}`; `Stray`
(`57-63`) = a worktree git registers outside `.worktrees/`.

Two state categories, by design (CLAUDE.md:14-17, `docs/index.md:32-40`):

- **Derived** — live git/tmux, recomputed on every `ls`, never stored.
- **Declared** — `.worktrees.places.json`.

### `.worktrees.places.json` — what it is, who writes it

`crates/worktrees-core/src/store.rs`. Path: `<repo main root>/.worktrees.places.json`
(`16`, `101-104`), sibling of `.worktrees/` so a `rm -rf .worktrees` cannot lose
it (DESIGN.md:182-184). Shape (`store.rs:81-90` → `24-78`):

```json
{ "version": 1, "updated_epoch": …,
  "places": { "<slug>": { "lifecycle"?, "pinned"?, "note"?, "title"?,
                          "last_opened_epoch"?, "last_worked_epoch"?,
                          "profile_id"?, "profile_epoch"?, …extra } } }
```

Unknown keys round-trip through `#[serde(flatten)] extra` (`76-77`, `88-89`) —
that is how the app's cached "Ask Claude" `status_report` lives there without
being a known key (`App.tsx:41-44`; you can see one in the live file at
`.worktrees.places.json:29-33`). `active`/`idle` are never written; `reconcile`
(`153-169`) derives `lifecycle_effective` from sticky labels + tmux liveness +
a 7-day idle window (`IDLE_WINDOW_SECS`, `15`).

Writers: all go through core's `store::edit` under an in-process `WRITE_LOCK`
(`19`) plus a cross-process `mkdir` lock `.worktrees.places.json.lock/`
(`190-200`); reads are lock-free and lenient (`172-177`); a parse error is never
overwritten (`181-188`). Callers: the app commands `set_lifecycle/set_pin/
set_note/set_title/touch_place` (`lib.rs:688-722`), `stamp_worked` from the poll
thread (`4954`), core `ops::launch` (profile stamp, DESIGN.md:311-314), and the
MCP tools `set_note/set_pin/set_lifecycle` (`mcp.rs:377-409`). The first write
also appends the file to `.git/info/exclude` (`store.rs:106-149`). The CLI's
`ls --json` and MCP `list_places` are **live-only** and never read it
(`store.rs:1-3`, `mcp.rs:350-353`); only the app overlays it.

The copy at the worktrees repo root (`.worktrees.places.json:1-77`) is
dogfooding state for the tool's own repo (gitignored, `.gitignore:5-7`): fourteen
places with pins, open/worked epochs, one `lifecycle: "closed"`, one
`status_report`.

### What the app knows per place (and where it lives)

`snapshot(repo)` (`lib.rs:246-316`) = `project.ls()` + `unborn` flag + declared
overlay + `reconcile` + profile badge (`profile_name`, `profile_stale`).
`list_workspace` (`359-383`) fans that out over every registered project root,
four at a time. Frontend types: `Place` (`App.tsx:47-74`), `Declared` (`30-45`),
`Snapshot` (`80`).

| Fact | Source | Storage |
|---|---|---|
| path, branch, dirty, ahead/behind, tmux up, claude dir present | `project.ls()` | none (derived) |
| lifecycle, pinned, note, title, last opened/worked, profile stamp, status_report | `store.rs` | `<repo>/.worktrees.places.json` |
| registered projects (ordered) | `lib.rs:338-354` | `<app config dir>/projects.json` |
| dock open/tab/width, md zoom, diff, term tab names/strip/active, every setting | `settings.ts` | `<app config dir>/ui-state.json` (frontend writes whole blob) |
| each dock shell tab's last cwd | `lib.rs:3690-3714` | `<app config dir>/shell-cwds.json` (backend only) |
| usage metrics | `lib.rs:3980-4030` | `<app config dir>/ui-events.jsonl` |
| Claude busy/waiting per place | `agent.rs:1-24` reading `~/.claude/sessions/<pid>.json` | event `sessions:busy` (in-memory) |
| unsent prompt drafts | `scan_drafts` via one chained `tmux capture-pane` | event `sessions:drafts` |
| AI profiles | `profile.rs` | `~/.config/worktrees/profiles.json` + `$XDG_DATA_HOME/worktrees/profiles/<id>/` (DESIGN.md:251-257) |
| live PTYs | `Terminals`, `Shells` | in-memory only (`lib.rs:4221`, `4400`) |
| health verdict | `place_health`/`doctor` on demand | none |

App config dir on macOS = `~/Library/Application Support/net.casadelvalle.worktrees/`
(`APP_IDENT`, `lib.rs:30`; log at `~/Library/Logs/net.casadelvalle.worktrees/app.log`,
CLAUDE.md:465). No SQLite anywhere.

Two more per-place conventions the tool already owns: the agent brief at
`.planning/brief.md` (`ops.rs:344-347`, `BRIEF_PATH`/`BRIEF_OPENER`), and the
project config `.worktrees.toml` (`projcfg.rs:31`) whose `[ports]` section is
`{stride, max_slots, base: map}` (`projcfg.rs:218-222`, defaults `38-39`).

---

## 4. Process supervision — the most important question

**Yes, the app already owns long-running per-place processes, but only PTY
children, and only with the thinnest possible supervision.** Everything is in
`app/src-tauri/src/lib.rs`; there is no supervisor abstraction, no port
allocation on the app side, no health checks, no service registry, no tokio
(commands are `async fn` but the work is std threads and blocking IO).

### 4a. `Terminals` — tmux attach clients (not owned processes)

`struct Term { master, writer, child, stop }` in `Terminals(Mutex<HashMap<u32, Term>>)`
(`lib.rs:4213-4223`). `term_open` (`4230-4288`) opens a pty with `portable-pty`
(`4237`), spawns `tmux -u attach-session -t <session>` (`4250-4254`), and a
reader thread streams raw bytes to the webview through
`Channel<InvokeResponseBody>::Raw` (`4268-4284`). `term_close` kills the *client*
= detach, never the session (`4311-4318`). tmux owns the shell; the app is one
more client (DESIGN.md:413-437). Session creation is delegated to core
`ops::launch` (`open_place`, `875`).

### 4b. `Shells` — owned login-shell PTYs per dock tab (the real precedent)

This is the closest thing to "the app supervises a process for a place":

- Registry `Shells(Mutex<HashMap<(repo, slug, index), Shell>>)` (`4397-4400`);
  `Shell { master, writer, child, stop, ring, sink, gen, size }` (`4338-4357`).
- Spawn: `shell_open` (`4457-4564`) holds the registry lock for the whole body
  (`4450-4455`, race lesson), spawns `$SHELL -l` in the place dir or the
  remembered cwd (`4506-4513`), 256 KB replay ring (`SHELL_RING`, `4336`),
  attach generations so a stale detach is a no-op (`4347-4353`).
- Output: reader thread → ring + current sink channel (`4530-4553`); on EOF it
  emits `shell:exit {repo, slug, index}` (`4554-4559`). The event is transient;
  liveness must be re-asked on mount: `list_shell_sessions` calls
  `child.try_wait()` (`3656-3665`), and that `try_wait` **reaps**, after which
  `process_id()` keeps returning the dead pid (`3818-3826`, CLAUDE.md:396-406).
- Crash handling: none beyond "the tab stays and the frontend offers Restart"
  (`4554-4555`; `TerminalTabs` dead-tab UI). No auto-restart, no backoff.
- Cleanup: `kill_shell` (`4402-4407`, `Child::kill()` = SIGHUP, survives only
  because dropping the master closes the pty, CLAUDE.md:396-399);
  `kill_place_shells` on place close/rm (`4411-4423`; `close_place` takes
  `State<Shells>` at `937`, `remove_place` at `3945`); and on
  `tauri::RunEvent::Exit` every shell is killed after cwds are saved
  (`5050-5064`). Shells deliberately die with the app (`4329-4332`).
- Sampling: the 3 s poll thread saves shell cwds every 5th tick via
  `/proc`-or-`lsof`-style `proc_cwd` (`4871-4875`, `3773-3826`).

### 4c. Fire-and-forget subprocesses

`open_editor`/`open_terminal` (`2917-2953`): `/bin/sh -c`, reaped on a detached
thread. `run_deadline` (`1009-1046`) runs a `Command` with a timeout and kills
it — the pattern for a bounded probe. `fixup_gui_path` (`4612-4635`) resolves the
login-shell PATH at startup; anything spawned before it runs, or not on the
login PATH, is invisible (CLAUDE.md:132-134).

### 4d. The background loop (the only "monitor")

One std thread spawned in `setup` (`lib.rs:4820-4960`): `sleep(3s)`; optional
auto-fetch inline; cwd sample every 5 ticks; tmux fingerprint → emit
`places:changed` on change or every 10 ticks; draft scan every 5 ticks; Claude
probe scan → `sessions:busy` on change; completion edges → `sessions:done`.
It is a hand-rolled scheduler with counters, not a supervisor.

### 4e. Ports, health, registry

- **Port allocation** exists only in core `provision.rs` for the *user's* docker
  stack: `select_slot` (`251-275`) picks the lowest free slot in `1..=max_slots`,
  probing with `TcpListener::bind` (`port_free`, `281-290`) and scanning sibling
  `.worktree.env` files (`ENV_FILE`, `57`), under a `mkdir` lock
  `.worktrees.slots.lock` (`60`). The slot is derived, never stored in the places
  file (`12-18`). Nothing app-side asks for a free port.
- **Health**: `health.rs` is a pure judgement over git facts ("behind is never
  sickness", `11-13`), unrelated to processes.
- **Service registry**: none. `Place.stack` is reserved and null (`model.rs:41-42`).
  DESIGN.md's "infra strip (Start/Stop, port chips, open-localhost links)"
  (`31-32`, `467-468`) was the only design that ever showed a running service
  with a port in the UI, and its executable half was reversed by ADR 0001.

### What a new supervised process would hook into

A `.manage()`'d registry struct next to `Shells` (`lib.rs:4731-4732`), keyed by
`(repo, slug)` or by repo; a command that spawns on demand (async fn, PATH
already fixed); `app.emit` for state changes; `try_wait` liveness on every
read; a sweep in `kill_place_shells`'s call sites and in the `RunEvent::Exit`
handler (`5054`); `applog` for every failure (CLAUDE.md:450-453); a unit test in
`mod tests` (`5068`+) that drains the pty if it is one (CLAUDE.md:400-403). Port
choice would have to be added — `provision::port_free` is reusable, the slot
allocator is not (it is per `.worktrees.toml` and per user stack).

---

## 5. Tauri specifics

Versions (`Cargo.lock`): tauri **2.11.5** (`3675-3676`), tauri-runtime-wry 2.11.4
(`3936`), wry 0.55.1 (`5266`), tao 0.35.3 (`3607`), portable-pty 0.9.0 (`2658`),
tauri-plugin-opener 2.5.4 (`3846`), tauri-plugin-updater 2.10.1 (`3878`).
`tauri = { version = "2", features = [] }` — no `protocol-asset`
(`app/src-tauri/Cargo.toml:23`). Plugins registered: opener, dialog, updater,
process (`lib.rs:4727-4730`); `objc2` on macOS for one selector override
(`Cargo.toml:38-41`, `lib.rs:4754-4814`). No `tauri-plugin-shell`, `-http`, `-fs`.

### Rust ↔ JS surface

- ~90 `#[tauri::command] async fn` handlers (`lib.rs:85` … `4674`), all
  registered in one `generate_handler![…]` (`4963-5047`). **Must be `async fn`**
  or the main thread freezes (CLAUDE.md:130-131). Called with `invoke()`.
- Managed state: `Terminals`, `Shells` injected as `State<'_, T>`.
- Streaming Rust→JS: `Channel<InvokeResponseBody>` carrying `Raw(Vec<u8>)` for
  both PTY kinds (`4234`, `4464`); `Channel<sync::SyncProgress>` for sync
  (`2542`). ROADMAP.md:501-513 documents the per-send cost.
- Events Rust→JS (`app.emit`): `places:changed` (`515`, `1539`, `2624`, `2645`,
  `4869`, `4881`), `sessions:done` (`1530`, `4955`), `sessions:busy` (`4941`),
  `sessions:drafts` (`4914`), `shell:exit` (`4558`). JS side `listen(...)`:
  `App.tsx:952`, `3119`, `3152`, `3176`, `3188`.
- No custom URI scheme (`register_uri_scheme_protocol` — 0 hits), no window
  creation from Rust, no multi-window.

### CSP / config / permissions

- `tauri.conf.json:22-24`: `"security": { "csp": null }` — **no CSP at all**.
  The files-viewer session says it plainly: "there is no second line of defence"
  (`docs/sessions/2026-08-03-files-viewer/summary.md:89-90`). So nothing in
  config forbids an `<iframe src="http://localhost:PORT">`, a `<script src>`,
  or a fetch to localhost.
- `capabilities/default.json:8-22`: `core:default`, `opener:default`,
  `opener:allow-open-path` scoped `**` (with `requireLiteralLeadingDot: false` in
  `tauri.conf.json:39-41`, CLAUDE.md:454-464), `dialog:default`,
  `updater:default`, `process:default`. Resolved set confirmed in
  `gen/schemas/capabilities.json`. `core:default` includes `core:window:default`
  and `core:webview:default`; **unverified** whether those grant
  `allow-create` for windows/child webviews from JS (in Tauri 2 the defaults
  are read-mostly; creation would need `core:window:allow-create` /
  `core:webview:allow-create-webview`). Rust-side creation needs no ACL.
- Origin: production loads `frontendDist` over the `tauri://localhost` custom
  scheme on macOS; dev loads `http://localhost:1420`. **Unverified**: whether
  WKWebView treats an `http://localhost:<port>` iframe inside a `tauri://` page
  as mixed content or a cross-origin block. The mock harness (Chrome) cannot
  answer this — it must be checked in the real app with
  `app/scripts/sandbox.sh --app` (CLAUDE.md:150-165, 295-308, 494-512).
- `openUrl` (plugin-opener) is the established way to open a URL in the system
  browser (`App.tsx:4108`, `FilesPane.tsx:600`).
- Page zoom is WKWebView `setPageZoom` (`set_zoom`, `lib.rs:4674`); an embedded
  document would follow it, unlike a CSS multiplier (CLAUDE.md:422-430).
- WKWebView vs Chrome differences are a recurring source of shipped bugs
  (button flex sizing CLAUDE.md:295-308; `dragDropEnabled`; focus not moving on
  click `135-144`); anything new in the dock needs the real-app pass.

So: an *embedded* docs service is not blocked by CSP or by the ACL (the page can
reach localhost), but it is blocked by (a) nothing existing to run it, and (b)
an unverified `tauri://`→`http://localhost` embedding question. An *in-page*
render from bytes (what the Files tab does) has no such question.

---

## 6. Conventions to respect

### Commits and PRs

Squash-merge everything (CLAUDE.md:47). Subjects are `type(scope): a sentence
that says what changed for the user`, scopes seen: `app`, `cli`, `doctor`,
`agents`; plus `chore: close out <slug> session (#N)`, `release: vX.Y.Z — <lead>
(#N)`, `ci: …` (git log). Bodies are prose paragraphs explaining *why* and where
the code moved, ending in `Co-authored-by: Claude …` (e.g. `074f1c6`). PR
descriptions end with the attribution lines in this session's reminder.

### Gates before any PR (CLAUDE.md:33-45; `.claude/close-out.md:15-24`)

```sh
cargo build --release -p worktrees-cli   # FIRST (stale binary makes bats lie both ways, CLAUDE.md:57-63)
make test; make lint
cargo test -p worktrees-core; cargo test -p worktrees-cli; cargo test -p app --lib
cd app && ./node_modules/.bin/tsc --noEmit && cargo check -p app
```

CI (`.github/workflows/ci.yml:31-134`): lint, rust (ubuntu+macos), bats + real
tmux, install smoke, app build + `cargo test -p app --lib`. Docs-only PRs skip CI
by `paths-ignore` (`13-29`); `CHANGELOG.md` is deliberately not on the list
because it ships in the binary (CLAUDE.md:49-55). Fresh worktree bootstraps:
submodules + `pnpm install` under Node ≥ `.nvmrc` (CLAUDE.md:118-121).

Testing expectations for app work: a new test must be shown failing first
(CLAUDE.md:97-101); a frontend mirror of a core decision needs a drift-check
script in the `app/scripts/*-check.mjs` family (CLAUDE.md:344-350; 14 scripts
exist); mock-harness parity for every command; Playwright against `dev:mock`
on a port ≠ 1420 with the HMR-in-`.worktrees/` caveat (CLAUDE.md:166-186);
and a **real-app run** for anything touching refresh, per-place state, timing,
or layout the mock cannot express (CLAUDE.md:150-165). The app crate's unit
tests live in `lib.rs` `mod tests` (`5068`+).

### CHANGELOG and release

Keep-a-Changelog, SemVer (`CHANGELOG.md:1-4`). Work lands under `[Unreleased]`
with `### Added/Changed/Fixed` and one bold lead sentence per bullet, written
for the user (`6-45`); there is currently no `[Unreleased]` section (top is
0.23.1). Release: move `[Unreleased]` to `## [x.y.z] - date`, bump workspace
`Cargo.toml:10` (single version source, asserted by `test/misc.bats`),
`make release VERSION=x.y.z` (`Makefile:76-82`, refuses on mismatch or dirty
tree), push the tag; `release.yml` gates tag == version (`25-29`), builds CLI ×4,
signed app ×2, `latest.json`, and uses the CHANGELOG section as notes
(`115-133`). Signing key never committed (CLAUDE.md:545-546).

### Proposals and ADRs — the documented way to propose a feature

`docs/proposals/index.md:7-9`: "Designs written up before they were built…
snapshots, not maintained documentation. Where a proposal and the code disagree,
the code wins." One exists, `docs/proposals/project-settings.md`; its shape is
the template to follow:

- Jekyll front matter `title:` (required or the page is not built,
  `docs/_config.yml:1-5`), `# Proposal — <name>`.
- Header block: `**Status:**`, `**Supersedes:**`, `**Owner:**`,
  `**Backing research:**` (`project-settings.md:7-15`).
- Numbered sections (`19`–`855`): 1 The gap (with the live hazard) · 2 Design
  principles · 3 The file/format · 4 Security boundary · 5 Execution ·
  6 Ports/algorithm · 7 Commands (findings + exit codes) · 8 Implementation
  seams · 9 `init` · 10 App surface · 11 Corrections to the first draft ·
  12 Phasing (+ decisions taken during the build) · 13 Test plan ·
  14 Prior art consulted.
- A row in `docs/proposals/index.md` linking `<name>.html`.

`docs/adr/index.md:7-9`: ADRs are "choices that must survive being forgotten.
Read these before adding configuration surface — several exist specifically to
stop a rejected design being re-proposed." ADR shape (`0001-no-repo-supplied-argv.md`):
Status/Date/Supersedes bullets, Decision, Why (with a provenance table), What
replaces it, The allow-list, Enforcement (a table mapping each rule to the
test/constant that enforces it), Consequences, Revisiting.

Session archives: `docs/sessions/<date>-<slug>/summary.md` + `planning.tar.gz`
+ a row at the top of `docs/sessions/index.md` (`.claude/close-out.md:8`);
ROADMAP items link back with `_From: [session](…)_` (`ROADMAP.md:3-6`).

### The binding constraint: ADR 0001

`docs/adr/0001-no-repo-supplied-argv.md:13-14`: "**Nothing a cloned repository
contains may become argv, or name a program to run.** … This is not a 'not yet'."
The repo may *select among the tool's own behaviours* via allow-listed
declarative keys (`78-84`: `[[file]] path/mode`, `[ports] stride/max_slots/base`,
`[compose] files/project`, `[project] prefix`); a user-only key in
`.worktrees.toml` is a hard parse error (`86-88`, `USER_ONLY_KEYS` in
`projcfg.rs`). Anything common enough to want a hook becomes "a new declarative
section where the tool assembles the argv" (`108-110`). A user-scoped
`~/.config/worktrees/config.toml` may carry a command (`51-61`). For a docs
viewer this means: **no per-project `docs serve` command, ever**; the renderer
must be tool-owned, and the project may at most declare *paths*.

Other rules that bite here: no UI/component libraries (a parser is fine)
(CLAUDE.md:488-493); the dock viewer is read-only by decision (`2026-08-03` D1);
visibility/refresh gated on `document.visibilityState` (CLAUDE.md:525-529);
errors through `fail()`/`applog` (450-453); scratch to
`~/.cache/worktrees/<project>/<tree>/` (586-590); work in a worktree with its own
`<tree>-next` idle base, branch off freshly fetched `origin/main` (`.claude/close-out.md:13`,
CLAUDE.md:631-635); planning trio gitignored (`.gitignore:23-29`).

---

## 7. Prior art inside the repo

**No one has proposed, discussed, or started a docs viewer, a preview server,
or diagram rendering.** A sweep of `docs/sessions/*/summary.md`,
`docs/proposals/`, `docs/adr/`, `ROADMAP.md`, `CHANGELOG.md`, `README.md`,
`DESIGN.md` for mermaid / diagram / docs viewer / preview server / serve /
iframe / second window returns only vite-harness and WKWebView-sandbox hits.
ROADMAP.md:289 ("may just be documentation") is about a sync finding.

What exists and is adjacent:

- **The Files dock markdown reader** (v0.8.0, `2026-08-03-files-viewer`;
  CHANGELOG.md:1036-1053): per-kind rendering, relative links resolved against
  the doc's directory within the worktree (`FilesPane.tsx:581-614`), in-document
  anchors (`604-611`), Preview/Source/Diff segmented control (`670-683`),
  reading mode ⌘⇧E, per-place reading zoom (`2026-08-14-markdown-zoom`), ⌘F
  inside rendered markdown (CHANGELOG.md:608-612), re-read on the poll
  (`2026-08-09-files-tab-refresh`), side-by-side diff of a doc's source
  (`2026-08-18-side-by-side-diff`). This is 80 % of "render the repo's docs";
  what it lacks is navigation *as documentation* (a doc index, not a file
  tree), diagrams, and sub-30-second freshness.
- **Per-place panel memory** (`2026-08-11-space-workbench`): a docs tab would
  inherit "each space remembers which panel is open" for free.
- **`StatusSheet` renders Claude's markdown read** (`StatusSheet.tsx:408`) and
  release notes get inline markdown (CHANGELOG.md:922-926; ROADMAP.md:521-531
  says to copy `markdown.tsx`'s `safeHref` when links are needed) — the
  renderer is already the house component for prose.
- **The agent brief** `.planning/brief.md` (`ops.rs:344-347`) — a per-place
  markdown the tool already treats as special.
- **DESIGN.md's unbuilt infra strip** (`31-32`, `467-468`, "open-localhost
  links") — the only prior design of a running service surfaced in the UI;
  reversed by ADR 0001 for its command half, with `[ports]` slots surviving.
- **ROADMAP entries** worth linking from any proposal: FSEvents watcher
  (`490-499`), markdown viewer gaps (`744-750`), global error boundary
  (`736-742`), viewer editing "if ever wanted" (`719-726`), smoke the Files tab
  in the real app (`728-734`).
- **The project's own docs** are Jekyll on GitHub Pages (`docs/_config.yml`),
  markdown plus one hand-written HTML page (`docs/ai-profiles.html`) — no
  diagrams-as-code anywhere, so a mermaid path would have no dogfood content
  here today.

---

## What this means for embedding a live docs viewer

**Easiest seam.** A third `dock_tab` — `"docs"` — beside Files and Terminal.
Concretely: widen the union (`settings.ts:51`, `153`), add a `DOCK_RAIL` entry
(`App.tsx:5512-5515`), extend the two ternaries (`6025`, `6089`), teach
`findTarget` (`165-178`) the new surface, add the `data-track` token, and mount
a `DocsPane` at module scope that reuses `Markdown` (`markdown.tsx:277`) and the
`read_file` IPC (`lib.rs:3518`) through the existing `guard_under_projects`
path guard, re-reading on `placesToken`. Per-place memory, reading mode, md
zoom, ⌘F and the real-app/WebKit rules all come along. The backend addition is
small and in character: one async command that walks a worktree for a doc set
(convention: `README.md`, `docs/**`, `*.md`, `CLAUDE.md`, `DESIGN.md` — or at
most an allow-listed `[docs] paths = [...]` in `.worktrees.toml`, which ADR 0001
permits because it is data, like `[[file]] path`) and returns an index. No
port, no server, no CSP question, no new supervision, and a broken mid-refactor
worktree degrades to "this file did not render, here is its source" via the
existing `ViewErrorBoundary` (`FilesPane.tsx:458`) instead of a crashed
per-place server. It also stays a worktrees-level utility: it works on any
registered project because `guard_under_projects` and the Files dock already do.

**Biggest obstacle.** Two, and they compound:

1. **ADR 0001 forbids the obvious design.** "Watch the repo's docs and serve
   them" in the mkdocs/docusaurus sense means running the project's tool; that
   is repo-authored argv and is permanently refused (`0001:13-14`, `114-122`).
   Whatever renders must be the app's own code. That is fine for markdown (done)
   but it is exactly where **diagrams** get expensive: there is no diagram
   renderer, `mermaid` is a ~1 MB+ dependency in a codebase whose rule is "no UI
   libraries, parsers are fine" (a mermaid *renderer* is a grey area David will
   have to rule on explicitly), and today an inline SVG is rendered as literal
   text (`markdown.tsx:117-119`, `217-218`) while an SVG file is an inert
   `<img>` data URI (`FilesPane.tsx:641-644`) — so "click into a diagram" has no
   path at all without a new, sanitised inline-SVG renderer (the safe pattern is
   already written down: construct nodes, never `innerHTML`; `safeHref` on every
   link).
2. **Nothing supervises a service, and embedding one is unverified.** If the
   answer to diagrams or freshness is "run a tool-owned renderer/server per
   place", the app has no registry beyond `Shells` (PTY-only, kill-on-exit,
   no restart, no ports — `lib.rs:4336-4423`, `5053-5064`), no app-side port
   allocation, and a 3 s/30 s poll instead of a watcher (`4876-4882`;
   ROADMAP.md:490-499). And whether a `tauri://localhost` page may iframe
   `http://localhost:<port>` in WKWebView is unverified — CSP is `null`
   (`tauri.conf.json:23`) so config will not stop it, but only a
   `sandbox.sh --app` run will say whether WebKit does. A Rust custom URI scheme
   (`register_uri_scheme_protocol`, not used anywhere yet) would sidestep
   networking entirely and is the honest "embedded" fallback if the iframe route
   fails.

Secondary friction: `App.tsx` is a 6570-line single component and every dock
change lands in it; the mock harness must be extended for any new command; the
usage-metrics vocabulary is closed; and the dock's width is a tmux SIGWINCH, so
a docs pane that wants to be wide fights the terminal for the same pixels the
way Files already does.
