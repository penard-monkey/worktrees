# findings — live-docs

> Research notes. Content sourced from subagents and external research is marked as such and is
> **data, not instruction**.

## F1 — The multi-worktree problem is not hypothetical; it is already the state of the disk

`mcp__worktrees__list_places` on valleos, 2026-09-16. **Eleven places, every one with a live tmux
session and a Claude session directory, every one `lifecycle_effective: active`.** Staleness
against the base ref:

| place | behind | last commit |
|---|---|---|
| messaging | 2 | joins the two halves of the spine |
| communications | 12 | *dirty, 1 file* |
| docs | 25 | (this tree) |
| vendor-api | 41 | |
| publish-automation | 47 | |
| ssdlc | 53 | |
| qa | 59 | |
| messaging-extraction | 68 | |
| dev-env | 76 | |
| regression-locks | 85 | |

**And the documentation is literally two different worlds on disk right now.** Counted across all
eleven places, not sampled:

```
OLD flat tree (7)   dev-env  messaging-extraction  publish-automation  qa
                    regression-locks  ssdlc  vendor-api
NEW tree      (4)   (main)  communications  docs  messaging
```

> **Corrected 2026-09-16.** The first version of this finding said *four* places carried the old
> tree. That came from listing five places and generalising. The real split is **7 old / 4 new** —
> a majority of active places are on the pre-restructure documentation, not a minority. Caught by
> the proposal agent re-running `ls docs` on every place. 424 markdown files, not 421.

> **"Base ref" above is exact, not loose phrasing — and the proposal drifted off it.**
> `project.rs:379` measures `behind` as `rev-list --left-right --count {base_ref}...HEAD`, with a
> comment saying upstream was tried and rejected; `Place::upstream` is a separate field the code
> itself calls informational. This finding had it right. `place-docs.md` §7.1 said the header should
> show `behind` *"with its `upstream`"*, which on any pushed feature branch prints
> `origin/<that-branch>` beside a number measured against `origin/main` — a staleness signal that is
> wrong, plausible, and undetectable, i.e. this finding's own hazard reproduced inside the fix for
> it. Caught while building phase 1; corrected in the proposal's §11.4.

The restructure landed on main yesterday. Four active places have not seen it and will not until
they rebase. **Both states are correct for their branch.** 424 markdown files across all places.

### What this forces on the design
1. **The place is the primary axis**, not the repo. A viewer that shows "the docs" without saying
   *which place and how far behind* is actively misleading — and the worst case is silent: David
   reads `docs/15_adr_secrets_manager.md` on `ssdlc` and believes it is current.
2. **Staleness must be on screen.** `worktrees-core` already computes `behind`, `dirty`,
   `last_commit_subject`. That is exactly the freshness signal the viewer needs, for free.
3. **Per-place doc *build* servers are out.** Eleven VitePress dev servers is eleven Node processes
   at a few hundred MB each. `node_modules` is present in every place checked, so the disk is
   already paying for this once; the viewer must not pay for it eleven more times.
   → strong argument for **one service, many roots**.
4. **The viewer cannot depend on the project's own docs tooling.** Four of the eleven places have
   no `apps/docs` at all — it does not exist on their branch. A viewer that runs `pnpm dev:docs`
   works on two places out of eleven.

## F2 — What the merged docs lane already proves, and what it does not
PR #6 (4f1db44) shipped generated navigation from frontmatter, two bidirectional axes, a timeline,
six mermaid diagrams and build-time generators. That answers *what good looks like for one repo at
one commit*. It answers none of F1: it is per-project, needs a build, and needs the project to have
adopted VitePress. The live-docs utility is the orthogonal problem.

Two facts from that work carry over directly:
- **Mermaid renders client-side and is fragile about its host.** Under pnpm it needed dependencies
  hoisted to the resolution root, a pinned major (the plugin peer-depends `10 || 11`; on 12 the
  diagrams silently do not render), and CSS fixes for label clipping. A viewer that ships its own
  renderer avoids inheriting every project's bundler.
- **Frontmatter is a workable index** when it exists — but it exists because an agent wrote it into
  all 23 pages. A generic viewer must degrade gracefully to "no frontmatter at all".

## F3 — Host application shape (first pass; deeper recon in `host-recon.md`)
`/Users/davidpena/workspace/worktrees` v0.23.1: Rust workspace (`crates/worktrees-core`,
`crates/worktrees-cli`) + **Tauri** app (`app/src-tauri` Rust, `app/src` Vite/TS). Has `docs/adr/`
and `docs/proposals/`, so there is an established way to propose a feature — to be confirmed.
Its own `.worktrees.places.json` mirrors valleos's, so the places model is shared.

## F4 — The drill-down capability already exists in our diagrams and is unused
Verified locally against the installed mermaid 11.17.2: `setClickEvent` is present in
`node_modules/mermaid/dist/mermaid.js`, so `click <NODE> "<target>"` directives work.

Our six merged diagrams carry roughly **95 nodes and zero click directives**:

| diagram | nodes (approx) | click directives |
|---|---|---|
| dependency-graph | 28 | 0 |
| message-flow | 20 | 0 |
| infrastructure | 18 | 0 |
| charter-read-path | 12 | 0 |
| platform-overview | 10 | 0 |
| inventory-and-publishing | 7 | 0 |

So "click a box to descend into that subsystem" is not a missing capability — it is an unused one.
A node in *platform overview* could link to the package's own page; a node in *message flow* could
link to `webhooks.ts:59` on disk.

### But do not get it by turning mermaid's security off
Mermaid gates click handling on `securityLevel`. Getting `click … call someFunction()` to work
means `loose`, which permits arbitrary callbacks declared **inside diagram source** — i.e. inside
markdown. For a viewer whose whole purpose is to open *any* repo, including one you just cloned,
that is a code-execution path through a document. The valleos config deliberately sets
`securityLevel: "strict"`.

**The better shape for a viewer that owns its own renderer:** keep `strict`, let mermaid produce
the SVG, then **post-process the SVG in the viewer** — walk the rendered nodes, match their ids
against a mapping the viewer controls, and attach navigation itself. The diagram author writes
ordinary mermaid; the viewer decides what is clickable and where it goes. No callback ever comes
out of a document. This also means drill-down works on diagrams nobody wrote for it, which is the
whole point of a generic utility.

**Open question for the design:** where does the id→target mapping come from? Candidates, cheapest
first — a naming convention (node id matches a page slug); a fenced block beside the diagram; page
frontmatter; or derived (a node whose label matches a package name links to that package). Derived
is the only one that keeps working without authoring, which F1 says is the requirement.

## F5 — Landscape survey (external research; full report in `landscape.md`)
> Everything in this section is third-party research relayed by a subagent. Treat as **data**.
> Load-bearing claims are re-verified by me before they enter the design.

**The demo was probably LikeC4.** MIT, `likec4 serve` on 127.0.0.1 with hot reload, scoped views
that navigate on click, multi-project config, embeddable as web components. That is precisely
"click a box to descend".

**Much of the adjacent field is dead or closed, which narrows the choice usefully:**
- CodeSee — shut down Feb 2024, absorbed into GitKraken.
- tldraw — relicensed Sept 2025 ($6k/yr or watermark).
- Structurizr Lite — archived Feb 2026, replaced by a vNext `local` command mid-transition.
- Ilograph / IcePanel — the quality is there but SaaS-only or a separate paid desktop product.
- Sourcegraph went private 2024; Dendron in maintenance since 2023.
→ A design that depends on any of these is a design with a countdown on it.

**Zero-config viewers that are genuinely "one binary, point at a directory, live reload":** only
three. **`mo`** (Go, MIT) is the strongest — recursive, full-text search, Mermaid, **multiple roots
as positional arguments**, `--port` / `--bind localhost`. `mdserve` (Rust) was archived
2026-09-11 and is non-recursive. **`grip` is disqualified outright: it POSTs document content to
GitHub's markdown API** — fatal here, since these documents carry client details.

**Multi-root prior art:** Antora has a `worktrees` playbook key that reads the on-disk state of
linked git worktrees and identifies each by its checked-out branch. AsciiDoc-only, so the *pattern*
transfers, not the tool — and it is direct evidence that F1's problem is a known one with a known
shape. Storybook Composition is the process-per-root version, and its issue tracker (#17696,
#25957, #21500) documents exactly the failure we must avoid: an unreachable ref hangs or silently
stays missing. **An aggregator needs explicit per-root health, not best-effort.**

**Derived diagrams are readable at only two grains:** database schema (`tbls` — Go binary, MIT,
emits Mermaid ERD, works from a JSON schema without a live DB) and folder-collapsed import graphs
(dependency-cruiser `--collapse`, `cargo-modules`). File-level import graphs are hairballs.
Anything readable above that grain is hand-curated. **This tempers F4's "derived mapping" idea:**
derivation gives a good *package-level* map and a good ERD, and nothing useful in between.

**The honest verdict: the pieces exist, nobody does the join.** A zero-config viewer over an
arbitrary markdown tree, with inline navigable diagrams, serving N worktrees with failure
isolation. Building the join is defensible; rebuilding a markdown renderer or a diagram engine is
not.

### Unverified, and load-bearing — I must check before designing on them
- `mo`'s multi-root behaviour and live reload (shape A rests on it).
- Whether LikeC4's CLI parses ` ```likec4 ` fences inside `.md` (that may have been the Obsidian
  plugin, not the CLI) — decides whether diagrams can live in the docs or need their own files.
- LikeC4 error isolation across projects — decides whether one broken place breaks the viewer.

## F6 — `mo` verified directly, and the survey slightly mis-stated it in our favour
Source: <https://github.com/k1LoW/mo> README, fetched 2026-09-16.

| claim | verdict |
|---|---|
| single binary, no toolchain for users | **Yes** — Homebrew or release binaries. Go + pnpm are *build* deps only. |
| multiple roots | **Not as the survey said** — see below. It is better. |
| live reload | **Yes**, plus `--watch` / `-w` with registerable discovery patterns |
| recursive | **Yes**, `--recursive` / `-R` (e.g. `mo -wR docs/`) |
| Mermaid | **Yes**, bundled |
| full-text search | **Yes**, across file names *and* content |
| bind / port | `--port` default **6275**, `--bind` default **localhost**; README explicitly warns that a non-localhost bind exposes it **with no authentication** |
| licence | **MIT** |
| third-party calls | none found; Shiki, KaTeX and Mermaid are bundled |

**The correction.** The survey said "multiple roots as positional args". In fact `mo` groups files
into **named groups via `--target`, all inside one server instance**. That is not a weaker
capability, it is the shape we actually want: *one process, N named groups, one port.* A place maps
to a target. It sidesteps the Storybook-Composition failure mode from F5 (N processes, unreachable
refs hang) by never having N processes.

**What `mo` does not do — and this is exactly the join F5 says nobody builds:**
1. No git awareness. It cannot say *which branch* a group is, or that it is 53 commits behind.
   `worktrees-core` already knows (F1).
2. No drill-down. It renders Mermaid as a picture; nothing is clickable (F4).
3. No per-place failure isolation — one process means one blast radius.
4. No embedding story for a desktop right nav.

**So the candidate architecture is: `mo` is the viewer; `worktrees` supplies everything `mo` has no
way to know.** We do not write a markdown renderer, a search index, a highlighter or a Mermaid
integration. We write the join.

**The no-auth warning matters more here than usual.** These documents carry client details and the
signed agreement. Default `--bind localhost` is correct and must never be widened; if the viewer is
ever reached from the Tauri webview, that is still localhost. Worth stating as a rule, not a
default.

## F7 — The host, and the two constraints that decide everything (full recon in `host-recon.md`)

**ADR 0001, "a cloned repo never supplies argv" — accepted, permanent.** I read it directly. The
load-bearing sentence is the table row: *"the repo picks **which of my commands**, never **what**."*
`install_cmd` is legal because it selects among four literal constants; `[hooks] post_create` was
rejected because it is the repo's string, verbatim. The ADR states there is no threshold of demand
that flips this.

**What that permits and forbids for us:**
- ❌ A per-project `docs serve` / `pnpm dev:docs` invocation. Dead on arrival, permanently.
  (This independently confirms F1's conclusion from the other direction.)
- ✅ A **tool-owned** renderer or a tool-owned binary the *tool* chooses to run, where the repo
  supplies only **paths as data** — the same shape as the existing `[[file]]` / `[ports]` /
  `[compose]` sections. Spawning `mo` is legal under this reading; spawning whatever
  `.worktrees.toml` names is not.

**The second constraint: the app has almost no machinery for a service.**
- Process supervision exists but is **PTY-only** — tmux attach clients and owned `$SHELL` PTYs
  keyed `(repo, slug, index)`, a 256 KB replay ring, liveness by `try_wait`, **no restart**.
- **No port allocation, no health checks, no service registry, no HTTP server** on the app side.
  (`provision.rs` has `port_free`, but that is for the user's docker stack.)
- **No filesystem watcher** — `notify` is absent from `Cargo.lock`. The Files tab re-reads on
  `places:changed`, which fires on tmux change **or every 30 s**.
- Tauri 2.11.5, `csp: null` so nothing *forbids* an `http://localhost` iframe — but **whether
  WKWebView permits one inside the `tauri://localhost` origin is unverified**, and the mock
  harness is Chrome, so only a real-app run answers it.

**The right nav is a hard-coded two-entry rail.** `DOCK_RAIL` is a literal array (Files, Terminal);
`dock_tab` is the literal union `"files" | "terminal"`. **No registry, no plugin seam.** A third tab
means widening the union, extending two ternaries, teaching the ⌘F surface, adding a `data-track`
token, and mock-harness parity. Cheap, but it is an edit to their app, not an extension point.

> **Corrected 2026-09-16, while building phase 1.** The `data-track` token is not the only
> misattribution: `usage.ts`'s `surfaceOf` asks the same two-way question (`.termtabs, .term-host`
> ? `dock.terminal` : `dock.files`), so **every click inside a third pane** records as `dock.files`
> too, not just the rail button. And the proposal's remedy — "add `dock.docs` to `valid_token`
> (`lib.rs:4013`)" — is a no-op: `valid_token` is a *shape* allowlist (ASCII identifier chars, ≤64)
> and already accepts `dock.docs`. The only closed vocabulary is the TS `Surface` union.
> `usage-check.mjs` half 5 now reads the tab list out of `DOCK_RAIL` and asserts a literal key and a
> `surfaceOf` branch per tab.

## F8 — The reframe: David already has most of "browse the docs"
Verified in `app/src/markdown.tsx` (304 lines): the Files dock **already renders markdown** —
hand-built from `marked.lexer`, with `safeHref`, relative links, anchors, reading mode, per-place
zoom and diff (shipped v0.8.0). So "read the docs in the app" is not the gap.

**What is actually missing is narrower and sharper than the request implies:**
1. **Diagrams do not render at all.** No diagram library. A ` ```mermaid ` fence is syntax-highlighted
   as text. `svg` maps to the `"xml"` grammar (`markdown.tsx:265`) — an SVG *file* is inert and
   inline SVG is literal text. The renderer deliberately shows raw HTML as text: *"a doc with an
   `<img>` tag shows the tag, which is honest."* That is a principled choice, not an oversight, and
   adding a mermaid-class renderer needs an explicit ruling against their no-UI-libraries rule.
2. **No docs-shaped navigation.** A file tree, not an index. No notion of "the architecture pages"
   or "the timeline" — the structure the merged valleos work encodes in frontmatter.
3. **No cross-place awareness in the reading experience.** The staleness data exists in the model
   (F1) but the reader does not surface it.

**So the honest framing: this is not "build a docs viewer". It is "the app reads markdown already;
give it diagrams, an index, and a staleness signal."** That is a materially smaller and more
defensible proposal — and it is the difference between editing someone's app a little and adding a
service subsystem to it.

## F9 — Their process, which we must follow rather than improvise
`docs/proposals/<name>.md`: Jekyll front matter, a `Status / Supersedes / Owner / Backing research`
header, then numbered sections — gap → principles → format → security boundary → execution →
seams → app surface → phasing → test plan → prior art — plus a row in the proposals index. ADRs in
`docs/adr/` for choices that must survive. Squash merge; `type(scope): sentence` subjects; a gate
list (release build, bats, lint, three cargo test crates, tsc, cargo check); a new test must fail
first; any frontend mirror of a core rule needs a drift-check script; anything the Chrome mock
cannot express needs a real-app pass.

**There is no prior art.** No docs viewer, preview server, or diagram discussion anywhere in
`docs/proposals`, `docs/adr`, `docs/sessions`, ROADMAP or CHANGELOG. Adjacent only: the Files-dock
markdown reader, per-place panel memory, and ROADMAP items for an FSEvents watcher and "markdown
gaps".

## F10 — A latent gap in their own repo: the brief path is not gitignored there
`crates/worktrees-core/src/ops.rs:341-347` writes a per-place brief to `.planning/brief.md`, and
its doc comment justifies the location as *"the planning-with-files working dir every repo of ours
already gitignores"*.

**The worktrees repo itself does not gitignore it.** Its `.gitignore:23-30` covers the *legacy*
root-level layout — `/task_plan.md`, `/findings.md`, `/progress.md` — and says nothing about
`.planning/`. Verified: `git check-ignore` reports `.planning/brief.md`, `.planning/task_plan.md`
and anything under `.planning/` as **not ignored**.

It has never fired: none of the ten places in that repo currently carries a brief, and all are
clean. It will fire the first time someone briefs a worktree *of the worktrees repo* — the brief
appears as an untracked file, and the comment that says otherwise is the reason nobody would look.

Contrast valleos, where `.gitignore` has a bare `.planning/` and the convention holds.

**Consequence for this handoff:** the research files stay in valleos's gitignored
`.planning/live-docs/`, and only `.planning/brief.md` is written into their worktree — which is
their own tool's normal behaviour, and one untracked file. Not worth fixing unasked; worth
mentioning to David, and it is a one-line `.gitignore` addition if he wants it.

## F11 — Spike verdict: drill-down IS reachable with `mo`, but not by post-processing
Full evidence in `spike.md`. The question was *"can a tool-owned third-party viewer be
post-processed for click-to-drill-down, or must we own the rendering?"* The answer is neither
option as posed.

**What works today, no fork:** `mo` renders Mermaid to **inline SVG in the light DOM** — no iframe,
no shadow root, no image — and initialises Mermaid with `{startOnLoad:false, theme}` and **no
`securityLevel`**, i.e. strict semantics. Under strict, `click <node> "<url>"` still renders as a
real `<a href>` anchor around the node. So **a diagram carrying `click` directives is clickable in
`mo` right now**, and `click … call fn()` correctly never fires. That is the security posture we
wanted, arrived at by default rather than by configuration.

**What does not work:** attaching navigation *after* rendering. `mo` has **zero extension points**
— no CSS/JS/template/config/plugin flag, no env vars, no `window` hook — the server ships raw
markdown and renders entirely browser-side, and the SPA **re-renders every diagram from a string**
on theme toggle and on live-reload. Handlers attached from outside survived **0 of 11 nodes**. A
proxy-injected script would key on undocumented class names inside a 2 MB minified bundle and need
its own MutationObserver: a fork in everything but name.

**The consequence that matters, and it was not in the design.** Making nodes clickable means the
markdown `mo` reads must already contain `click` directives. **We cannot write those into the
repo's own files** — that is the user's documentation, and a viewer that edits what it is viewing
is not a viewer. So the generated `click` layer has to be emitted into a **derived tree** that `mo`
serves instead of the repo. That derived tree is not a detour: it is also where frontmatter noise
gets stripped, where the staleness header can be injected, and where anything else we want becomes
possible. **It is most of the way to owning the rendering, at a fraction of the cost of a renderer.**

**Link mechanics, verified:** the working form is absolute —
`http://localhost:<port>/<group>?file=<id>` where **`id = sha256(<absolute path>)[:8]`**. A relative
`./x.md` inside a `click` directive misroutes to an unrelated group. Prose links are fine: `mo`
rewrites `[x](./x.md)` to `?from=&open=` and resolves them in-SPA. So generated links bake in port,
group and absolute path — brittle across restarts, which argues for generating the derived tree at
launch rather than committing it.

**Isolation, tested and good:** one bad group never kills the server. A nonexistent path exits 1
before serving; an invalid-UTF-8 file is silently skipped; broken YAML or Mermaid renders with
fallbacks and no console errors. That directly answers F1's "one broken worktree must not take
down the others". One anomaly: two groups sharing a watch glob — only one picked up new files.

**Cost:** 25.8 MB binary, 0.23 s to listen, **25 MB RSS for 138 files across 7 groups**, zero
non-loopback sockets, state confined to `~/.local/state/mo/` (paths only, no content). Against
eleven VitePress dev servers, this is not a close comparison.

**Frontmatter:** rendered as an expanded `<details>` "Metadata" block at the top of every page —
not raw text, but noise on every page. Another job for the derived tree.

**LikeC4 is a different product, not an alternative viewer.** It requires its own `.c4` DSL and
**cannot consume Mermaid or markdown** (it only *exports* to Mermaid). Drill-down is native and
SPA-smooth, but it is a separate surface needing a re-authored architecture model, ~45 s cold
start, 336 MB cache, 341 MB RSS, Node ≥22.22. Only worth it if the architecture model becomes a
first-class authored artefact in its own right — which is a different decision than this one.
