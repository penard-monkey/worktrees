# Spike: can `mo` give us click-to-drill-down diagrams, or must we own the rendering?

Run 2026-09-16, `mo` v1.6.8 (darwin_arm64 release binary, checksum verified), LikeC4 1.59.3 via `npx`.
Everything ran on `localhost`, from a scratch directory, and was removed afterwards (see the last section).

## The verdict

**Yes, with one specific mechanism, and no with the one the question assumed.** `mo` renders Mermaid to *inline SVG in the light DOM* and honours Mermaid `click <node> "<url>"` directives as real `<a href>` anchors around the node, so a diagram *author* (or a generator that rewrites the markdown before `mo` reads it) gets working click-to-navigate today, without forking. But "post-process the rendered SVG" is **not** achievable: `mo` exposes no CSS/JS/template/config/plugin hook of any kind, the SPA re-renders every diagram from a string on theme change and on live-reload (which drops anything attached from outside), and the server only ever serves raw markdown (the browser does all rendering). If drill-down must be attached *after* rendering, or must be SPA-smooth, we own the rendering (or use LikeC4, which does it natively but only from its own DSL).

## What was observed versus what was inferred

Every statement below is tagged **[observed]** (I saw it in a tool result) or **[inferred]** (my reading of code/docs/behaviour). Inconclusive points are marked as such.

---

## Test 1. Drill-down

### Setup

```
mo --foreground --no-open -p 6299 -t arch -R /Users/davidpena/workspace/valleos/docs/architecture/
mo --no-open -p 6299 -t plain <scratch>/fx/plain/     # click.md + second.md, no frontmatter
```

`click.md` (scratch fixture, not in the repo) contained two flowcharts with five `click` directives: absolute URL, `href ... _blank`, `call myCallback()`, relative `./second.md`, and mo's own `/plain?from=<id>&open=./second.md` form.

### How mo renders Mermaid

- **[observed]** The SPA bundle (`/assets/index-C5Ozrl5j.js`, 2.19 MB) initialises Mermaid as
  `ZY.initialize({startOnLoad:!1,theme:bX()})` — **no `securityLevel` is set**, so Mermaid's default `strict` applies **[inferred from Mermaid docs]**. The render result is kept as a string in React state and injected with `dangerouslySetInnerHTML` into `<div class="overflow-x-auto">` inside `<article class="markdown-body">`.
- **[observed]** In the browser: 2 `<svg aria-roledescription="flowchart-v2">` elements, `iframes: 0`, `shadowHosts: 0`, `imgs: []`, `window.mermaid: undefined`. Inline SVG in the light DOM, no shadow root, no iframe, no image.
- **[observed]** Node ids are deterministic: `mermaid-1-flowchart-A-0`, `mermaid-2-flowchart-X-0`. The counter prefix (`mermaid-N`) increments on every re-render, so selectors on `#mermaid-1` go stale after a live-reload (I hit this).
- **[observed]** A `MutationObserver` on `data-theme` re-runs the render; toggling the theme replaced all 11 `g.node` elements of `platform-overview.md` — handlers attached from outside survived **0 of 11**. Live-reload (SSE `/_/events`) does the same.

### Do `click` directives do anything?

| directive | rendered as | on click |
|---|---|---|
| `click A "http://localhost:6299/plain?file=07184939"` | `<a href=...>` wrapping `g.node`, class `clickable`, cursor `pointer` | **full-page navigation** to second.md (JS context destroyed, `performance` shows a new `navigate` entry) **[observed]** |
| `click B href "https://example.invalid/b" _blank` | `<a href="https://example.invalid/b">` (no `target` attribute survived) | not clicked (external) |
| `click C call myCallback()` | `clickable` class, cursor pointer, **no anchor** | `window.myCallback` never called **[observed]** — consistent with `strict` |
| `click X "./second.md"` | `<a href="./second.md">` verbatim | navigated to **`/arch?file=129895ee`**, a file in a *different group* — the browser resolves `./second.md` against `/plain`, hits the SPA catch-all and mo falls through to something unrelated **[observed]**; not usable |
| `click Y "/plain?from=05878b0b&open=./second.md"` | `<a href="/plain?from=...&open=./second.md">` | synthetic click did nothing (**inconclusive**; may be the synthetic event on a root-relative SVG anchor). A direct full navigation to that URL **does** resolve to `?file=07184939` **[observed]** |

So the mechanism that works is: an **absolute** `http://localhost:<port>/<group>?file=<id>` URL in a `click` directive, where `id = sha256(absolute path)[:8]` — verified: `sha256("/private/tmp/.../fx/plain/click.md")[:8] == "05878b0b"` **[observed]**. Ids are stable across restarts and identical when the same path is in two groups **[observed]**.

### Extension points

- **[observed]** `mo --help` and README list no `--css`, `--js`, theme dir, template, config file or plugin flag. Flags are exactly: bind, clear, close, dangerously-allow-remote-access, foreground, json, no-open, open, port, recursive, restart, shutdown, status, target, unwatch, version, watch.
- **[observed]** No `MO_*` environment variables in the binary strings; no `window.*` hook in the bundle.
- **[observed]** The server API is `/_/api/groups`, `/_/api/groups/<g>/files/<id>/content` (returns `{"content": "<raw markdown>", "baseDir": ...}`), `/_/api/search`, `/_/api/version`, `/_/api/restart`, SSE at `/_/events`. The server never renders; there is no server-side SVG to post-process.

### Could a wrapper attach click navigation without forking mo?

- **Rewriting the markdown** (a generator step that injects `click N "http://localhost:PORT/group?file=<sha256[:8]>"` before mo reads the file): **yes, works today [observed]**, with two costs — the links are full-page loads, and the URL bakes in the port, the group name and an absolute-path hash, so the same doc in two worktrees needs two different link sets (a generated copy per worktree, or a redirecting proxy).
- **Post-processing the DOM** (a reverse proxy injecting a script into the SPA shell that attaches handlers to `g.node`): technically possible — I attached handlers from the console and they fired on every node **[observed]** — but they are destroyed on every theme toggle and live-reload **[observed]**, so the injector would need its own MutationObserver, and it depends on undocumented class names (`article.markdown-body`, `g.node`, `mermaid-N-flowchart-X-i`) in a 2 MB minified bundle. This is a fork in everything but name. **No, not as a supported path.**

---

## Test 2. Multi-place behaviour

### Invocation that worked

```
mo --foreground --no-open -p 6299 -t arch -R /Users/davidpena/workspace/valleos/docs/architecture/
mo --no-open -p 6299 -t main      -wR /Users/davidpena/workspace/valleos/docs/
mo --no-open -p 6299 -t messaging -wR /Users/davidpena/workspace/valleos/.worktrees/messaging/docs/
mo --no-open -p 6299 -t ssdlc     -wR /Users/davidpena/workspace/valleos/.worktrees/ssdlc/docs/
mo --no-open -p 6299 -t qa        -wR /Users/davidpena/workspace/valleos/.worktrees/qa/docs/
```

`mo --status -p 6299` **[observed]**:

```
http://localhost:6299 (pid 89431, 1.6.8 bc105cb)
  main: 45 file(s)       watching: /Users/davidpena/workspace/valleos/docs/**/*.md
  messaging: 43 file(s)  watching: .../.worktrees/messaging/docs/**/*.md
  ssdlc: 23 file(s)      watching: .../.worktrees/ssdlc/docs/**/*.md
  qa: 17 file(s)         watching: .../.worktrees/qa/docs/**/*.md
  arch: 7 file(s)
```

Note the first invocation must be `--foreground` under `nohup` (or accept mo daemonising itself); later invocations on the same port just add groups and return.

- **Distinguishable in the UI?** **[observed]** A header button shows the current group name and opens a list of group names (`arch, bad, main, messaging, plain, qa, ssdlc`); each group has its own URL path and sidebar; sidebar entries carry the absolute path as a tooltip. Files with identical names in `ssdlc` and `qa` are distinguishable **only** by which group you are in and by that tooltip — nothing shows a branch name or diff state.
- **Live-reload per group:** **[observed]** on the `plain` group, editing `click.md` re-rendered the open page within ~1 s (SSE). **[observed]** on a `-w` group in scratch, a newly created `w3.md` appeared in the group within 1.5 s. I did **not** edit files under the repos (read-only rule), so live-reload on the four repo groups is **[inferred]** from the per-file kqueue watches (`lsof` showed 135 open `.md` read fds and 187 `KQUEUE` entries covering them).
- **Anomaly [observed]:** two groups registered with the *same* watch pattern (`watch`, `watch2`): the new file appeared in `watch` but not in `watch2`. Duplicate patterns across groups are unreliable.
- **Nonexistent path:** `mo -t ghost /Users/davidpena/does-not-exist/docs/` → `Error: file not found: ...`, exit 1, prints usage. The server kept running; no group created **[observed]**.
- **Malformed file:** a file with **invalid UTF-8** was silently skipped (`added 0 item(s)`, exit 0, no log line) **[observed]**. A UTF-8-valid file with broken YAML frontmatter and broken Mermaid was accepted and rendered: the bad YAML shows inside the Metadata block as text, the broken Mermaid falls back to a `<pre><code>` of the source; **no console errors, nothing else affected** **[observed]**.
- **One bad group degrades, never kills:** all of the above happened on a server that was concurrently serving the four repo groups; nothing else changed **[observed]**.

---

## Test 3. Zero-config fidelity

- **Plain markdown, no frontmatter, no config:** `plain` group rendered headings, task lists, tables and both diagrams correctly, no console messages **[observed]**.
- **Frontmatter (valleos docs, 38 of 45 files):** rendered as a **`<details open>` "Metadata" block** at the top of the article, syntax-highlighted YAML, above the H1 — not raw `---` text **[observed]**, but it is *expanded by default* and occupies the first ~250 px of every page (screenshot taken on `platform-overview.md`).
- **Fidelity bug [observed]:** `docs/.generated/acai-sections.md` starts with a multi-line HTML comment that contains backticks. `mo` rendered the tail of the comment as visible text: `; starts at h3 and carries no frontmatter. -->`. On a second load of the same file the leak was not visible (the article had no such text), so this is **inconclusive as to trigger**, but it did happen once on first render.
- **Relative `.md` links between docs [observed]:** `mo` rewrites `[Platform overview](./platform-overview.md)` to `/main?from=1f033a42&open=.%2Fplatform-overview.md` and resolves it in the SPA (no reload, JS state preserved) to `?file=f20471f0`. Cross-doc navigation in prose works zero-config, portably per group.
- **[observed]** The architecture diagrams' `%%{init: ... fontFamily: "IBM Plex Sans"}%%` did not take effect (computed font was the system stack) — the font is not installed on this machine, so this is not a mo defect; `theme: base` colours and clusters rendered as authored (11 nodes, 3 clusters, 13 edges on `platform-overview.md`).

---

## Test 4. Cost and shape

| metric | value |
|---|---|
| binary | 25,788,530 bytes (25.8 MB) unpacked; 8.1 MB zip **[observed]** |
| startup to listening | 0.232 s with 7 files **[observed]** |
| RSS | 25.4 MB with 138 files in 7 groups; 25.1 MB after 5 minutes and 5 tabs (SSE connections: 6) **[observed]** |
| open fds | `lsof` 2,227 lines: 1,887 `DIR` (every directory in every watched path chain), 187 `KQUEUE`, 140 `REG` (one per watched `.md`) **[observed]**. Scales linearly with file count; macOS launchd `maxfiles` soft limit is 256 but the process evidently raises it — **[inferred]** risk only for very large trees |
| state on disk | `~/.local/state/mo/backup/mo-<port>.json` (mode 0600; keys `groups` = absolute paths per group, `patterns`; **no file content**) and `~/.local/state/mo/log/mo-<port>.log` (JSON lines: add/remove events with paths; no content) **[observed]**. Created by the very first `mo --status` call, before any server ran. `XDG_STATE_HOME` is honoured **[inferred from binary strings]** |
| other writes | nothing else under `~`, nothing in the served directories **[observed]** (`find ~ -newer`, `lsof` regular files) |
| network | only `127.0.0.1:6299 LISTEN` plus loopback client connections; zero non-loopback sockets across the whole run **[observed]** |
| session restore | after `--shutdown`, a bare `mo --foreground -p 6299` restored all 9 groups (148 files, 6 patterns) **[observed]**. `--clear` asks `[Y/n]` interactively and cancels without a TTY **[observed]** |

Privacy note **[observed]**: the session file and log hold absolute paths (e.g. `.../governance/acuerdo-colaboracion-confidencialidad.md`), not content. Anyone on a non-localhost bind could read every file the user can, per mo's own warning; we never left `localhost`.

---

## Test 5. LikeC4 (since mo fails the "post-process the SVG" form of the question)

Run: `npx --yes likec4@1.59.3 serve --port 6399 --listen 127.0.0.1` from a scratch project, with `npm_config_cache` pointed into scratch so nothing landed in `~/.npm`.

- **Cost [observed]:** ~45 s cold start (download + Vite build); npm cache grew to **336 MB** (128 MB of it the npx install tree; 17 direct deps incl. `vite`, `esbuild`, `playwright`, `@hpcc-js/wasm-graphviz`); server RSS **341 MB** vs mo's 25 MB; requires Node >= 22.22.3 (David has v26.8.1). Package itself is 11.6 MB unpacked, MIT.
- **Own DSL required [observed from docs, `/dsl/intro/`]:** it "recursively searches for `*.c4` and `*.likec4` files"; model and views must be authored in the DSL. There is **no** import from Mermaid, PlantUML or markdown fences; the only Mermaid relationship is *export* (`likec4 gen mmd`, and the dev server logs `generating likec4:mmd`). So it **cannot consume the six diagrams in `docs/architecture/`**; they would be re-authored as a model plus views.
- **Drill-down is native [observed]:** on `/view/index/`, the `valleos` node had cursor `pointer` and a navigate affordance; clicking it moved the SPA to `/view/valleos/` with JS state preserved (marker survived) and rendered the child containers. Docs: a scoped view becomes an element's default, "on click navigates to 'view1'".
- **Hot reload [observed]:** editing `model.c4` (`title 'Inside ValleOS' → 'Inside ValleOS (edited for HMR)'`) updated the open view's header in place, no navigation.
- **Coexistence with a markdown viewer [observed from docs]:** it is a **separate surface** (its own React/react-flow app at its own port). Embedding into markdown exists only through build-time integrations: the Vite plugin (`likec4:react` virtual modules; Astro/Starlight documented, Next via a library-mode workaround), React components (`LikeC4View`, `ReactLikeC4` with `onNavigateTo`), a web component, and a community MkDocs plugin (` ```likec4-view <id>` fences; needs Python + likec4 + graphviz; maintained by doubleslash.de). None of those plug into `mo`; they plug into a site *we* build.
- **Network/side effects [observed]:** only loopback sockets (6399 and HMR 24678); nothing written into the project dir or home.

---

## What this means for the design

1. **`mo` is a good zero-config *reader* and a poor *platform*.** It renders our docs faithfully (frontmatter handled, cross-doc links resolved, diagrams as real SVG), costs 25 MB / 25 MB RSS / 0.2 s, phones nowhere and serves multiple worktrees as named groups. It offers no surface to build on: no hooks, browser-side rendering only, re-render-on-anything.
2. **If "drill-down" means "a diagram node links to another doc", we can ship that with `mo` today** by writing `click` directives with absolute `http://localhost:PORT/<group>?file=<sha256(path)[:8]>` URLs. This is deterministic and generatable, but it is a full page load per click, it bakes port + group + absolute path into the markdown (so it belongs in a generated layer, not in the hand-written source), and it does not survive a move to another host without regeneration.
3. **If "drill-down" means anything richer** — hover, in-place expand, same-page zoom, node → view rather than node → file, or attaching navigation *after* the fact to diagrams the authors did not annotate — **we must own the rendering.** The cheapest ownership is not a fork of `mo`: it is a small static generator (Mermaid CLI or `mermaid.render` in Node → SVG → post-process anchors → HTML) that we serve with anything, which incidentally removes the per-worktree URL problem because relative links work in static HTML.
4. **LikeC4 answers a different question.** It gives native, SPA-smooth drill-down and HMR, but only from its own DSL, at ~13x the memory and a Node toolchain, and as a separate surface from the markdown. It is the right tool if we decide the architecture model is a first-class artefact worth re-authoring; it is the wrong tool for "any repo, zero config".
5. **Multi-worktree with `mo`:** works, but group names are the only signal of *which* tree you are in, and duplicate watch patterns across groups misbehave. A wrapper that names groups after branches and never registers the same glob twice is enough.
6. **Small hygiene items if we adopt `mo`:** invoke with `--foreground` under our own supervision (it daemonises otherwise), pin `-p` per purpose, expect `~/.local/state/mo/` to appear on first use, expect invalid-UTF-8 files to vanish silently, and expect the Metadata block open at the top of every page.

---

## What I could not test, and why

- **Live-reload on the four repo groups themselves** — the read-only rule forbade editing files under `valleos/` or its worktrees; verified on scratch groups only, and inferred for the repo groups from the per-file kqueue watches.
- **The root-relative `click Y "/plain?from=…&open=…"` anchor** — a synthetic click did nothing, while a direct navigation to the same URL worked. Inconclusive whether a real pointer click would navigate; absolute URLs are the proven path.
- **The HTML-comment leak** on `acai-sections.md` — seen once on first render, not on a second load; I could not isolate the trigger without editing repo files.
- **Mermaid version bundled in `mo`** — the minified bundle did not expose a version string my greps could find; only the behaviour (`strict` semantics: href links yes, callbacks no) is established.
- **A one-off navigation entry** to `/plain?file=x` appeared in the first tab's `performance` log before I clicked anything; it did not recur on a fresh load. Unexplained; most likely a browser-side artefact, not a `mo` behaviour.
- **`--clear`** could not be exercised because it prompts interactively; the state dir was removed by hand instead.
- **LikeC4 embedding into markdown** was read from the docs, not run — running the Vite plugin or MkDocs plugin means building a site, which is beyond "does it coexist".

## Cleanup performed

- Killed: `mo` server (pid 89431, then restart pid 58043), `likec4 serve` (npx pid 38016, node pid 41494). Verified zero listeners on 6299 / 6399 / 24678 and zero matching processes.
- Removed: `~/.local/state/mo/` (did not exist before this spike; created by the first `mo --status`), the scratch `mo` binary, fixtures, the 336 MB npm cache and the LikeC4 project — all under the session scratchpad.
- Closed all five test tabs in the isolated browser context.
- `git status --porcelain` is empty in `valleos`, `messaging`, `ssdlc`, `qa` and `docs` worktrees. Nothing under the repos was created, modified or committed; the only file written is this one.
- Nothing left behind that I know of. `~/.npm/_npx` was untouched (cache redirected to scratch).
