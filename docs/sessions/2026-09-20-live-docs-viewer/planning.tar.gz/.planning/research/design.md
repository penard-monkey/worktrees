# live-docs — the design, and the fork David has to settle

Derived from F1–F9 in `findings.md`. Nothing here is built.

## What the problem actually is

Not "build a docs viewer". The worktrees app **already renders markdown** in its Files dock (F8).
Three things are missing, and they are what "alive" and "see rather than hunt" mean:

1. **Diagrams do not render at all** — a mermaid fence is highlighted as text, SVG is inert.
2. **No docs-shaped index** — a file tree, not "the architecture pages" / "the timeline".
3. **No staleness signal while reading** — the data exists (`behind`, `dirty`, `last_commit`) and
   the reader never shows it, so `ssdlc`'s 53-commits-behind ADR reads as current (F1).

## Two constraints that remove most of the option space

- **ADR 0001 is permanent:** a cloned repo never supplies argv. So no per-project `docs serve`.
  The renderer must be **tool-owned**; a repo may supply **paths as data** only.
- **The app has no service machinery:** PTY supervision only, no ports, no health checks, no
  watcher (`notify` absent), 30 s poll. And the right nav is a hard-coded two-entry rail, not a
  plugin seam.

## The fork

### Path A — native dock tab
A third `dock_tab: "docs"`. Reads bytes through the existing `read_file` + `guard_under_projects`
pipeline, renders with the existing `Markdown` component, adds an index and a staleness header.

- **For:** no port, no server, no iframe question, no supervision to build. Per-file failure
  isolation for free — a broken file is a broken card, and F1's eleven places cost nothing because
  nothing is running per place. Fits ADR 0001 exactly. Automatically a worktrees-level utility.
- **Against:** **diagrams need a renderer added to their app**, which needs an explicit ruling
  against their no-UI-libraries rule. Mermaid is ~2–3 MB and is the single biggest dependency the
  app would take. No full-text search unless written. Reimplements things `mo` already has.

### Path B — tool-owned service
`worktrees` spawns a tool-owned binary (`mo`, F6) with one `--target` group per place, and the app
embeds it.

- **For:** diagrams, search, live reload and syntax highlighting arrive free and maintained. One
  process for all eleven places. ADR-0001-legal, because the *tool* chooses the binary.
- **Against:** needs port allocation, health checks and supervision the app does not have (F7);
  one process means one blast radius; and the embed is **unverified** — WKWebView may refuse an
  `http://localhost` iframe inside `tauri://localhost`, answerable only by a real-app run.
  It is a service subsystem added to an app that has deliberately never had one.

### Path C — native index, browser viewer  ← my recommendation
The dock tab is **not a reader**. It is an index: the docs tree for this place, its staleness
header, search-by-name, and one button. Reading long documents and looking at diagrams happens in
the **user's real browser**, served by the tool-owned viewer.

- **For:** kills the iframe question entirely — `openUrl` already exists and is already permitted.
  No new UI library in their app, so no ruling needed. The heavy rendering happens where a real
  renderer already lives. Documentation on a second monitor while the app stays a control surface,
  which matches how David actually works (11 tmux sessions at once). Smallest possible edit to
  someone else's app.
- **Against:** two surfaces instead of one; the browser is not "in the right nav" as literally
  requested; still needs the service lifecycle, though only one instance for the whole app rather
  than one per place.

## The drill-down, in any path

Keep mermaid `securityLevel: strict`, render to SVG, then **post-process the SVG in the viewer**:
walk node ids, match against a mapping the viewer owns, attach navigation. Never turn on `loose` —
that permits callbacks declared inside a document, and this tool opens repos you just cloned (F4).

Mapping source, cheapest first: naming convention → sidecar block → frontmatter → **derived**.
Derived is the only one that works with zero authoring, but F5 tempers it: derivation is readable
at exactly two grains — **package-level graphs** and **database ERDs**. In between is a hairball.
Our six merged diagrams already carry ~95 nodes and zero click directives, so the capability is
sitting unused (F4).

## What I would ask David to decide

1. **Path A, B or C.**
2. **Is "in the right nav" a hard requirement**, or is "one keystroke from the app" enough? This
   single answer collapses the fork.
3. **Scope:** the valleos docs specifically, or a pattern for every project from day one? He said
   the latter; it is worth confirming, because it is the difference between a feature and a
   subsystem.
4. **Do we approach it as a proposal in their repo** (`docs/proposals/`, F9) — which is their
   documented process and the honest way in — or prototype first and propose after?
