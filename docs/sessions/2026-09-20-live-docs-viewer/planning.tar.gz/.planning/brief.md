# live-docs — per-place documentation for the worktrees app

You own this lane. A proposal is already drafted and waiting for you; your job is to take it the
rest of the way, not to start over.

## Read first, in this order

1. **`docs/proposals/place-docs.md`** — the proposal, 660 lines, uncommitted. This is the artefact.
2. **`.planning/research/findings.md`** — F1–F11, the evidence the proposal rests on. Gitignored.
3. **`.planning/research/spike.md`** — an executed spike against the viewer, with observed output.
4. `.planning/research/host-recon.md` — 656 lines of `file:line` recon on this app at `29671fc`.
5. `.planning/research/design.md` and `landscape.md` — how the three-way fork was decided, and the
   external tooling survey behind it.

`CLAUDE.md` and **`docs/adr/0001-no-repo-supplied-argv.md`** are binding. Read the ADR before you
form an opinion about the architecture; it is the reason the architecture is what it is.

## What this is

A **Docs tab** in the app's right rail, per place. Not a reader — the Files dock already renders
markdown (`app/src/markdown.tsx`, shipped v0.8.0). An **index**: the doc tree for the selected
place, a **staleness header**, a name filter, and a way through to a full viewer in the browser.

**The problem it solves, in one number:** valleos has eleven active places, and **seven of them are
on the pre-restructure `docs/` tree** while four are on the new one. Both are correct for their
branch. A reader that does not say *which place, how far behind* lets someone read a 53-commits-old
ADR as current and never notice. That is the hazard; diagrams are a feature, the header is a
correction.

## Decisions already taken — do not re-litigate without new evidence

| Decision | Why |
|---|---|
| **Path C** — native index in the dock, viewer in the browser | no new UI library in this app, no `tauri://`→`http://localhost` iframe question, smallest edit |
| **Zero config** — must work on a repo with nothing but markdown | four of eleven places have no `apps/docs` at all; it does not exist on their branch |
| **ADR 0001 derives the architecture** | a per-project `docs serve` is `[hooks]` wearing a docs badge. Permanently dead. Paths are data; the tool assembles argv |
| **`mo` serving a *derived* tree** (A′, §5.2) | post-processing its SVG is impossible — 0 of 11 handlers survive its re-render — but generated `click` directives work today under strict semantics |
| **`securityLevel: strict`, always** | `loose` permits callbacks declared inside a document, and this tool opens repos you cloned seconds ago |

## State of play

- Branch `live-docs` off `origin/main` @ `29671fc`. One commit already on it: `eea0fad`,
  gitignoring `.planning/` — unrelated to the proposal and **probably wants its own PR**, since
  this repo squash-merges.
- `docs/proposals/place-docs.md` is **untracked**; `docs/proposals/index.md` is modified with its
  index row. Nothing else is touched. **Nothing has been committed for the proposal, deliberately
  — David reads it first.**

## Your job, in order

1. **Read the proposal and argue with it.** It was written to be pushed back on. §5.2 and §5.3
   changed late, after the spike; check they still cohere with §8's phasing.
2. **Close the five open questions** marked in the text (§3.1/§7.3 brief-in-index, §7.3 the
   `(main)` strip, §4.3 URL token as hard requirement, §7.1 `behind` against upstream vs base ref,
   and §5.2's remaining cost — a Go binary in a Rust release pipeline).
3. **Verify what the drafting agent could not**, all listed at the end of §6 and §9: whether
   `FilesPane` (`FilesPane.tsx:822`) accepts an externally-supplied path; whether `toggleDock`
   (`App.tsx:4856`) or ⌘⇧T cycles tabs or only toggles; whether `openUrl` to loopback `http:`
   behaves like the existing `https:` calls in WKWebView.
4. **Then, and only then, phase 1.** The Docs tab with a staleness header and a name filter. No
   viewer, no process, no dependency, no config. It is shippable alone and it is the part that
   fixes the hazard.

## House rules that will catch you out

- `type(scope): sentence` subjects, prose bodies, `Co-authored-by: Claude <model>
  <noreply@anthropic.com>` — **lowercase, no session trailer.** Match the log, not your defaults.
- A new test **must fail first**. Any frontend mirror of a core rule needs a drift-check script.
  Anything the Chrome mock cannot express needs a `sandbox.sh --app` pass.
- `.gitignore` is **not** in CI's `paths-ignore`, so a change to it runs the full suite.
- `crates/worktrees-core/src/projcfg.rs` contains a non-UTF-8 byte: plain `grep` silently returns
  nothing on it. Use `grep -a`.
- `App.tsx:6187` hard-codes `data-track={d.key === "terminal" ? "dock.terminal" : "dock.files"}` —
  a third tab reports as `dock.files` unless you fix it. There is a red-first test for it in §9.

## Boundaries

Nothing is committed to `main`. The proposal is David's to approve before it becomes a PR. If the
audit of your own work contradicts something in `findings.md`, correct the finding and say so —
the count in F1 was wrong once already (four, when it was seven) and was corrected rather than
quietly patched.
