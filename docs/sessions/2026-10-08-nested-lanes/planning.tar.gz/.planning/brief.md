# Brief: DESIGN — lanes that own lanes (nested places / sub-orchestrators)

INVESTIGATION + DESIGN only. Deliverable: `docs/proposals/nested-lanes.md` (shape like the other
files in `docs/proposals/`, add a row to `docs/proposals/index.md`), opened as a docs-only PR. Do NOT
implement. When the PR is up, use the worktrees MCP `report` tool to tell `(main)` the PR number, your
recommendation in a few lines, and the decisions you need from David. Do not merge anything.

## David's idea, in his words (paraphrased)
Today `(main)`'s agent is the orchestrator: it spins up lanes off `origin/main`, reviews and merges
them. He wants any lane to be able to become a hub for a long-planned feature: a place on its own
long-lived branch (e.g. an "experimental"/"development" branch) whose agent spins up its OWN child
lanes off that branch; children merge back into the hub; the hub can run its own "dev" build
(its own Docker stack or local app) separately from main; eventually the hub goes to main. The
navigation becomes a tree: project → hub → its child lanes. "Orchestrator" is not a required name.

## Already decided by David
- **Close-out runs at both levels**: each child closes out into the hub; the hub closes out into main.
- **"Place" and "lane" become synonyms in the app** — pick one user-facing word and say how the
  rename lands (UI strings, MCP tool descriptions, CLI help, docs, AGENTS.md); `place` may stay as the
  internal/API identifier. Recommend which word and the migration.
- **One tmux server per project** is wanted (design it here as a dependency; see §tmux below).
- The app stays read-only toward GitHub (docs/proposals/pull-requests.md §10).

## Questions the proposal must answer — with evidence from the code, not guesses
1. **Data model.** Where a place's parent is recorded (declared state `.worktrees.places.json`, see
   `store.rs`, vs derived from git). What `worktrees new` needs (`--parent <slug>` / base branch =
   parent's branch; today every lane bases off `origin/main` — `ops.rs` ~501/812). Depth: recommend a
   cap (orchestrator's suggestion: main → hub → children, no deeper) and enforce it where?
2. **Git flow.** Children branch off the hub branch; their PRs target the hub branch (must be pushed).
   Squash vs merge commits into the hub, and what the hub's final PR to main looks like. How main
   moving underneath is handled (hub merges/rebases main; children rebase onto hub) — survey how
   Graphite, git-town, `gh stack`/stacked PRs solve it and pick one. What breaks today: merged-PR
   detection assumes main (`github.rs` mapping from #455, close-out's "did it land" checks,
   `health`/`maybe_merged`), `remove_place --branch` (`-d` vs `-D`, AGENTS.md "force is two
   permissions"), the `-next` idle-base convention.
3. **The hub's agent.** It orchestrates like `(main)` but SCOPED: may create/merge/close its own
   children; must not merge to main, release, or touch siblings. How MCP enforces scope server-side
   (`create_worktree` needs a parent/base; mutations limited to the caller's subtree — the server
   already knows its own place). Messaging: Claude↔Claude uses Claude's own bus (`/tmp/cc-socks`
   sockets, independent of tmux); cross-provider uses the MCP message log in the git common dir
   (`messages.rs`). Confirm neither depends on tmux, and list what DOES (pane capture for Codex/pi
   activity in `activity.rs`, MCP `send` = send-keys, `place_status`, the app's terminals).
4. **Running a hub's own build/stack.** `.worktrees.toml` already has `[ports]` + `[compose]`
   (`provision.rs`: per-place slot, `.worktree.env`, compose project name) — read
   `docs/proposals/project-settings.md` and ADR 0001 (`docs/adr/0001-no-repo-supplied-argv.md`: a
   cloned repo never supplies argv; no `[infra] up`). Say what already works for a hub as-is, what a
   hub needs beyond a slot (e.g. a separately-identified app build like `app/scripts/sandbox.sh --app`
   does), and keep every "run this" in user-only config.
5. **Navigation/UI.** Tree in the nav (collapse, indentation, drag rules — `dnd.ts::predictTier` mirrors
   `store::reconcile`, keep it in sync), roll-up of activity dots / unread / PR attention onto a
   collapsed hub, ⌘N "new lane here" (child of the selected hub), nav history, the header. ASCII
   mockups. Follow the app's rules in AGENTS.md (no UI libs, tokens, dots not coloured text).
6. **Lifecycle.** Removing a hub with live children (refuse? cascade with confirmation?), close-out
   order, review policy (children reviewed before merging into the hub? the hub's PR to main reviewed
   as a whole?), releases only from `(main)`.
7. **tmux: one server per project.** Today every session is on the default socket. On 2026-10-07 the
   default server (25+ sessions across projects) lost its socket file — almost certainly a client got
   ECONNREFUSED under load, unlinked the socket and started a second server — leaving every old
   session alive but unreachable and the app relaunching duplicates. Design per-project servers
   (`tmux -L <project-key>` on EVERY call in core + app: `tmux.rs`, `activity.rs`, the app's attach,
   cross-project reach into another project's server), migration of live sessions, and a guard that
   recreates a known server's socket (`SIGUSR1`) instead of letting a new server start. Say whether
   this should ship BEFORE nested lanes.
8. **Load/quota.** More agents per tree: quota gate (`quota.rs`), MCP server count, polling cost.
9. **Phasing**: a phase 1 that is useful alone, then the rest. Open questions for David at the end.

## Rules
- Read AGENTS.md first, plus DESIGN.md, `docs/adr/`, `docs/proposals/project-settings.md`,
  `docs/proposals/cross-project.md`, `docs/proposals/pull-requests.md`.
- Docs-only work. Do not modify code. Probes go in `~/.cache/worktrees/worktrees/nested-lanes/`.
- Any tmux probe: `tmux -L <unique-name>` on EVERY call; never a bare `tmux kill-server`; never touch
  the default server's sessions.
- Never `git worktree add`; never edit (main)'s checkout — only your own place.
- GitHub: read-only except pushing your own branch and opening your own PR.
- No session URLs / session trailers in commits or PR; keep a Co-Authored-By line for yourself.
