# Progress log

## Session 1 — 2026-08-13 — markdown font zoom

- Branch: `ui-changes-next` (worktree `ui-changes`). Clean at start, HEAD
  `8d270c2 chore: close out cmdk-activity-order session (#125)`.
- Phase 0 recon done — see findings.md. Key discovery: `.md` headings/table/
  fences are sized in `rem` / `--fs-*` / `--term-size`, so a plain `font-size`
  on `.md` would have scaled paragraphs only.
- Phase 1 — user chose: **markdown preview only** (not the source view), **with**
  ⌘+ / ⌘− / ⌘0 shortcuts.
- Phases 2-4 implemented:
  - `settings.ts` — `files_md_zoom` (default 100), `MD_ZOOM_STEPS`
    (70…200), `clampMdZoom` (snaps to nearest stop), `stepMdZoom`.
  - `App.css` — `.md` defines `--md-z: var(--md-zoom, 1)` plus `--md-s1..s6`
    scaled spacing; headings rem→em (1.714 / 1.371 / 1.2), table 0.929em,
    fence-lang 0.786em, rawhtml 0.857em, `.md-fence .code` =
    `calc(var(--term-size) * var(--md-z))`; `.reading .md` padding scaled too.
    New `.zoomseg` / `.seg-b:disabled` / `.zoom-val` rules.
  - `FilesPane.tsx` — `mdZoom`/`onMdZoom` props, `--md-zoom` written inline on
    the `.scroll` box, `A− / <pct>% / A+` group in the viewer header, shown only
    when `kind === "markdown" && !mdSource`. Readout is the reset (disabled at
    100%), steppers disabled at the ends.
  - `App.tsx` — wired at BOTH mounts (dock pane + reader overlay); `ZOOM_KEYS`
    module const; the chord is handled ABOVE the meta-only gate because ⌘+ is
    ⌘⇧= on a US layout and the gate drops shifted chords; `keyRef.mdPreview`
    gates it to a visible rendered doc; `kr.mdZoom` is written back so a fast
    double-press steps twice.
- CHANGELOG `[Unreleased]` → Added entry.

### Tests run

| Gate | Result |
|------|--------|
| `tsc --noEmit` | exit 0 |
| mock harness (port 5199) + Playwright `getComputedStyle` | see below — pass |
| `cargo build --release -p worktrees-cli` | exit 0 |
| `cargo check -p app` | exit 0 |
| `make test` (bats) | exit 0, `not ok` count = 0, 288 tests |
| `cargo test -p worktrees-core` | 208 passed |
| `cargo test -p worktrees-cli` | 6 passed |

### Harness measurements (README.md in the mock tree)

| Thing | 100% | 110% | ratio |
|-------|------|------|-------|
| `.md` font-size | 13.125px | 14.4375px | 1.10 |
| `.md-h1` | 22.496px (was 22.5 = 1.5rem) | 24.746px | 1.10 |
| `.md-h2` | 17.994px (was 18) | 19.794px | 1.10 |
| `.md .code` (fence) | 13px (= --term-size) | 14.3px | 1.10 |
| `.md-table` | 12.193px (was 12.1875) | 13.412px | 1.10 |
| `.md` padding | 16/24/32px | 17.6/26.4/35.2px | 1.10 |
| `.reading .md` padding | 24/24/32px | 26.4/26.4/35.2px | 1.10 |

100% is the OLD rendering to within 0.01px (the em conversions are exact
ratios of the previous rem values).

Also asserted: ⌘+ → 125%, ⌘− → 110%, ⌘0 → 100% and the readout disables;
Source view shows no stepper AND swallows nothing (`.code` stayed 13px through
a ⌘+); the reader overlay (⌘⇧E) carries the same control; `get_settings`
round-trips `files_md_zoom: 110`, so it persists.

The only console error is the mock's pre-existing xterm `dimensions` throw on
opening a place — unrelated.

Artifacts moved to `~/.cache/worktrees/worktrees/ui-changes/`
(`md-zoom-reader.png` = reader at 125%, plus the playwright logs).

### Follow-up (same session) — per-place memory

User asked whether the size is remembered per worktree; it was global. Moved it
onto the existing per-place machinery:

- `PlacePanels` gained `files_md_zoom` (4th field). `panelsFor` returns
  `p.files_md_zoom ?? s.files_md_zoom` — a `{...s, ...p}` spread alone would put
  `undefined` over the global for every entry written by an OLDER build, so
  every already-set-up place would have read as "no size".
- `updatePanels` writes the full record (now a quad, renamed `triple` → `panels`).
- App.tsx reads `eff.files_md_zoom` (not `settings.`) at both mounts and in
  `keyRef.mdZoom`; both write paths go through `updatePanels`.
- Unlike `dock_open`, zoom DOES seed from the global: an inherited size changes
  nothing until you are reading, which is not the "furniture rearranged itself"
  complaint that made `dock_open` non-seeding.
- Pruning is free — `dropPanels` + the once-per-session sweep already drop keys
  for dead places.

Harness-verified (fresh vite `--force`, served file grepped for the edit):

| Step | Result |
|------|--------|
| search-index → A+ ×2 | 125%, `place_panels[…\|search-index].files_md_zoom = 125`, global seed 125 |
| switch to billing-refactor, open README | inherits **125%** (16.4062px) |
| A− ×3 there | 90%; panels = `{search-index: 125, billing-refactor: 90}`, global 90 |
| back to search-index, reopen README | **125%** — its own value, not the seed |
| `panelsFor` with a legacy entry (no zoom key) | falls back to the global (150) |
| `clampMdZoom(133 / NaN / 999)` | 125 / 100 / 200 |

`tsc --noEmit` exit 0 after the change. No Rust touched since the green run
above, so those gates still stand.

### Shipped

- Rebased onto v0.13.0 (origin/main had moved 4 commits; stash → branch off
  `origin/main` → pop; settings.ts auto-merged, and the CHANGELOG entry had
  landed INSIDE the released 0.13.0 section — moved to a fresh `[Unreleased]`).
- PR #129 → squash-merged as `6333633`. Branch `ui-changes-md-zoom` deleted
  local + remote; worktree parked on `ui-changes-next` off fresh origin/main.
- Fable review found 3, all fixed in `0093d7d` before merge:
  1. `updatePanels` filled `files_md_zoom` from `cur` (which falls back to the
     global), so ANY panels write — ⌘J, a drag, a tab switch — pinned the seed
     into a place with no size of its own and pushed that stale number back to
     the global. Field is now optional; absent stays absent.
  2. `.md-fence .code-text` kept an 8/12px inset at every zoom.
  3. `.md-check` stayed ~13px. `width: 1em` alone did NOT fix it (measured
     13.33px at 150%): form controls do not inherit font, so the em resolved
     against the UA's control font — `font-size: inherit` is the actual fix.
     Same reason `top: 0.35em` had been ignoring the zoom.
- Fable also cleared the WKWebView question: no native menu and no
  `zoomHotkeysEnabled` in tauri.conf, so ⌘+/− reach JS in a real build.
- CI green on the merged SHA (9/9: lint, rust ×2, test ×2, install ×2, app ×2).

### Still open

- **Real-app check (Phase 6):** whether WKWebView eats ⌘+/⌘−/⌘0 before the
  window handler in a Tauri build. The mock harness cannot answer this — it is
  Chromium via Playwright and the events were synthetic. Needs
  `app/scripts/sandbox.sh --app` and a human pressing the keys.
- No PR opened yet.
