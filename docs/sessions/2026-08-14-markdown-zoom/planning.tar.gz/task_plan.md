# Task: markdown font-size zoom in the Files viewer

**Goal:** in the dock's Files tab, when a markdown file is shown as a rendered
preview, the user can increase / decrease the reading font size, and that choice
survives a place switch and an app restart.

**Non-goals (unless the scope answer says otherwise):** changing the global UI
scale (`--ui-rem`, Settings → UI font size), the terminal font, or the code
viewer's font.

## Phases

| # | Phase | Status |
|---|-------|--------|
| 0 | Recon — how the viewer, settings and `.md` CSS are wired | complete |
| 1 | Scope decisions (zoom target, control surface, shortcuts) | complete |
| 2 | CSS: make `.md` scale off one multiplier (rem → em sweep) | complete |
| 3 | State: `files_md_zoom` in settings.ts + App.tsx wiring | complete |
| 4 | Controls: −/percent/+ in the viewer header + ⌘+/⌘−/⌘0 | complete |
| 5 | Verify: mock harness `getComputedStyle` assertions | complete |
| 6 | Gates (green) + fable review + PR #129 squash-merged (`6333633`) | complete |

## Design (current intent)

- One knob: `--md-zoom` (unitless multiplier) set inline on the `.md` root.
  `.md { font-size: calc(var(--fs-body) * var(--md-zoom, 1)); }`
- Every descendant size inside `.md` must be **relative** or it will not move:
  `.md-h1/.md-h2/.md-h3` are `rem` today (root-relative → immune), `.md-table`
  and `.md-rawhtml-block` use `--fs-*` tokens, `.md .code` uses `--term-size`
  (px). Phase 2 converts these to `em` / `calc(... * var(--md-zoom))`.
- Persistence follows the existing `files_wrap` / `files_md_source` pattern:
  a flat global setting, passed down as a prop, saved via `updateSettings`.
- Steps: 70 / 80 / 90 / 100 / 110 / 125 / 150 / 175 / 200 (%); clamp helper next
  to `clampRem` / `clampTerm`.

## Decisions

| Question | Answer |
|----------|--------|
| Persist per-file or globally? | **PER PLACE**, seeded from the flat last-used value (user, session 1 follow-up). Rejected: per-file (unbounded map, needs its own prune, a size with no visible cause on reopen). |
| Store as % int or multiplier? | % int, clamped 70–200 |
| Zoom the source/code view too? | no — rendered markdown only (user, Phase 1) |
| ⌘+ / ⌘− / ⌘0 shortcuts? | yes, gated on a visible rendered doc (user, Phase 1) |
| Where does `--md-zoom` live? | inline on the `.scroll` box; CSS reads it with a `, 1` fallback |
| Fence code size at 100%? | unchanged (`--term-size`) — it scales, it does not become prose |

## Errors Encountered

| Error | Attempt | Resolution |
|-------|---------|------------|
| — | — | — |
