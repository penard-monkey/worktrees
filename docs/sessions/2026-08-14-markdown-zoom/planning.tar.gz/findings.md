# Findings — markdown font zoom

## Where the markdown preview lives

- `app/src/FilesPane.tsx:525` — the only `<Markdown>` mount in the app:
  `<div className="scroll"><Markdown src={read.content} … /></div>`, reached when
  `info.kind === "markdown" && !mdSource`.
- `app/src/markdown.tsx:297,303` — renders into `<div className="md">…</div>`.
  All block classes are `md-*`; fences delegate to `<CodeBlock>` (`CodeView.tsx`),
  which emits `.code` / `.code-text`.
- Viewer header: `FilesPane.tsx:532-555`. Existing controls = Preview/Source
  `.seg`, `Wrap` (`ctrl sm`, `.on` when active), Expand, Editor. `dock-spacer`
  pushes them right. `showSourceToggle` / `showWrap` gate visibility.

## Type system in CSS

`app/src/tokens.css`:
- `--ui-rem: 15px` on `:root` → `html { font-size: var(--ui-rem) }` (line ~401).
  ONE knob scales all rem-based chrome. Settings → "UI font size" (13–18).
- `--fs-micro .6875rem`, `--fs-meta .75rem`, `--fs-label .8125rem`,
  `--fs-body .875rem`, `--fs-row .9375rem`, `--lh-prose 1.6`.
- `--term-size: 13px` — **independent of rem, px**, used by `.xterm` AND `.code`.

`app/src/App.css`:
- `.md` (1007): `font-size: var(--fs-body); line-height: var(--lh-prose);
  max-width: 78ch` — the measure is in `ch`, so it tracks font-size for free.
- Sizes that will NOT follow a `.md` font-size change (root-relative or px):
  - `.md-h1 1.5rem`, `.md-h2 1.2rem`, `.md-h3 1.05rem`, `.md-h4/5/6 var(--fs-body)`
  - `.md-fence-lang var(--fs-micro)`
  - `.md-table var(--fs-label)`
  - `.md-rawhtml-block var(--fs-meta)`
  - `.code { font-size: var(--term-size) }` — every fence body
- Already relative (fine as-is): `.md-code-inline 0.9em`, its `0.05em/0.35em`
  padding, `.md-check top: 0.35em`.

## Settings plumbing (the pattern to copy)

- `settings.ts:73-140` type, `145-182` DEFAULTS, `192-193` `clampRem`/`clampTerm`,
  `263-271` `applySettings` (writes CSS vars on `<html>`), `299-321`
  load/save (debounced 250 ms `set_settings`).
- `SETTINGS_REV = 1` + `migrate()` — only needed when a DEFAULT changes for
  existing installs. A brand-new key does not need a rev bump (absent key →
  `{...DEFAULTS, ...raw}` supplies the default).
- `App.tsx:3127-3130` and `3163-3166` — the TWO places `wrap`/`mdSource` are
  passed (dock pane + reading overlay). A new prop must be wired at both.
- `SettingsSheet.tsx:315-319` — the `ui_rem` control is a `range` input with a
  `<span className="val">` readout; `266-269` is the same for `term_size`.

## Keyboard

- Global handler `App.tsx:2338-2406`. Taken: ⌘⇧T, ⌘⇧E, ⌘K, ⌘J, ⌘, , ⌘1-9, ⌘E.
- ⌘+ / ⌘− / ⌘0 are FREE in the app's own handler. Unverified whether WKWebView
  itself swallows them for page zoom in a Tauri build — must be checked in the
  real app, not the browser harness.

## Verification notes (from CLAUDE.md, apply here)

- Assert layout with `getComputedStyle` in the mock harness; do not eyeball.
- HMR is dead inside `.worktrees/` — restart vite with `--force` after edits and
  diff `curl -s localhost:PORT/src/App.css` against disk when a change "does
  nothing".
- One click per `browser_evaluate` (React batches).
- Real-app run (`app/scripts/sandbox.sh --app`) before calling it done.
