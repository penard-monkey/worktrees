# Task Plan: tmux detection after-the-fact + installer gating

## Goal
Fix two related problems:
1. App installed without tmux → user installs tmux later → app never "registers" tmux (no re-detect path?). Investigate + fix.
2. install.sh: tmux install never triggered/offered on David's mac. Decide gating: on macOS require/point to brew + tmux before (or during) install; on Linux point at distro package manager. Design + implement.

## Phases

### Phase 1: Investigate current behavior — status: complete
- [x] How app detects tmux — have_tmux() live probe, no caching; PATH fixed once at startup
- [x] UI when tmux missing — nothing global; per-place "down" + error toast; no recheck
- [x] install.sh tmux handling — NOTE only, never offers; brew never checked
- [x] Where brew fits — hint assumes brew exists; /opt/homebrew fallback only when login-shell probe fails

### Phase 2: Design decision — status: complete (David answered 2026-07-30)
- [x] Installer: tmux MANDATORY, no escape hatch. macOS: brew present + tty → offer `brew install tmux` [Y/n]; no brew → hard error pointing at https://brew.sh; non-interactive → hard error. Linux: detect apt/dnf/pacman/zypper, print exact command, exit 1.
- [x] App: banner when tmux missing + Re-check button → new async tauri command re-running fixup_gui_path() + have_tmux(). Mock harness parity.
- [x] Bonus fix: fixup_gui_path() always appends standard dirs (~/.local/bin, /opt/homebrew/bin, /usr/local/bin) even when login-shell probe succeeds — covers profiles without brew shellenv.

### Phase 3: Implement (opus agent) — status: complete
- [x] install.sh tmux gate (require_tmux helper; bash-3.2 + shellcheck clean; header documents requirement)
- [x] fixup_gui_path always-append fallback dirs (+ doc comment on re-entrancy)
- [x] tauri command tmux_check(refresh) + TmuxBanner (module scope) + Re-check in App.tsx
- [x] mock harness tmux_check (?notmux / ?notmux=stuck fixtures, Playwright-verified)
- [x] CHANGELOG [Unreleased] Added/Changed/Fixed entries

### Phase 4: Verify + fable review — status: complete
- [x] All gates pass (agent): release build, bats 238 ok, lint, core 137 tests, tsc + cargo check -p app
- [x] Fable re-ran lint + tsc independently — clean
- [x] Diff reviewed: tokens/icon exist, mock stateful pattern matches file, banner module-scope per CLAUDE.md rule
- Review notes (non-blocking): (1) tmux_check refresh calls std::env::set_var at runtime — concurrent getenv on other threads is technically racy on POSIX; pre-existing pattern, low risk, noted. (2) PATH grows by std-dirs prefix per Re-check — dups harmless, unbounded only if hammered. (3) macOS interactive [Y/n] branch not machine-verifiable (needs real tty) — reuses proven app-prompt pattern.

## Status: DONE — uncommitted on bug-fixes, awaiting David's look + PR

## Decisions
- (none yet)

## Errors Encountered
| Error | Attempt | Resolution |
|-------|---------|------------|
