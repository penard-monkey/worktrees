# Findings

## Problem statement (from David)
- App installed first time WITHOUT tmux → installing tmux afterwards: no way to get tmux registered after the fact?
- Feels installer shouldn't proceed until brew + tmux exist (macOS); Linux → whatever installs tmux there.
- On his mac: tmux install never triggered/offered.
- macOS: should tell users to install brew.

## Code findings

### After-the-fact tmux registration — engine ALREADY supports it; blockers are PATH + UI
- `have_tmux()` (crates/worktrees-core/src/tmux.rs:71) shells `tmux -V` live on every call — nothing caches "tmux missing".
- Places created without tmux need no migration: app Enter (app/src-tauri/src/lib.rs:428 `place_enter`) creates the session if down; CLI `open` same (ops.rs:552). First enter/open after tmux appears just works.
- REAL blocker #1: `fixup_gui_path()` (lib.rs:1988) resolves login-shell PATH ONCE at startup. Install brew/tmux while app runs → app PATH stale → `have_tmux()` false until app restart.
- REAL blocker #2 (edge): login-shell probe succeeds but profile lacks `brew shellenv` → even restart won't see tmux (fallback `/opt/homebrew/bin` only appended when the probe FAILS, lib.rs:2005-2008).
- REAL blocker #3: zero UI affordance. Frontend has no "tmux available" concept — only per-place `tmux_session.up`. tmux missing looks like: every place "tmux ○ down" + Enter error toast "tmux not found". No banner, no install hint, no re-check.
- CLI `new` degrades: `tmux not found — continuing with --no-tmux` (ops.rs:264). `open`/`close` hard-error "tmux not found".

### Installer (install.sh)
- Preflight hard-REQUIRES: curl, Xcode CLT (macOS), git ≥ 2.23.
- tmux: line 110-117 — version warning if old; if ABSENT only a NOTE ("new will degrade… brew install tmux · apt install tmux") and install proceeds. Nothing ever offers/triggers a tmux install — matches David's mac experience.
- brew never checked. If brew absent, the printed hint `brew install tmux` can't even run.
- Precedent exists for interactive offer: the desktop-app [y/N] prompt reads /dev/tty (line 203-218) — same mechanism usable for a brew-install-tmux offer.

## Proposed design (pending David's answers)
1. install.sh gates on tmux before installing:
   - macOS, no tmux, brew present, tty: offer "brew install tmux now? [Y/n]" → run it.
   - macOS, no brew: ERROR — install Homebrew first (https://brew.sh), then `brew install tmux`, re-run.
   - Linux, no tmux: detect apt/dnf/pacman/zypper → print exact install command, exit 1.
   - Escape hatch: `WORKTREES_INSTALL_NO_TMUX=1` keeps today's degrade behavior (CI/source builds).
2. App: `have_tmux()` false → banner "tmux not installed" + platform hint + Re-check button; Re-check re-runs `fixup_gui_path()` + probe (fixes stale PATH without restart). New tauri command + mock harness parity.
