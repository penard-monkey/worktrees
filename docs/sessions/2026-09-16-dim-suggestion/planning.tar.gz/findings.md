# Findings
- Versions all 0.23.1 (workspace, ~/.local/bin, /Applications). Not a staleness issue. claude 2.1.273.
- `scan_drafts` (app/src-tauri/src/lib.rs) chains `display-message -p @@i@@ ; capture-pane -p -t %N -S <n>` per pane.
- Live `capture-pane -e` on 34 idle panes: suggestion lines are `ESC[39m❯\xa0ESC[2m<text>ESC[0m` (reset may fall on next line when wrapped).
  Typed drafts: `ESC[39m❯\xa0<text>` — no attribute; one selected draft had `ESC[48;5;66m` (bg) before the NBSP, not dim.
- Box edges under -e: `ESC[38;5;244m───…`; the prompt line starts `ESC[39m❯`.
- Suggestion is dim on every claude version seen live (2.1.269–2.1.273); not a "stale claude" symptom. ✎ shipped in 0.22.0 (#191) and never read styling.
