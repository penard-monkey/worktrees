# Task: ✎ must not light for Claude's own dim suggestion

## Goal
The nav's ✎ (unsent-prompt) glyph lights when Claude Code paints its dimmed
follow-up suggestion in the prompt box, because `capture-pane -p` drops styling
and the parser cannot tell suggestion from typed text. Make it tell them apart.

## Phases
- [x] Phase 1: pull main, locate parser (`agent::draft_from_screen`) + I/O (`lib.rs::scan_drafts`)
- [x] Phase 2: measure live panes with `capture-pane -e` → suggestion = `ESC[2m` before first body char; typed = no attr
- [x] Phase 3: implement — `-e` in scan_drafts, SGR-aware parser, dim ⇒ no draft
- [x] Phase 4: tests (shown to FAIL first), CHANGELOG, gates
- [x] Phase 5: PR

## Decisions
- Detect on the prompt line only, on the RAW line, after locating the prompt via stripped lines.
- Plain (no-escape) input must behave exactly as before.

## Errors Encountered
| Error | Attempt | Resolution |
|-------|---------|------------|
| zsh glob in grep --include | 1 | quote the globs |
