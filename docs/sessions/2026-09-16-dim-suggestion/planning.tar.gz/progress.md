# Progress
## 2026-09-16
- ff-merged bug-fixes-next to origin/main (84b89fa).
- Located parser + I/O, measured live panes (see findings.md).
- Added tests (each shown red first: styled-typing red on old parser; suggestion red with stripping alone), implemented strip_escapes/body_starts_dim/apply_sgr in agent.rs, `-e` in lib.rs scan_drafts, CHANGELOG Fixed entry.
- Live spot check: parser vs 34 captured panes (30 suggestion/empty → None, 4 typed → Some) OK.
- Gates all green: release build fresh, bats 335 ok/0 not ok, lint, core 300, cli 7, app 47, tsc, cargo check. Uncommitted on bug-fixes-next; awaiting go-ahead for branch+PR.
- PR #210 opened from bug-fixes-dim-suggestion.
