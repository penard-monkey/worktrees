# Progress — usage widget time-until-reset

## Session 1 — 2026-08-06

- Read `UsageWidget` (`app/src/App.tsx:783-855`), `.usage*` CSS
  (`app/src/App.css:134-164`), the whole backend usage block
  (`app/src-tauri/src/lib.rs:757-994`), and the mock `claude_usage` fixture
  (`app/src/mock/install.ts:514-540`).
- **Discovery**: `resets_at` already reaches the frontend for all three row
  kinds — session, weekly_all, weekly_scoped (Fable). Change is frontend-only.
- Nav width bounds confirmed: `NAV_MIN 220` / `NAV_MAX 460`, default
  `--nav-w: 300px` (`app/src/settings.ts:142-143`, `app/src/tokens.css:105`).
- Planning files created. Blocked on D1 (row layout) — asking the user.

- D1 = inline 4th column, D3 = two units (user). Implemented `fmtEta()`, a 15s
  local tick, the `.usage-eta` column, and a `?usage=edge` mock fixture.

### Tests run

| Gate | Result |
|------|--------|
| `tsc --noEmit` | pass |
| `cargo check -p app` | pass (no Rust touched) |
| harness @ 300px, oauth | `5h 35% 3h 02m` · `7d 59% 2d 5h` · `Fable 80% 2d 5h` |
| harness @ 220px, `?usage=edge` | `<1m` · `47m` · blank (reset already passed), ETA column holds 42px, bars 75–90px |
| harness @ 460px, `?usage=stale` | dimmed as before, `40m` / `1d 23h` |

Full gate set run before the PR, all green: `cargo build --release -p
worktrees-cli`, `make test` (248 ok), `make lint` (clean), `cargo test -p
worktrees-core` (143 passed).

`make test` first failed with a bare "No such file or directory" — the bats
submodules were never checked out in this fresh worktree. `git submodule update
--init --recursive` fixed it.

### Merge

PR #82 → squash-merged as `4d8bde8` on 2026-08-06.

**GitHub Actions never ran it.** The queue was backed up org-wide (unrelated
runs sat queued 47m and 1h44m); `gh pr checks 82` reported "no checks reported"
throughout, so `--auto` had no required check to wait on and merged at once. The
local gates mirror ci.yml except for the app-crate build on ubuntu — worth a
glance at the next run on main.

`gh pr merge --delete-branch` errored on its local cleanup step ("'main' is
already checked out at /Users/davidpena/workspace/worktrees") — the merge itself
had already landed. Remote `ui-tweaks` still exists at `4acf077`.

### Environment notes

- Worktree started with no `app/node_modules` — `pnpm install` needs Node
  >= 22.13 (`nvm use 22.23.2`); the shell default here is v22.12.0.
- Mock harness: `VITE_MOCK=1 vite --port 5199`. **HMR is dead in this worktree**
  (see task_plan errors) — restart with `--force` after each edit.
