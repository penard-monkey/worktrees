# Task plan — usage widget: time-until-reset

## Goal

Nav-footer usage rows show `label · bar · %`. Add **time remaining until the
window resets** for every row: 5h session (`3h 02m`), weekly all-models
(`2d 5h`), and the model-scoped weekly bucket (Fable) — same treatment, no
special case.

## Key fact (unblocks everything)

`resets_at` (unix secs, `Option<i64>`) is ALREADY on every `UsageLimit` from
both sources and already crosses into the frontend — see findings.md. This is a
**frontend-only** change. No Rust, no new command, no new parsing.

## Phases

| # | Phase | Status |
|---|-------|--------|
| 1 | Recon: where the data lives, what renders it | complete |
| 2 | Design decision: row layout + countdown format (user picks) | complete |
| 3 | Implement: `fmtEta()` + ticking clock + markup | complete |
| 4 | CSS: column, tabular nums, narrow-nav behaviour | complete |
| 5 | Mock harness: reset-edge fixtures (`?usage=edge`) | complete |
| 6 | Verify: tsc, cargo check, harness at 220/300/460px nav | complete |
| 7 | CHANGELOG + PR | complete — squash-merged as `4d8bde8` (#82) |

## Design decisions (log)

- **D1 — layout**: **A, inline 4th column** (user, 2026-08-06). ETA is a
  right-most tabular column after the %. Row height unchanged. Bar is allowed to
  squeeze at the 220px nav floor; the label ellipsizes first.
- **D2 — cadence**: countdown must tick independently of the 180s poll. Local
  `setInterval` at 15s in `UsageWidget`, minute-granularity display → never
  more than 15s stale. Widget is module-scope, so the re-render is local.
- **D3 — format**: **two units max**, biggest-first (user, 2026-08-06). `<1m` →
  `<1m`; `<1h` → `42m`; `<24h` → `3h 02m`; `>=24h` → `2d 5h`. Past/missing → no
  ETA rendered. Absolute reset time stays in the existing `title=` tooltip.
- **D4 — narrow nav**: nav clamps to 220–460px. ETA column must not squeeze the
  bar to nothing; container query on `.usage` decides what drops first.

- **D5 — `Xd 0h` collapses to `Xd`**: at day scale a zero hour is noise. The
  padded `00m` at hour scale stays (minutes are live there).

## Errors encountered

| Error | Attempt | Resolution |
|-------|---------|------------|
| `.usage-eta` rule silently dropped by the CSS parser | 1 | Stray `*/` left mid-comment by an edit — the rule was swallowed. Caught by asserting `getComputedStyle().minWidth`, not by eye. |
| Vite served the OLD file after the fix (and again after a mock edit) | 2 | **Vite's watcher does not see edits under `.worktrees/`** — the dot-directory is in chokidar's default ignore. `touch` didn't help. Restart with `--force` after every source edit in this worktree. |

## Files in play

- `app/src/App.tsx` — `UsageWidget` (~L783-855), `usageTick()`
- `app/src/App.css` — `.usage*` block (L134-164)
- `app/src/mock/install.ts` — `claude_usage` case (L514-540)
- `app/src-tauri/src/lib.rs` — read-only reference (L757-994); no change expected
