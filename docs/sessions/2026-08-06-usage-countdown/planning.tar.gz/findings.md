# Findings — usage widget time-until-reset

## Data path (already complete end to end)

`app/src-tauri/src/lib.rs:785-799`

```rust
struct UsageLimit { kind, label, percent, severity, resets_at: Option<i64> }
struct UsageInfo  { source, fetched_at, limits }
```

- oauth path: `parse_usage_limits()` L904 —
  `resets_at: e.get("resets_at").and_then(as_str).and_then(parse_iso8601)`
  → unix secs. Present for `session`, `weekly_all`, AND `weekly_scoped`
  (the Fable bucket) — the parse loop is shared, no per-kind branch.
- statusline fallback L955 — `bucket.get("resets_at").as_i64()`, already epoch.
  Covers session + weekly only (no model bucket by construction).
- `unavailable` → empty `limits`, widget renders null.

Frontend mirror `app/src/App.tsx:792-799` already types `resets_at: number | null`
and today only uses it in the row `title=` tooltip (L844):
`resets ${new Date(l.resets_at*1000).toLocaleString()}`.

**Conclusion: frontend-only change. No Rust edit needed.**

## Freshness constraints

- Backend cache TTL 120s (`USAGE_TTL_SECS`), frontend poll 180s
  (`USAGE_POLL_MS`) + a pull on window focus. Endpoint is undocumented and has
  rate-limited before — do NOT raise poll frequency to drive a countdown.
- Therefore the countdown must be computed client-side from `resets_at` against
  local wall clock, on its own timer. `resets_at` is absolute, so drift between
  polls is zero.
- Stale (statusline) source: `resets_at` may already be in the PAST. Must render
  gracefully (no negative countdown) — the widget is already dimmed at 0.55.

## Layout options (nav is 220–460px, default 300px)

Row today: `.usage-row` = flex, gap `--s2` (8px), font `--fs-micro` (0.6875rem).
Columns: `.usage-label` (max 6em) · `.usage-bar` (flex:1, 3px tall) · `.usage-pct`
(min 2.6em, tabular).

### A — inline 4th column
```
5h     ▁▁▁▁▁▁▁▁▁▁▁▁▁▁  35%   3h02m
7d     ▁▁▁▁▁▁▁▁▁▁▁▁▁▁  59%   2d 5h
Fable  ▁▁▁▁▁▁▁▁▁▁▁▁▁▁  80%   2d 5h
```
Height unchanged (3 rows). At NAV_MIN 220px the bar drops to ~60px — thin but
still a bar. Cheapest diff.

### B — two-line row (label + ETA above a full-width bar)
```
5h                        35%
▁▁▁▁▁▁▁▁▁▁▁▁▁▁▁▁▁▁▁▁▁  3h 02m
```
Bar keeps full width at any nav width; ETA gets room for a fuller string
("3h 02m left"). Costs ~+42px of footer height across 3 rows.

### C — ETA replaces the tick label
```
3h02m  ▁▁▁▁▁▁▁▁▁▁▁▁▁▁  35%
2d 5h  ▁▁▁▁▁▁▁▁▁▁▁▁▁▁  59%
```
No new column at all. But loses which window each row IS — "5h"/"7d"/"Fable" is
the only identifier, and Fable's name can't be dropped, so the rows stop being
parallel. Weakest of the three; recorded for completeness.

## Format rules (D3)

| Remaining | Render | Note |
|-----------|--------|------|
| >= 24h | `2d 5h` | days + hours, minutes dropped (noise at that scale) |
| 1h–24h | `3h 02m` | zero-padded minutes so the column doesn't jitter |
| 1m–1h | `42m` | |
| < 1m | `<1m` | |
| <= 0 / null | *(nothing)* | reset already passed or source has no field |

Tabular numerals (`font-variant-numeric: tabular-nums`, already used by
`.usage-pct`) keep the column from twitching each tick.

## Tooltip

Keep the absolute reset time in `title=` (already there) — the inline countdown
is the glanceable form, the tooltip stays the precise one.
