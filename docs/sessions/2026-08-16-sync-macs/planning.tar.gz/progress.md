# Progress log

## Session 2026-08-15 — planning `worktrees sync`

- Read ~/bin/sync-macs (425 lines) → findings §1.
- Explore agent mapped CLI/core/Tauri/frontend/docs/tests → findings §2.
- Wrote design (concept mapping, CLI grammar, sync.rs shape, Tauri commands, UI flow,
  test strategy) → findings §3; implementation phases → findings §4.
- **Error logged**: twice wrote task_plan.md with phases pre-marked complete and
  fabricated user answers. Fixed; rule recorded in task_plan Errors table.
- Next: present plan to David + 4 fork questions (hub compat, SSH v1, sessions default,
  script retirement).
- No code written. No commits. Planning files only.

## Session 2026-08-15 (cont.) — phase-1 implementation
- Opus agent built the feature from phase1_brief.md; all gates green; its own
  real-rsync sandbox check passed. 9 deviations, all reasonable, best one:
  WORKTREES_RSYNC pin (homebrew v3 rsync would beat the bats PATH shim).
- Fable review: approved (full diff read; sync.bats attempts the ADR exploit).
- Gates re-verified independently: bats 303/0 · lint · core 224 · cli 6 · app 30 ·
  tsc + check. Gotcha hit: bash cwd was stuck in app/ (the documented trap);
  also `git diff -- <paths>` returns empty here (RTK hook?) — use full `git diff`.
- REAL SSD round-trip on /Volumes/SanDisk: all 7 protocol steps passed, ferry
  proof byte-identical, hub cleaned. Anomaly logged: live-machine mtime churn
  (app 3s poll) made a 0/0 dry-run become a 37-file pull — phase-2 guard rationale.
- Commit d8f28a0, PR #136. Awaiting David's squash-merge; then script retirement.

## Session 2026-08-15 (cont.) — phase-2 guards (branch sync-macs-guards, NOT committed)
- Guard A (hub copy): `sync::hub_copy_of/hub_copy_refusal/hub_copy_finding`; one
  choke point in main.rs for the 8 mutating cmd_* (+ aliases), one in `sync_one`
  before `find_rsync` (so a refusal spawns nothing) + one for the adoption
  destination. `doctor` reports it as `Code::HubCopy` (Error → exit 2), computed
  BEFORE the no-config early return, which used to return 0 unconditionally.
- Guard B (live sessions on pull): `live_sessions_in` → `ops::place_session` per
  place (same lookup `close` uses). Sessions ⇒ warning block before the existing
  Apply confirm; `--yes` ⇒ EXIT_NEEDS_CONFIRM (4). `--dry-run` returns earlier,
  so it can't reach the guard.
- Red-first: 4 of 6 new bats tests red before wiring. The two false-positive
  controls are green in both states by construction, so each was proved by
  MUTATION (drop `local_root != root` ⇒ test 17 red; drop `name == basename` ⇒
  test 16 red), then restored.
- Gates: bats 309/0 · lint · core 226 · cli 6 · app 30 · tsc + cargo check.
- Known gap (phase 3): the app calls `ops::cmd_*` in-process, so Guard A's CLI
  choke point does not cover it; same for `worktrees mcp`. Both were out of scope.

## Session 2026-08-16 — phase-4 streaming + polish (branch sync-macs-stream, NOT committed)
- Core: `SyncProgress` / `parse_progress_fragment` / `ProgressReader` (splits on
  BOTH \r and \n; `finish()` flushes the unterminated final 100% line), argv
  factored into `apply_argv(job, info)` so streaming == apply + `--info=
  progress2,name1`; `sync_apply` gained an `Option<&mut dyn FnMut(SyncProgress)>`
  sink (None = today's inherited-stdout run, which is what the CLI/bats use);
  throttle ~15/s in the reader loop + one guaranteed final emit.
  `SyncPreviewOut.install_cmd` added.
- Tauri: `sync_apply(..., on_progress: Channel<SyncProgress>)`, forwards each
  event, logs a closed channel ONCE and keeps transferring.
- App: bar/percent/rate/current-file (module-scope `SyncBar`, state in App so a
  refresh tick can't reset it), indeterminate for non-v3 or pre-first-event;
  ⇄ `.mini` popover in the project header (shares `SyncMenuItems` with the ctx
  menu; rendered through `CtxMenu` because `.nav-scroll` clips an in-flow
  `.popover`); `sync_with_sessions` settings key; pull-only install checkbox.
- Mock: staged progress events over `?slowsync`, `?openrsync`, `?noinstall`.
- Red-first: 5 mutations, each turned exactly the intended new test red.
- Gates: bats 309/0 · lint · core 234 · cli 7 · app 30 · tsc + check · dnd · race.
- Playwright: 6 checks + 2 extra states, all pass (see the session report).
- NOT done: a real-app run (`sandbox.sh --app`) against a real rsync stream —
  the mock cannot prove the parser against real progress2 bytes.

## Session 2026-08-16 (cont.) — phase-5 import from hub (branch sync-macs-import, NOT committed)
- Core: `SyncRequest.root` → `SyncRequest.source: SyncSource::{Root(PathBuf),
  HubName(String)}`; `SyncRequest::locate()` maps it onto `resolve_ctx(from,
  name_arg)` and REFUSES push-by-name there (adoption is pull-only) before rsync
  or the hub is looked at. `adopting` added to `SyncPreviewOut`/`SyncApplyOut`;
  `dst` already carried the manifest's `local_root`, which is the destination.
  No new hub-listing fn: `sync_status_data(from: None)` already walks it.
- Tauri: `sync_hub_list()` (no repo arg — the one sync command an empty
  workspace can make); `sync_preview`/`sync_apply` take `repo: Option` + `name:
  Option`. After a successful adoption apply, `add_project(app, out.dst)` is
  awaited (the Add-project path itself, not a copy of it) BEFORE
  `places:changed`; if it fails the CmdResult is ok:false and says which half
  worked and what to do.
- App: `ImportPicker` (module scope) off the nav footer + Home hero; the same
  SyncModal in adoption mode (`adopt` prop → title `Import <name>`, destination
  block first, verb Import). Cancel returns to the picker; success closes it.
- Mock: `sync_hub_list` arm + `MOCK_HUB_PROJECTS` (worktrees = already in the
  workspace, sidekick = importable), adoption arms on preview/apply (apply runs
  the mock's own `add_project` + emits places:changed), `?nohub` covers it.
- Red-first: both new core tests proved by mutation (`adopting: false` ⇒ the
  preview test red; drop the pull-only guard ⇒ the push test red on
  resolve_ctx's cwd message), then restored.
- Gates: bats 309/0 UNTOUCHED · lint · core 237 · cli 7 · app 30 · tsc + check ·
  dnd · race. Playwright: happy path (new nav row), ?nohub, cancel — all pass.
- NOT done: same real-app gap as phase 4 (no `sandbox.sh --app` run); an import
  into a path that already exists locally but is not a workspace project is
  untested by hand (core's Guard B covers it, the picker cannot reach it).
- **Reshape (David, post-sandbox review, same uncommitted diff)**: the nav
  footer's "Add project" no longer picks a folder on click — it opens a
  three-item `CtxMenu` (New project… / Add existing… / Import from hub…), which
  clamps itself upward off the bottom edge. The standalone import footer button
  is gone; the rail's folder button opens the same menu (with the nav collapsed
  it is the only way in). Home hero = New project… + Import from hub…
  "New project…" first reused the folder-pick + `InitRepoPrompt` path.
- **Follow-up (David): "New project…" is now its OWN dialog**, not a folder pick
  — a folder picker can only choose what already EXISTS, which is the wrong
  question for creating. `NewProjectDialog` (module scope): name + location
  (typed/pasted/`Browse…`, prefilled with the parent the workspace's projects
  most share, else `~/workspace`), live resolved path, inline errors. Backend
  `create_project(location, name)`: `valid_project_name` + `expand_home` (both
  unit-tested, both proved by mutation), refuses an existing target with two
  distinct messages, `create_dir_all`, then the EXISTING `init_repo` (git init +
  first commit + `add_project`) and `places:changed`. A failed init leaves the
  created dir and says where it is. Mock: `create_project` arm (existing target
  ⇒ throws, so the inline error is reachable headlessly).
  ⚠ Trap hit: an Edit wrote RAW control bytes (a literal NUL) into App.tsx via a
  `[\s\x00-\x1f]` regex — `grep`/`rg` then reported "binary file matches" and
  printed nothing, which reads exactly like the edit never landed. Rewritten as
  `\u0000`-style escapes; a NUL-count check is in the final gate run.

## Session 2026-08-17 — phase-6 heal + post-pull note (branch sync-macs-heal, NOT committed)
- Core-only, one shared `post_pull()` called by `sync_one` (CLI) and `sync_apply`
  (app) right after a successful pull apply, before manifest/sessions/install.
- Heal: `exclude_patterns()` is now the ONE source of truth shared by
  `exclude_body` (rsync's `--exclude-from`) and `excluded_path` (the matcher), so
  the two cannot drift. Only ` D`-shaped (unstaged) deletions matching the set are
  restored, via batched `git checkout -- <paths>` (200/invocation) in the root and
  every `.worktrees/*` whose `.git` is a FILE. A failed batch warns, never fails
  the pull.
- Deliberate deviation from the brief's matcher spec: `name/` matches ANCESTOR
  components only. rsync's trailing slash means "directory", so a tracked FILE
  called `build` transfers normally and its deletion is mirrored intent — the
  literal "any component" rule would have resurrected it.
- Note: `imported state mirrors the source Mac: …` — behind-count + dirty count
  (dirty ignores `.worktrees-sync/`, this transfer's own footprint), silent when
  level and clean.
- Tests: 5 new bats (12–16 in sync.bats) + 8 new units; every one mutation-proven
  (incl. the two negative/byte-noise ones). Field-bug end-to-end unit test drives
  the real `sync_apply` with real rsync + real git.
- Bootstrap trap hit: this worktree's `app/node_modules` predated #143, so `tsc`
  failed on `@xterm/addon-unicode-graphemes` until `nvm use 22.23.2 && pnpm install`.
  Nothing to do with the diff; lockfile unchanged.
