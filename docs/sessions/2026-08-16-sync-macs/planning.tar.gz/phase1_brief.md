# Implementation brief — `worktrees sync` phase 1 (full CLI parity)

You are implementing a new `worktrees sync` subcommand in this repo
(`/Users/davidpena/workspace/worktrees/.worktrees/sync-macs`, branch `sync-macs`).
It ports `~/bin/sync-macs` (rsync courier sync of a project between Macs via an SSD
"hub") into the Rust engine. Read these BEFORE writing code:

1. `CLAUDE.md` (repo root) — gates, traps, conventions. Non-negotiable.
2. `findings.md` (repo root, gitignored) — §1 source script behavior, §2 codebase map
   with file:line refs, §3 design (as amended §3.2/§3.2b), §4 scope.
3. `~/bin/sync-macs` — the source script, for exact rsync behavior parity.
4. `docs/adr/0001-no-repo-supplied-argv.md` — governing constraint.

## Scope — phase 1 ONLY
- New `crates/worktrees-core/src/sync.rs` + registration in core `lib.rs`.
- CLI wiring in `crates/worktrees-cli/src/main.rs` (USAGE + pre-guard dispatch).
- `[sync]` table reader added to `crates/worktrees-core/src/config.rs`.
- `test/sync.bats` (new) + `test/helpers/common.bash` (fake rsync ALWAYS).
- Unit tests in `sync.rs` `mod tests`.
- `CHANGELOG.md` → `[Unreleased]`.
- **Do NOT touch**: app/ (anything), mcp.rs, projcfg.rs semantics, version numbers.
  No guards (hub-copy marker, live-session check) — that's phase 2. Do NOT delete or
  modify `~/bin/sync-macs`. **Do NOT commit** — leave the working tree for review.

## CLI grammar (findings §3.2 amended — registry-free)
```
worktrees sync push   [--hub PATH] [--dry-run|-n] [--yes|-y] [--with-sessions] [--json]
worktrees sync pull   [name] [--hub PATH] [--dry-run|-n] [--yes|-y] [--with-sessions] [--install] [--json]
worktrees sync status [--hub PATH] [--json]
```
- Dispatch from the PRE-GUARD block in main.rs (like `skills`, main.rs:42-58): sync must
  work outside a git repo (adoption pull, hub status). Inside a repo, resolve the project
  via `Project::discover(&cwd)`; the **sync unit is the project root dir** (repo root,
  which contains `.worktrees/`). Project name = basename of root.
- push/status: cwd-scoped only (no name positional). `sync push` outside a repo = error
  (exit 1) telling the user to cd into a project.
- pull: inside repo ⇒ that project (optional name must match, else error). Outside repo
  + name ⇒ adoption: read `<hub>/<name>/.worktrees-sync.toml`, print the destination
  (`local_root`), require confirm (or `--yes`). Outside + no name ⇒ exit 1, list
  available manifests on the hub.
- status outside a repo: hub-level — list each `<hub>/*/.worktrees-sync.toml` (name,
  local_root, pushed_at, host). Inside: project status (see Output below).
- `--json` honored on all three + also via `WORKTREES_JSON=1` env (two-line idiom:
  main.rs:81-82 / ops.rs:1486-1488).
- Unknown flag ⇒ `ui.error("Unknown flag: …")` + exit 1 (cmd_doctor idiom,
  ops.rs:1463-1488). Bare `worktrees sync` / unknown sub ⇒ usage line + exit 1.
- All output through the `Ui` trait (ui.rs) — never println! in core. Follow existing
  glyph/tone conventions (look at cmd_doctor / cmd_provision output).

## Core engine — `crates/worktrees-core/src/sync.rs`
Shell out to rsync (NEVER a Rust rsync lib — bats shims must intercept; same rationale
as git.rs:1-4). Model subprocess wrappers on `git_status_captured` (git.rs:77) and argv
assembly on `provision::compose_down` (provision.rs:554-572).

### rsync discovery
Candidates in order: `/opt/homebrew/bin/rsync`, `/usr/local/bin/rsync`, `rsync` on PATH.
First existing+executable wins as fallback; first whose `--version` output contains
`version 3.` or `version 4.` wins outright and sets `v3 = true`. Capture --version to a
buffer (Command::output), never a pipe. No rsync at all ⇒ hard error.
IMPORTANT for tests: PATH lookup must happen at call time so the bats shim dir wins.
In the test environment the shim is plain `rsync` on PATH (not the homebrew paths —
those don't exist in CI); the absolute-path candidates must be checked with
`Path::exists` so they're skipped cleanly on machines without them.

### Hub resolution (precedence: flag > env > user config > autodetect)
`--hub PATH` > `WORKTREES_SYNC_HUB` env > config `[sync] hub` > autodetect: scan
`/Volumes/*`, skip symlinks and denylist basenames
`["Macintosh HD", ".timemachine", "com.apple.TimeMachine.localsnapshots", "davidpena"]`.
Exactly 1 candidate ⇒ use it (print `auto-detected SSD hub: …` as info). 0 ⇒ error
"no external volume mounted; plug in the SSD or pass --hub PATH". >1 ⇒ error listing
them, "ambiguous — pass --hub PATH". Factor the candidate-filter into a pure fn taking
`&[(String /*basename*/, bool /*is_symlink*/, PathBuf)]` so units test it without
/Volumes. bats tests always pass `--hub` or the env var (portable to linux CI).

### Hub layout (FRESH — no sync-macs compat)
```
<hub>/<name>/.worktrees-sync.toml     # manifest, data only
<hub>/<name>/<name>/                  # the tree copy (basename dir, mirrors local)
<hub>/<name>/.claude-sessions/        # sessions store (only if ferried)
<hub>/<name>/.worktrees-sync/backups/<stamp>/   # push-direction backups
```
Local pull-direction backups: `<local_root>/.worktrees-sync/backups/<stamp>/`.
`.worktrees-sync/` is in the exclude set (never ferried).

### Manifest — `.worktrees-sync.toml`
Serde struct, `#[serde(deny_unknown_fields)]`:
```toml
schema = 1
name = "worktrees"
local_root = "/Users/davidpena/workspace/worktrees"   # ABSOLUTE project root path
pushed_at = 1755300000       # epoch seconds
host = "davids-mbp"          # lenient: `hostname` shell-out, empty ok
hint = "cargo build …"       # human-readable rebuild hint — PRINTED, NEVER EXECUTED
```
ADR 0001 extended to media: the manifest may never supply argv. `deny_unknown_fields`
makes any command-like key a hard parse error — add a unit test proving a manifest with
`install_cmd = "…"` is REJECTED. Unknown schema number ⇒ error advising CLI update.
`local_root` from a manifest is data; writing to it is gated by the adoption confirm.
Written on every successful (non-dry-run) push. `hint` comes from the user's own
`[sync.projects.<name>] install` if set, else a static per-nothing empty string.

### Excludes (rebuildable bulk — ported from the script, verbatim minus renames)
```
node_modules/  .pnp  .pnp.cjs  .next/  .next-e2e/  .turbo/  .expo/  .expo-shared/
dist/  build/  out/  target/  coverage/  .nyc_output/  .playwright-mcp/
*.tsbuildinfo  tsconfig.tsbuildinfo  *.log  .DS_Store  .gradle/  .cxx/  Pods/
DerivedData/  .worktrees-sync/  *.tar.gz
```
Const slice in sync.rs. Appended: `extra_excludes` from `[sync.projects.<name>]`.
Written to a temp exclude file (std::env::temp_dir + unique name) passed via
`--exclude-from`; delete after. NOTE: `.git` is deliberately NOT excluded — ferrying
gitignored state + `.git` itself is the whole point.

### Plan/apply split (materialize.rs probe/plan/apply idiom)
- **Preview**: `rsync -ani --delete --exclude-from=<f> <src>/ <dst>/` → parse itemized
  output with a PURE function → `SyncPlan { sends: u32, deletes: u32, delete_paths:
  Vec<String> /*cap 15 + "and N more"*/ }`. Deletion lines start `*deleting`; change
  lines match `^[<>ch.][fdLDS]`. Unit-test the parser on canned output (steal real
  samples by reading the script's grep patterns, lines 192-193).
- **Skipped report** (v3 only): `rsync -an -vv --exclude-from=<f> <src>/ <dst>/`, parse
  `^(\[sender\] )?hiding (directory|file) .* because of pattern (.*)$` → pattern→count
  map. Pure fn, unit-tested. Non-v3: print "skipped report unavailable (openrsync)".
- **Apply**: `rsync -a --delete --exclude-from=<f> [--info=progress2 if v3+tty | --progress if tty]
  --backup --backup-dir=<bk_root>/<name> <src>/ <dst>/` with Stdio::inherit for stdout
  (progress), stderr captured-on-failure pattern like git_status_captured. mkdir -p the
  destination parent first (skip in dry-run).
- Flow per direction (push: local→hub; pull: hub→local): preview → print counts
  (`N to send/update, M to delete` + capped deletion list) → skipped report → if
  `--dry-run` stop → confirm `Apply to <name>? [y/N]` unless `--yes` (reuse the existing
  interactive confirm mechanism — find how `rm` confirms, test/common.bash `wt_answer`
  drives it; stdin, NOT /dev/tty, so bats can answer) → apply → `done.`
- Preview rsync exiting non-zero ⇒ hard error with code. Apply non-zero ⇒ error
  including first stderr line.
- push additionally: write manifest (after successful apply); print next-step hint line
  (`pull --install` on the other Mac). pull additionally: `--install` (below).
- `--json` + `--dry-run` ⇒ emit SyncPlan as one JSON line instead of prose.

### Sessions ferry (`--with-sessions`, default off; config `[sync] with_sessions` flips default)
Escaped prefix = local_root with `/`→`-` (e.g. `-Users-davidpena-workspace-worktrees`);
source dirs = `$HOME/.claude/projects/<prefix>*` (glob catches worktree keys). Ferry each
matching dir ADDITIVELY: `rsync -a <src>/ <dst>/` — **no --delete, no backup** — to/from
`<hub>/<name>/.claude-sessions/<dirname>/`. Pull direction: iterate hub store dirs, merge
into `~/.claude/projects/`. Missing store on pull ⇒ info "(hub has no sessions yet)",
not an error. Honor `CLAUDE_PROJECTS` env override (script line 241) for testability.
Print count ferried. Skipped when flag off: one info line mentioning --with-sessions.

### `pull --install`
After successful pull, look up `[sync.projects.<name>] install` in USER config
(~/.config/worktrees/config.toml — user tier argv is allowed, same as ai_cmd/post_create).
Present ⇒ run `bash -c <cmd>` with cwd = local_root, inherit stdio; non-zero ⇒ warn
"rebuild failed — run it manually" (do NOT fail the pull). Absent ⇒ print the manifest
`hint` if any, prefixed "Next:" — NEVER execute the hint. Without `--install`, always
print the Next:/hint line after pull.

### Timestamps / host
Backup stamp + `pushed_at`: follow whatever `sysclock.rs` provides (it shells out to
`date` so bats can shim it — read it first; add a helper there if needed, e.g. epoch +
`%Y%m%d-%H%M%S` formatting). Do NOT add chrono. Host: `hostname` Command, trim, empty on
failure.

### Config reader (config.rs)
`cfg_toml_get` is top-level-string-only (config.rs:88-92). Add a minimal table-aware
accessor for the `[sync]` schema in findings §3.2b: hub (string), with_sessions (bool),
`[sync.projects.<name>]` install (string) + extra_excludes (array of strings). Same
lenient posture as the existing reader (config.rs:83-87): parse error or wrong type ⇒
None/default, never a hard error. Keep it private to what sync needs — don't build a
general config framework.

### Status output (inside repo, human)
Project name, rsync path + v3 flag, local root, hub (or `<none>` + why), branch + dirty
count for the root repo via git.rs helpers, and if the hub manifest exists: pushed_at
(raw epoch is fine, or date -r via sysclock if trivial) + host. `--json` ⇒ one-line JSON
struct (own serde types in sync.rs; do NOT touch model.rs).

## Exit codes
0 ok (including "user answered n" — declined confirm prints `skipped.` like the script;
match `rm`'s existing decline behavior if it differs — consistency with the repo wins).
1 usage/guard/config errors. 3 not used. Hard rsync failures: 1.

## Tests
### bats — `test/sync.bats`
FIRST: in `test/helpers/common.bash` `common_setup`, add `install_fake_cmd rsync` right
next to the docker line (common.bash:23-30) WITH a comment mirroring docker's rationale:
a suite that reaches real rsync is a suite that can `--delete` the developer's files.
Remember: `install_fake_cmd` shims exit 0 and log argv to `$BATS_TEST_TMPDIR/rsync.log`.
Preview parses empty output ⇒ 0 sends / 0 deletes — fine for argv-assertion tests.
Non-trivial preview output needs a hand-written stateful shim in the test body (see
install_fake_tmux for the pattern). `rm "$SHIMS/rsync"` does NOT un-fake (real binary
next on PATH — provision.bats:310); a "no rsync" test must shim `rsync` with `exit 127`?
No — simplest correct: skip a no-rsync test entirely; the discovery-order logic is unit
tested instead.
Always pass `--hub "$BATS_TEST_TMPDIR/hub"` (portable; no /Volumes in CI).

Minimum cases:
1. `sync` bare ⇒ exit 1, usage mentioning push/pull/status.
2. `sync push --dry-run --hub …` inside repo ⇒ exit 0; rsync.log contains `-ani`,
   `--delete`, `--exclude-from`, src `<root>/`, dst `<hub>/<name>/<name>/`; hub dir NOT
   created (dry-run touches nothing — assert no manifest written).
3. `sync push --yes --hub …` ⇒ apply line in rsync.log with `-a`, `--delete`,
   `--backup`, `--backup-dir=…/.worktrees-sync/backups/`; manifest exists on hub with
   correct `name` + `local_root`; NO `--info=progress2` (shim isn't v3 and no tty).
4. push declined (`wt_answer "n"` or however rm-style confirm is driven) ⇒ apply absent
   from rsync.log, manifest absent, exit 0.
5. `sync push` outside any repo ⇒ exit 1.
6. `sync pull --yes --hub …` inside repo ⇒ direction reversed in rsync.log (hub src,
   local dst), backup-dir under local root.
7. Adoption: outside repo, hub prepared with manifest (write one by hand in the test)
   ⇒ `sync pull <name> --hub … --yes` rsyncs into manifest's local_root; without name ⇒
   exit 1 listing `<name>`.
8. Manifest with an extra key (e.g. `install_cmd = "evil"`) on hub ⇒ pull errors, nothing
   rsynced (rsync.log has no apply line).
9. `--with-sessions` push with `CLAUDE_PROJECTS` pointed at a fixture dir containing
   `<escaped-prefix>-x/f.jsonl` ⇒ rsync.log line WITHOUT `--delete` targeting
   `.claude-sessions/`; without the flag ⇒ no `.claude-sessions` line.
10. `sync status --json --hub …` inside repo ⇒ valid JSON (pipe to python3 -c json load
    or jq if available in other tests — copy whatever json.bats does).
11. `pull --install` with a user config `[sync.projects.<name>] install = "touch marker"`:
    marker file created in root. (User config location: common_setup sets isolated HOME —
    write `$HOME/.config/worktrees/config.toml` in the test.)
12. Hub with no pushed set ⇒ pull errors mentioning push.

**Red-first rule (CLAUDE.md)**: bats tests for a NEW feature are born red — run
`test/sync.bats` once BEFORE wiring the dispatch arm (or at any pre-completion point),
save the red transcript into progress notes, then make them green. State in your final
report where the red run happened.

### Unit tests (sync.rs mod tests)
- itemized-preview parser: sends/deletes counts + delete path extraction + cap.
- hiding-pattern parser (the -vv scan).
- hub candidate filter: 0/1/many, denylist, symlink skip.
- escaped-prefix fn.
- manifest: round-trip; unknown field rejected; bad schema rejected.
- exclude-file content includes extra_excludes.
Remember `cargo test -p app --lib` compiles `mod tests` that `check` does not — you're
not touching app, but run it anyway (gates).

## Gates (run ALL, in this order, from repo root — CLAUDE.md traps apply)
```sh
cargo build --release -p worktrees-cli   # FIRST — stale release binary poisons bats
make test > /tmp/bats.log 2>&1; echo "exit=$?"; grep -cE '^not ok' /tmp/bats.log
make lint
cargo test -p worktrees-core 2>&1 | grep -E "^running|^test result"
cargo test -p worktrees-cli  2>&1 | grep -E "^running|^test result"
cargo test -p app --lib      2>&1 | grep -E "^running|^test result"
cd app && ./node_modules/.bin/tsc --noEmit && cargo check -p app   # then cd back
```
- Confirm binary freshness before trusting bats:
  `[ target/release/worktrees -nt crates/worktrees-core/src/sync.rs ] && echo fresh`
- `grep -c` exits non-zero on count 0 — never chain gates with `&&` after it.
- Use `make -C <abs repo root>` if your cwd moved (Bash cwd persists).
- Node for tsc: `nvm use 22.23.2` (app/node_modules already installed).

## Conventions checklist
- All core output via `Ui`; errors carry exit codes via `WtError` where the existing
  code does; CLI prints errors via render::error_line pattern — mirror `skills`' pre-guard
  handling.
- USAGE string (main.rs:13-32): add sync lines matching existing formatting.
- Comments: only for constraints code can't show (repo style — sparse, load-bearing).
- CHANGELOG.md: add `### Added` bullet(s) under `[Unreleased]`.
- New files need no license headers (match existing files).
- If a design detail here conflicts with what you find in the code, follow the CODE's
  convention and flag the deviation in your final report — do not silently improvise.

## Final report (your return value)
Raw data, no prose padding: files touched + line counts; gate transcript (the grep
lines + bats not-ok count + exit codes); where the red-first run happened; deviations
from this brief with one-line reasons; anything punted with TODO(sync-p2) markers.
