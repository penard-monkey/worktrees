# Implementation brief — `worktrees sync` phase 6 (heal excluded-tracked files + post-pull status)

Repo: /Users/davidpena/workspace/worktrees/.worktrees/sync-macs, branch `sync-macs-heal`
(= origin/main, all five sync PRs merged). Do NOT commit. Read FIRST: CLAUDE.md,
findings.md, phase1-5 briefs, `crates/worktrees-core/src/sync.rs` (EXCLUDES const,
`sync_one`, `sync_apply`, the post-apply pull section), `crates/worktrees-core/src/git.rs`.

## The field bug (David, real cross-Mac import, 2026-08-16)
The exclude list (`*.tar.gz`, `build/`, `dist/`, `out/`, `*.log`, …) is "rebuildable
bulk" — but repos TRACK files matching it (casadelvalle: committed `old-plans/*.tar.gz`;
this repo: 25 committed session tarballs). Push skips them → the hub copy's `.git` says
they exist but the working files are absent → a fresh-machine import shows a wall of
`deleted:` in git status. The blobs are NOT lost (`.git` ferries complete) — the working
copies just never arrive. Second, softer issue: an import that faithfully mirrors a
source Mac that was behind origin / dirty LOOKS broken to the user; nothing explains it.

## Scope — two features, core-only (no new commands, no frontend changes)
1. **Heal pass** after every successful PULL apply (CLI `sync_one` AND API `sync_apply`
   — one shared fn, called from both; put it right after `apply()` succeeds for
   `SyncDirection::Pull`, BEFORE the manifest/sessions/install steps' output so the
   report reads in causal order).
2. **Post-pull status note** for the root repo (CLI prose + API `messages`).
- CHANGELOG `[Unreleased]` (create the section — last release rolled it).
- Do NOT change: rsync argv, excludes content, manifest, CLI grammar, app/, mcp.rs.
  Existing bats tests untouched; NEW bats tests are expected.

## 1. Heal pass

**Matcher** — translate the exclude patterns to a repo-relative path matcher. ONE
source of truth: the same `EXCLUDES` const + `proj_cfg.extra_excludes` that build the
exclude file (factor a fn both call — the exclude-file body and the matcher must not
drift). Semantics for the subset we use (this is not a general rsync implementation —
say so in a comment):
- `name/` → matches any path having a COMPONENT equal to `name`.
- `*.ext` (or any pattern with `*`) → glob against the BASENAME (also match a leading
  component for dir-ish globs only if trivial — our list has no `dir*/` shapes; keep it
  basename-only and comment the limitation).
- bare `name` → basename equals `name`.
Pure fn + unit tests: `old-plans/x.tar.gz` ✓ (`*.tar.gz`), `a/node_modules/b.js` ✓
(component), `docs/keep.txt` ✗, `.DS_Store` anywhere ✓, extra_excludes participate,
`tsconfig.tsbuildinfo` exact ✓.

**Walk** — repos to heal: the pulled `local_root` plus every dir under
`local_root/.worktrees/` that is a git worktree (a `.git` FILE — reuse whatever helper
exists; a plain non-worktree dir is skipped silently).

**Detect** — `git status --porcelain` per repo (git.rs helpers). Heal ONLY lines whose
WORKTREE column says deleted and whose INDEX column does not (` D`): an unstaged
deletion of a tracked file. A STAGED deletion (`D `) is mirrored user intent from the
source Mac — leave it. Parse defensively (rename lines `R  a -> b` must not panic).
Filter through the matcher; non-matching deletions are mirrored state — leave.

**Restore** — `git -C <repo> checkout -- <paths…>`, batched (≤200 paths per invocation;
paths after a `--`, never interpolated into a pattern position). Failures: warn with the
first stderr line, continue with the other repos, never fail the pull over a heal.

**Report** — through the existing `Ui`/messages channel, only when N > 0:
`restored N tracked file(s) the transfer skips (excluded as rebuildable): p1, p2, … (+K more)`
— cap the list at ~5. Add one clause covering the honest edge: restored files come back
at their last committed version (an uncommitted change to an excluded file was never
ferried). Silence when nothing was healed.

## 2. Post-pull status note (root repo only)

After a successful pull (and after the heal, so its numbers reflect the healed tree):
branch, ahead/behind upstream, dirty count — via git.rs (`rev-parse --abbrev-ref HEAD`,
`rev-list --left-right --count @{u}...HEAD` — tolerate a missing upstream, skip the
ahead/behind clause), `status --porcelain` line count. Emit ONLY when behind>0 or
dirty>0, one or two lines, e.g.:
`imported state mirrors the source Mac: main is 7 behind origin (git pull to advance), 2 files modified`
Exact wording yours; the point is that mirrored-behind reads as fidelity, not breakage.
Goes to `ui.info` (CLI, non-json) and `SyncApplyOut.messages` (API) — the app modal
already renders messages, so NO frontend change.

## Tests

**bats** (new tests in test/sync.bats; the fake rsync transfers nothing, which is fine —
heal operates on real git state, so build the post-import state by hand):
1. Repo with COMMITTED `data.tar.gz` + `docs/keep.txt`; prepare a hub (manifest + tree
   dir); delete BOTH files from the working tree; `sync pull --yes --hub …` ⇒ exit 0;
   `data.tar.gz` EXISTS again (healed), `keep.txt` still deleted (mirrored intent
   preserved); output contains `restored 1` and names `data.tar.gz`.
2. Staged deletion of `data.tar.gz` (`git rm`) ⇒ pull does NOT resurrect it; no
   `restored` line.
3. A worktree under `.worktrees/` with its own unstaged-deleted tracked `x.log` ⇒ healed
   there too.
4. Clean tree ⇒ no `restored` line, no status note (byte-noise check).
5. Root repo behind upstream (commit on a bare "origin", fetch, reset back) + pull ⇒
   output contains the mirrors-the-source note naming the behind count. If wiring a
   fake upstream in the harness is disproportionate, a unit test on the note-formatting
   fn + a bats test for dirty-only is acceptable — SAY which you did.
**Units**: matcher (cases above), porcelain parse (unstaged vs staged vs rename),
note formatting.
**Red-first** for everything; mutation-prove any test green-by-construction.

## Gates
Full list (release build FIRST + freshness, make test grep'd — expect >309 now, lint,
cargo test core/cli/app, tsc + cargo check -p app, dnd-check, race-check). App code
untouched ⇒ race-check should be trivially green; run it anyway.

## Final report
Raw data: files+counts, gate transcript, red-first notes, deviations, punted. Flag the
wording you chose for both user-facing lines.
