# Findings: `worktrees sync`

## §1 — ~/bin/sync-macs (source material, 425-line bash, read 2026-08-15)

Courier sync of working set between Macs via SSD "hub" (or any mounted path).

**Commands**: `push [project]` (local→hub), `pull [project]` (hub→local), `status`,
`add [name]` (register cwd repo). Project omitted ⇒ cwd detection, else default.

**Flags**: `--hub PATH`, `--yes/-y`, `--dry-run/-n`, `--install` (pull: rebuild),
`--with-sessions` (ferry Claude transcripts). Env overrides: SYNC_HUB, SYNC_LOCAL_ROOT,
SYNC_ITEMS, SYNC_HUB_SUBDIR, SYNC_MAIN_ITEM, SYNC_CONF_DIR.

**Mechanics worth porting**:
- Project registry: builtin case arms + `~/.config/sync-macs/<name>.conf`
  (LOCAL_ROOT, ITEMS_STR, HUB_SUBDIR, MAIN_ITEM, REBUILD_CMD_STR, REBUILD_HINT).
- Hub adoption: push writes `<hub>/<subdir>/.sync-macs-project.conf` manifest; other Mac's
  `pull <name>` copies it into local conf dir — no manual `add` needed there.
  ⚠ manifest carries REBUILD_CMD_STR = **argv from foreign medium** — violates ADR 0001 spirit.
- Hub autodetect: scan /Volumes, denylist (Macintosh HD, .timemachine, TM snapshots,
  davidpena SMB), skip symlinks; exactly 1 candidate ⇒ use, 0 ⇒ error, >1 ⇒ ask --hub.
- rsync selection: prefer Homebrew rsync 3.x (`/opt/homebrew/bin`, `/usr/local/bin`),
  fallback system openrsync; capability flag RSYNC_V3 gates --info=progress2 + the
  "hiding X because of pattern" skipped-report.
- Per-item flow: preview (`rsync -ani --delete`) → counts (send/update vs delete) +
  first 15 deletions → skipped-excludes summary → [y/N] unless --yes → real run
  `-a --delete --backup --backup-dir=<dest>/.sync-macs-backups/<ts>/<item>`.
- Excludes (rebuildable bulk, ~47G→8.5G): node_modules/ .next/ .turbo/ .expo/ dist/
  build/ out/ target/ coverage/ Pods/ DerivedData/ .gradle/ .cxx/ *.log .DS_Store
  *.tsbuildinfo .sync-macs-backups/ *.tar.gz etc.
- Sessions ferry: `~/.claude/projects/<escaped-path>*` ↔ `<hub>/<subdir>/.claude-sessions/`,
  **additive** (no --delete) both ways — union of both Macs' histories. Works because both
  Macs use the SAME native repo path so escaped keys match.
- Rebuild on pull --install: cd MAIN_ITEM && REBUILD_CMD (pnpm install / cargo build).
- Both-Macs-same-path invariant: worktree absolute paths stay valid across machines.

**Documented gotchas (KEEP in port)**:
- Never run git/worktrees from /Volumes copy — worktree abs paths escape the mount;
  prune there can prune the WRONG repo's worktrees.
- Bash traps they hit: `head` SIGPIPE under pipefail silently aborting; capture rsync
  --version to var not pipe (SIGPIPE misreport). (Rust port sidesteps these.)

## §2 — worktrees codebase map (Explore agent, condensed; file:line verified by agent)

**CLI** (`crates/worktrees-cli/src/main.rs`, hand-rolled parsing, NO clap):
- USAGE string main.rs:13-32; pre-guard match main.rs:42-58 (`help/version/skills` —
  skills is pre-guard because user-global, **precedent for sync adoption-pull**);
  git-repo guard main.rs:61-74 (`Project::discover`); dispatch match main.rs:79-108.
- Per-cmd flag parsing idiom: `ops.rs:1463-1488` (cmd_doctor) — loop over &[String].
- Output via `Ui` trait (ui.rs:10-36); CliUi prints, CaptureUi collects for app.
- `--json` idiom: per-command flag + `WORKTREES_JSON=1` env (main.rs:81-82, ops.rs:1486-88).
- Exit codes: error.rs; diag::EXIT_FINDINGS=2, diag::EXIT_NEEDS_CONFIRM (diag.rs:20).

**Core** (`crates/worktrees-core/src/`, 20 modules): git.rs/tmux.rs = thin shell-out
wrappers (deliberate: bats fake-PATH shims intercept; git.rs:1-4). Best rsync-wrapper
model: `git_status_captured` git.rs:77 (passthrough stdout on success, Err(stderr) on
fail). Closest argv-assembly analogue: `provision::compose_down` provision.rs:554-572
(validated paths only, cites ADR 0001).
- User config: config.rs — `config_dir()` :61-70 = `~/.config/worktrees`;
  `cfg_toml_get` :88-92 reads **top-level string keys only** — a `[sync]` table needs a
  new reader. Precedence: flag > env > user config > default (config.rs:3-4).
- Convention (proposal §8): human-edited = TOML, machine = JSON; data under
  `$XDG_DATA_HOME/worktrees/`.
- projcfg.rs = per-repo `.worktrees.toml`, hostile input; `USER_ONLY_KEYS` projcfg.rs:44-45
  (ai_cmd, post_create, hooks, infra, install_cmd, …) → hard parse error, closed key sets
  per scope (survey_keys :441-454).
- store.rs = `.worktrees.places.json`, DirLock + tmp + atomic rename, in-process
  WRITE_LOCK mutex.

**ADR 0001** (docs/adr/0001-no-repo-supplied-argv.md, permanent): nothing a cloned repo
contains may become argv or name a program. Forward path for new capability = declarative
section, tool assembles argv. **Extends naturally to hub media: a manifest that rode in on
an SSD must not supply commands either.**

**Tauri backend** (app/src-tauri/src/lib.rs, 4279 lines, 73 commands, ALL async fn):
- `run_op` helper lib.rs:615-635 → CmdResult {ok, code, output, needs_confirm?, warnings}
  — sync command family fits this shape; model = new_place lib.rs:640-673.
- Progress today: (a) Tauri events from one 3s poll thread (places:changed lib.rs:1298…,
  sessions:busy/done); (b) **`Channel<InvokeResponseBody>` streaming** — term_open
  lib.rs:3068-3126, shell_open :3236 — the mechanism for live rsync output.
- Register in generate_handler![…] lib.rs:3566-3637.

**Frontend** (app/src, no invoke wrapper module — direct `invoke` imports):
- `mutate(promise)` App.tsx:2131-38 (await→fail→refresh); `runCmd(name,args)` App.tsx:2143+
  (banners, re-read state first, report second) — **sync ops use runCmd**.
- Context menus: CtxMenu App.tsx:226-249; project ctx menu App.tsx:3975-4017 — "Fetch
  origin" at :3984 = closest sibling for Sync items.
- Hover idiom: `.mini` buttons in project header App.tsx:3199-3206, CSS reveal
  App.css:247-252 (`.project-h:hover .mini { opacity:1 }`).
- Popover idiom: `.menu-wrap` + `menu` state App.tsx:1286, backdrop `.menu-catch` :3887.
- Mock harness: app/src/mock/install.ts — one switch(cmd) :501-1200, add case arms;
  `emitEvent("places:changed")`; latency knobs `?slowlist=ms` idiom :68-71; escape
  hatches `window.__mock.*` :1268-1324.

**bats**: test/helpers/common.bash — SHIMS dir prepended to PATH :19-20;
`install_fake_cmd <name>` :99-106 logs argv → `$BATS_TEST_TMPDIR/<name>.log`, exit 0.
**docker is faked ALWAYS** (:23-30) so the suite can never touch the real daemon —
**identical rationale mandates faking rsync always** (real rsync --delete could eat real
files). Argv assertions à la provision.bats:232-233. Caveats: non-zero-exit rsync needs a
hand-written stateful shim (see install_fake_tmux); `rm $SHIMS/cmd` does NOT un-fake
(real binary found next on PATH) — provision.bats:310.

**ROADMAP/DESIGN**: no existing sync/SSD/transfer item anywhere. DESIGN.md §"Extended CLI
surface" (:91) and §"Tauri architecture" (:405) are where the design doc slots in.
DESIGN.md §"Infra convention" (:320) is SUPERSEDED by ADR 0001 — don't build on it.

## §3 — Design

### 3.1 Concept mapping (sync-macs → worktrees)
| sync-macs | worktrees port |
|---|---|
| project registry (case arms + conf files) | **the workspace IS the registry** (app) / `Project::discover` (CLI). No separate `add` needed for known projects. |
| ITEMS = dirs under LOCAL_ROOT | **sync unit = one project root dir** (repo + its `.worktrees/`). Multi-repo sets (casadelvalle's 2 items) = 2 workspace projects; "push both" = per-project or later `--all`. |
| `.sync-macs-project.conf` hub manifest (sourced bash!) | `<hub>/<name>/.worktrees-sync.toml` — **data only** (name, local_root, pushed_at, host, schema ver). Parsed strictly; any command-like key = hard error (ADR 0001 extended to media). |
| REBUILD_CMD ferried via manifest | **REFUSED.** Rebuild = user-scoped config on the receiving Mac (same tier as post_create/install_cmd). Manifest may carry a human-readable HINT string, printed never executed. |
| ~/.config/sync-macs/*.conf | `[sync]` in `~/.config/worktrees/config.toml` (needs table-aware reader) — hub path pin, per-project overrides, extra excludes, sessions default. |
| SSD autodetect + denylist | port as-is (flag > env WORKTREES_SYNC_HUB > user config > /Volumes scan, single-candidate rule). |
| excludes heredoc | default const in sync.rs; user-extendable via config (`extra_excludes`). Rename backup dir → `.worktrees-sync/backups/<ts>/`, self-excluded. |
| --with-sessions additive ferry | port as-is; keys off project path; store at `<hub>/<name>/.claude-sessions/`. |
| per-item [y/N] | CLI: interactive + `--yes`/`--dry-run`. App: preview → confirm modal (needs_confirm channel exists: diag::EXIT_NEEDS_CONFIRM). |

### 3.2 CLI grammar (AMENDED 2026-08-15 pre-implementation — registry-free simplification)
```
worktrees sync push   [--hub PATH] [--dry-run|-n] [--yes|-y] [--with-sessions] [--json]
worktrees sync pull   [name] [--hub PATH] [--dry-run|-n] [--yes|-y] [--with-sessions] [--install] [--json]
worktrees sync status [--hub PATH] [--json]
```
Rationale: CLI has no project registry (that's the app's workspace). You push from the
machine that HAS the project ⇒ push/status are cwd-scoped, no name arg. You pull-adopt on
the machine that DOESN'T ⇒ pull takes optional name, resolved from the hub manifest.
- push/status inside repo: cwd project via `Project::discover`.
- status outside repo: hub-level status — list `<hub>/*/.worktrees-sync.toml` manifests.
- pull inside repo: that project (name arg must match manifest or be absent).
- pull outside repo + name: **adoption** — manifest supplies local_root (data), destination
  shown, explicit confirm required (or --yes). Outside + no name: error listing available
  hub manifests.
**Placement: pre-guard block** (like `skills`, main.rs:42-58) since adoption/hub-status
run outside any repo. `sync` bare / unknown ⇒ usage, exit 1.

### 3.2b User config schema (`~/.config/worktrees/config.toml`, user tier only)
```toml
[sync]
hub = "/Volumes/FastSSD"      # optional pin; else autodetect
with_sessions = false          # default for the flag

[sync.projects.worktrees]      # key = project name (basename of root)
install = "cargo build"        # pull --install runs this (user argv tier — allowed)
extra_excludes = ["foo/"]      # appended to builtin exclude set
```
Needs a table-aware reader (cfg_toml_get is top-level-string-only); same lenient posture
(parse error ⇒ None/defaults, config.rs:83-87 rationale).

### 3.3 Core engine (`crates/worktrees-core/src/sync.rs`)
- Probe/plan/apply split (materialize.rs idiom):
  - `probe`: find rsync (v3 preferred, openrsync fallback — port path list), resolve hub,
    read manifest if present.
  - `plan` (= preview): `rsync -ani --delete --exclude-from=<tmp>` → parse itemized lines
    → `SyncPlan { sends: u32, deletes: u32, delete_paths: Vec (capped), skipped: Vec<(pattern,count)> }`.
    Pure parse fn = unit-testable. Serializable for --json + app.
  - `apply`: `rsync -a --delete --backup --backup-dir=<dest>/.worktrees-sync/backups/<ts>
    [--info=progress2]` — argv fully tool-assembled, only validated paths interpolated.
- Sessions ferry: additive `rsync -a` (NO --delete) both directions, per escaped-path dir.
- Manifest write on push; strict TOML parse on read (serde deny_unknown_fields; version field).
- **New safety (worktrees-native, script can't do these)**:
  1. **Hub-copy guard**: manifest lives at hub copy root ⇒ `worktrees` ops (or at least
     sync + doctor) detect "this tree is a hub copy" ⇒ refuse mutating ops there. Kills
     the script's worst GOTCHA (pruning wrong repo's worktrees from /Volumes) structurally.
  2. **Live-session guard on pull**: engine knows tmux sessions per project — pull with
     active sessions ⇒ needs_confirm with session list (rsync --delete under a live
     shell = foot-gun the script silently allowed).
  3. Refuse pull when cwd is inside the destination being rewritten? No — cwd irrelevant
     in Rust (no sourcing); but warn if destination == a path currently under /Volumes
     (i.e., accidentally pulling INTO the hub).

### 3.4 Tauri surface
- `sync_status(repo)` — hub detection, manifest stamp (last push host/time), per-direction
  dirty hint. Cheap; callable on menu open.
- `sync_preview(repo, direction, with_sessions)` — returns SyncPlan JSON.
- `sync_apply(repo, direction, opts, on_progress: Channel)` — streams parsed
  `--info=progress2` (pct, current path) as events on the channel; final CmdResult;
  emits `places:changed` after pull. All async fn (hard rule).
- Mock: 3 case arms + `?slowsync=ms` knob + `__mock.syncFail()` escape hatch. Mock answers
  instantly ⇒ **real-app run mandatory before release** (CLAUDE.md timing rule).

### 3.5 App UI
- **Entry point (the "hover menu")**: hover-revealed `.mini` sync button (⇄) in
  `.project-h` next to `+`/`×` (App.css:247-252 idiom) → opens popover (`.menu-wrap`
  idiom): header = detected hub (or "no SSD"), items: *Push to <hub>…*, *Pull from
  <hub>…*, *Status*, checkbox *include sessions*. Same items duplicated in the project
  ctx menu next to *Fetch origin* (App.tsx:3984) — right-click parity.
- **Flow**: item click → `sync_preview` → modal: N send/update, M delete (danger-styled,
  sample paths), skipped summary → Confirm → progress bar (Channel) → summary line.
  Cancel = no-op. Deletes > 0 gets the two-step danger treatment (armed confirm,
  same family as Remove worktree).
- Long-run UX: v1 modal w/ progress bar is enough; dock pane streaming = later polish.

### 3.6 Test strategy
- bats: `install_fake_cmd rsync` in common_setup **always** (docker precedent — a test
  reaching real rsync can --delete real files). `test/sync.bats`: argv assertions
  (excludes, --backup-dir, no --delete on sessions), missing-hub error, >1 volume
  ambiguity, manifest write + adopt + reject-argv-keys, needs_confirm paths. Preview
  parse: hand-written shim emitting canned -ani output. Every new test shown red first
  (repo rule).
- core units: plan parser, exclude set, manifest serde rejects, hub-resolve with injected
  volume list (no real /Volumes in tests).
- App: mock arms + Playwright happy path; then real `sandbox.sh --app` run (timing bugs).

## §4 — Implementation phases (each ~1 PR, gates per repo CLAUDE.md)
**Phase 1 = full CLI parity** (David retires ~/bin/sync-macs at phase-1 merge, so the
whole courier workflow he uses daily must land in one PR):
1. **Core + CLI, script parity.** sync.rs (probe/plan/apply, manifest, excludes, backups),
   CLI push/pull/status + USAGE, adoption pull outside repo, sessions ferry
   (--with-sessions, opt-in), `--install` from user-scoped config, `--json`.
   bats (fake rsync always) + units. Gate: one real SSD round-trip by hand before the
   script is deleted.
2. **Guards.** Hub-copy marker guard (refuse mutating ops on a /Volumes copy),
   live-session guard on pull (needs_confirm w/ session list).
3. **App backend + minimal UI.** 3 Tauri commands, mock arms, ctx-menu items +
   preview/confirm modal (await + spinner, no streaming yet).
4. **Polish.** Hover popover, Channel progress streaming, docs (DESIGN.md §, CHANGELOG),
   real-app timing pass (sandbox.sh --app), release.
- v2 parking lot: SSH targets (rsync -e ssh — target abstraction shouldn't preclude),
  workspace-level "push all", scheduled/auto sync, network-share auto-detect.

## §5 — Real hub hardware (checked 2026-08-15, drive plugged in)
- Hub = `/Volumes/SanDisk`, 931Gi total / 919Gi free.
- Autodetect will resolve it unambiguously: /Volumes contains only denylisted entries
  (.timemachine, TM localsnapshots, Macintosh HD symlink) + SanDisk ⇒ single candidate.
- Existing sync-macs data (Aug 7): `/Volumes/SanDisk/{casadelvalle,worktrees}/`.
  `worktrees/` holds `.claude-sessions/`, `.sync-macs-backups/`, tree copy at
  `worktrees/worktrees` (135M).
- **Path overlap, works in our favor**: old tree-copy path `<hub>/worktrees/worktrees`
  == NEW layout's tree path exactly. First new push mirrors incrementally over Aug 7
  data (fast) and drops `.worktrees-sync.toml` alongside; stale `.sync-macs-project.conf`
  + `.sync-macs-backups/` linger as inert siblings until David deletes them manually
  (his stated preference). No migration step needed.

## David's answers (2026-08-15, via AskUserQuestion)
1. Hub layout: **fresh** — no sync-macs compat; one re-push per project; old SSD data
   left in place until manually deleted.
2. SSH: **hub-only v1**; abstraction keeps SSH open for v2.
3. Sessions ferry: **opt-in** (flag + app checkbox), default off.
4. Script: **retire at phase-1 merge** → phase 1 must be full parity (folded in above).
