# Implementation brief — `worktrees sync` phase 4 (streaming progress + polish)

Repo: /Users/davidpena/workspace/worktrees/.worktrees/sync-macs, branch `sync-macs-stream`
(= origin/main; phases 1-3 merged). Read FIRST: CLAUDE.md (all Tauri rules), findings.md,
phase1-3 briefs (conventions), then the code you extend: `crates/worktrees-core/src/sync.rs`
(the `apply`/`sync_apply` pair), `app/src-tauri/src/lib.rs` (sync commands ~:1929+,
`term_open` :3068-3126 — THE Channel streaming model), `app/src/App.tsx` (SyncModal,
sync state, ctx menu group, `.mini`/popover idioms :3199/:1286), `app/src/mock/install.ts`
(sync arms; how the mock handles `transformCallback`/channels — read how `term_open` is
mocked before inventing anything), `app/src/settings.ts` + the Settings flow
(`settings_info`/`get_settings`/`set_settings`, ui-state.json whole-blob rule).

Motivation (David, 2026-08-16): "for larger items will it just stay at 'Pushing…'?" —
yes, today. An 8.5G first push is minutes of frozen button. This phase fixes that and
ships the hover menu he asked for on day one.

## Scope — four items
1. **Streaming progress** into the modal (headline).
2. **Hover sync popover** on the project row.
3. **`with_sessions` persistence** (global setting).
4. **`--install` control** in the pull modal.
Plus CHANGELOG. **Do NOT**: change CLI behavior or argv (bats untouched = gate, again);
no version bumps; manifest schema frozen.

## 1. Streaming progress

**Core** (`sync.rs`): `sync_apply` gains a progress sink — suggested shape:
```rust
pub struct SyncProgress {
    pub percent: Option<f32>,      // overall, from progress2's to-chk/% token
    pub rate: Option<String>,      // "12.34MB/s" as rsync prints it
    pub current: Option<String>,   // most recent file name (name1)
}
pub fn sync_apply(req, confirmed, install,
    progress: Option<&mut dyn FnMut(SyncProgress)>) -> Result<SyncApplyOut, String>
```
- `None` ⇒ exactly today's behavior (the CLI path and any caller that doesn't stream).
  The CLI's `sync_one` does NOT go through `sync_apply` — leave its inherited-stdout
  `apply()` untouched; bats proves it.
- `Some(cb)` ⇒ spawn rsync with stdout PIPED and (v3 only) `--info=progress2,name1`
  appended to the same argv `apply()` builds — factor, don't duplicate, the argv
  assembly so the two paths cannot drift. Read stdout incrementally; **split on BOTH
  `\r` and `\n`** — progress2 rewrites its line with `\r`, and a `\n`-only reader sees
  one giant line at the end (i.e. no progress at all). Parse each fragment:
  - progress2 line: bytes, `NN%`, rate, elapsed, `(xfr#i, to-chk=a/b)` → percent from
    the `%` token (f32; `to-chk` is available if the token is missing), rate as printed.
  - anything else non-empty = a filename (name1) → `current`.
  Pure parser fn (`parse_progress_fragment(&str) -> Option<...>`) + unit tests: canned
  progress2 fragments with `\r` separators, name lines, the summary lines rsync prints
  at the end (must not be mistaken for filenames — filter the known trailer shapes:
  `sent … bytes`, `total size is …`), malformed noise.
- **openrsync (v3=false)**: no progress flags exist; run piped anyway, emit `current`
  from `-v`?? NO — do not add `-v` (changes argv shape/verbosity risk); emit nothing
  and let the modal show its indeterminate state. `SyncPreviewOut.skipped_available`
  already tells the frontend v3-ness — reuse it (or add a field if cleaner).
- stderr stays captured for the failure path exactly as today.

**Tauri** (`lib.rs`): `sync_apply` gains `on_progress: Channel<SyncProgress>` (serde
Serialize on the struct). Forward each callback event. Keep the final `CmdResult`
return unchanged. Throttle: at most ~15 events/sec (progress2 can emit hundreds; a
flooded IPC channel is its own jank) — coalesce in the reader loop, always send the
LAST fragment of a read chunk.

**Modal** (`App.tsx`/`App.css`): during apply —
- v3: determinate progress bar (width % off tokens.css vars, no UI libs), `NN%` text,
  rate, current file (middle-truncated, `direction: rtl` trick or JS truncation — your
  call, but it must not reflow the modal width).
- non-v3 or no event yet: existing indeterminate "Pushing…" state.
- Progress state must live so a re-render doesn't reset the bar (module-scope component,
  state via props/refs — the remount rule).

## 2. Hover sync popover (the original ask)

`.mini` button (`⇄`, title "Sync") in the project header row next to the existing `+`/`×`
(App.css:247-252 reveal idiom). Click → popover anchored to it (`.menu-wrap` + `menu`
state + `.menu-catch` backdrop — the topbar popover pattern, App.tsx:1286/:3535+):
- header: hub basename, or the no-hub reason (dim), or "hub copy" disabled state —
  same `sync_status` data the ctx menu already fetches (fetch on popover open; reuse
  the existing `syncStatus` cache/state, don't duplicate).
- items: `Push to <hub>…`, `Pull from <hub>…` → the SAME open-modal handlers the ctx
  menu uses (extract if they're inline); a dim status line: `last push: <ago> from
  <host>` or `never pushed` (there's an existing relative-time helper somewhere in
  App.tsx — search before writing one).
- Popover closes when the modal opens (an armed/open menu must not survive under a
  modal — closeMenu discipline, App.tsx:2263-2273 family).
- Drag interplay: `.mini` buttons already coexist with navdrag — copy whatever
  stopPropagation the `+` button does.

## 3. `with_sessions` persistence

Global flat setting (NOT per-place — the `place_panels` seed trap in CLAUDE.md does not
apply, keep it out of that record). Follow the existing Settings key flow end-to-end:
backend `Settings` struct default false → `get_settings`/`set_settings` → frontend
`settings.ts` type → modal checkbox initial value ← setting; toggling it writes the
setting (debounced like other settings writes if that's the pattern). Mock: settings
fixture gets the key. If any part of that chain needs a migration/compat shim beyond
"serde default", STOP and note it instead of inventing one.

## 4. `--install` control (pull modal)

`SyncPreviewOut` gains `install_cmd: Option<String>` (the user's
`[sync.projects.<name>] install`) — the modal's pull variant shows a checkbox
`Run rebuild after pull: <cmd>` only when configured (absent ⇒ no checkbox, the
after-pull hint text still lands in the success output as today). Checked ⇒
`sync_apply(..., install: true)`. Default unchecked. CLI unchanged.

## Tests
- Unit: progress parser (the cases above), argv-factoring test if you add one seam
  (the streaming argv == apply argv + the two info flags).
- bats: UNTOUCHED and green (CLI path identical). If a bats test fails, the refactor
  leaked — fix the leak, not the test.
- Mock: `sync_apply` emits staged progress events through the mocked Channel under
  `?slowsync` (e.g. 5 events 0→100 with filenames); follow the mock's existing channel
  handling for `term_open`. Settings key in the mock settings fixture.
- Playwright (harness, same rules as phase 3 — port ≠1420, background task, one click
  per evaluate): (a) `?slowsync=3000` push — bar VISIBLE and percent strictly increases
  across two sampled reads (assert two snapshots, not animation); (b) hover popover:
  `.mini` reveal on hover (getComputedStyle opacity), click opens popover, `Push…` opens
  the modal and the popover is GONE; (c) sessions checkbox persists across a reload
  (mock settings round-trip); (d) install checkbox present on pull when mock config has
  the cmd, absent otherwise; (e) non-v3 fixture (add a `?openrsync` knob or reuse
  skipped_available=false) shows indeterminate state, no bar.
- Red-first where bats/unit-shaped (parser tests born red pre-parser is fine; state it).

## Gates — full list as phase-3 brief (release build + freshness, make test grep'd,
lint, three cargo crates, tsc + cargo check -p app, dnd-check, race-check). App code
touched ⇒ race-check matters: sync state interacts with refresh via places:changed —
if you touch ANY of refresh/commitWs/patchDeclared/mutate, run race-check and say so.

## Final report
Raw data: files+counts, gate transcript, red-first notes, Playwright results (each
check, pass/fail), deviations w/ reasons, punted items. Flag anything that should go
in the release notes beyond CHANGELOG.
