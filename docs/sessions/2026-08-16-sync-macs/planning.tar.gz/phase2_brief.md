# Implementation brief — `worktrees sync` phase 2 (guards)

Repo: /Users/davidpena/workspace/worktrees/.worktrees/sync-macs, branch `sync-macs-guards`
(= origin/main, which now contains phase 1: `crates/worktrees-core/src/sync.rs`,
`test/sync.bats`). Read first: CLAUDE.md (gates/traps), findings.md §3.3 (guard design),
phase1_brief.md (conventions you must stay consistent with), then the phase-1 code
itself — sync.rs is the file you are extending.

Motivating incident (findings/progress, 2026-08-15): a real-SSD round-trip showed a
`pull --yes` move 37 files immediately after a 0/0 dry-run — the app's 3s poll re-touches
`.git/index` mtimes on a live machine, so rsync re-copies over a tree that is actively
in use. Same family: running ANY mutating worktrees op inside the /Volumes hub copy can
prune the wrong repo's worktrees (the old script's worst GOTCHA). Phase 2 makes both
structurally hard.

## Scope — exactly two guards
- **Guard A: hub-copy guard.** Mutating ops refuse to run inside a hub copy.
- **Guard B: live-session guard on pull.** `sync pull` onto a project with live tmux
  sessions requires an interactive answer; `--yes` alone refuses.
- Plus: doctor reports hub-copy state; CHANGELOG `[Unreleased]` entries; bats + units.
- **Do NOT touch**: app/, mcp.rs, version numbers, the phase-1 rsync argv, manifest
  schema (no new fields), `~/bin/sync-macs`. **Do NOT commit.**

## Guard A — hub-copy detection + refusal

Detection (pure fn in sync.rs, e.g. `hub_copy_of(root: &Path) -> Option<Manifest>`):
the project root's PARENT directory contains `.worktrees-sync.toml` (sync::MANIFEST)
that (a) parses, (b) has `name == basename(root)`, and (c) has `local_root != root`
(a hub copy never sits at its native path — this kills the false positive where a user
pushes FROM the native tree whose parent somehow holds a manifest). A missing file is
the fast path — one stat. A file that exists but fails (a)/(b)/(c) ⇒ not a hub copy.

Wire-up: whatever is cheapest and most idiomatic given `Project::discover` — either a
lazily-computed check the ops call, or a field on `Project`. Read project.rs first and
follow its grain; don't force a redesign. The refusal must cover the mutating cmd_* set
(`new`, `switch`, `open`, `close`, `rm`, `relink`, `provision`, `init`) **and both sync
directions** (`push` from a hub copy is the wrong direction by definition; `pull` into
one would mirror hub→hub). `ls`, `doctor`, `sync status` stay allowed — status/doctor
are how you find out what the tree is.

Error message must name the way out, e.g.:
`this is a hub copy (pushed from <host>) — run worktrees at the native path: <local_root>`
Exit 1 via the normal error channel. Check how each cmd_* reports guard failures today
and match it; the check should live in ONE place, not be pasted into eight functions —
find the natural choke point (ops.rs entry? a helper both ops.rs and sync.rs call?).

Doctor: a finding (diag.rs conventions — pick the severity that matches "you are
standing somewhere you should not mutate"; read how existing findings choose severity
and exit codes) reporting hub-copy state with the native path. Do not make plain `ls`
slower for normal projects: the parent-manifest stat only, no extra subprocesses.

## Guard B — live sessions on pull

After phase-1's `sync_one` resolves `local_root` for a PULL (both the in-repo case and
adoption), and before the Apply confirm:
1. Determine the project's live tmux sessions. The engine already knows how sessions map
   to a project (`<prefix>-<slug>`, tmux.rs; project.rs's snapshot lists them) — reuse
   that machinery against the DESTINATION root. Adoption onto a machine where
   `local_root` doesn't exist yet ⇒ no sessions, guard passes silently. If `local_root`
   exists but isn't a discoverable project, treat as no sessions.
2. No live sessions ⇒ behavior unchanged (this must be byte-identical for the common
   case — phase-1 bats tests must not need edits for it; if one does, that's a signal
   you changed default behavior, stop and reconsider).
3. Live sessions + interactive (no `--yes`): print a warning block BEFORE the existing
   `Apply to <name>? [y/N]` — list each live session by name, one line, plus one line of
   consequence ("pull mirrors over a tree these sessions are using"). The existing
   single Apply confirm then covers it — do NOT add a second question.
4. Live sessions + `--yes`: REFUSE. Print the same session list, then an error telling
   the user to close the sessions or run without `--yes`. Exit code: use
   `diag::EXIT_NEEDS_CONFIRM` (read diag.rs for its value and existing usage — the
   semantic is exactly "a human must answer"). `--yes` must never silently mirror over
   a live session — that is the entire guard.
5. `--dry-run` never triggers the guard (it writes nothing).

tmux is already faked by bats (`install_fake_tmux`, common.bash — it models a session
registry). Read how existing tests create/register fake sessions and reuse that.

## Tests

bats (`test/sync.bats` — extend it, keep its style; or a new `test/sync-guards.bats`
if the file gets unwieldy):
1. Hub-copy layout (`$TMP/hub/proj/proj` = a real `make_repo`-style git repo, manifest
   written at `$TMP/hub/proj/.worktrees-sync.toml` with `name = "proj"`, `local_root`
   pointing elsewhere): from inside the copy, `worktrees new x` exits 1 and names the
   native path; `worktrees ls` still works; `worktrees sync push --hub …` and
   `sync pull --yes --hub …` both refuse; NOTHING lands in rsync.log.
2. False-positive check: same layout but manifest `name = "other"` ⇒ ops run normally.
   And the native-path case: manifest whose `local_root` EQUALS the root ⇒ not a hub
   copy (this is what a normal `<hub>` layout looks like to the machine that pushed…
   actually it is not — think it through with the real layout and encode the truth in
   the test name).
3. doctor inside a hub copy surfaces the finding (assert on message + whatever exit
   code diag conventions give it).
4. Live-session pull: register a fake tmux session for the project, `sync pull --yes
   --hub …` ⇒ refused, exit = EXIT_NEEDS_CONFIRM's value, output lists the session
   name, rsync.log has NO apply line. `wt_answer "y" sync pull --hub …` ⇒ proceeds
   (apply present). No sessions ⇒ `--yes` proceeds exactly as phase 1 (this is test
   sync.bats:103's existing behavior — it must keep passing untouched).
5. Adoption pull with no local tree ⇒ guard silent (exit 0 path unchanged).

Units (sync.rs mod tests): `hub_copy_of` — hit, name mismatch, local_root == root,
missing file, unparseable file.

**Red-first (CLAUDE.md)**: new tests must be shown red. For guard tests that's easy —
run them before wiring the guard. Report where the red run happened.

## Gates — identical list and order to phase-1 brief (rebuild release FIRST, freshness
check, `make test` with not-ok grep, make lint, three cargo test crates with
`grep -E "^running|^test result"`, app tsc + cargo check). All from repo root; watch
the cwd trap.

## Conventions
Same as phase 1: Ui trait only, comments only for constraints, match existing error
wording/glyphs, CHANGELOG under `[Unreleased]` (it already has the phase-1 section —
add to it, don't duplicate the heading). If code reality contradicts this brief, follow
the code and flag it.

## Final report
Raw data: files touched + line counts, gate transcript, red-first location, deviations
with one-line reasons, anything punted.
