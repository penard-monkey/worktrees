# Implementation brief — `worktrees sync` phase 3 (app backend + minimal UI)

Repo: /Users/davidpena/workspace/worktrees/.worktrees/sync-macs, branch `sync-macs-app`
(= origin/main; phases 1+2 merged: sync engine + guards in
`crates/worktrees-core/src/sync.rs`, tests in `test/sync.bats`).

Read FIRST, in order: CLAUDE.md (gates + the Tauri "hard-won rules" section — every
line of it applies to this phase), findings.md §2 (Tauri/frontend map with file:line),
§3.4-§3.5 (app design), phase1_brief.md + phase2_brief.md (conventions), then the code:
`crates/worktrees-core/src/sync.rs`, `app/src-tauri/src/lib.rs` (run_op lib.rs:615-635,
new_place :640-673 as the command model, generate_handler :3566-3637), `app/src/App.tsx`
(runCmd ~:2143, project ctx menu :3975-4017, CtxMenu :226-249, menu-catch/popover
idioms), `app/src/mock/install.ts` (switch :501-1200, knobs :56-71, __mock :1268-1324),
`crates/worktrees-cli/src/mcp.rs` (how mutating tools dispatch).

## Scope
1. **Core: extract a programmatic sync API** (no CLI behavior change — `test/sync.bats`
   must pass UNTOUCHED; that is the regression gate for this refactor).
2. **Tauri commands**: `sync_status`, `sync_preview`, `sync_apply` (+ registration).
3. **Close the two carried guard gaps**: hub-copy refusal in the app's `run_op` path
   and in `mcp.rs`'s mutating tools.
4. **Mock harness**: three arms + `?slowsync[=ms]` knob + `window.__mock.syncFail()`.
5. **UI (minimal)**: Sync section in the project context menu + preview→confirm modal
   + busy/summary via `runCmd` semantics. NO hover popover, NO Channel streaming —
   phase 4.
6. CHANGELOG `[Unreleased]`.
- **Do NOT**: change rsync argv, manifest schema, CLI flags/output; no version bumps;
  do not edit phase-1/2 bats tests (adding a new bats file/test only if something
  CLI-visible changes — it should not).

## 1. Core API extraction (sync.rs)

Today `sync_one`/`cmd_status` parse CLI opts and drive a `Ui`. The app needs data in,
data out. Refactor INSIDE sync.rs (pub API, CLI wrappers call it):

```rust
pub struct SyncRequest {
    pub root: PathBuf,            // project root (app always knows it; no cwd discovery)
    pub direction: SyncDirection, // Push | Pull
    pub hub: Option<String>,      // None = env/config/autodetect (existing resolve_hub)
    pub with_sessions: Option<bool>,
}
pub struct SyncPreviewOut {
    pub plan: SyncPlan,                    // sends/deletes/delete_paths (already Serialize)
    pub skipped: Vec<(String, u32)>,       // hiding report (empty if !v3)
    pub live_sessions: Vec<String>,        // Guard B data — pull only, else empty
    pub hub: String, pub src: String, pub dst: String,
    pub name: String,
}
pub fn sync_preview(req: &SyncRequest) -> Result<SyncPreviewOut, String>;
/// `confirmed` = a HUMAN answered a prompt that showed them the live sessions.
/// false ⇒ live sessions still refuse (the CLI's --yes semantics).
pub fn sync_apply(req: &SyncRequest, confirmed: bool, install: bool)
    -> Result<SyncApplyOut, String>;   // re-checks guards; returns needs_confirm data
pub fn sync_status_data(root: Option<&Path>, hub_flag: Option<&str>) -> StatusJson;
```
Shape details are yours — the REQUIREMENTS are: (a) hub-copy guard enforced inside
these fns (not only in callers); (b) `sync_apply(confirmed=false)` with live sessions
returns a needs-confirm outcome carrying the session list rather than applying — and
**re-lists sessions at apply time** (the preview's list may be stale); (c) manifest
still parsed before any pull rsync; (d) `StatusJson` becomes `pub` (it already derives
Serialize). CLI `cmd_sync` keeps its exact output by delegating to these — byte-for-byte
(bats enforces).

## 2. Tauri commands (app/src-tauri/src/lib.rs)

All `async fn` (CLAUDE.md: sync handlers freeze the UI — ironic here). Place near
`provision` (~:1906+), register in `generate_handler![…]` (list currently ends with no
trailing comma — check before appending).

- `sync_status(repo: String) -> Result<serde_json::Value, String>` — core
  `sync_status_data`; cheap, called when the menu opens. Include whether the repo IS a
  hub copy (the menu disables sync actions there).
- `sync_preview(repo: String, direction: String, with_sessions: bool)
  -> Result<serde_json::Value, String>` — serialized `SyncPreviewOut`.
- `sync_apply(app: AppHandle, repo, direction, with_sessions, confirmed: bool, install: bool)
  -> Result<CmdResult, String>` — maps the core outcome into the existing `CmdResult`
  shape (lib.rs:590-613): needs-confirm outcome ⇒ `needs_confirm: true` + session list
  in `output`; success ⇒ ok. After a successful PULL emit `"places:changed"`
  (Emitter — lib.rs:1298 pattern). Log via the same `applog` conventions run_op uses.
  Failures must reach the frontend as values, never be swallowed (CLAUDE.md).

**Guard gap A (app)**: `run_op` (lib.rs:615-635) gets a `sync::hub_copy_refusal` check
on its repo before running the op — one place, covers every op-shaped command the app
invokes. Return it as a failed `CmdResult` (ok:false, the message as output), NOT an
Err — the frontend renders op failure banners from CmdResult.

**Guard gap B (mcp)**: read mcp.rs's dispatch; every mutating tool path gets the same
refusal (match how mcp reports op errors today). Add/extend an mcp unit test in the cli
crate proving a mutating call inside a hub-copy layout is refused (`cargo test -p
worktrees-cli` covers mcp — see existing tests there for the harness pattern).

## 3. Mock harness (app/src/mock/install.ts)

Three `case` arms with module-level fixture state:
- `sync_status`: fixture hub `"/Volumes/MockSSD"`, pushed_at/host when `pushed`.
- `sync_preview`: plausible plan (e.g. 12 sends / 2 deletes with sample paths, skipped
  list); pull direction includes `live_sessions: ["wt-mock-a"]` when the fixture flag
  says so (make one — default OFF so the happy path stays simple).
- `sync_apply`: `confirmed=false` + fixture live sessions ⇒ CmdResult with
  needs_confirm; else flips `pushed`, returns ok, `emitEvent("places:changed", {})` on
  pull.
- `?slowsync[=ms]` knob (copy the `?slowlist` idiom, install.ts:68-71) delaying all
  three. `window.__mock.syncFail()` makes the next apply fail with an rsync-ish error
  (escape-hatch idiom :1268-1324). `?nohub` (or a `__mock` toggle — your call) for the
  no-SSD state.

## 4. UI (app/src/App.tsx + App.css)

**Entry**: a "Sync" group in the PROJECT context menu, placed by *Fetch origin*
(App.tsx:3984): `Push to <hub>…`, `Pull from <hub>…` (hub basename from a `sync_status`
fetched when the ctx menu opens — cheap; while unknown, plain "Push to hub…"). No hub ⇒
items disabled with the reason as `title`. Repo is a hub copy ⇒ the whole group
disabled ("this is a hub copy"). With-sessions: a small checkbox row inside the modal,
NOT a menu item (persist last choice in ui-state settings ONLY if a matching settings
key pattern is trivial — otherwise default false every time; do not invent settings
plumbing).

**Flow** (component at MODULE SCOPE — CLAUDE.md: components inside App() remount every
render): click → `sync_preview` → modal:
- header `Sync push — <project>` / pull;
- counts line; deletions list (danger styling, capped — the payload is already capped);
- skipped summary line;
- pull + live_sessions ⇒ warning block listing them (this IS the human answer Guard B
  wants — confirming the modal passes `confirmed: true`);
- buttons: Cancel / `Push`|`Pull` (danger-styled when deletes > 0). No second arming —
  the modal is already an explicit answer (matches CLI's single confirm).
- confirm → `sync_apply` via `runCmd` semantics (App.tsx:2143 — busy banner for the
  duration, re-read state first, report second). Modal shows a spinner while awaiting
  (mock's `?slowsync` is how you see it). Result: success line (sends/deletes applied)
  or the error, in the modal or the existing banner system — follow whichever pattern
  `remove_place` uses for its confirm flow.
- `needs_confirm` coming back from apply (sessions appeared between preview and apply):
  re-render the modal's warning block with the fresh list; the user may confirm again.

Styling: existing tokens/classes (`.ctxmenu`, sheet/modal patterns — find how
ProjectSheet or the remove-confirm renders and stay in-family). Assert layout in the
harness via `getComputedStyle` for at least the modal's visibility state (CLAUDE.md).

**Playwright/mock checks** (drive the harness headless; CLAUDE.md rules: ONE click per
browser_evaluate, read state in the NEXT call; vite on a port ≠ 1420; kill-check by
CONTENT not port; launch as a real background task, never `nohup` in a tool call):
- happy push: menu → modal shows counts → confirm → success, `pushed` state visible in
  a later `sync_status`.
- pull with fixture live sessions: modal shows the session; confirm passes.
- `__mock.syncFail()`: apply error surfaces (no silent swallow).
- `?slowsync=2000`: spinner state exists while pending.

## 5. Gates — brief-1 list (release build, freshness, make test w/ grep, lint, three
cargo test crates, tsc + cargo check -p app) **plus**: `cargo test -p app --lib` now
matters (mock-adjacent app tests), and `node app/scripts/dnd-check.mjs` if you touched
anything it reads (you should not). Red-first applies to the mcp guard test; UI checks
are Playwright-verified, not bats.

## Final report
Raw data: files + line counts; gate transcript (grep patterns); mcp red-first location;
Playwright check results (what was asserted, pass/fail); deviations with reasons;
punted items. Note anything phase 4 must pick up (streaming, hover popover, settings
persistence you skipped).
