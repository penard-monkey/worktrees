# Implementation brief — `worktrees sync` phase 5 (Import from hub, in the app)

Repo: /Users/davidpena/workspace/worktrees/.worktrees/sync-macs, branch
`sync-macs-import` (stacked ON `sync-macs-stream` — phase 4 is committed there but NOT
yet merged; diff against `sync-macs-stream`, not main). Do NOT commit.

Read FIRST: CLAUDE.md (all Tauri rules), findings.md, phase1-4 briefs, then the code:
`crates/worktrees-core/src/sync.rs` (`resolve_ctx` — it ALREADY does name-based
adoption with `from: None`; `sync_preview`/`sync_apply`/`sync_status_data`),
`app/src-tauri/src/lib.rs` (sync commands, `add_project` :388-ish and how the app adds
a project to the workspace, `probe_dir`), `app/src/App.tsx` (SyncModal + sync state,
how "Add project" is surfaced in the UI — find the actual affordance before designing),
`app/src/mock/install.ts`.

Motivation (David, 2026-08-16): a brand-new machine can adopt via CLI
(`worktrees sync pull <name>`), but the app's sync surface hangs off a project ROW —
a project not yet in the workspace has no row, so the app cannot import. Close that.

## Scope
1. **Core**: extend the programmatic API to adoption (name-based, no local tree).
2. **Tauri**: hub listing + adoption preview/apply; auto-add to workspace on success.
3. **UI**: "Import from hub…" at the workspace level → picker → the existing
   preview/confirm modal (progress bar included) in adoption mode.
4. Mock + Playwright + CHANGELOG.
- **Do NOT**: change CLI behavior/argv (bats untouched = gate), version bumps,
  manifest schema. The CLI already adopts; nothing CLI-side should move.

## 1. Core (sync.rs)

`SyncRequest.root` is a `PathBuf` today and both API fns discover a project from it.
Adoption has no root. Reshape minimally — suggestion:
```rust
pub enum SyncSource {
    Root(PathBuf),        // existing: a project on this machine
    HubName(String),      // adoption: resolve local_root from the hub manifest
}
```
(or `root: Option<PathBuf>` + `name: Option<String>` mapped straight onto
`resolve_ctx(from, name_arg, …)` — pick whichever reads better against the existing
code; `resolve_ctx` already implements every rule: manifest strict-parse, hub-copy
check on the adoption DESTINATION, valid_name, "this repo is X not Y".)

Requirements:
- `sync_preview` for an adoption returns the destination (`local_root` from the
  manifest) — the modal must show where the tree will land; add a field or reuse
  `dst` + an `adopting: bool`.
- `sync_apply` adoption: same confirmed-semantics; Guard B already passes silently on
  a nonexistent destination and still fires if the path DOES exist with live sessions.
- Direction: adoption is PULL ONLY — a push for a name with no local tree is
  meaningless; refuse it in the API with a clear message (unit test).
- Hub listing: `sync_status_data(from: None)` already returns `projects` — expose
  whatever thin wrapper the app command needs, don't duplicate the walk.
- Unit tests: adoption preview carries the destination; push-by-name refused;
  existing tests untouched.

## 2. Tauri (lib.rs)

- `sync_hub_list() -> {hub: Option<String>, hub_error: Option<String>, projects: [...]}`
  — hub-scope status; called when the import picker opens. No repo arg.
- Adoption flow through the EXISTING `sync_preview`/`sync_apply` commands (add an
  optional `name` arg; `repo` becomes optional) OR two new commands — whichever keeps
  the mock and frontend simplest; do not fork the modal's data shape.
- **After a successful adoption apply**: add the project to the workspace the same way
  "Add project" does (find and REUSE that path — `add_project` command or its inner
  fn; do not reimplement validation), then emit `places:changed`. If add-to-workspace
  fails after a successful transfer, the CmdResult must SAY so (transfer ok, add
  failed, here's why) — never silently half-succeed.
- `--install` on adoption: same checkbox rules as phase 4 (config keyed by name works
  the same — `[sync.projects.<name>]` exists or not).

## 3. UI (App.tsx)

- Entry: an "Import from hub…" item wherever "Add project" lives today (match its
  idiom — if it's a menu item, be a menu item; if a button, a button). ALSO show it in
  the workspace empty state if one exists (a brand-new machine starts empty — that is
  THE import moment).
- Picker: small sheet/modal (existing sheet family styling) listing `sync_hub_list`
  projects: name, destination path, last push (relative time + host). Projects whose
  root is ALREADY a workspace project: disabled, "already in workspace". No hub ⇒ the
  reason, dimmed, and nothing clickable. Loading state while listing.
- Pick one → the SAME SyncModal in adoption mode: title `Import <name>`, destination
  path shown prominently (this is a write to a path the user has never seen — the
  modal IS the consent), counts, progress bar, install checkbox per config, sessions
  checkbox. Confirm → apply → success → picker closed, nav shows the new project row
  (via the workspace add + places:changed).
- Modal/picker state at module scope, the remount rule as always.

## 4. Mock + Playwright

Mock: `sync_hub_list` arm (fixture: 2 hub projects, one already in the workspace);
adoption arms for preview/apply (apply adds the project to the mock workspace fixture
+ emits places:changed); `?nohub` already exists and must make the picker show its
no-hub state.

Playwright (harness rules as before): (a) import happy path — picker lists 2, one
disabled "already in workspace", pick the other → modal shows destination → confirm →
progress events → success → NEW ROW in the nav; (b) `?nohub` picker state; (c) cancel
at the modal leaves workspace unchanged. Assert the new row by data attribute, not
pixel position.

## Gates
Full list as phase-4 brief (release build + freshness, make test grep'd — bats
UNTOUCHED green, lint, three cargo crates, tsc + cargo check -p app, dnd-check,
race-check — you're touching workspace add + places:changed, so race-check matters
and SAY whether refresh/commitWs/patchDeclared/mutate were touched).
Red-first for the new core unit tests.

## Final report
Raw data: files+counts, gate transcript, red-first notes, Playwright results,
deviations w/ reasons, punted items.
