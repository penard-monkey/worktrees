# Progress

## Session 2026-08-11 — unify list ordering on the nav's clock

### Pre-work: phantom worktree state
Worktree opened with 616 lines of staged deletions (the inverse of #117–#120)
— CLAUDE.md's documented `checkout -B` hazard: another worktree moved `ui-next`
out from under this one. Verified `git diff --cached` was byte-identical to
`git diff 403393d abac288`, no untracked files, no stash → `git reset --hard
403393d`. Nothing lost.

### Changes (app/src/App.tsx, app/src/App.css)
- `recencyEpoch` deleted. `usedEpoch` survives with ONE consumer: the new
  `restoreTarget` memo (restore-on-launch), for the reason its comment gives.
- `QuickSwitch` takes a `rank` prop (was importing `recencyEpoch` directly);
  App passes `activityAt`. New `.qs-age` column renders `ago(rank(p))`.
- `recentItems`, `resume` → sort by `activityAt`; both memos gained `donePaths`
  as a dep, since `activityAt` reads it via `workedAt`.
- Home resume row age: `usedEpoch` → `activityAt`.
- `FlatLens.ageOf` and `PlaceRow.ageEpoch` removed — dead once every list shares
  one clock.
- Restore-on-launch split off `resume[0]` into its own `usedEpoch` memo so the
  Resume list could move without taking the launch target with it.

### Verification (mock harness, port 5178, `--force`)
Served file checked for `qs-age` / absence of `recencyEpoch` before trusting the
run (HMR is dead inside `.worktrees/`).

| List | Order observed |
|------|----------------|
| ⌘K | now, now, 4m, 30m, 45m, 5h, 26d ×5 — monotonic |
| Recent lens | now, now, 5m, 46m, 5h, 26d ×4 — monotonic |
| Home Resume | now, now, 5m, 46m, 5h, 26d — monotonic |
| Nav tree | messaging/billing-refactor now, worktrees (main) 30m — agrees |

`.qs-age` computed style: `text-align: right`, `flex-grow: 0`, right edge 17px
inside the panel. Screenshot → `~/.cache/worktrees/worktrees/ui-changes/cmdk-activity-order.png`.

Caught during verification: the first nav read showed `messaging` at 26d and ⌘K
at "now" — the mock's `sessions:done` event had landed between the two reads.
It confirmed the `donePaths` dep is load-bearing, not defensive.

### Gates — all clean
`tsc --noEmit` ✔ · `cargo check -p app` ✔ · release CLI build ✔ · `make test`
288 bats, 0 `not ok` ✔ · `make lint` (shellcheck + bash-3.2) ✔ ·
`cargo test -p worktrees-core` 208 passed ✔ · `-p worktrees-cli` 6 passed ✔
(chain exit 0).

### Shipped
Branch `ui-cmdk-activity-order` → PR #121, all 9 CI checks green →
squash-merged as `ebc1cbf`. Branch deleted local + remote.

Worktree is now on `ui-changes-next`, level with `origin/main`.
NOTE: `ui-next` belongs to the **ui-tweaks** worktree, not this one — that is
what moved the branch out from under this tree and produced the phantom staged
state at session start. This tree's idle base is `ui-changes-next`.
