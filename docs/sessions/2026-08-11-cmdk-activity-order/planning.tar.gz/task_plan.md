# Task plan — unify list ordering on the nav's clock

## Goal
⌘K quick-switcher and the Recent lens must order places by the SAME clock the
default Places tree orders/labels by, so the dates on screen explain the order.

## Key facts (see findings.md for detail)
- Nav Places tree: sorts + labels by `activityAt` = max(worked, last_commit) —
  opens EXCLUDED on purpose (App.tsx:1439, 2199, 2532).
- ⌘K: sorts by `recencyEpoch` = usedEpoch || last_commit (App.tsx:168, 517-520,
  547). Rows show no age at all.
- Recent lens: sorts by `usedEpoch` = max(last_opened, last_worked) and labels
  rows with it via `ageOf` (App.tsx:2675-2677, 2789).
- Home "RESUME WHERE YOU LEFT OFF": `usedEpoch` (App.tsx:2431-2437, 3029) and
  `resume[0]` is ALSO the restore-on-launch target (App.tsx:2456).
- `activityAt` lives INSIDE App() (closes over `donePaths` state); `usedEpoch` /
  `recencyEpoch` are module scope. QuickSwitch is a module-scope component →
  the sort key must be passed in as a prop.

## Phases
| # | Phase | Status |
|---|-------|--------|
| 1 | Map the four orderings + their labels | complete |
| 2 | Confirm scope with user (does "resume" include the home list?) | complete |
| 3 | Implement: thread `activityAt` into QuickSwitch + Recent lens | complete |
| 4 | Gates: tsc, cargo check, mock harness visual/DOM assert | complete |
| 5 | Commit + PR + squash-merge (#121 → ebc1cbf) | complete |

## Decisions (answered by the user, 2026-08-11)
- Scope: ⌘K + Recent lens + home Resume LIST all order and label by
  `activityAt`. The launch restore target stays on `usedEpoch` in its own memo
  (`restoreTarget`) — `activityAt` counts commits, so a CLI-made worktree that
  was never opened would otherwise become what the app launches into.
- ⌘K rows gained an age column (`.qs-age`), since a list must label rows with
  the clock it orders by.
- `recencyEpoch` deleted; `usedEpoch` kept for `restoreTarget` alone.

## Errors Encountered
| Error | Attempt | Resolution |
|-------|---------|------------|
| Worktree showed 616 lines of phantom staged deletions | 1 | Verified byte-identical to abac288 tree (inverse of #117-#120), no untracked/stash → `git reset --hard 403393d` |
