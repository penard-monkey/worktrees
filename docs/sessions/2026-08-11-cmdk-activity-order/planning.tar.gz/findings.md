# Findings — ordering clocks in the app

## The four clocks (App.tsx)

| Consumer | Sort key | Age label shown | Line |
|----------|----------|-----------------|------|
| Nav Places tree | `activityAt` = max(workedAt, last_commit_epoch) | same key | 2199 / 2532 |
| ⌘K QuickSwitch | `recencyEpoch` = usedEpoch \|\| last_commit_epoch | **none** | 517-520, 547 |
| Recent lens | `usedEpoch` = max(last_opened, last_worked) | same key (`ageOf`) | 2675-2677, 2789 |
| Home Resume list | `usedEpoch` | same key | 2431-2437, 3029 |

`workedAt(p)` = max(donePaths live event, declared.last_worked_epoch) — App.tsx:1432.

## Constraints found in the code's own comments
- App.tsx:155-160 — `usedEpoch` deliberately has NO commit fallback so the
  "where was I" lists (Resume, Recent, auto-restore) are not led by a branch
  tip: a CLI-created, never-opened worktree has a commit from yesterday and
  would otherwise top Resume AND become the restore-on-launch target.
  → moving the home Resume list to `activityAt` (which DOES include commits)
  re-opens that hazard for restore. Keep restore on `usedEpoch`.
- App.tsx:1434-1438 — opens are excluded from the nav clock on purpose: clicking
  a row must not reshuffle the tree.
- App.tsx:2497-2499 — "a list must label rows with the SAME clock it orders by,
  or its ages read as a broken sort". ⌘K currently labels nothing.

## Structural constraint
`activityAt` is defined inside `App()` (closes over `donePaths` state).
`QuickSwitch` is module scope (App.tsx:502) and imports `recencyEpoch`
directly → the key has to arrive as a prop.

## No automated coverage
No Playwright/vitest suite for the app; UI is driven through the mock harness
(`pnpm dev:mock`, app/src/mock/install.ts) + Playwright MCP by hand.
`app/scripts/` holds ad-hoc harness scripts only.
