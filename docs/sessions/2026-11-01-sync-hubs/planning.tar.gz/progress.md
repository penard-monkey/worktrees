# progress
- 2026-11-01: read brief, surveyed sync.rs/project.rs/App.tsx; measured identity (see task_plan decisions).
- core §1 + api committed (00ec00b, 510bdf6). Checkpoint sent to worktrees-(main); WAITING for OK on entry point before UI.
- note for report: AGENTS.md says "185 commands" — now 190 (can't edit AGENTS.md; propose).
- env has WORKTREES_VIEWER_JS set → unset it when running cli tests.
- PR #587 open, CI green on 80dc175 (run 41353519769). Messaged main; waiting for review.
- AGENTS.md 185→190 committed locally (David OK'd); holding push for fable review items.
- Review fixes + main merged (#588-#591); head e91c049, CI green 9/9 after one rerun of an unrelated macOS engine timing test. Reported to main; awaiting merge.
