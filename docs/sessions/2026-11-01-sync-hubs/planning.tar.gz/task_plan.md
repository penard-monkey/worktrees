# sync-hubs — task plan
Goal: hub selector, hub dashboard, multi-project sync, push to several hubs, SSH design doc. One PR.

## Phases
- [x] 1 core: synchub.rs — volume classification (statfs + getattrlist UUID), remembered/chosen file sync-hubs.json, resolve chain, `worktrees sync hubs`
- [x] 2 api: sync_hubs (dashboard data), sync_hub_choose, sync_hub_forget; hub id on sync_preview/apply; batch preview/apply (sequential, lock)
- [x] 3 CHECKPOINT: message worktrees-(main) w/ entry point + sketch + identity method; WAIT
- [x] 4 UI: dashboard, selector in modals, batch modal; mock (2 hubs / 0 hubs)
- [x] 5 docs/sync-ssh-design.md, CHANGELOG, user docs
- [x] 6 gates, PR, manual check list, message main

## Decisions
- identity: getattrlist ATTR_VOL_UUID (no spawn, no prompt; == diskutil VolumeUUID, measured). Share: f_mntfromname minus user → smb://host/share
- kind: statfs. network = smbfs/afpfs/nfs/webdav; removable = MNT_REMOVABLE (set on both USB SSDs here); else internal. Excluded: not a mount point, ROOTFS, DONTBROWSE, symlink, TM names.
- file: $XDG_CONFIG_HOME/worktrees/sync-hubs.json (core config root) so CLI + app agree; CLI reads chosen[0] below [sync] hub.
