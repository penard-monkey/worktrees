# R2 — validation inventory (Phase 0 exit criterion)

Every input check that lived in a Tauri wrapper, a frontend dialog, or a
`cmd_*` argv parser rather than in the engine. A check on the far side of the
IPC is a check a remote client skips, so each one is either MOVED into
`worktrees-api` or consciously re-asserted there.

`clone::parse_source` is the shape to copy: engine-side, so it holds for a
caller that is not the dialog.

## Moved so far

| Check | Was | Now | Note |
|---|---|---|---|
| `guard_under_projects` | `app/src-tauri/src/lib.rs`, reachable only via a `#[tauri::command]` | `worktrees_api::projects` | THE containment boundary. Canonicalises and requires the result under a registered root. |
| `under_roots` | same | `worktrees_api::projects` | The same test against an already-canonical path, for symlink targets. |
| `project_roots` | same | `worktrees_api::projects` | Canonical roots, built once per listing. |
| `valid_project_name` | same | `worktrees_api::workspace` | Its own comment already said the frontend's copy "is never evidence". One path component; no `/`, no leading dot, no whitespace or control chars. |
| `expand_home` | same | `worktrees_api::workspace` | Leading `~` only — `~user` stays a literal directory name rather than becoming someone else's home. |
| `probe_dir` | same | `worktrees_api::workspace` | Not a refusal, but the dialog's evidence for which offer to make. |
| `log_event` level | same | `worktrees_api::meta` | Unknown level → `info`; message truncated to 4000. |
| `log_tail` bound | same | `worktrees_api::meta` | `min(2000)` lines. |

## Already engine-side (verified, no action)

- `clone::parse_source` — scheme allowlist, refuses every `helper::address`
  form, passes `--`, guards a leading `-`, sets `GIT_ALLOW_PROTOCOL`. The
  fixture `("ext::sh -c touch% /tmp/pwned", None)` is in core.
- `clone::plan_target` — refuses a target that already exists.
- `sync::valid_name` — the hub-directory name rule `valid_project_name` mirrors.
- `init.rs` — refuses absolute paths, `~` and `$` in `[[file]].path`.

## Still to inventory

Sections not yet extracted. Each gets a row as it moves.

## Moved in the rest of Phase 0

| Check | Was | Now | Note |
|---|---|---|---|
| `valid_token` / `valid_event` | `lib.rs`, behind `ui_events_append` | `worktrees_api::prefs` | Allowlists ASCII identifier characters for a metrics key, and validates a whole batch on the way in. `usage-check.mjs` guards both and now reads them where they live. |
| `UI_EVENTS_MAX` | same | `worktrees_api::prefs` | The cap on the events file. |
| `LIFECYCLE_LABELS` | same, behind `set_lifecycle` | `worktrees_api::ops` | The four labels a declared lifecycle may be. `dnd-check.mjs` mirrors it. |
| `known_harness` | same | `worktrees_api::ops` | Refuses a provider id that is not in `provider::PROVIDERS`. |
| `valid_tag` | same, behind `install_app_version` | `worktrees_api::status` | Tag shape. The INSTALL stays Tauri-side; the check that decides what is installable does not. |
| `TERM_PATHS_MAX` | same | `worktrees_api::files` | Caps a path-resolution batch. `mdpaths-check.mjs` mirrors it. |
| `DIFF_MAX` / `cap_patch` | same | `worktrees_api::files` | Caps a diff at a line boundary. |
| `DOC_MAX_BYTES`, `PLACE_KEY_MAX`, `place_key_ok`, `ASSET_EXTS`, `ASSET_CSP`, `safe_under` | `app/src-tauri/src/{viewer,docserver}.rs` | `worktrees_api::{viewer,docserver}` | The docs server's whole refusal surface, moved intact with its tests. |
| `log_event` level, `log_tail` bound | `lib.rs` | `worktrees_api::meta` | |

## Left in the Tauri shim, deliberately

Two handlers and one startup path. None is an input check.

- `install_app_version` — drives `tauri_plugin_updater`. §III.4.B client-local.
- `set_zoom` — WKWebView `setPageZoom`. A window has one; a socket does not.
- `winstate` — window geometry, for the same reason.

## Still open for Phase 2

**R1 is NOT addressed by this phase and nothing here should be read as
addressing it.** `guard_under_projects` answers "is this path under SOME
registered project", which is the right question for a single trusted desktop
user and the wrong one for a device whose capability names a subset of
projects. The per-object check belongs in front of it, resolved server-side,
and it is a Phase 2 exit criterion.
