# Codex permissions and pi trust are host policy: no client may set them by loading a page (OWASP review M2)

Based on `feat/server-edition` (PR #508, Server Edition Phase 0) at `f308062`. The user approved this fix.

## Why

Read these first:
- `docs/proposals/server-edition.md`: decision 2 (one engine process per host) and the "Queued" bullet "Two security settings are decided by whichever client loaded last".
- OWASP report finding **M2**: `~/.cache/worktrees/worktrees/owasp-serve/report.md`.

Today:
- `app/src/App.tsx:4725-4733` pushes `set_codex_permissions` and `set_pi_trust` from two `useEffect`s on every hydration and on every settings change.
- They land in `worktrees-api/src/project.rs:566` / `:619`, and from there in core's in-memory, process-global overrides (`codex.rs:214` `PERMISSIONS_OVERRIDE`, `trust.rs:59` `PI_TRUST_OVERRIDE`).
- Those overrides outrank `$WORKTREES_CODEX_PERMISSIONS` / `$WORKTREES_PI_PROJECT_TRUST` and the user config (`codex.rs:220`).
- The value's only durable home is the frontend's `ui-state.json`: `settings.codex_permissions`, `settings.pi_project_trust`, rendered by `SettingsSheet.tsx:916`.

With one engine per host, every client (the desktop app, a dev browser, later a phone) talks to ONE process. So the last client to load decides what Codex may auto-run and how pi trusts repos, in every lane the host launches, and opening a page is enough to change it. Agents run with the user's full local privileges, so a stale client whose settings say `full` silently widens Codex for everyone.

**Ruling: host policy.** The value lives on the host. It changes only by an explicit act, and loading a client never sets it. (`docs/statics-audit`, another lane, is writing this ruling into the proposal. Do not edit `docs/proposals/server-edition.md` yourself.)

## Target, with the constraints that matter

1. **A backend-owned file in the config dir** (`Ctx::config_dir`), for example `host-policy.json`.
   - Write it with core's existing atomic write (lock plus rename) and preserve unknown keys.
   - **Never `ui-state.json`.** The frontend writes that whole-blob, and AGENTS.md records why the backend must never write into it (`shell-cwds.json` exists for the same reason).
2. **Precedence and scope do not change from what users have today.**
   - Order stays: app setting (now persisted on the host) > env var > user config > default.
   - Scope stays: only the ENGINE process (the app today, `serve` tomorrow) reads the host setting. A CLI or MCP-launched lane keeps using env and user config exactly as now.
   - Whether the CLI should honour it is a real question, and it widens what MCP-created Codex lanes may do. Put it in your report as an open question; do not change it.
3. **Setters persist, and they are called only from the explicit act** (the Settings click). Delete the two load effects.
   - An unknown value is refused and NOT persisted (that stays as it is).
   - The UI updates optimistically and rolls back on refusal, through `fail()`, never swallowed.
4. **The UI shows the host's value, not its own copy.**
   - Add a getter, or extend an existing status command. `pi_status` already returns `trust`; see whether Codex has an equivalent.
   - The Settings control renders from that getter.
   - Decide what happens to the two `Settings` fields (drop them, or keep and ignore them) and say why. If they stay, nothing may read them as authority.
5. **One-time migration, done on the host.**
   - If `host-policy.json` lacks a key and `ui-state.json` has a non-default value, copy it once. The backend may READ `ui-state.json`, never write it.
   - Put it in a `worktrees-api` function, called with one line from the app's setup in `app/src-tauri/src/lib.rs`. `feat/worktrees-serve` moves setup into `host::boot`, so keeping it to one line keeps that rebase trivial.
   - The migration must never run because a CLIENT loaded. It is a host act at boot.
6. **The mock harness** (`app/src/mock/install.ts`) must track every command change (AGENTS.md: it must mirror lib.rs).

## Tests: fail first

AGENTS.md: "A new test must be shown to FAIL first." Show each test red on the base commit.
- **Rust:**
  - the setter persists
  - a fresh state, with the override cleared, reads the persisted value
  - persisted-over-env precedence is preserved
  - an unknown value is refused and leaves the file untouched
  - the migration copies once and never overwrites an existing host value
- **Frontend:** a guard proving that loading a client invokes neither setter. Either an `app/scripts/*-check.mjs` that slices the real App.tsx and fails if `set_codex_permissions` / `set_pi_trust` are invoked from a `useEffect` (the `race-check.mjs` slice-the-real-source shape; slice off comments so it cannot be satisfied by prose), or a mock-harness drive that counts invokes on load (expect 0) and on a Settings click (expect 1). The guard must fail on the base.
- **Drive the mock harness once** (`pnpm dev:mock` on a port other than 1420; AGENTS.md has the HMR-in-`.worktrees` and content-check traps):
  - flip Codex permissions in Settings and reload; the host value persists and renders
  - prove a reload sends no setter

## Rules

- All gates per AGENTS.md: release build FIRST, `make test`, `make lint`, `cargo test` for core, cli, api and `-p app --lib`, `tsc --noEmit`, `cargo check -p app`, and every `app/scripts/*-check.mjs` from the REPO ROOT. Report cargo with `grep -E "^running|^test result"`.
- CHANGELOG: one bullet under the existing `## [Unreleased]`. Count the `###` headers so there are no duplicates.
- Commit locally:
  - SSH-signed as `bret@brethash.com`, NO attribution trailer
  - do not push
- **Grep trap:** use `git grep` or `/usr/bin/grep` for any "not found" a conclusion rests on.
- Do not edit other places' trees: `feat-worktrees-serve`, `feat-serve-transport`, `docs-statics-audit`, `fix-argv-positionals`. `feat-serve-transport` also edits `App.tsx` (an import swap), so keep your App.tsx diff to the effects and the Settings wiring.

`report` to (main) when done:
- commits
- each fail-first test's before and after
- what happened to the two `Settings` fields
- the migration's behaviour
- the CLI-scope open question
- gate counts
