# Progress (2026-10-18)

- Rust: 7 tests in worktrees-api hostpolicy. Base-semantics stub: 5 red, 2 green
  (refusal + no-default migration: base never writes). Mutations M1-M4 all red.
  Logs: ~/.cache/worktrees/worktrees/fix-host-policy/{red-base-stub,mutations}.log
- Guard app/scripts/hostpolicy-check.mjs: 6 failures on base App.tsx; green now;
  FM1-FM4 mutations red (guard-mutations.log).
- Mock drive (scratchpad pw/hostpolicy-drive.mjs), chromium + webkit: all
  host-policy checks ok (drive.log); screenshots codex-*.png in cache dir.
- Gates: running (gates/summary).

- Commit c768319 -> rebased to a25a65e on feat/server-edition ad09f5d (conflict
  in lib.rs setup: boot line kept beside app.manage(Ctx::new)). Rule 4 added to
  the guard (boot inside the last .setup), red on c768319's lib.rs.
- Gates on a25a65e: bats 518/518; core 799 (+2 ignored); cli 68+1; api 165+7;
  app --lib 8; tsc 0; cargo check -p app 0 warnings; lint clean; test-frontend
  42/42. Not pushed.

## Scope addition from (main): term-history push gated on hydration
- Guard rule 5 red on the base (scratch extract of ad09f5d: 8 failures total,
  rule 5 at App.tsx:4673) and on the pre-edit tree; green after; FM5-FM7 red.
- Mock drive ?slowsettings=800 + stored "off": base pushes {true,true} x2 before
  {false,false} on every load and reload (chromium + webkit); fixed pushes only
  {false,false}. Logs: termhist-drive-{base,fixed}.log.
- Commit 5a41ed0. Gates on 5a41ed0: bats 518/518; core 799 (+2 ign); cli 68+1;
  api 165+7; app 8; tsc 0; check -p app 0 warnings; lint clean; frontend 42/42.

## Real-app check (2026-10-19, sandbox.sh --app on 5a41ed0)
- Seeded sbx ui-state.json with codex_permissions=full (pi absent). Boot log:
  "host-policy: copied codex_permissions from ui-state.json (once...)" then
  "host-policy: codex_permissions=full pi_project_trust=(env/config)".
  host-policy.json = {"codex_permissions":"full"}; frontend re-saved ui-state
  without the key. 0 panics / 0 errors / 0 warns after 67 s; log under .sbx.
- Real app.log got only the pre-IDENT startup line. Killed pid 74615 by PID;
  :1420 free. sbx config dir restored byte-identical (sha diff empty).
  Evidence: ~/.cache/worktrees/worktrees/fix-host-policy/sbx-after/.
