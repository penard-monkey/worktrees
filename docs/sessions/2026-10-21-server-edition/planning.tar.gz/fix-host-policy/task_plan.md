# Task: Codex permissions + pi trust become HOST policy (OWASP M2)

Brief: .planning/brief.md. Base f308062 (feat/server-edition).

## Goal
Loading a client never sets `codex_permissions` / `pi_project_trust`. They live
in a backend-owned `host-policy.json` in `Ctx::config_dir`, change only from the
Settings click, and the UI renders the host's value.

## Design (decided)
- `worktrees-api/src/hostpolicy.rs`: FILE = host-policy.json; read (lenient),
  `set_key` via `worktrees_core::config::edit_user_config` (lock + rename,
  symlink-through, mode kept) editing a serde_json Map (unknown keys kept; a
  corrupt file is refused, not clobbered); `apply` (file -> core overrides);
  `boot(config_dir)` = migrate from ui-state.json (READ only) then apply.
- Setters `project::set_codex_permissions(ctx, mode)` / `set_pi_trust(ctx, mode)`:
  parse (refuse unknown, nothing written) -> persist -> set override.
- Getter: new `get_codex_permissions` (effective `codex::permissions()`); pi uses
  existing `pi_status.trust`.
- lib.rs setup: ONE line `worktrees_api::hostpolicy::boot(&config_dir)` before
  the Ctx is managed.
- Frontend: delete both App.tsx effects; SettingsSheet gets a module-scope
  `CodexPermissions` section (getter + optimistic set + rollback via onReport);
  PiPanel renders trust from `status.trust`, same optimistic shape, reload after.
- Settings fields: DROP from type/DEFAULTS/sanitizer, delete from blob on load
  (agent_setup_dismissed precedent).
- Mock: get_codex_permissions; host policy persisted in sessionStorage.
- Guard: app/scripts/hostpolicy-check.mjs.

## Phases
- [x] 1 fail-first tests written against base (Rust + mjs), shown red
- [x] 2 backend implementation, Rust tests green
- [x] 3 frontend + mock, guard green
- [x] 4 mock harness drive (flip + reload persists; reload sends no setter)
- [x] 5 CHANGELOG bullet; gates; commit (signed, no trailer)
- [x] 6 rebased onto LOCAL feat/server-edition ad09f5d (fix bbfed64); gates re-run green; commit a25a65e
- [x] 7 report to (main); real-app run deferred ((main)'s sandbox holds 1420 + shared .sbx dir)

## Changes vs the design above
- Settings fields: DROPPED and stripped from the blob on load.
- Both controls re-read the host after every set, newest read wins (seq ref) —
  (main)'s out-of-order point for serve.
- Guard rule is positive: every path to a setter ends in an onClick (AST walk).
