# Findings

- BLOCKER on base f308062 (and serve branches): two `.setup()` calls; tauri
  2.11.5 `Builder::setup` REPLACES (app.rs:1777), so the closure managing the
  Ctx never runs -> every ctx() panics "state() called before manage()".
  Reported to (main); (main) measured 50 such panics in the real app.log and is
  fixing it on #508 (one .setup, plus viewer::Viewer state lookup -> pollctx.viewer).
- core `config::edit_user_config` is the only public lock+rename writer; used it
  for host-policy.json; temp now named after the file (`<name>.tmp-<pid>`).
- `ts.forEachChild` stops at a truthy callback return — the guard's first cut
  walked first children only and passed a file it never read.
- Playwright 1.63.0 matches the cached browsers (chromium-1243, webkit-2359).
- Headless harness: selecting a place throws an xterm `dimensions` page error
  (Viewport.syncScrollArea) with no Settings interaction — unrelated harness noise.
- Two .click() in one evaluate: React has not re-rendered, the second closure
  sees stale `mode` and returns early (AGENTS.md's one-click rule).
