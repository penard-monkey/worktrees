# Findings

## Measured (release CLI 0.42.0, scratch repo under $TMPDIR, fake HOME, tmux shimmed)
Script: scratchpad/repro.sh (PORTS=1 for the provision variant).
- `.worktrees.places.json.tmp` link: `ls`, `ls --json`, plain `new --no-tmux` do NOT
  write. MCP `set_note` DID: victim now holds the store JSON and
  `.worktrees.places.json` itself became a symlink to the victim.
- `.worktrees.toml.tmp` link: `init -y` (needs something to suggest; a committed
  compose file publishing a port is enough) wrote the TOML into the victim.
- `..worktree.env.tmp-<pid>` (note the DOUBLE dot: `.{ENV_FILE}` with ENV_FILE
  `.worktree.env`): a committed `[ports]` + 3000 links over a pid window -> plain
  `worktrees new feat-x` overwrote the victim. Pid suffix = no protection.
- App (code, not measured): store written with NO click by `stamp_worked` (poll,
  lib.rs ~9022/9037, whenever Claude finishes a turn in a place) and
  `backfill_worked` (every launch, 8864); also last_opened/last_seen on viewing.
- write_file (dock editor save): explicit save; writes the EDITED FILE's content
  (repo-authored) + chmods the victim to the file's mode (exec bit) -> e.g.
  ~/.zshrc replaced by repo text.
- materialize copy_atomic: pre-`remove_file(tmp)` defeats a static plant (race
  only); but deletes a pre-existing regular file at that name.

## Site classes
A (repo-controlled dir): store.rs, init.rs, provision.rs, materialize.rs copy_atomic, app write_file
B (user config/state/cache/app dirs): profile.rs x2, registry, skillstore, guidance x3,
  planning, plancmd remember, config.rs, inbox, lib.rs shell-cwds + hist, viewer.rs
C (git common dir, clone cannot plant): messages.rs
Already safe / different shape: tmux_server publish (create_new), slots register_wait
  (locked fd, state dir), guidance write_hashed (dir staging), materialize link_atomic
  (symlink(2) never follows), log rotations (rename only).
