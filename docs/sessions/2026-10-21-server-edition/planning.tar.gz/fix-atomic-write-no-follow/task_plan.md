# Lane F — atomic writes must not follow a planted symlink

## Goal
One core helper (`fsx::write_atomic`) that a cloned repo cannot redirect; use it
at every temp+rename site; fail-first tests; gates; CHANGELOG; #508 port note.

## Phases
- [x] 1. Survey every temp+rename site (A = repo-plantable dir, B = user dir)
- [x] 2. MEASURE with release CLI 0.42.0 (scratchpad/repro.sh)
- [x] 3. Tests first (red against current code)
- [x] 4. fsx helper + convert sites
- [x] 5. Green + mutation checks
- [x] 6. Gates via `worktrees run --slot gate`
- [x] 7. CHANGELOG (count headers)
- [ ] 8. Commit (signed, no trailers); report to (main) incl. #508 port note
