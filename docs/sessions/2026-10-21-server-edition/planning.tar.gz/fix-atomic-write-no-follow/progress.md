# Progress

## 2026-10-20
- Survey + measurement done (findings.md). Interim report to (main) sent.
- Tests written FIRST, red against current code: store, init, provision,
  materialize (core, 4/4 red), app dock save (red), ops brief (red).
- fsx::write_atomic added; converted: store, init, provision, materialize copy,
  ops write_brief (+ .planning real-dir check), app save_file (extracted from
  write_file), plus user-dir sites profile x2, registry, skillstore, guidance x3,
  planning, plancmd, config.rs, inbox, messages, app shell-cwds + hist.
- Left: viewer.rs (per-derive sync cost, own dir), slots register_wait (locked fd),
  tmux_server publish (already create_new), guidance write_hashed (dir staging),
  materialize link_atomic (symlink(2) never follows; comment updated).
- guidance test `a_save_that_dies_halfway_still_asks` relied on a taken TEMP name;
  rewritten to fail the edit via a non-empty dir at the target; mutation (base
  first) -> red; restored by edit + touch.
- Mutations: fsx create_new->create+truncate & no cleanup -> 3 red; app mode
  None -> red (0644 vs 0755). Restored by edit + touch.
- Re-ran repros against fixed target/release: all victims untouched.
- CHANGELOG Fixed entry (headers: 1 each). AGENTS.md rule added.
- Gates running: scratchpad/gates.sh -> scratchpad/gates/*.log
- Port note for #508: scratchpad/port-508.md
- (main) asked for: copy_atomic not deleting a file at the temp name (done),
  and a guard -> fsx::tests::no_source_builds_its_own_temp_name (OWN_TEMP_NAMES
  allowlist with reasons; stale rows fail). Red on old tree: 18 sites listed.
  Inlined materialize tmp_beside into link_atomic so no write can borrow it.
- Committed 44726c6 (signed G). Final gates all green: bats 534/534, core 877
  (+2 ign), cli 68+1, app lib 166, lint, test-mcp, tsc, check, 40/40 mjs. Only
  warning: pre-existing `claim` unused (viewer.rs, main since #311).
- #508 port dry-run in throwaway clone: conflicts = lib.rs, core config.rs,
  core ops.rs; after note: api 170/170, core 883 (+2), app test build ok.
- (main) says user chose a PUBLIC PR; (main) pushes. Not pushing here.
