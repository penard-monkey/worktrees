# Atomic writes must not follow a planted symlink (security fix on main, lane F)

You are a lane. `(main)` coordinates you through the worktrees MCP `report` / `messages` tools. Do NOT push.

## The bug, found by reading in the Phase 2 design lane and NOT yet measured

Several "atomic write" helpers write a FIXED-NAME temp file next to the target with `fs::write`, then `rename` it over the target. `fs::write` FOLLOWS a symlink. A cloned repository can commit a symlink at that temp name: AGENTS.md notes that git checks out a tracked `120000` blob with no check at all. The next write then goes THROUGH the link into any file the user can write, e.g. `~/.zshrc` or `~/.ssh/authorized_keys`. After that, `set_permissions` follows it too, and the rename puts the symlink itself in place of the target.

Sites on `origin/main`:
- `app/src-tauri/src/lib.rs:6622`: `write_file`, the dock editor's save, writes temp `.<base>.wt-tmp` next to the edited file.
- `crates/worktrees-core/src/store.rs:303`: `write_atomic`, temp `.worktrees.places.json.tmp` in the repo root. Every place note, pin and lifecycle change writes it, and possibly automatic stamps too, e.g. `last_worked_epoch`. Find out whether simply USING worktrees in a cloned repo triggers it with no click.
- `crates/worktrees-core/src/init.rs:1014`: `write_config`, temp `.worktrees.toml.tmp`.
- Check `crates/worktrees-core/src/materialize.rs:857` (`.<name>.wt-tmp-<pid>`): a pid suffix is predictable, not protection.
- SWEEP for every other instance across core, api, cli and the app: a temp path built from a fixed or predictable name, then written with `fs::write`, `File::create` or `OpenOptions` without `create_new`. Use `git grep -n` or `/usr/bin/grep -a`, since Claude Code's grep wrapper skips binary-looking files (AGENTS.md).

## Do

1. **MEASURE FIRST.** Reproduce with the release CLI in a scratch repo under `$TMPDIR`, using a guarded helper, never the live tree (AGENTS.md's `git -C ""` trap):
   - commit a symlink `.worktrees.places.json.tmp` pointing at a scratch victim file;
   - run the normal flow (`worktrees new`, `set_note` via the CLI or MCP, and plain `worktrees ls` to see whether it writes);
   - show the victim overwritten.

   Do the same for `init -y` and `.worktrees.toml.tmp`. For the dock editor, a unit test is enough. Record which sites are reachable WITHOUT any explicit user action; that decides the severity wording.
2. **ONE core helper**, e.g. `worktrees_core::fsx::write_atomic(path, bytes, mode: Option<Permissions>)`:
   - the temp is in the same directory, with a RANDOM suffix, opened with `OpenOptions::create_new(true)` plus `O_NOFOLLOW` (unix `custom_flags`), so an existing path or link is refused;
   - write, `sync_all`, set the mode through the HANDLE (`File::set_permissions`, i.e. fchmod, never a path), then rename;
   - on any error, remove only the temp IT created.

   Use it at every site. Keep each site's semantics: write_file's expected_mtime CAS and returning the new mtime; the store lock; init's error type.
3. **Tests, each shown FAILING first against the current code,** then restored by editing back and `touch`:
   - per site, a planted symlink at the old temp name leaves the victim untouched and the target correct;
   - a pre-existing regular file at the old name is not clobbered and not followed;
   - the mode is preserved (write_file keeps the exec bit).

   Use Linux-safe constructs: CI runs ubuntu as well as macOS, and Linux support is the default.
4. **Gates** from the REPO ROOT via `worktrees run --slot gate -- …`, with 0 warnings:
   - `cargo build --release -p worktrees-cli` first, confirmed fresh;
   - `make test` (redirect, then count the plan line and `not ok`);
   - `make lint`;
   - `cargo test -p worktrees-core`, `-p worktrees-cli` and `-p app --lib`;
   - tsc;
   - `cargo check -p app`;
   - every `app/scripts/*-check.mjs`.

   Report cargo with grep, not tail.
5. **CHANGELOG** under `## [Unreleased]` ### Fixed, in plain words, saying what a malicious repo could have done. Count the headers.

## Then, a second deliverable: the port for PR #508

On `feat/server-edition` (eb0f72e), `write_file` moved to `crates/worktrees-api/src/files.rs:1323`, with the same code. When #508 next merges main, that file will need your helper. Write the port as a ready-to-apply note in your report: the exact function body using your helper, plus any test. Don't touch the #508 branch.

## Rules

- Commits are `bret@brethash.com`, SSH-signed (`%G?` = G), with NO `Co-Authored-By` and NO "Generated with".
- Never a bare `git stash`. tmux probes always use `-L`.
- Disk is shared. Stop if `df -h /` shows under 8 GiB free.
- Report to (main):
  - the measured reproduction, saying which sites need no user action;
  - the helper and the sites changed;
  - the fail-first evidence;
  - the gates;
  - the #508 port note;
  - the commits.

Don't push.
