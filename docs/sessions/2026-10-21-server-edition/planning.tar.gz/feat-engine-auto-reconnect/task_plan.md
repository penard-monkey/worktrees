# Task plan — automatic reconnection to `worktrees serve` (lane B)

Base: `feat/app-serve-client` @ fadb2ce. Branch: `feat/engine-auto-reconnect`. Do NOT push.

## Goal
The socket drops → the app reconnects on its own, with backoff; the manual
Reconnect stays as "try now".

## Status
- [x] Phase 0 — read brief, engine.rs, ipc.ts, EngineGate.tsx, main.tsx, ipcws.ts, checks, checklist, §III.7
- [x] Phase 1 — plan reported to (main); APPROVED (Q1 yes + "started on request"; Q2 settle in scope; sandbox.sh honours preset WORKTREES_SERVE_BIN)
- [x] Phase 2 — shim: `engine_connect {reason, start, manual, onPhase}`; permit/settle/ConnectError; Rust tests, fail-first (5 mutations)
- [x] Phase 3 — `app/src/reconnect.ts` + `reconnect-check.mjs`, fail-first (12 mutations); `tripped` added so a press never re-arms auto starts
- [x] Phase 4 — engineDoor/main.tsx/EngineGate; transport-check (6 mutations) + engine-route-check (5 mutations)
- [x] Phase 5 — sandbox drive (kill -9 ✓, SIGTERM ✓, 3-starts-in-53s stop ✓, settle live ✓, stand-in crash loop ✓; banner in dev stack headless ✓)
- [x] Phase 6 — docs, gates (all green; worktrees-cli serve test flaky 2/15, untouched crate), commits 9aea3a0 a8ba4b5 2a083a5, report
- [x] Phase 7 — (main) 2026-10-20: merge feat/app-serve-client dc46a38 (git merge, signed) → 91cd0a3, no conflicts, CHANGELOG 1/1/1
- [x] Phase 8 — term_open's new `{id, err}` vs reconnect: only boot/now/visibility/lost feed the retrier; ipcws rejects a known-id err (releases its channels) and shuts only on an id-less err; TerminalPane writes the error into the pane. Pinned in transport-check (c937e04), red under 3 mutations (ff-termopen.py)
- [x] Phase 9 — full gates via the gate slot: 56/56 exit 0, 0 cargo warnings; reported tip c937e04 to (main). Don't push.
- [x] Phase 10 — (main) 2026-10-21: c937e04 is pushed under #525. Merge feat/app-serve-client 5cdfac0 (#524) → 2b3c359, no conflicts, CHANGELOG 1/1/1 and no line lost. dispatch.rs TEST_PANIC trap: this branch's checks cut through engine-route's noTests / transport's shipped (both fixed in the merge); no change needed
- [x] Phase 11 — gates2.sh (full set + serve_bin with no tmux on PATH): 57/57 exit 0, 0 cargo warnings; reported tip 2b3c359 to (main). Don't push.
- [x] Phase 12 — (main) 2026-10-21: merge origin/feat/app-serve-client e602f9a (D2/D3/D6/D7 + D2 follow-up) → 1b430a5. ONE conflict, ipc.ts engineDoor: upstream rewired the retry-less connect(); its wiring moved into attempt() (wire on dial return, unwire on loss/failure, one-shot TTL on env.now). transport-check: 3 one-shot blocks ported to the retrier door; 5-reconnect expects app:open-doc per socket. 4cfdfca adds the held-show-after-reconnect test (red when wiring waits for the proof).
- [x] Phase 13 — drive: launch → stale pid → start 36633; kill -9 app → 36633 idle-stopped at +122 s, serve.json removed; relaunch → "no serve.json → starting one" → 47329 ready. kill -9 47329 → no retry: window fully occluded by Safari (CGWindowList) → hidden deferral (not distinguishable from a missed loss without screen access). Dev stack headless: lost → countdown → restart → reconnected. [panic] 0; one [error] = pre-existing feedback-init in headless page.
- [x] Phase 14 — (main) change of plan: the user squash-merged #513 onto origin (73d6cb3, parent 2b3c359). Aborted the 4cfdfca gate run. Merged 73d6cb3 → 8b60c16 (no conflicts; CHANGELOG 1/1/1, all lines in [Unreleased]; childenv-check ok; no bare Command::new outside tests). FF of origin: 11 ahead, 0 behind.
- [x] Phase 15 — gates once on 8b60c16: 59/59 exit 0, 0 cargo warnings, 48 checks, dist 0/14 stale; reported to (main). Don't push.
- [x] Phase 16 — (main) re-cascade: merge LOCAL feat/app-serve-client a17a0be (main through #523) → 2c3c5af. No textual conflicts; one semantic: kimi_usage.rs test Command::new("ps") vs #513 dropping the Command import → test uses std::process::Command. fsx guard ok; workspace --all-targets check ok, 0 warnings. FF of origin 8b60c16 (8 ahead).
- [x] Phase 17 — gates once on 2c3c5af: 59/59 exit 0, 0 cargo warnings, 48 checks, dist 0/14 stale; reported. Don't push.
- [x] Phase 18 — (main): #525 merged. `cargo clean` only (own target/, nothing running from it): 11.2 GiB freed, disk 25 → 58 Gi; reported.

## The numbers
- Backoff: nominal `d(n) = min(30 s, 0.5 s · 2^n)` → 0.5, 1, 2, 4, 8, 16, 30, 30…
  - 0.5 s first, not 0: the close usually arrives while the serve that closed
    it is still exiting; at once we would observe its pid alive on a shut port.
  - 30 s cap: at the cap an attempt costs one observe and ~3 app.log lines,
    twice a minute; 30 s is also the longest a person who fixed something by
    hand should wait before the app notices. "Reconnect now" covers impatience.
- Jitter: "equal jitter", uniform in [d/2, d]. One app per host makes a herd
  unlikely, but a second client of the same serve (dev page, later the phone)
  should not reconnect in lockstep; never LATER than nominal, so the countdown
  shown is an upper bound.
- Crash-loop: at most 3 STARTS in any 60 s window (sliding). The launch's own
  start counts. A start = the shim reached `start()` (spawn tried, whatever
  came of it) — reported by the shim, not guessed.

## Ownership rules (where they live)
- The policy lives in the PURE TS machine (one place, virtual-clock tested, as
  the brief asks). The shim enforces only the mechanism: `start: false` ⇒ it
  never spawns and never replaces; it answers truthfully whether it started.
- `owned` = the last successful connect's `how` ∈ {started, adopted}. Before
  the first success (launch) starting is allowed.
- Automatic attempt: `start = (owned !== false) && starts-in-60s < 3`.
  - Reconnecting to a live serve is always allowed (any `start`).
  - Unowned and gone → shim declines → keep retrying (capped), banner says the
    serve was started outside the app and the app will not start one itself.
  - Owned, budget spent, shim declines → STOP: banner with the reason and
    serve.log; no more timers.
- Manual "Reconnect now": cancels the timer, tries at once, and MAY start (a
  person asked) — one start per press, recorded in the ledger, so it never
  re-arms automatic starts. QUESTION for (main): OK, or should manual obey the
  same rules (then a stopped/unowned app can only be fixed by relaunch)?
- Hidden window (`document.visibilityState === "hidden"`): a timer that fires
  while hidden does nothing and marks the retry due; becoming visible runs it
  at once. The launch attempt is not deferred. Why defer: nobody is looking,
  attempts would spend the start budget unseen, and an unowned/refused state
  would poll + log forever in the background.

## Shim changes (Rust)
- `engine_connect(reason, start: bool)`; `Engine::connect(reason, may_start)`.
  Under `!may_start`, `Decision::Start`/`Replace` → `Err{declined: true}`.
- `Endpoint` + `owned: bool, started: bool`; error = `ConnectError {message,
  started, declined}` (serialized; the page normalizes string errors too).
- PROPOSED (ask main): a `PortClosed` observation whose pid is still alive is
  a serve still stopping (`listener.stop()` → `host::stop` flushes rings →
  serve.json removed): before starting, wait (≤ STOP_WAIT) for that pid to go,
  so an automatic restart never overlaps a serve flushing its rings. Pid reuse
  falls through after the bound.

## Visible
- Waiting: "Reconnecting… (next try in Ns) · Reconnect now" (countdown ticks;
  last failure shown small). In flight: "Reconnecting…", button disabled.
- Unowned gone: "The engine was started outside this app and is not running.
  The app reconnects when it is back; Reconnect now starts the app's own."
- Stopped: "Disconnected from the engine. <why> Its log: serve.log" + Reconnect now.
- Boot screen (gen 0) runs the same machine: countdown + "Try now".
- No toasts: `fail()` already drops while `kind !== "up"`.

## Tests (each shown failing first; restore by editing back + touch)
`app/scripts/reconnect-check.mjs` (pure machine, virtual clock, scripted connector):
1. backoff sequence (random=1 ⇒ 0.5,1,2,4,8,16,30)
2. cap (30 s from step 6 on, never above)
3. jitter bounds (many draws ∈ [d/2, d]; random=0 ⇒ d/2)
4. crash-loop: 3 starts in 60 s, 4th attempt sent start:false, declined ⇒ stopped, no timer
5. owned vs unowned: unowned ⇒ every auto attempt start:false, retries continue; owned ⇒ start:true
6. manual-now cancels the pending timer, attempts at once, may start
7. hidden: timer fires hidden ⇒ no attempt; visible ⇒ attempt at once; visible again ⇒ nothing extra
8. exactly one in flight (manual during flight, visibility during flight, lost during flight)
`transport-check.mjs` (engineDoor over real ipcws harness sockets):
9. 5 auto reconnects ⇒ each event name subscribed exactly once per socket, each handler hears one event once
Plus Rust unit tests: `start:false` never starts/replaces (decision gate), Endpoint/ConnectError shapes.
engine-route-check / transport-check: update the main.tsx dial assertion (`{ reason, start }`).

## Errors encountered
| Error | Attempt | Resolution |
|---|---|---|
| reconnect-check: 4 red on first run | 1 | test bookkeeping (answered settled tries); tries numbered from 1 |
| transport-check: "started 4 times" | 1 | an earlier scripted started:true was inside the window; advance 61 s first |
| engine-route-check: connect signature regex stopped at Fn(&str) | 1 | pin the exact signature |
| drive: staged settle got "may start: no" | 1 | real crash-loop limit: 3 starts in 53 s; relaunched and spaced phases |
