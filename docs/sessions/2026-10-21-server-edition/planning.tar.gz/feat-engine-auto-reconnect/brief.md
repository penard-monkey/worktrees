# Automatic reconnection to `worktrees serve` (lane B, the next slice after the Reconnect button)

You are a lane. `(main)` coordinates you through the worktrees MCP `report` / `messages` tools. Do NOT push.

## Where this sits

Your base is `feat/app-serve-client` at `fadb2ce`, pushed but with no PR yet. It is stacked on #515 → #516 → #508. That branch made the desktop app a client of a local `worktrees serve`:
- `app/src-tauri/src/engine.rs`: find, start, adopt or replace, through a pure `decide()`;
- `app/src/ipc.ts` `engineDoor`: the routing table, the listeners it owns, and engine state `starting` / `up(gen)` / `down(reason)`;
- `app/src/EngineGate.tsx`: a boot screen, then a banner with a manual **Reconnect**;
- the engine `gen` in the terminal panes' keys, so they remount and replay after a reconnect.

Read those files, `docs/engine-client-manual-checks.md` and `docs/proposals/server-edition.md` §III.7 ("Reconnection is the new state machine… a dropped socket must not look like a closed place").

## Goal

When the socket drops, the app reconnects ON ITS OWN, with backoff, and keeps the manual Reconnect as "try now".

## Rules you must design and test

1. **Backoff with jitter.** Something like 0.5 s, 1, 2, 4… capped at about 30 s. Pick the numbers and say why.
2. **What a retry may do depends on ownership.**
   - Reconnecting to a serve that is still alive is always allowed.
   - STARTING a new serve is allowed only when the serve that died was one this app OWNED (started or adopted), and only up to a crash-loop limit, e.g. 3 starts in 60 s.
   - Past the limit, stop retrying and show the banner with the reason, naming serve.log. Never start a serve repeatedly.
   - A serve someone else started (unowned) is never restarted by the app. Reconnect to it if it comes back; otherwise say so.
3. **No thrash.** At most one attempt in flight. A manual Reconnect cancels the pending timer and tries now. If the window is hidden (`document.visibilityState`), defer attempts until it is visible again, or explain why not.
4. **What the user sees.** During retries, "Reconnecting… (next try in Ns) · Reconnect now", without the error toasts. The terminals keep their last screen, as today. After success, the existing gen/remount/re-pull path runs once.
5. **Events and listeners** re-subscribe exactly once per new socket. There must never be duplicate handlers after N reconnects; the existing router tests should cover that.

## Tests

Put the retry state machine in a PURE module with an injected clock and connector, then test it on a VIRTUAL clock, the way `termresize-check.mjs` does, so it can't be flaky.

Cover:
- the backoff sequence;
- the cap;
- jitter bounds;
- the crash-loop limit;
- owned vs unowned;
- manual-now cancelling the timer;
- hidden/visible;
- exactly one in flight;
- no listener duplication after 5 reconnects.

Every new test or check must be shown failing first: break the rule, see it go red, then restore by editing back and `touch`.

Update `engine-route-check.mjs` and `transport-check.mjs` if their assertions change. Update the manual checklist's step 3 to cover the new behaviour.

## Real app

`app/scripts/sandbox.sh --app` (it exports WORKTREES_SERVE_BIN). Use an ISOLATED tmux server (`env -u TMUX`, your own `TMUX_TMPDIR`), and drive by PID only, never by name.

This terminal has NO macOS Accessibility permission, so no clicks are possible. Do what needs none:
1. kill -9 serve, then watch app.log retry and recover on its own;
2. crash-loop: replace `WORKTREES_SERVE_BIN` with a binary that exits at once, and see the limit stop the retries.

Read only the bytes of app.log and serve.log appended after offsets you take at the start. `[panic]` must be 0.

## Gates

From the REPO ROOT via `worktrees run --slot gate -- …`:
- release CLI build first, confirmed fresh;
- bats;
- lint;
- core, cli and api tests;
- `cargo test -p app --lib`;
- tsc;
- `cargo check -p app --all-targets`;
- `pnpm build`;
- every `*-check.mjs`.

0 warnings.

## Rules

- Signed `bret@brethash.com` (`%G?` = G), NO `Co-Authored-By` and NO "Generated with". A CHANGELOG bullet under `## [Unreleased]`; count the headers.
- Linux support is the default: nothing here may be macOS-only. CI's ubuntu jobs run the checks.
- Disk is shared and limited. Stop and report if `df -h /` shows under 8 GiB free.
- Never a bare `git stash`. tmux probes always use `-L`.
- Write `task_plan.md` first, and REPORT the plan to (main) before writing the state machine: the numbers, the ownership rules and the test list. Wait for OK.
- When done, report the tip, the commits, the fail-first evidence, the drive log excerpts, the gates, and anything unverified. Don't push.
