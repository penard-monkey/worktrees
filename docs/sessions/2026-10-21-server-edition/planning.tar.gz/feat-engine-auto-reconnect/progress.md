# Progress — feat-engine-auto-reconnect (lane B)

2026-10-20/21
- Plan reported, approved by (main).
- 9aea3a0 feat(app): reconnect on its own (shim + machine + door + gate + checks)
- a8ba4b5 chore(sandbox): honour preset WORKTREES_SERVE_BIN
- Fail-first logs: ~/.cache/worktrees/worktrees/feat-engine-auto-reconnect/failfirst-*.log
- Drive (sandbox, isolated TMUX_TMPDIR=/tmp/claude-501/ar, stand-in serve-bin):
  - 00:53:05 kill -9 79194 → retry 1 same second, may start: yes → 81819 ready
  - 00:53:19 SIGTERM 81819 → stopped+removed serve.json before retry → NoFile → 83087
  - 00:53:44 kill -9 83087 (+ staged stopping stand-in) → may start: no (3 starts in 53 s) → stopped; quiet for 2m22s
  - relaunch 00:56:36 → 46174
  - 00:57:02 kill -9 46174 + staged sleep-3 stand-in → settle waited 3 s → 69551
  - 00:58:10 crash flag + kill -9 69551 → pending
  - 00:58:10 crash flag + kill -9 69551 → 3 stand-in starts (:10 :11 :13) → retry 4 may start: no → stopped; 0 bytes in 40 s
  - [panic] 0, [error] 0 in appended bytes of app.log and serve.log
- Gates: all exit 0 except worktrees-cli first run (flaky serve test, EINVAL at tests.rs:229; 2/15 alone; crates untouched; rerun 119/119)
- Dev stack headless Chromium: banner renders, counts down, reconnects when the stack's serve returns
- Docs commit amended (checklist note) after gates: docs only
