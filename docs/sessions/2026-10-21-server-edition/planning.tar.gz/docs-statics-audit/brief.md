# Statics audit — which process-global state survives "one engine per host"

Based on `feat/server-edition` (PR #508, Server Edition Phase 0) at `f308062`. This lane is an AUDIT. It produces rulings in the proposal doc, not code changes.

## Why

Read these first:
- `docs/proposals/server-edition.md`: "Decided since the plan", items 2 and 6.
- The same file's "Queued, not yet in a phase" section.
- §III.6 "What multi-client breaks".
- §III.4, the 143-command triage.

Decision 2 is **one engine process per host**. The desktop app becomes a client of a local `worktrees serve`, and later a phone and a second Mac connect to the same process.

Any process-global `static` is therefore shared by every client. That includes `OnceLock`/`LazyLock`, a `Mutex<…>` static, an atomic, and `thread_local!` (which is effectively global on a long-lived pool).

That is right for a fact about the host, such as "the caches of git status". It is wrong for one client's preference, and dangerous for a security policy. The transport lane found the dangerous case: `App.tsx:4727`/`4732` push `set_codex_permissions` and `set_pi_trust` on every page load into core's in-memory overrides. Those overrides outrank the env var and the user config, so the last client to load decides Codex's permissions for every lane on the host.

## Inventory (do your own; this is a starting point)

`git grep -n -P '(^|\s)static\s+[A-Z_][A-Z0-9_]*\s*:' -- crates/worktrees-api crates/worktrees-core/src app/src-tauri/src` finds 61 lines across about 37 files. The biggest clusters:
- `worktrees-api/src/term.rs` (6)
- `viewer.rs` (3)
- core `sysclock`, `slots`, `profile`, `pimodels` (3 each)

Extend the search to `thread_local!`, function-local statics, and atomics.

Also do the second half, which is what found the bad one: list every `invoke(` in `app/src` that runs from an effect on load or on a settings change and calls a setter (`set_*`, `*_override`, anything writing process state). Those calls are how a client's preference turns into host state.

Also cover serve's own state. Read it from the branch without checking it out, because another agent is editing that tree: `git grep … feat/worktrees-serve -- crates/worktrees-cli/src/serve` or `git show feat/worktrees-serve:<path>`. Never edit `.worktrees/feat-worktrees-serve`.

**Grep trap:** inside Claude Code, `grep` is a function that skips any file containing a NUL byte (AGENTS.md). Use `git grep` or `/usr/bin/grep` for anything a conclusion rests on.

## The ruling, one per static

Give each static exactly one of these rulings:
- **host fact**: the value describes the machine, so it stays global. Examples: caches of git, tmux or GitHub state, process registries.
- **host policy**: global, but it may only be changed by an explicit act and must be persisted on the host. It must never be set as a side effect of a client loading. Examples: Codex permissions, pi trust, anything that widens what an agent may do.
- **client preference**: moves into the client's session. Name the session it would live in (per connection? per enrolled device?) and how a command reaches it.
- **per-launch identity**: like `viewer::ISSUED`. It needs a lifecycle and an `_in` seam (AGENTS.md has the order-dependent test story).
- **test-only / const-like**: say so and move on.

For each one, record:
- `file:line`
- what it holds
- who writes it (which command, from which client action) and who reads it
- the ruling
- the concrete multi-client failure today, if there is one: two clients, what each does, what goes wrong
- the fix shape
- the phase it blocks: Phase 1 (the desktop app becomes a client of local serve) or Phase 2 (a second device)

**Verify every claim by reading the code.** Do not infer from names. A ruling that rests on "this looks like a cache" is how the plan got §III.6 wrong the first time. If the frontend writes it, cite the call site.

## Deliverable

1. A new section in `docs/proposals/server-edition.md`, `## Appendix B — process-global state under one engine per host`, placed after Appendix A:
   - a short lead
   - a table (static, file:line, ruling, phase it blocks)
   - one paragraph per static that is NOT a host fact
   - the load-time-setter list
2. Point the "Queued" bullets about statics and about the two security settings at Appendix B, and trim them to one line each. Do not delete the reasoning; move it into the appendix.
3. One commit:
   - SSH-signed as `bret@brethash.com`, with NO `Co-Authored-By` or other attribution trailer.
   - Do not push.
   - Docs-only, so no gates are needed. Run `file docs/proposals/server-edition.md` and confirm it says text. If you write it with a script, use raw strings: AGENTS.md "A backslash escape written through a script can land as the raw byte".
4. `report` to (main):
   - the commit
   - counts per ruling
   - every host-policy and client-preference item, one line each
   - anything that blocks Phase 1, said first

Out of scope: changing any Rust or TypeScript. If you find a bug that is not about multi-client state, put it in the report's "noticed" list.
