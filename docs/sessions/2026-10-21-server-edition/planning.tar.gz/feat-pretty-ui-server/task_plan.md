# Conversation view + Server Edition (feat/pretty-ui-server)

**Status: PLAN ONLY. Nothing implemented.** Written 2026-10-15 against
`b47cbe0` (origin/main). Every `[v]` claim below was re-read in this tree.

**Provenance.** Part II is the `feat/pretty-ui` plan of 2026-09-18, rescued
from a zero-content worktree before teardown and re-verified against main 195
commits later (all four of its gaps are still open — §II.3a). Part III is new.

---

## Part I — why these are one workstream

The conversation view was proposed as a nicety: prose that reflows instead of
an 80-column TUI. On its own that is a preference, and a preference is a weak
reason to build a second renderer for something that already works.

The server edition supplies the strong reason.

> **A terminal does not cross a network to a phone. A conversation does.**

Streaming a tmux pane to an iPhone is a bad product at every layer: the grid
is fixed-width, the input is a keyboard, the reconnect story is a repaint, and
the thing on the other end is a TUI drawing boxes for a 13" screen. Every one
of those objections dissolves if what crosses the wire is **structured turns**
instead of **bytes**. Markdown reflows to 390px. A tool call is a card whether
it is 1200px wide or 320px. A permission question is a two-button sheet.

So the dependency runs one way and it is not the obvious one:

```
  conversation view ──enables──> useful mobile client
  server edition    ──justifies──> conversation view
```

Part II is therefore **not** a prerequisite the server edition waits on — the
two ship independently, and Part III's phases 0–2 need nothing from Part II.
But Part II Phase 1 is the first thing on a phone that is worth the trip, and
Part III is the reason to go past Part II Phase 1.

A second, smaller convergence: both halves need the same new thing in core, a
**transcript reader** (`transcript.rs`, §II.5 Phase 0). The chat view reads it
to render; the server reads it to push structured turns to a client that is not
going to be handed a pty. Write it once.

---

# Part II — the conversation view

Goal: a friendly, structured view of what Claude is doing in a place — prose
that reflows, tool calls as cards, diffs as diffs — instead of an 80-column
xterm painting a TUI.

## II.1 What is there now

The main pane is a single `TerminalPane` keyed on the place's tmux session
name. Rust spawns a PTY whose child is `tmux attach-session`; xterm renders the
bytes. Claude Code runs as a TUI *inside* that tmux pane. The app has no idea
what Claude said — it only moves bytes.

Everything semantic the app knows about a session it gets by going *around* the
terminal:

| Signal | Source | Where |
|---|---|---|
| busy / waiting / idle dots | `~/.claude/sessions/<pid>.json` probes | `worktrees_core::agent` |
| Codex/pi activity | rollouts + pane capture | `worktrees_core::activity` |
| the unsent prompt (nav `✎`) | `tmux capture-pane -e -p` + a hand-written parser | `agent::draft_from_screen` |
| "Claude finished here" ember | busy→idle edge in the poll loop | `lib.rs` `completion_edges` |
| last activity | max `timestamp` in the transcript tail | `transcript_epoch` |

`agent::draft_from_screen` is the tell. It is ~250 lines of parser plus a test
suite full of war stories (U+00A0 after `❯`, DEC line-drawing SO/SI bytes, a
selector menu that reads exactly like a wrapped draft) — all to recover **one
line of text** the user typed. Screen-scraping does not scale to a conversation.

Directly reusable, already in the tree:

- `app/src/markdown.tsx` — `marked` lexer → React nodes, no `innerHTML`.
- `app/src/CodeView.tsx` + `highlight.ts` — hand-rolled highlighting.
- `app/src/DiffView.tsx` + `diff.ts` — unified-diff parse and render.
- `app/src/CtxMenu.tsx`, `useEscape.ts`, `Find.tsx`, `tokens.css`.
- `tmux::paste_to_ai` (`tmux.rs:814`) + `ai_pane` (`:575`) — text into Claude's
  pane as a bracketed paste, addressed by `%pane`, refuses honestly when no
  Claude is running. `[v]`

## II.2 The constraint that decides the design

DESIGN.md principle: **terminals ATTACH to tmux, never own shells.** Sessions
outlive the app, stay `tmux attach`-able from a bare shell, and are shared with
CLI users. A chat UI must not become "the app owns a Claude process" — that
forks the product into two incompatible kinds of session.

So the chat view is a **view**, not a host:

```
  READ  <- transcript JSONL (append-only, structured, already on disk)
  WRITE -> tmux paste (the existing, proven channel)
  TRUTH  = tmux. The terminal stays one keystroke away, always.
```

This constraint is what makes Part III possible at all. Because truth lives in
tmux and on disk rather than in the app's memory, a second client is not a
replication problem — it is a second reader.

## II.3 The read side — the transcript is the whole unlock

Claude Code writes an append-only JSONL transcript per session at
`<claude config root>/projects/<mangled cwd>/<sessionId>.jsonl`. The mangling
rule is implemented: `project::claude_dir_in` (`project.rs:728`) `[v]`. It is a
full conversation DAG:

- `uuid` / `parentUuid` chain; `isSidechain` marks subagent traffic.
- One record per **content block** — an assistant turn with thinking + text +
  two tool calls is four records, all sharing `message.id`.
- Block kinds: `text`, `thinking`, `tool_use`, `tool_result`.
- `toolUseResult` carries the structured result (`stdout`/`stderr`/`interrupted`).
- Per-record `timestamp`, `model`, `usage`, `gitBranch`, `cwd`, `version`.
- Meta records: `last-prompt`, `mode`, `permission-mode`, `custom-title`,
  `agent-name`, `queue-operation`, `file-history-snapshot`, `attachment`, and
  `system` with subtypes (`api_error`, `turn_duration`, `stop_hook_summary`).

**Sizes, re-measured on this machine 2026-10-15 — they have moved, and the
move changes the design.** 591 transcripts: p50 **0.42 MB**, p90 **2.85 MB**,
max **44.8 MB**. The 2026-09-18 figures were 484 files, p50 0.28, p90 1.0, max
12.2 — so the max has grown 3.7x in four weeks and p90 has nearly tripled.

Two consequences. "Whole-file parse is fine at p90" was true at 1.0 MB and is
marginal at 2.85 MB: the tail window is now the **default** path, not the
fallback. And a 45 MB file is past the point where it can be read into memory
casually on a phone — which means the tail window has to be a real seek from
the END of the file, and it has to survive landing mid-record (it will, every
time, at that size).

**This is strictly more than the terminal can show.** A place whose tmux session
is gone still has its transcript on disk — the chat view works where today the
main pane shows only the "No live session" hero.

### II.3a Gaps found — ALL FOUR STILL OPEN at `b47cbe0`

1. **`agent::live_probes()` throws away which config root a probe came from.**
   `agent.rs:123` loops `profile::claude_config_dirs_all()` and pushes a bare
   `ClaudeProbe`; there is no `config_root` field anywhere in the file. `[v]`
   A profiled session writes its transcript under the *profile's* config dir,
   so without the root the file cannot be located. Add a non-serde
   `config_root` set after parse, carried through `agents_at` → `Agent`.

2. **Two different escapings of the same path still exist.**
   `project::claude_dir_in` (`project.rs:728`) replaces every non-alphanumeric
   char; `sync::escaped_prefix` (`sync.rs:917`) replaces only `/`. `[v]`
   `claude_dir_in` is the correct one (it matches Claude Code). Route new code
   through it; open a ROADMAP item for `sync.rs` rather than fixing it here.

3. **`session_id` is in core and never reaches the frontend.** `Agent` has it
   (`agent.rs:40`, set at `:205`); `App.tsx` has no `session_id` anywhere. `[v]`
   The chat view needs it, or it has to guess by mtime — and mtime is a known
   lie for claude's files (AGENTS.md: 24 of 28 transcripts had an mtime 12
   minutes to 34 hours ahead of their newest record).

4. **The transcript does not record a *pending* permission question.** It is
   written when the turn resolves. A pure chat view cannot answer "do you want
   to allow this?" — see Phase 3, and §III.6, where it gets worse because the
   person holding the phone is not sitting at the tmux pane.

There is no `transcript.rs` in core today. `[v]`

## II.4 The write side

`tmux::paste_to_ai` pastes **without a newline** (deliberate — the nav drag
drops a reference into a prompt the user then edits). A composer needs paste +
submit, and submit is the one genuinely dangerous new primitive:

> A bare `send-keys Enter` into a pane showing a permission prompt **answers
> that prompt**, choosing whatever the cursor is on.

Rules for `submit_prompt` (new, in `tmux.rs` beside `paste_to_ai`):

- Re-read the probe immediately before sending. Submit only when
  `effective_state` is `idle`. `waiting` / `busy` / `shell` → refuse with a
  message naming the state.
- Paste, re-check the state, *then* `send-keys Enter` — the check must
  **bracket** the paste, not precede it, because the paste itself can change
  what is on screen.
- Address the `%pane` id from `ai_pane`, never an index (the `base-index`
  lesson, ROADMAP).
- Never a `send-keys -l` fallback for the text itself.

## II.5 Phases

Each ships on its own and is independently revertable.

### Phase 0 — de-risk the tailer (no UI)

- `worktrees-core/src/transcript.rs`: locate (probe `sessionId` +
  `config_root` → path; fall back to newest `*.jsonl` in the dir), tail-window,
  incremental follow, tolerant parse into a `Record` enum with an
  `Unknown { type }` arm.
- **Partial lines are the correctness trap**: the file is being appended to, so
  a read can catch a half-written line. Emit only up to the last `\n`; buffer
  the remainder. A test writes a record in two chunks and asserts nothing is
  emitted until the newline lands.
- Fixtures under `crates/worktrees-core/tests/fixtures/transcripts/`. **Real
  transcripts are the user's work and cannot go in the repo** — write a
  redaction script that preserves shape (types, keys, block kinds, ordering)
  and replaces every text payload. Collect: plain turn, tool-heavy turn,
  thinking, `/clear` boundary, `/compact`, api_error, interrupted Bash,
  sidechain.
- **Seek from the end, never read-then-slice.** At 45 MB the window must be a
  positioned read; the first record in it is nearly always a fragment and is
  discarded up to the first `\n`. The buffer-to-newline rule above covers the
  tail of the window; this covers its head, and they are different bugs.
- Exit: tail the **45 MB** worst case < 150 ms (re-measure, do not assume the
  12 MB figure scales); follow latency < 300 ms; unknown record types
  round-trip as `Unknown` without failing the parse; a window that opens
  mid-record yields the same turns as one that opens on a boundary.

### Phase 1 — read-only Conversation view

The whole "friendlier" win, zero write risk. It is a file reader.

- Backend: `transcript_open(repo, slug, onRecords) -> { replay: n }`,
  `transcript_close(id)` — the same Channel transport shape as `shell_open`.
  Poll the selected place only, ~250 ms, pure `std::fs` (this repo counts
  spawns).
- Frontend: `app/src/ChatPane.tsx`. Mode toggle in the space header,
  terminal | chat. Persist per place in `place_panels` — **the key must be
  optional**, with the flat `Settings` key as the seed (the frozen-seed trap).
- Rendering: user turn → bubble; assistant `text` → `<Markdown>`; `thinking` →
  collapsed "Thought for Ns"; `tool_use` → collapsed card with a one-line
  summary (`Read App.tsx`, `Bash cargo test`, `Edit 3 hunks`); `tool_result` →
  folded into its card by `tool_use_id`; `system/api_error` → an inline strip,
  never swallowed.
- Group records into turns by `message.id`; group turns by `last-prompt`.
- Virtualise the list. 12 MB is tens of thousands of records.
- Exit: open a real place, read a real past session, have it say the same
  things the terminal scrollback says.

### Phase 2 — the composer

- Textarea at the foot, Enter sends / Shift-Enter newline.
- `submit_prompt` per §II.4, with the state gate.
- Optimistic pending bubble, resolved when the transcript emits the matching
  `user` record — **not** when the invoke returns. The invoke returning only
  means tmux accepted the paste.
- Disabled with a reason shown whenever the gate would refuse.

### Phase 3 — interactive handoff

The honest answer to §II.3a.4. Probe state `waiting` → an inline card, "Claude
is asking something", with a live `TerminalPane` embedded in it. The terminal
stays the answer surface; the chat view stops pretending it is idle. Same card
for plan-mode approval and `AskUserQuestion`. Esc → interrupt, same gated path.

### Phase 4 — the part that makes it nice

Tool-specific renderers (`Edit`/`Write` → `DiffView`, `Read` → `CodeBlock`,
`Bash` → output card with exit code, `TodoWrite` → checklist); sidechains
nested under the `Agent` call that spawned them; file paths → open the Files
dock; per-turn cost/duration from `usage` and `system/turn_duration`; Find over
rendered text rather than xterm's grid.

---

# Part III — the server edition

Goal: **one machine runs the engine; any of the user's devices drives it.**
The machine with the repos, the worktrees and the tmux server keeps being the
only machine that has them. An iPhone, an iPad, or a second Mac running
Worktrees gets the same product, not a cut-down status page.

## III.1 The seam already exists, and the mock has been using it for a year

This is the finding that decides the architecture.

`app/src/mock/install.ts:3304` assigns `window.__TAURI_INTERNALS__` — four
members, nothing more: `[v]`

```js
{ invoke, transformCallback, convertFileSrc, metadata }
```

With that object in place, **the real `App.tsx` runs unmodified in plain
Chrome**, against a stateful fake backend, driven headlessly by Playwright.
That is the daily development workflow, not a thought experiment.

So there is no refactor needed on the 20+ files that `import { invoke } from
"@tauri-apps/api/core"`. There is no chokepoint to introduce, because the
chokepoint is below them and is already load-bearing.

> **A server edition is that same object pointed at a network transport
> instead of at fixtures.**

The terminal has its own, equally convenient seam: `Transport` at
`app/src/TerminalPane.tsx:76` is a five-method interface
(`open`/`write`/`resize`/`close`/`wheel?`) with two existing implementations,
`tmuxTransport` (`:97`) and `shellTransport` (`:111`). `[v]` A third,
`remoteTransport`, slots in beside them.

Both seams were cut for other reasons — the mock for headless development, the
`Transport` for dock shells vs place terminals — and both happen to be exactly
the right shape. That is worth saying out loud, because it is the difference
between a quarter and a year.

## III.2 What the server actually is

```
  today    App.tsx --Tauri IPC--> app/src-tauri/lib.rs --> worktrees-core (in-process)
  server   App.tsx --WebSocket--> worktrees serve       --> worktrees-core (in-process)
                    (or iOS/iPad/browser client)
```

The engine does not move and does not change. What has to move is the **command
layer**, which today lives in the Tauri crate: `app/src-tauri/src/lib.rs` is
11,288 lines holding **143** `#[tauri::command]` handlers. `[v]` Nothing else in
the repo can call them.

### The one real refactor: extract `worktrees-api`

Measured coupling of those 11,288 lines to Tauri types: `[v]`

| Type | Mentions |
|---|---|
| `AppHandle` | 60 |
| `State<…>` | 17 |
| `Channel<…>` | 5 |
| `tauri::Window` / `WebviewWindow` | 1 |

That is shallower than the line count suggests. `list_workspace(app:
AppHandle)` uses the handle for exactly one thing — `read_projects(&app)`, a
config-dir lookup. The pattern repeats.

So the extraction is mechanical, and bounded:

- `AppHandle` → a `Ctx { config_dir, events: Arc<dyn EventSink> }`.
- `State<T>` → fields on `Ctx`.
- `Channel<ArrayBuffer>` → `Arc<dyn ByteSink>`; Tauri's `Channel` and the
  server's WebSocket frame writer each implement it.
- The 1 `Window` is a genuinely client-local call (§III.4) and does not move.

`app/src-tauri/src/lib.rs` keeps 143 thin `#[tauri::command]` wrappers that
build a `Ctx` and call `worktrees_api::*`. The server calls the same functions.
**This refactor is the critical path and should be a PR of its own**, with the
app shipping unchanged on top of it before any socket is opened.

It also pays for itself independently of the server: 11,288 lines in a crate
whose tests do not run under `cargo check` (AGENTS.md: `check`/`build` do NOT
compile `mod tests`) becomes a library crate that does.

### Why `worktrees serve`, not a new daemon binary

One engine is the repo's first architectural rule. `worktrees serve` is a
subcommand of the existing CLI, linking `worktrees-api` the way the app links
core. No third build artefact, no third place for the version to drift, and
`install.sh` already ships the binary to every machine that would host one.

Two launch hazards, both already documented for other reasons:

- **`fixup_gui_path()` exists because launchd gives a bare PATH** (no homebrew
  → no tmux). A launchd/systemd-launched server has precisely the same problem
  and must resolve the login-shell PATH at startup the same way.
- **A long-lived server outlives an upgrade.** AGENTS.md already records two
  days of debugging a "live" MCP bug that was a stale server answering after
  the fix shipped. `worktrees serve` must log its version on start and expose
  it in a handshake, or the same two days get spent again with more clients.

## III.3 The security inversion — read this before anything else

**The repo currently holds the opposite rule, written down and gated in CI.**

`app/src-tauri/src/docserver.rs` is 1,630 lines whose module header is six
numbered refusals, and whose premise is a loopback bind. The release workflow
runs its boundary tests by exact name and greps for `test result: ok. 4
passed`. AGENTS.md states the rule the witness guards as: *"reachable from the
LAN is a data leak"*.

A server edition deliberately reverses that. This plan is not allowed to do so
quietly.

What makes the reversal defensible is that **the docserver's rule was never
"never listen off-loopback"** — it was "this surface, which hands out the
user's documents behind a URL token, must not be reachable by anything the user
did not intend." The docserver could not express intent, so it used the
interface as a proxy for it. A server edition has to express intent directly,
and then the interface stops being the control.

Concretely, every one of docserver's six refusals has to be re-derived rather
than inherited:

| docserver refusal | Still right? | What replaces it |
|---|---|---|
| 1. `Host` must be loopback | **No** — reversed | Origin pinning + TLS cert identity. DNS rebinding is answered by TLS, not by `Host`. |
| 2. Non-matching `Origin` → 403, no CORS header ever | **Yes, harder** | Browser clients are now real. Keep: no CORS header, ever. |
| 3. Per-launch path token | **Insufficient** | A per-DEVICE credential that survives restart (§III.5). A per-launch token re-pairs every device on every restart. |
| 4. Nothing outside the generated tree | **Yes** | `safepath::safe_under`, unchanged — it is already shared between docserver and the CLI (`safepath.rs`). |
| 5. GET only, no body, no keep-alive | **No** — impossible | The whole surface is mutating RPC over a long-lived socket. Request smuggling is answered by using one well-tested HTTP/WS stack, not by refusing bodies. |
| 6. `Referrer-Policy: no-referrer` | **Yes** | Keep; cheap. |

Refusal 5 is the uncomfortable one and should be named in the PR: the
docserver's safety came substantially from being a read-only, one-shot,
GET-only surface. The server edition is none of those things. The compensating
control is not a cleverer parser — it is that the surface is **authenticated
before it is parsed**, and the engine behind it already refuses what it should
(`reach.rs`, `USER_ONLY_KEYS`, `safe_under`, `remove_place`'s confirm).

**Recommended default: the server binds loopback and nothing else, out of the
box.** Remote reach is opt-in, per the registry's own precedent that
*registering is the consent act*. The two supported exposures:

1. **Overlay network (recommended).** Tailscale / WireGuard. The server binds
   the overlay interface; the overlay owns device identity, key rotation and
   NAT traversal; iOS has a first-class client. This is the configuration to
   document, test and recommend, because it removes TLS-certificate pain on
   iOS entirely and because the alternative is asking a developer to run a CA.
2. **Explicit LAN bind with TLS.** For users who will not run an overlay.
   Requires a real cert; a self-signed cert on iOS needs a profile install and
   is a support burden. Document it, do not recommend it.

Not supported: binding `0.0.0.0` with a bearer token and no TLS. There is no
configuration flag that should make that reachable.

**The CI witness has to change shape, carefully.** AGENTS.md records exactly
how this test went wrong before: an assertion about *binds* was measured on
macOS only and went red on Linux, and *"no bind means the same thing twice"* —
the witness has to be a **CONNECT**, and it must be preceded by a loopback
connect that succeeds, because without it a dead server passes every check. The
new witness is the same shape with the polarity flipped per mode: loopback
connect succeeds always; LAN connect is refused in default mode and accepted
only when the user turned it on. Measure on both platforms before writing it
down.

## III.3a OWASP review of this plan — required changes

Reviewed against OWASP Top 10:2025, the API Security Top 10, and the Agentic /
LLM lists (this is an agent-orchestration surface, so those apply). Done with
the `owasp-security` skill, on the plan as written at Part III.

**What the baseline already gets right, measured rather than assumed.** Three
findings were drafted and then RETRACTED after reading the code, which is worth
recording so a later reviewer does not re-raise them:

- Shell injection into the git/tmux shell-outs: git is invoked as an argv array
  (`Command::new("git").arg(…).args(…)`), never through a shell.
- `clone_project` as a remote RCE via `ext::`: `clone::parse_source` refuses
  every `<helper>::<address>` form with a comment that says why ("`ext::` is a
  command line"), allowlists schemes, refuses a leading `-`, and passes `--`;
  there is a fixture `("ext::sh -c touch% /tmp/pwned", None)`. `GIT_ALLOW_PROTOCOL`
  is set as a second belt, and the validation lives in the ENGINE, not the dialog.
- "Internal-only, so the surface is low risk": not claimed anywhere in the plan;
  §III.3 already names the reversal honestly.

Default-loopback, opt-in exposure, overlay-first, per-device credentials over a
per-launch token, no CORS header ever, refusing `update_cli` remotely, an
exhaustive `Exposure` enum, and revocation that kills live sockets are a
stronger starting posture than most. The changes below are what is MISSING.

### R1 — Per-OBJECT authorization is undefined (A01, API1 BOLA) · blocking

`Exposure` answers *may this command be called remotely*. Nothing answers *on
which object*. Commands carry paths and `<project>:<slug>` addresses as
ARGUMENTS, and over a socket the arguments are the attack surface.
`safepath::safe_under` constrains a path to a root; it says nothing about which
roots a device may reach, and `reach.rs` reasons about cross-project addresses
for a LOCAL user who already has the filesystem.

**Change:** a device's capability names its SCOPE (which projects), and every
command taking a path or a `<project>:<slug>` resolves it server-side against
that scope before `safe_under` ever runs. Two checks, not one. ROADMAP's open
`resolve_rel` / `root.join(rel)` symlink items become remotely reachable the day
this ships and must close first.

### R2 — Validation that is not in `worktrees-api` is validation a remote client skips (A01/A02) · blocking, and it lands in Phase 0

`parse_source` is engine-side, which is why clone is safe. That is not a
guarantee about the other 142 commands. The frontend demonstrably carries
decision logic — `NewPlaceDialog` reimplements `cmd_new`'s ordering, and
AGENTS.md records four cases wrong in its first version — and `cmd_*` argv
parsing in `ops.rs` is a second entry path with its own checks. **A remote
client is not the dialog and not argv.**

**Change:** Phase 0's exit criteria gain an inventory: every input check
currently performed in a Tauri wrapper, a frontend dialog, or a `cmd_*` argv
parser, with each item either moved into `worktrees-api` or consciously
re-asserted there. This is the cheapest moment to do it — the extraction is
already touching all 143 — and the most expensive to retrofit.

### R3 — Write the argument-injection invariant down and test it (A05)

clone.rs is the model; nothing states the rule for everything else. A branch
name, slug, remote name or ref that reaches git beginning with `-` is a FLAG.

**Change:** state the invariant — every subprocess argument reachable from a
remote client is `--`-separated or validated — and add one test that walks the
engine's git/tmux call sites for it, in the `*-check.mjs` mirror-drift family.

### R4 — Enrollment needs channel binding and a closed window (A04/A07)

§III.5's short code is exchanged over a channel the device cannot yet
authenticate. Without binding, an attacker reachable during the window races
the legitimate device; without limits, a short code is guessable.

**Change:** the QR carries the server's SPKI pin, so the device knows WHICH
server it enrolled with; the pairing listener exists only while pairing is
active; one failed attempt closes the window; the code is high-entropy in the
QR with the human-typed fallback rate-limited separately. Otherwise the overlay
network is silently carrying the entire channel-security burden, which §III.3
says it should not be asked to do alone.

### R5 — No security audit log (A09)

The plan logs the server version on start and nothing else. This surface can
remove worktrees and delete branches from another device.

**Change:** a server-side append-only audit record — device id, command,
object, outcome — for enrollment, auth failure, revocation, capability denial
and every group-A mutation. Explicitly NOT `ui-events.jsonl`: §III.6.2 keeps
that file's "never leaves the machine" premise by not emitting usage events
remotely, and an audit log is a different file with a different premise.

### R6 — No resource limits (A10, API4) 

Unbounded: sockets per device, frame size, live terminal channels, enrolled
devices, and request rate. `list_workspace` is a git fan-out (0.28s for one
project with nine worktrees, per AGENTS.md) that a client can call in a loop.

**Change:** per-device rate limit and concurrency cap, a maximum frame size, and
a bounded number of live terminal channels. Fail closed.

### R7 — The server makes an agent-instruction surface remotely writable (ASI01/ASI02, LLM01) · the product-specific one

This plan's real novelty, and §III.4 does not name it. worktrees launches agents
against briefs; `new_place --brief`, `write_file`, and anything that writes
`.planning/` or `AGENTS.md` steer an agent that then runs with the user's full
local privileges. ADR 0001 ("a cloned repo never supplies argv") exists because
the repo already takes this seriously for repository content — the server
edition widens *who can supply* the text that becomes an agent's instructions,
which is the same axis.

**Change:** brief-setting, and writes under `.planning/` and to agent-instruction
files, require the SECOND capability (the group-C gate), never plain `full`.
This is also the strongest argument for refusing §V.2 outright.

### R8 — The CI witness should cover identity, not only reachability

§III.3's connect-witness proves where the server listens. It does not prove who
it answers.

**Change:** add to the witness — an unenrolled device is refused, and a revoked
device's LIVE socket dies — and keep the §III.3 rule that the loopback connect
which must succeed runs first, or a dead server passes everything.

### R9 — §V.5 is now blocking, not open

Every control above is written for one human with several devices. Multi-user
changes `devices.json`, per-place authorization, and per-user git identity.

**Change:** answer it before the auth schema is written. If the answer is no,
record it as a NON-GOAL the design may rely on.

## III.4 Triaging 143 commands

Not one surface. Four, and the split is the bulk of the design work:

**A. Engine commands — remote, the whole point.**
`list_workspace`, `list_places`, `new_place`, `remove_place`, `switch_place`,
`open_place`, `close_place`, `set_lifecycle`, `set_pin`, `set_note`,
`place_health`, `place_plan`, `changed_files`, `file_diff`, `read_file`,
`write_file`, `list_docs`, `project_prs`, `doctor`, `provision`, `sync_*`,
`rules_*`, `agent_*`, `claude_usage`, `codex_usage`, … — the large majority.

**B. Client-local commands — must execute on the DEVICE, never the server.**
`open_editor`, `open_terminal`, `detect_editors`, `copy_text`, `set_zoom`,
`set_title`, `open_docs_viewer`. A phone has no VS Code and the server's
clipboard is not yours. These stay in the Tauri shim and the remote client
either implements its own (clipboard, zoom) or **greys them out with a reason**
— silently doing nothing on the server is the worst available outcome.

**C. Host-management commands — server-side, and privileged.**
`install_app_version`, `update_cli`, `check_update`, `list_releases`,
`add_project`, `remove_project`, `clone_project`, `init_repo`,
`create_initial_commit`, `mcp_install`/`uninstall`, `codex_mcp_*`, `pi_mcp_*`,
`save_profile`, `delete_profile`. These change the *host machine's*
configuration. A remote client should need a second, explicit capability to
reach them, and `update_cli` from a phone — replacing the binary that is
serving the request — is a footgun that should simply be refused.

**D. Terminal/stream commands — remote, but the hard ones.**
`term_open`/`write`/`resize`/`close`/`wheel`, `shell_*`, and the new
`transcript_*`. §III.7.

The deliverable for this section is a **table in code, not prose**: one
`Exposure` enum per command, checked exhaustively so a new command cannot be
added without choosing. The precedent is `projcfg::USER_ONLY_KEYS` — a hard
parse error rather than a default — and `reach.rs`'s three-level model
(`off` / `read` / `full`, user-tier only, *a profile can NARROW it, never
widen it*). A remote device's capability should be the same shape and the same
file family, and `full` should not imply C.

## III.5 Enrollment and identity

The registry's own header states the principle to copy: **"Registering is the
consent act."** Enrolling a device is the same act, and belongs in the same
user-tier config directory (`~/.config/worktrees/`), under the same
lock-and-rename discipline the registry already uses (`registry.rs` — every
write is read-modify-write under a lock, because the app and the CLI can write
at the same moment).

Shape:

- `worktrees serve --pair` prints a short code and a QR, valid ~60s, one use.
- The device posts its public key; the server records
  `{ device_id, pubkey, name, capability, enrolled_at, last_seen }` in
  `devices.json`.
- From then on the device authenticates with its key. No passwords, no bearer
  token in a URL (the docserver's own §6 note about `Referer` leaking a
  URL-borne capability applies with more force to a credential that persists).
- The server lists enrolled devices and can revoke one. Revocation must kill
  live sockets, not just refuse the next handshake.
- Pairing is only possible from the console or an already-trusted device.

**Open question for the user (§V.1):** whether an overlay network's own
identity (a Tailscale ACL) is allowed to *stand in for* this, rather than sit
under it. It is less code and one fewer thing to get wrong; it is also a
dependency on a third party for the security boundary.

## III.6 What multi-client breaks — found in the code, not guessed

The declared-state spine is **already safe**. DESIGN.md's concurrency contract
is "Rust sole writer": `.worktrees.places.json` is written under an atomic
`mkdir` lock with a re-read and a per-field merge preserving unknown keys, and
*"UI never second-writes; it calls Rust setters"*. Two clients mutating two
different places is already a solved problem. This is a large piece of luck and
it is luck the repo earned.

Three things are not safe:

1. **`ui-state.json` is written WHOLE-BLOB by the frontend.** It holds the
   selected place, sidebar mode, sort, terminal visibility. Two clients = lost
   updates, and worse, two clients *fighting over the selected place*, which is
   not even shared state conceptually — my phone's selection is not my desktop's.
   The repo has already hit this one rung down and solved it the right way:
   `shell-cwds.json` and `ui-events.jsonl` are separate, backend-owned files
   *precisely because* "a backend write into [ui-state.json] is erased by the
   next settings save." The fix is the same move again: split **per-device view
   state** (selection, zoom, sidebar) from **shared preferences** (theme,
   profiles, quota settings). Per-device state should not reach the server at
   all.

2. **`ui-events.jsonl`'s premise is that "the file never leaves the machine."**
   That is written down in DESIGN.md as a privacy guarantee. With a remote
   client, usage events are generated on a device and would have to travel to
   be recorded. Either the guarantee is restated honestly, or remote clients do
   not emit usage events. **Recommendation: remote clients do not emit them.**
   The metric is not worth amending a privacy promise for.

3. **A permission prompt now has two audiences.** §II.3a.4 is a gap in the
   single-user case and a hazard in the multi-client one: if the phone and the
   desktop both render "Claude is asking something", both can answer, and the
   loser's tap lands on whatever the prompt became. The gate from §II.4 must
   extend to a **server-side lease**: one client holds the answer-token for a
   given pending question, the others see "being answered on <device>".

A fourth, smaller: `viewer::ISSUED` is a process-global `static`, per-launch by
design, and AGENTS.md already records it making unit tests order-dependent.
Per-launch is wrong for a long-lived server with reconnecting clients; it needs
the same `_in` seam the tests got.

## III.7 Transport

**One authenticated WebSocket per client, carrying both RPC and streams.**

- Request/response frames carry `{ id, cmd, args }` → `{ id, ok | err }`. That
  is `invoke`, exactly, and it is what `__TAURI_INTERNALS__.invoke` becomes.
- Channel frames carry `{ channel_id, seq, payload }`. Tauri's `Channel` is
  already an ordered, index-buffered stream (AGENTS.md: *"only the channel's
  own order (`index`-buffered in `@tauri-apps/api`) is reliable"*), so the
  client-side semantics are unchanged — `transformCallback` keeps doing what it
  does today.

Why one socket rather than HTTP + a separate stream: the ordering guarantee
above is load-bearing and already bit this codebase once (the replay-answered-
as-input bug), and reconstructing it across two connections is how you get it
wrong.

**Terminal bytes are the thing to measure before committing.** A tmux attach
over a WAN link is latency-visible in a way that a `list_workspace` is not, and
`term_resize` is already coalesced behind `RESIZE_SETTLE_MS` because *every
distinct grid handed to the pty is a SIGWINCH*. Over a network the settle
window probably has to grow, and the existing
`app/scripts/termresize-check.mjs` runs the real `useTerm` on a **virtual
clock** — so it can test a WAN-ish profile without becoming flaky. Use it.

**Reconnection** is the new state machine with no existing analogue: a dropped
socket must not look like a closed place. The dock shell's 256K ring and its
`── restored · … ──` seam are the closest prior art and the right model —
replay on reattach, with a visible seam, and `trim_trailing_seam` so three
reconnects do not stack three seams.

## III.8 Clients

**Recommendation: the mobile client is the existing frontend in a browser /
PWA, not a native app.**

Reasons, in order of weight:

1. It already runs in a plain browser. The mock proves it daily, in Chrome and
   in headless WebKit.
2. The app has **no UI library** — plain CSS over `tokens.css`, scaling off
   `--ui-rem`. There is no framework lock-in to port and no component library
   that would have to be rebuilt in SwiftUI.
3. A native client is a second implementation of 143 commands' worth of
   semantics, and the repo already has a written rule about what happens when a
   frontend mirrors a core decision (`dnd.ts::predictTier` needs
   `dnd-check.mjs` to stop it lying quietly). A whole second client is that
   hazard at scale.
4. Per the Part I thesis, the mobile surface that matters is the **conversation
   view**, which is markdown and cards — the browser's home turf.

What that costs: no push notifications without extra work, iOS Safari quirks,
and the terminal is worse than a native terminal app would be. The first is the
one that hurts — "Claude is waiting for you" is the single best reason to have
a phone client at all. Web Push on iOS requires an installed PWA; that is the
path, and it should be proved in Phase 2 rather than assumed.

The **second-desktop** client is easier: it is the same Tauri app with a
different `__TAURI_INTERNALS__`. The interesting design question there is
whether a remote server appears as a **separate workspace** or as more projects
in the existing nav. Recommendation: **more projects in the existing nav.**
`registry::Entry` is `{ root, name, private, planning, … }` keyed on a local
path; a remote entry adds an origin. The nav already renders N projects, the
cross-project model (`reach.rs`) already reasons about `<project>:<slug>`
addresses, and a user with a laptop and a desktop wants one tree, not two
windows.

## III.9 Phases

### Phase 0 — `worktrees-api` extraction (no server, no socket)

Move the 143 handler bodies out of `app/src-tauri/src/lib.rs` into a new
`crates/worktrees-api`, leaving thin Tauri wrappers. `Ctx` replaces `AppHandle`
and `State`; `ByteSink` replaces `Channel`.

Exit: the app is byte-for-byte equivalent in behaviour; all gates green; the
mock harness untouched (it talks to `__TAURI_INTERNALS__`, which has not
moved). **This PR opens no port and adds no dependency.** It should merge on
its own merits, which it has.

Plus **R2**: an inventory of every input check that today lives in a Tauri
wrapper, a frontend dialog or a `cmd_*` argv parser rather than in the engine,
each item moved into `worktrees-api` or consciously re-asserted there. The
extraction is already touching all 143 — this is the cheapest moment, and the
most expensive to retrofit. `clone::parse_source` is the shape to copy: it is
engine-side, so it holds for a caller that is not the dialog.

### Phase 1 — loopback server + browser client

`worktrees serve` binds 127.0.0.1 only. A dev-mode frontend build points
`__TAURI_INTERNALS__` at it. No auth beyond a per-launch token, no TLS, no
remote — this phase is about proving the RPC shape and the Channel mapping,
and it is testable with the same Playwright setup used for the mock.

Exit: drive the real app in Chrome against a real engine over a socket;
`list_workspace`, a mutation, and one terminal attach all work.

### Phase 2 — identity, capability, exposure

Device enrollment (§III.5), the `Exposure` table (§III.4), the per-device /
shared settings split (§III.6.1), the new CI connect-witness (§III.3). Only
after this does anything bind off-loopback, and only behind the opt-in.

Exit: a second machine on an overlay network drives the server; an unenrolled
device cannot; a revoked device's live socket dies; both platforms measured.

Plus the OWASP gates that belong here, and nothing binds off-loopback until all
of them hold: **R1** per-object scope (a device's capability names its
projects, resolved server-side before `safe_under`), **R4** enrollment channel
binding (SPKI pin in the QR, window closed on first failure, pairing listener
only up while pairing), **R5** the audit log, **R6** rate and concurrency
limits, **R7** brief/`.planning/`/agent-instruction writes behind the second
capability, **R8** the witness covering identity as well as reachability, and
**R9** answered.

### Phase 3 — the phone

PWA install, Web Push for "waiting on you", the conversation view (Part II
Phase 1) as the default surface on a narrow viewport, terminal available but
not primary, the answer-lease from §III.6.3.

### Phase 4 — second desktop in one nav

Remote projects in `registry`, rendered in the existing tree.

---

## IV — combined order of work

```
  III.0  worktrees-api extraction      <- unblocks everything, merges alone
  II.0   transcript.rs tailer          <- independent, merges alone
  II.1   conversation view (local)     <- ships value with no server
  III.1  loopback server               <- proves the transport
  III.2  identity + exposure           <- the gate before any remote bind
  II.2   composer                      }  either order
  III.3  phone                         }
  II.3   interactive handoff + III.6.3 answer lease   <- do together, same problem
  II.4 / III.4  polish, second desktop
```

The two items worth starting in parallel are `III.0` and `II.0`: different
files, no shared surface, and each is independently shippable.

## V — open questions for the user

1. **Does an overlay network's identity stand in for device enrollment, or sit
   under it?** (§III.5) Tailscale ACLs alone = much less code and a third-party
   security boundary. Own device keys = more work, no dependency.
2. **Is `update_cli` / `install_app_version` from a remote client refused
   outright, or allowed behind a second capability?** (§III.4.C) Recommendation:
   refused.
3. **Is the phone a PWA or a native app?** (§III.8) Recommendation: PWA, and
   the push story proved in Phase 3 rather than assumed.
4. **Does a remote server appear as projects in the existing nav, or as a
   separate workspace?** (§III.8) Recommendation: projects in the nav.
5. **Multi-user, ever?** Everything above assumes one human with several
   devices. Multi-user is a different product (per-user git identity,
   per-user tmux, authorisation on every place) and should be explicitly out
   of scope or explicitly in it, now, because the `devices.json` schema differs.

## VI — risks

| Risk | Mitigation |
|---|---|
| **The transcript format is private and undocumented.** Fields seen here (`atis-latch`, `wireIngestContext`, `advisorModel`) are version churn. | Tolerant parse, `Unknown` arm, never hard-fail. Pin observed `version` values in the fixture corpus so a format break is a red test, not a support ticket. The terminal is always one click away — a broken chat view is cosmetic. |
| **The security inversion is the largest single risk in this plan.** | §III.3. Default loopback; opt-in exposure; overlay recommended; the CI witness is a CONNECT measured on both platforms; the `Exposure` table is exhaustive so a new command cannot default to reachable. |
| A stale/wrong `sessionId` shows the wrong conversation. | Assert the transcript's `cwd` matches the place path before rendering a row. Mismatch → refuse and say so. |
| `/clear` mid-view silently switches files. | Watch the probe's `sessionId`; on change, re-locate and show a "new session started" divider. |
| Two claude sessions in one place. | `agents_at` already ranks them. Session picker in the header when > 1. |
| Submit lands on a permission prompt. | §II.4's bracket-the-paste gate, plus §III.6.3's lease once there are two clients. |
| **The mock answers instantly and cannot express any of this.** | AGENTS.md: three v0.12.x bugs got through exactly here. Every phase needs a real run (`app/scripts/sandbox.sh --app`), and the server phases need a real *slow* link — the mock's microtask resolution is the opposite of a WAN. |
| A long-lived server outlives its upgrade and answers with old code. | Version in the handshake, logged on start. AGENTS.md's two-day MCP debugging session is the precedent. |
| The `worktrees-api` extraction silently changes behaviour across 143 commands. | Diff `ls --json` against the shipped binary (the repo's existing technique for exactly this); the mock harness is an unchanged consumer and is a second witness. |

## VII — alternatives considered

- **App owns `claude --print --output-format stream-json`.** Clean documented
  stream, real permission control via the SDK control protocol. Rejected: it
  breaks the tmux spine — the session would not survive app quit, would not be
  `tmux attach`-able, and would not be the object the CLI manages. Revisit only
  if the product decides app-owned sessions are a second, explicitly different
  kind of place.
- **Screen-scrape the pane into structure.** Rejected on the evidence of
  `draft_from_screen`: ~250 lines and a war-story test suite to recover one line.
- **A dock tab instead of a main-pane mode for the chat view.** Rejected: the
  conversation is the primary thing in a place, and the dock is 240–400px.
- **SSH + the CLI as the "server edition".** It genuinely covers some of this
  today and costs nothing. Rejected as the answer because it does not give a
  phone anything, and because the product being asked for is the app, not a
  terminal into the machine that runs it. Worth documenting as the thing to do
  until Phase 2 lands.
- **Rendering the desktop app remotely (VNC-alike).** Rejected: it is the
  terminal problem one level up — a 1440px layout on a 390px screen, and every
  interaction pays a round trip.
