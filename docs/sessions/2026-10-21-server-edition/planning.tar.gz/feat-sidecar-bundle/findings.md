# Findings — sidecar bundle

## Versions in the lockfiles
- tauri 2.11.5, tauri-build 2.6.3, tauri-utils 2.9.3; @tauri-apps/cli 2.11.4.
- `tauri build -c/--config` takes JSON strings OR file paths, repeatable, merged
  in order (later wins). The CLI hands the merged overlay to cargo as
  `TAURI_CONFIG`; tauri-build re-reads it (`rerun-if-env-changed=TAURI_CONFIG`).

## M1 — externalBin breaks a clean `cargo check -p app` (MEASURED)
`TAURI_CONFIG='{"bundle":{"externalBin":["binaries/worktrees"]}}' cargo check -p app`
on a clean checkout (no target/ at all) → exit 101:
`resource path 'binaries/worktrees-aarch64-apple-darwin' doesn't exist`.
tauri-build 2.6.3 `build()` → `copy_binaries()` runs for ANY profile when
`bundle.external_bin` is set. So the base tauri.conf.json must NOT carry it —
it would break check, test, dev and CI's app build on both OSes.

## tauri-build's copy lands ON the CLI's own output path
`copy_binaries` dest = `target_dir.join(<name minus -triple>)`, where target_dir
= OUT_DIR/../../.. = `target/<profile>/` (or `target/<triple>/<profile>/` with
`--target`). For a sidecar named `worktrees` that IS `target/release/worktrees`
— the CLI binary the bats shim prefers. It does `remove_file(dest)` then copies.
Consequences:
- Harmless only if the staged file is byte-identical to that build (stage it
  from the build made immediately before, with the SAME --target choice as the
  tauri invocation, so the copy writes over itself).
- A stale staged file would silently replace a fresh CLI — and with a NEW mtime,
  defeating AGENTS.md's `-nt` freshness check. Never stage a CLI built elsewhere.
- The staged file must be a real copy, not a symlink into target/: dest is
  removed before the copy, which would leave the symlink dangling.

## The CLI's version is readable WITHOUT running it
`crates/worktrees-cli/src/stale.rs`: `RECORD = "\0WORKTREES_CLI_VERSION=<ver>\0"`,
retained in release builds via `black_box` in `version()`. The release
assertion can read the x86_64 sidecar's version as data (never exec a
cross-arch binary), and run `--version` only on the native one.

## Things the sidecar will touch later (out of scope, report)
- `install.sh:137` `pgrep -f "worktrees.app/Contents/MacOS"` = "app is running".
  Once the app starts `Contents/MacOS/worktrees serve`, that also matches serve.
- `profile::worktrees_bin()`: in the app current_exe is `Contents/MacOS/app`, so
  it falls back to PATH. Preferring the sidecar there = Option A's failure mode
  (MCP stanza pointing into a bundle that can move). Leave it.

## Linux (2026-10-20)
- externalBin in a .deb → /usr/bin/worktrees (public). GUI binary → /usr/bin/app (!).
  deb control Depends: libwebkit2gtk-4.1-0, libgtk-3-0; desktop Exec=app Icon=app.
- externalBin in an AppImage → $APPDIR/usr/bin/worktrees; AppRun.wrapped (AppImageKit
  classic) sets PATH=$APPDIR/usr/bin/:…:$PATH and LD_LIBRARY_PATH=$APPDIR/usr/lib/…;
  linuxdeploy-plugin-gtk hook exports GTK_*/GIO/GI/GSETTINGS/XDG_DATA_DIRS. All of it is
  inherited by the tmux server the app starts. (scratchpad/linux/boot-appimage.log)
- Boot (Xvfb, scratch HOME, non-root): both formats alive at 60s, 0 [panic]/[error].
  log ~/.local/share/net.casadelvalle.worktrees/logs/app.log; config ~/.config/<ident>/.
  mcp_status found worktrees=/usr/bin/worktrees (deb) / $APPDIR/usr/bin/worktrees.
- tauri-utils 2.9.3 resource_dir on Linux: <exe>/../lib/<productName> (canonical) →
  $APPDIR/usr/lib/<productName> → /usr/lib/<productName>. Dev: exe dir if under target/.
- updater 2.10.1: keys tried `{os}-{arch}-{installer}` then `{os}-{arch}`; deb install =
  pkexec dpkg -i; AppImage install rewrites $APPIMAGE in place (same-fs temp).
- tauri AppImage bundler needs xdg-open on the build host (copies it in).
- `bundle.macOS.files` / `linux.deb.files` / `linux.appimage.files` are invisible to
  tauri-build: TAURI_CONFIG with all three + nothing staged → cargo check -p app ok (mac).
- Repo is PUBLIC → ubuntu-24.04-arm hosted runner usable.
- AppRun also exports PYTHONHOME=$APPDIR/usr/ (would break every python3 in a pane)
  and chdir's to $APPDIR/usr (PWD) — childenv handles both (path rule + start_dir).
- `pnpm -C app` from the repo root under corepack refuses the pin (12.14 vs 11.5.2) —
  CI is immune (pnpm/action-setup); the Docker emulation needs pnpm installed directly.
- Linux log: ~/.local/share/<ident>/logs/app.log — HOME-relative, ignores XDG_DATA_HOME
  (tauri's own dirs honour it). Not ~/Library; flagged, not changed.
- deb metadata: Maintainer "David" (app crate Cargo.toml authors), long Description
  "(none)", desktop Categories empty. Flagged, not changed.
- glibc floor: bundles built on ubuntu-24.04 runners need its glibc; 22.04 runners would
  widen reach. Flagged.

## Phase 3 findings (2026-10-20)
- Kimi's spawn sites (all bare before the rebase fix): kimi.rs version() [Settings only, api
  project.rs:671] and opener_bin() [`worktrees kimi-opener --probe`, on a kimi launch with a
  brief]; kimi_usage.rs probe [`kimi web --port 0`, doctor --kimi and the launch gate];
  kimiplace.rs tracked() [ls-files, every kimi launch], worktree_dirs() [only when nothing of
  ours is left anywhere], hidden_by_us() [a user-owned kimi file under our exclude];
  ops.rs kimi_doctor [`kimi --version`].
- Kimi is the case where the leak bites hardest: kimi-cli is Python, and AppRun sets
  PYTHONHOME/PYTHONPATH into the AppDir.
- profile::worktrees_bin() returns current_exe when it is named `worktrees` — in the GUI it
  falls back to PATH; WORKTREES_CLI_BIN overrides both.
- tauri deb: Section comes from bundle.linux.deb.section, NOT from category; category gives
  the desktop entry's Categories (DeveloperTool → Development;).
- `tauri bundle` (CLI 2.11.4) re-bundles around an already-built target/release binary — a
  cheap way to check packaging config without a full Linux app build.

## Phase 4 (eb0f72e, #520)
- #520 builds the usage curl in a new `usage_cmd` (returns the Command + stdin bytes) and runs it
  through `proc::run_deadline_stdin`, which takes a caller-built Command, so childenv reaches it
  only if usage_cmd builds it with `childenv::command` — the check enforces that (mutant red).
- childenv does not touch stdin/stdout, so `-H @-` is unaffected; the loopback byte-exact test
  (`a_token_with_quotes_and_backslashes_arrives_byte_exact`) runs through the childenv'd Command.

## D1 audit (2026-10-21) — callers of worktrees_bin(), all fixed by the one function
Same 18 call lines on origin/feat/engine-auto-reconnect (2b3c359) as here, so the stack adds none.
- mcpsetup::status/install — `claude mcp add -s user` → user's GLOBAL ~/.claude.json (persisted)
- codexmcp::status/install — ~/.codex/config.toml (persisted)
- pimcp::status/install — pi's MCP config (persisted)
- kimiplace::status + ops::kimi_place_files — per-place .kimi-code/mcp.json (persisted)
- profile::MatPaths::for_profile — a profile's materialized MCP stanza (persisted)
- guidance::guard_bin → materialize — the guard's PreToolUse hook command (persisted plugin files)
- plancmd::probe_cli → ops::planning_for (plan hooks plugin, persisted) + api ops planning_status (display)
- kimi::opener_bin → ops::deferred_opener — `<bin> kimi-opener` run in a tmux pane (outlives the app)
Not callers, checked: api status::cli_binary (login-shell `command -v` + 4 fixed dirs, never
current_exe — Settings → Version and update_cli); cli stale.rs (its own staleness); childenv::appdir
(AppImage test); stack's host.rs:456 / tmux.rs:1125 current_exe are in #[cfg(test)].
