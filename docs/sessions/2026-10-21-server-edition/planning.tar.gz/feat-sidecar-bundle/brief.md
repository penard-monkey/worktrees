# Bundle the CLI inside the app as a private sidecar (Option B)

## Where you are

Based on `feat/server-edition` (PR #508, not yet on main). The decision is recorded in ROADMAP.md (top item, "Option A for the bundled CLI"): the CLI ships INSIDE the app bundle and is used ONLY by the app, to start `worktrees serve`. `install.sh` keeps putting the CLI on PATH. Putting the bundled copy on PATH (Option A) is a later opt-in. macOS releases stay ad-hoc signed; Apple signing is not part of this lane.

Read that ROADMAP entry and `crates/worktrees-api/src/lib.rs`'s crate doc (one engine process per host) first.

`worktrees serve` exists on a sibling branch (`feat/worktrees-serve`, local only). You do not need it: this lane is packaging. Any CLI that answers `--version` proves the bundle; a later lane wires the app to start `serve`.

AGENTS.md applies — read all of it, especially Gates, Release, Local installs, "A workflow that fails to PARSE is invisible", "Never run the bundle's binary to probe it", and the stale-release-binary notes.

Bootstraps (both fail confusingly without): `git submodule update --init --recursive`, then in `app/`: `nvm use && corepack pnpm install`.

## Facts already measured

- `app/src-tauri/tauri.conf.json`'s `bundle` has `resources: ["viewer/*"]` and NO `externalBin`. The identifier is `net.casadelvalle.worktrees`. The app's main executable is `app`, so a sidecar named `worktrees` does not collide in `Contents/MacOS/`.
- `release.yml`: job `build` builds the CLI for four targets (two macOS, two Linux). Job `app-bundle` builds the app for `aarch64-apple-darwin` and `x86_64-apple-darwin` on `macos-latest` with `pnpm -C app tauri build --target …`, then tars `target/<t>/release/bundle/macos/worktrees.app`. The x86_64 bundle is cross-built on an arm64 runner.
- `install.sh` runs `xattr -cr` on the installed app (around line 133), so quarantine is stripped recursively and a nested binary runs. `make install-app` installs local builds. The in-app updater (`install_app_version`, `latest.json`) replaces the whole bundle, so a sidecar inside it updates with it.
- The CLI release binary is about 4.7 MB.

## The trap to design around

Tauri's `externalBin` expects `binaries/<name>-<target-triple>` to exist when the app crate BUILDS. `tauri-build` checks or copies it from `build.rs`, so it may fail `cargo check -p app`, `cargo test -p app --lib`, `tauri dev` and CI's app build on BOTH OSes (Linux included). None of those should need a CLI build first. Measure whether that is true for the Tauri version in the lockfile before designing around it.

Candidate shapes, yours to choose and justify: `externalBin` only in a bundle-time config overlay passed with `--config` (release and `make install-app`); a build step that produces the binary first; or something better. The constraint: dev, check and test paths keep working on a clean checkout with no extra step, and a release cannot ship without the sidecar.

## Deliverables

1. The bundle, from release AND from `make install-app`, contains the CLI for the bundle's own architecture, built from the same commit at the same workspace version, and executable.
2. `release.yml` builds or obtains the per-target CLI before `tauri build` and ASSERTS on the bundle afterwards: the sidecar exists, is executable, its architecture matches the target (`lipo -archs` or `file`; never run a cross-arch binary, since Rosetta on the runner is not something to rely on), and the native one's `--version` equals the tag. Probe the CLI sidecar, never `Contents/MacOS/app` (that launches the GUI).
3. Signing unchanged in kind. Compare `codesign -dv` and `codesign --verify --deep --strict` on a local bundle before and after your change, and record both. Confirm that the updater signature (`TAURI_SIGNING_PRIVATE_KEY`) covers the tarball and needs no change.
4. Optional: a Rust helper in the shim that resolves the bundled sidecar's path at runtime. If you add one it needs a caller or a test, or it is a dead-code warning, and the gates refuse warnings in test builds too.
5. Prove it locally: a real `tauri build` (or an install into a scratch location — NOT /Applications, where the user's live app is), list the bundle, run the sidecar's `--version`. Prove the workflow at least parses (a YAML parse, plus `actionlint` if you can get it), because it only runs on `v*` tags and its first real exercise would otherwise be a release.
6. Docs: AGENTS.md's Release section, and README or install notes wherever they describe what a release contains. CHANGELOG entries under the EXISTING `[Unreleased]` headers, then count them (one `### Added` and one `### Changed` at most).

## Out of scope

Starting `serve` from the app; Option A (the PATH link); Apple signing or notarization; iOS; Linux app bundles (there are none today); anything under `app/src`.

## Gates

The whole AGENTS.md Gates block: `cargo build --release -p worktrees-cli` first, then `make test` (redirect to a file; check the exit code and `grep -c '^not ok'`), `make lint`, `cargo test -p worktrees-core`, `-p worktrees-cli`, `-p worktrees-api`, `-p app --lib`, `tsc --noEmit`, `cargo check -p app`. Report cargo with a grep, not a tail. Zero warnings, test builds included.

## Working rules

- Commit identity `bret@brethash.com`, SSH-signed; confirm with `git log --show-signature -1`. NO `Co-Authored-By: Claude` trailer and no "Generated with Claude Code" footer, ever.
- No push and no PR. Commit locally.
- Never edit another place's tree (`feat-worktrees-serve`, `feat-serve-transport`, `feat-server-edition`, `(main)`, or any other).
- Keep `.planning/task_plan.md`, `findings.md` and `progress.md` current.
- When done or blocked, `report` to (main): what shipped, gate results with numbers, the before/after codesign output, and anything out of scope you noticed. If you are blocked, report instead of waiting.
