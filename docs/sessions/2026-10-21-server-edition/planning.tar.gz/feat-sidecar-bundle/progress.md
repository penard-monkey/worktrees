# Progress — sidecar bundle

## 2026-10-17
- Bootstrapped (submodules, pnpm 11.5.2 / node 22.23.3).
- M1 measured: externalBin via TAURI_CONFIG + no binary → `cargo check -p app`
  exit 101 "resource path `binaries/worktrees-aarch64-apple-darwin` doesn't exist".
- BEFORE bundle (unchanged tree, `tauri build --bundles app`): MacOS/ = app only;
  adhoc,linker-signed, CD 191192/5971 hashes, Sealed Resources=none;
  `--verify --deep --strict` exit 1 "code has no resources but signature
  indicates they must be present". Installed v0.42.0 release app: same kind.
  (scratchpad/codesign-before.txt)
- Implemented overlay, sidecar.sh, Makefile (stage/overlay/check, APPDIR, lint),
  release.yml (stage step, overlay, assert on bundle + unpacked tarball).
- `make install-app APPDIR=<scratch>`: 1st run FAILED in check (needle bug —
  the gate working); fixed; 2nd run exit 0, "sidecar ok … ran --version:
  worktrees 0.42.0". AFTER codesign: app identical signature fields; sidecar
  adhoc,linker-signed, `--verify --strict` valid; bundle `--deep --strict`
  exit 1, same message as before. (scratchpad/codesign-after.txt)
- Release-shaped build (stage --target aarch64 + tauri build --target + overlay
  + throwaway updater key): release.yml's assert step run verbatim → ok ×2;
  wrong tag / wrong target / non-exec / symlink / missing / fat-app mismatch
  all fail; cross-arch branch (fake uname) reads marker, does not run.
- Updater sig: verified with tauri-plugin-updater's own minisign-verify 0.2.5
  logic → VERIFIED; 1-byte flip → REJECTED; real pubkey → REJECTED (different
  key). Updater unpack applies mode & 0o777 → 0755 survives an in-app update.
- actionlint 1.7.7 (docker) on release.yml + ci.yml: exit 0, no findings.
- Docs: AGENTS.md (Release 4, bundle-probe note, stale-binary note, Local
  installs), README Install, CHANGELOG Added (header counts 1/1/1).
- Gates (binaries/ absent before AND after): release build fresh; bats 1..518,
  518 ok, 0 not ok; lint clean; core 799 passed/2 ignored; cli 68+1; api 158+7;
  app --lib 8; tsc 0 errors; check -p app finished; test-frontend 41 ok, 0 FAIL;
  0 `^warning` lines in any cargo log.
- actionlint proven to fail on a typo'd matrix key and a line pasted above name:.
- Committed 48a53a1 (build) + f435555 (docs), SSH-signed, no trailer. Reported.

## 2026-10-18 — rebase onto local feat/server-edition (asked by (main))
- Why: #508 had a double `.setup()` (tauri keeps only the last), so no Ctx was
  managed and every command panicked; fixed in bbfed64. Local tip ad09f5d.
- `git rebase feat/server-edition`: clean, no conflicts. 48a53a1 → 41c8642,
  f435555 → ddf5336; `git range-diff` says both patches are IDENTICAL (=).
  Both re-signed (Good signature, bret@brethash.com), no trailer.
  Ancestry: 0 behind / 2 ahead of feat/server-edition.
- CHANGELOG after rebase: [Unreleased] has one each of ### Changed / Added /
  Fixed; my bullet is the first under Added, bbfed64's under Fixed.
- Gates re-running (scratchpad/gates2.sh), then make install-app APPDIR=<scratch>.
- Gates after rebase (binaries/ absent before AND after): release build fresh;
  bats 1..518, 518 ok, 0 not ok, 0 bats warnings; lint clean; core 799
  passed/2 ignored; cli 68+1; api 158+7; app --lib 8; tsc 0 errors; check -p
  app finished; app/scripts/*-check.mjs from repo root: 41 ok, 0 FAIL
  (api-boundary-check.mjs among them); 0 `^warning` lines in any cargo log.
- `make install-app APPDIR=scratchpad/appdir2`: exit 0, "sidecar ok:
  Contents/MacOS/worktrees, arm64, ran --version: worktrees 0.42.0"; sidecar
  0755, 4,709,712 B, cmp-identical to staged copy and target/release/worktrees.
  Staged binaries/ removed afterwards. New tip ddf5336. Not pushed.

## 2026-10-20 — Linux (asked by (main))
- Measured: externalBin → .deb /usr/bin/worktrees, AppImage $APPDIR/usr/bin (first on
  the app's PATH via AppRun); both boot 60s, 0 [panic]/[error]; reported plan.
- Design (approved): per-format `files` mappings in base tauri.conf.json (overlay
  deleted), tauri.linux.conf.json mainBinaryName worktrees-app, deb depends tmux,git.
  Measured: cargo check -p app clean on mac + Linux with nothing staged; tauri build
  with nothing staged FAILS ("Failed to copy custom files"); signed build makes
  AppImage+.sig AND deb+.sig. deb sidecar byte-identical; AppImage's has RUNPATH=$ORIGIN.
- sidecar.sh: stage → binaries/worktrees; check .app|.AppImage|.deb; unpack. Fail-first:
  new check vs old externalBin bundles → red ("has usr/bin/worktrees"). 26 Linux
  negatives all correct (scratchpad/linux/negatives.log).
- release.yml: Linux rows, apt deps, --bundles deb,appimage, checks, tmux/git assert,
  packaging, latest.json 6 keys. actionlint 0 errors; red on 3 broken copies (incl.
  shellcheck SC2086). Manifest step dry run: 6 keys ok; missing .sig → exit 1.
- install.sh Linux app: fake-curl Docker test A–G all correct; pgrep fixes proven
  (mac old pattern matched a `…/MacOS/worktrees serve` decoy; new does not).
- make install-app Linux branch: ran in Docker → staged, AppImage, check ok, installed.
- (main) asked to FIX the AppImage env leak here. childenv.rs: red 5/7 vs stub → green
  8/8; over-broad mutant → "not touched" test red (exe-check mutant blocked by the
  classifier). Wired: core tmux_cmd/git_cmd/tmux_server configure; api term.rs pty
  (attach + dock shell), launch_watched, fixup_gui_path login shell. Also start_dir
  (AppRun chdir's to $APPDIR/usr).
- Before (pre-fix AppImage): GUI's login shell 23 leaked vars; tmux -g 20; pane env 20.
- Measurement found 2 more leaking spawns (status.rs cli_binary `$SHELL -lc`, pimodels
  preflight `$SHELL -ic`) → made it STRUCTURAL: childenv::command() for all 59 non-test
  spawns in core+api; childenv-check.mjs fails on a bare Command::new (green on tree, 67
  failures on HEAD's tree). 0 warnings across core/api/cli/app --tests.
- Release-shaped (release.yml Linux steps verbatim, --target, throwaway key): all ok.
  Updater sig (minisign-verify 0.2.5 logic): AppImage + deb VERIFIED; 1-byte flip
  REJECTED ×2; real pubkey REJECTED ×2.
- After: GUI login-shell runs 0+0 leaked (before 23+23); tmux -g 0 (20); pane 0 (20).
  Boot 60s deb + AppImage: alive, 0 [panic]/[error]; mcp_status worktrees=- (CliMissing)
  — no longer resolves the private sidecar.
- macOS make install-app (files mapping): ok, ran --version; target/release/worktrees
  not rewritten (mtime before staged copy); codesign same kind as before.
- Gates (binaries/ absent before+after): release build fresh; bats 518/518, 0 not ok;
  lint clean; core 807+2 ign; cli 68+1; api 159+7; app --lib 8; tsc 0; check -p app ok;
  42/42 check scripts; 0 cargo warnings. Linux (Docker): childenv 8/8, api pty 1/1,
  cargo check -p app with nothing staged ok.
- Committed 5afea57 (build) a27497d (fix) e77506e (docs), SSH-signed, no trailer.
  Docker volumes removed (image kept). Reporting to (main).

## 2026-10-20 — Phase 3: rebase onto feat/server-edition 4067c33 + Kimi spawns
- (main): e77506e pushed (fast-forward). Rebase onto 4067c33 (Kimi #509-#511).
- Conflict only in core lib.rs mod list (argv vs childenv) → kept both. Signed G on all 5.
- CHANGELOG [Unreleased]: Changed 1 (l.8), Added 1 (l.31), Fixed 1 (l.114); our bullets under Added.
- childenv-check on rebased tree: 7 FAIL (scratchpad/rebase/childenv-red.log) → routed → ok.
- First gate run: core test build failed E0433 `Command` in ops.rs tests (base's new git_in
  + locked-worktree test used super::*'s Command) → test module imports it. core 873 ok.
- Docker (volume wt-kimi-env): CLI built before (HEAD) / after (tree). FIRST after-build was a
  byte-identical binary: cargo skipped — source mtimes older than the before build's outputs
  (the AGENTS mtime trap). Touched the changed files → rebuilt → binaries differ.
- measure.sh (scratchpad/kimi): doctor --kimi; new --ai kimi; user mcp.json + open with
  guidance off (reaches worktree_dirs + hidden_by_us; exclude lines 3→0); new --brief with
  WORKTREES_CLI_BIN=wrapper (opener probe). before 34 spawns, 11 leaked ×21 = 231 lines;
  after 34 spawns, 0. measure5.log.
- R6: tauri.linux.conf.json category/longDescription/deb.section; `tauri bundle` around the
  old .deb's binary: Section devel, long desc, Categories=Development;, validate clean.
  The rm -rf in one inline script was refused by the safety check; rewrote with mktemp, no rm.

## 2026-10-20 — Phase 4: rebase onto feat/server-edition eb0f72e (#520)
- (main): 1e68942 force-pushed (lease e77506e, user's request). Maintainer stays David.
  User: NO Docker until disk is freed. Disk 4.5 GiB free at start.
- Rebase eb0f72e: one conflict (claude_usage.rs usage_get). Kept #520's usage_cmd +
  run_deadline_stdin; usage_cmd's curl → childenv::command (security already was).
  New tip c0b3bfb, 7 commits, all G bret@brethash.com, 0 trailers.
- CHANGELOG [Unreleased]: ### Changed 8 / Added 31 / Fixed 114, one each.
- childenv-check: ok (92 files). Mutant (curl bare again) → 1 FAIL at claude_usage.rs:141;
  restored by sed + touch → ok. Logs scratchpad/rebase/childenv-{eb0,curl-red,curl-green}.log.
- Staged sidecar (from appdir4 install-app) moved to scratchpad/staged-aside so gates run
  with nothing staged, as on a clean checkout.
- gates5 (from the repo root, gate slot): every step exit 0. bats 1..538, 538 ok, 0 not ok;
  core 880 running, 878 ok + 2 ignored (#520's 5 new tests ran and passed); cli 67+1;
  api 170+9+7+0; app --lib 8; lint (bash-3.2 clean); tsc; cargo check -p app; 43/43 check
  scripts; 0 `warning:` in any cargo log; binaries/worktrees absent. Disk ≥ 4.5 GiB throughout.
- Reported c0b3bfb to (main). Not pushed.

## 2026-10-20 — Phase 5: Linux re-verification on c0b3bfb (Docker back, 27 GiB free)
- scratchpad/c0b: extract.py (release.yml → steps/NN.sh), dock.sh (wt-c0b-* volumes, label
  wt-c0b=1), watchdog.sh (10 s df, kill below 8 GiB), build.sh, inspect.sh, boot.sh, envleak.sh.
- build.log: 9/9 steps ok — version gate, viewer, docs-server GATE 4 passed, stage, tauri build
  (deb + AppImage + 2 updater sigs, throwaway key), sidecar check ×2, viewer ×2, Depends/no
  tmux-git, package + checksum. 0 cargo warnings in the step logs.
- inspect2.log: 13/13 (inspect.log had two regex bugs of mine: `Depends: tmux` is ": tmux",
  dpkg-deb -c paths have no "./").
- boot-{deb,appimage}.log: exit 124 at 60 s, 0 [panic]/[error]; the GUI reads claude_usage at
  startup ("keychain: no Claude Code credentials").
- envleak2.log (+ out/cenv records): 0 leaked lines in all; GUI's usage GET curl.217 + CLI's
  curl.367 (default-claude `new`) + curl.493 (`new --ai claude`) all stdin byte-exact, no token
  on argv. Control 20 lines (control.308/434). envleak.v1.sh = the first run without the control.
- Removed volumes wt-c0b-work (3.56 GB) + wt-c0b-reg; deleted linux/out + linux/sigout package
  copies. Image kept. Watchdog min free 24.1 GiB.

## 2026-10-20 — Phase 6: lane C, the release dry run
- Design + reasons in task_plan D1. Files: release.yml (steps), publish.yml (tag + publish),
  release-dry-run.yml (PR caller), app/scripts/release-dryrun-check.mjs.
- actionlint-{1,2}.log: 0 errors; alint/{noinput,shellbug}.out: exit 1 each (scratch git repos —
  actionlint needs a .git to find the project).
- mut/ + mut2/: 10/10 red; mut/pre-change.out: 20 FAIL on c0b3bfb's workflows.
- run2.log: Docker rehearsal interrupted — plan ok (but empty matrices: the image has no jq, and
  the step swallowed it → the plan fix), build ×3 ok, app-bundle 01-04 ok (docs GATE 4 passed,
  staged 0.42.0), 05 killed (exit 137) by the watchdog at 18:48:39, free_kib=231476 after the Mac
  woke from hibernate (pmset: Low Power Sleep 17:41:45 at 1% battery; Wake 18:48:38). Swap
  25.8/26.4 GB. Volumes removed. Not re-run: needs a go-ahead given memory/swap.
- stepcheck.log: 15/15 under bash 5.2 in a no-volume container. samejson.log: old vs new
  latest.json identical content (key order only).
- Commits ac7af0e, 6e75157.

## 2026-10-21 — Phase 7: D1
- d1/red.log: the_cli_an_app_bundle_carries_is_never_handed_out FAILED on the pre-fix seam
  (left = …/Worktrees Server.app/Contents/MacOS/worktrees, right = …/home/.local/bin/worktrees).
- d1/green.log: 3/3. d1/mutate.log: M0-M4 all rc=101, file restored identical.
- d1/drift-{green,red}.log: tauri.conf.json .deb dest → /usr/libexec/…: red; restored identical.
- Docker image wt-sidecar-linux:arm64 removed ((main) said so). Disk 19 GiB.
- gates7: build/fresh/bats 538/538/lint/core 882+2/cli 68/api 186/app 8/tsc/check, 44/44 mjs, 0 warnings,
  disk min 19.8 GiB. After the CHANGELOG rewrap: api 186, plan-usage-check 21, core docs:: 37 — green.
- Commit f46c224 (G bret@brethash.com, 0 trailers). Not pushed.

## 2026-10-21 — Phase 8: merge of the stack top
- 1401853 = merge f46c224 + 2b3c359; tree == b161a63 + D1 (m525/merged-vs-ref.diff == m525/d1.diff).
- childenv-check without the tests.rs skip: FAIL serve/tests.rs:748 (m525/childenv-without.log).
- gates8: all green but transport-check + test-frontend, which failed on a STALE app/dist (ignored,
  from my pre-merge bundle builds; the check printed "app/dist is older than ipcws.ts or main.tsx").
  After the gate's own pnpm build: transport-check with dist ok; dist removed; re-run without dist:
  transport 204/0, test-frontend 48/48. Counts = rehearsal d4ce51b's, core +4 (D1).

## 2026-10-21 cleanup
- #513 in main (8f65acd, via #525 squash 73d6cb3). (main) asked for `cargo clean` only: target/ was this tree's own (no CARGO_TARGET_DIR), nothing running from it; removed 45605 files / 12.8 GiB; free 16.4 -> 30.3 GiB. Branch, tree (1401853, clean) and place kept. Standing by.
