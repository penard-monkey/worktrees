# Task plan — bundle the CLI inside the app as a private sidecar (Option B)

Brief: `.planning/brief.md`. Branch `feat/sidecar-bundle` (based on
`feat/server-edition`, PR #508). No push, no PR; commit locally, report to (main).

## Goal
The macOS app bundle carries `Contents/MacOS/worktrees` — the CLI for the
bundle's own arch, same commit + workspace version, executable — from BOTH
release.yml and `make install-app`, while check/test/dev on a clean checkout
need no extra step.

## Phases
- [x] 1. Measure: does `externalBin` in config break `cargo check -p app` with no
      binary? Where does tauri-build copy it (collision with target/<p>/worktrees)?
      Where does the bundler read it from?
- [x] 2. "Before" local bundle: `tauri build --bundles app` on the unchanged branch;
      record `codesign -dv` + `codesign --verify --deep --strict`.
- [x] 3. Design + implement: overlay config, staging script, Makefile, release.yml
      (stage + assert), optional Rust helper.
- [x] 4. Prove locally: real bundle via the Makefile path into a scratch dir; list
      it, run the sidecar's `--version`; "after" codesign; YAML parse + actionlint.
- [x] 5. Docs: AGENTS.md Release, README/install notes, CHANGELOG (count headers).
- [x] 6. Gates (all, numbers), commit (signed, no trailer), report to (main).
- [x] 7. Rebase onto local feat/server-edition (bbfed64 setup fix), re-run gates +
      every *-check.mjs + install-app APPDIR=<scratch>, report new tip.

## Decisions
- externalBin ONLY in `app/src-tauri/tauri.bundle.conf.json`, passed with
  `--config` by release.yml and `make install-app` (M1: in the base config it
  breaks a clean `cargo check -p app`). tauri.conf.json is byte-identical.
- ONE script, `app/scripts/sidecar.sh` (stage | check), run by BOTH release.yml
  and `make install-app`, so every local install exercises the release path.
- Release builds the CLI in the app-bundle job (same checkout => same commit by
  construction) rather than downloading the `build` job's artifact.
- `check` runs on the bundle AND the unpacked updater tarball (what ships).
- Cross-arch version read as data with stale.rs's own rule (NUL both sides,
  x.y.z core) — the scanner's needle is in the binary too.
- No Rust helper (optional deliverable 4): its only honest caller is the lane
  that starts `serve`, which also has to decide what dev mode (`tauri dev`,
  sandbox) resolves to — there is no bundle there.
- `make install-app APPDIR=<dir>` added so the make path can be proven without
  touching /Applications.

## Errors
| Error | Attempt | Resolution |
|-------|---------|------------|
| check: "version marker says ' 0.42.0'" | 1st make install-app | grep found stale.rs's needle too (empty value); read NUL-delimited whole segments like read_version does |

## Phase 2 — Linux is a default target (PR #513, asked by (main) 2026-10-20)
New commits on ddf5336, no push. tmux/git are NOT bundled (.deb Depends; AppImage
uses the system's, like macOS).
- [x] L1. Measure in Docker (ubuntu:24.04 arm64): externalBin → .deb /usr/bin/worktrees,
      AppImage $APPDIR/usr/bin/worktrees (AppRun PREPENDS it to PATH). Both boot 60s,
      0 [panic]/[error]; mcp_status resolved the sidecar as `worktrees` in both.
- [x] L2. Report plan + measurements to (main).
- [x] L3. Config: drop externalBin + overlay; per-format `files` mappings in the base
      tauri.conf.json (macOS MacOS/worktrees, deb + AppImage /usr/lib/worktrees/worktrees);
      deb depends tmux, git; tauri.linux.conf.json mainBinaryName worktrees-app.
      Measure: cargo check clean on Linux; bundler FAILS with nothing staged.
- [x] L4. sidecar.sh: stage → binaries/worktrees; check .app | .AppImage | .deb (ELF arch,
      no usr/bin/worktrees, marker/--version). Negatives on Linux.
- [x] L5. release.yml: linux x86_64 (ubuntu-latest) + aarch64 (ubuntu-24.04-arm), deb +
      AppImage, checks, latest.json linux keys (+ -deb if signed). actionlint red/green.
- [x] L6. install.sh Linux app (~/Applications/worktrees.AppImage + .desktop), pgrep fix.
      Prove with fake curl in Docker. bash-3.2 lint.
- [x] L7. make install-app Linux branch (run inside Docker).
- [x] L8. Re-boot the new bundles; updater sig on AppImage (throwaway key); macOS
      install-app; full gates.
- [x] L8b. (main) 2026-10-20: FIX the AppImage env leak in this branch — one core
      helper (worktrees_core::childenv), spawn points in core + api, fail-first
      tests, Docker before/after (tmux show-environment -g + pane env), no-op pinned.
- [x] L9. Docs (AGENTS Release + Local installs, README, CHANGELOG count), ROADMAP
      (AppImage env leak into tmux), commit, report.

## Phase 3 — rebase onto feat/server-edition 4067c33 + Kimi spawns (asked by (main) 2026-10-20)
e77506e is pushed by (main). New base 4067c33 brings Kimi (#509-#511). No push after.
- [x] R1. Rebase; resolve core lib.rs mod list (Kimi modules vs childenv). argv + childenv both kept.
      Base's new ops.rs tests reached `Command` via super::* → own `use std::process::Command`.
- [x] R2. childenv-check.mjs red on the Kimi spawns (7: kimi.rs ×2, kimi_usage, kimiplace ×3,
      ops.rs doctor), routed → green. 5c63f78.
- [x] R3. CHANGELOG: under [Unreleased] exactly ONE each of Added, Changed, Fixed (8/31/114).
- [x] R4. Full gates from the repo root (gates4): bats 538/538, core 873+2i, cli 67+1, api 170+9+7,
      app 8, lint/tsc/check clean, 0 warnings, 43/43 check scripts. macOS install-app → appdir4 ok.
- [x] R5. Docker (real AppRun, CLI as GUI stand-in): before 11 spawns × 21 leaked, after 0/34.
      kimi::version() (Settings only) not reachable headless.
- [x] R6. .deb Section devel + longDescription + Categories=Development; via tauri.linux.conf.json
      (Linux-only). Verified by `tauri bundle` re-bundle in Docker. 1e68942.
- [x] R7. Report new tip 1e68942 to (main); no push.

## Phase 4 — rebase onto feat/server-edition eb0f72e (#520, asked by (main) 2026-10-20)
1e68942 was force-pushed by (main). eb0f72e = 4067c33 + merge of main's #520 (OAuth token
off curl argv: usage_cmd + proc::run_deadline_stdin). NO Docker (disk). No push after.
- [x] Q1. Rebase; one conflict, claude_usage.rs usage_get: kept #520 in full; usage_cmd's curl
      and claude_oauth_token's security both via childenv::command.
- [x] Q2. childenv-check green; red when usage_cmd's curl is put back bare (1 FAIL, l.141),
      restored by sed + touch. #520's other Command::new are proc.rs tests only.
- [x] Q3. CHANGELOG [Unreleased]: Changed l.8, Added l.31, Fixed l.114 (one each); #520's
      bullet under Fixed (l.167, before ## [ at l.172).
- [x] Q4. Full gates from the repo root (gates5), all exit 0: bats 538/538, core 878+2i (880;
      #520 +5), cli 67+1, api 170+9+7, app 8, lint/tsc/check clean, 43/43 checks, 0 warnings,
      nothing staged. Disk stayed 4.5-4.8 GiB.
- [x] Q5. Report the new tip c0b3bfb to (main); no push.

## Phase 5 — Linux re-verification on c0b3bfb (asked by (main) 2026-10-20, Docker back)
c0b3bfb is pushed (#513 tip, CI 9/9). No code change expected; report failures before fixing.
Disk floor 8 GiB (watchdog kills wt-c0b containers below it); clean up volumes + outputs.
- [x] P1. release.yml's Linux app-bundle steps, extracted from c0b3bfb (9 run steps, apt one
      skipped), fresh volumes wt-c0b-*, throwaway updater key: all 9 ok. 363 crates compiled.
- [x] P2. Packages: sidecar at usr/lib/worktrees/worktrees (regular, +x, --version 0.42.0),
      nothing in usr/bin but worktrees-app (+ xdg-open in the AppImage); .deb Section devel,
      long description, Depends tmux, git; both .desktop Categories=Development; validate clean.
      13/13 (first two runs had two regex bugs in MY script, not the package).
- [x] P3. Boot 60 s headless: .deb and AppImage both alive (124), 0 [panic], 0 [error].
- [x] P4. Env leak: GUI login shells 2, GUI's own security + 3 curls (incl. the #520 usage GET),
      tmux show-environment -g (22 lines), pane env (29), CLI quota-gate security + usage curl
      + fake claude: 0 leaked everywhere. Usage GETs ×3: no token/Bearer on argv, `-H @-`,
      stdin byte-exact. Control: AppRun's env for the CLI carries 20 matching vars.
- [x] P5. Cleanup: volumes removed, image kept (2.71 GB), old Linux package copies deleted.
      Disk min 24.1 GiB. Report to (main).

## Phase 6 — lane C: a Linux release DRY RUN (asked by (main) 2026-10-20)
New commits on #513, no rewrite, no push. Publishing guarded off on the PR path; a throwaway key.
- [x] D1. Design: release.yml = steps only (workflow_call, required boolean dry_run, read-only,
      no publishing op); publish.yml = v* tag → calls release.yml dry_run:false + key, then
      `gh release create` from release-dist (the one contents:write job); release-dry-run.yml =
      pull_request paths filter → dry_run:true, no secrets. Not `if: inputs.publish` (a tag push
      has no inputs → empty == false → real release skips publish) and not a ci.yml job (paths:
      is workflow-level; a callee error would sink every ci check).
- [x] D2. plan job: tag (v+Cargo in a dry run; refuses publish off a v* tag) + cli/app matrices
      from one table (dry rows: CLI linux×2, app mac-arm64 + linux×2). TAG replaces
      GITHUB_REF_NAME in every other job. Key step: dry run refuses a real key, generates a
      throwaway; release refuses a missing key. latest.json from the built targets; a release
      must have all six keys. Artifacts 1 day in a dry run.
- [x] D3. app/scripts/release-dryrun-check.mjs: green; red on 10 mutations + c0b3bfb (20 FAIL).
- [x] D4. actionlint 1.7.7: 0 errors on 4 workflows; red on a missing required input and on a
      shellcheck SC2045 inside a step.
- [x] D5. Docker rehearsal (aarch64): plan, CLI build, app-bundle 1-4 ok; KILLED in step 5 by my
      watchdog — the Mac hibernated at 1% battery (17:41→18:48), swap 25.8 GB, 0.23 GiB free on
      wake. Not restarted. Found: plan's `echo "x=$(jq)"` swallowed a jq failure → fixed.
- [x] D6. bash-5 step checks in a throwaway container (no volume): 15/15 (plan ×4 modes, jq
      before/after, key ×4 branches, manifest dry/release/missing/empty sig); old vs new
      latest.json same content for a full release.
- [x] D7. Commits ac7af0e (ci) + 6e75157 (docs), signed, no trailers. CHANGELOG: none (CI only).
- [x] D8. Full gates (gates6) all exit 0: bats 538/538, core 878+2i, cli 67+1, api 170+9+7,
      app 8, lint/tsc/check clean, 44/44 checks, 0 warnings, disk min 15.1 GiB. Reported.

## Phase 7 — rehearsal defect D1: the bundled CLI is never handed out (asked by (main) 2026-10-21)
Source: ~/.cache/worktrees/worktrees/rehearse-server-edition-update/report.md (Defects D1). D4/D5 skipped (user).
- [x] D1.1 Seam: worktrees_bin() → worktrees_bin_in(over, exe, PATH), pure refactor first
- [x] D1.2 Test red on the unfixed logic (bundle exe → the bundle path, not ~/.local/bin)
- [x] D1.3 Fix: is_bundled_cli (path rule: Contents/MacOS/, usr/lib/<x>/) on exe, override and PATH walk
- [x] D1.4 Mutations: 5/5 red; drift test vs tauri.conf.json `files` (red on a moved .deb path)
- [x] D1.5 Audit every caller (list in findings)
- [x] D1.6 CHANGELOG (amend the Added sidecar item; the bug never shipped), sidecar.sh header, AGENTS Release
- [x] D1.7 Gates (gates7) green, commit f46c224 signed, reported to (main)
Decision: a PATH rule, not a marker. The copy is the same build install.sh ships (nothing inside it
differs); an env marker from the app would leak into every pane serve starts and miss a hand run;
APPDIR is scrubbed before serve starts (#524 via childenv). The rule is pinned to tauri.conf.json.

## Phase 8 — merge the stack top (#513 retargeted onto feat/engine-auto-reconnect, asked by (main) 2026-10-21)
- [x] M1 Merge origin/feat/engine-auto-reconnect 2b3c359 on f46c224: 1 textual conflict (CHANGELOG ### Added)
- [x] M2 Resolutions as b161a63 (engine.rs childenv::command; childenv-check skips serve/tests.rs), D1 hunk on top
- [x] M3 Tree check: diff vs b161a63 == diff 6e75157..f46c224, byte-identical (hunk headers aside)
- [x] M4 Merge commit 1401853 signed, 0 trailers
- [x] M5 Gates (gates8) green after a stale app/dist (pre-merge, ignored) was cleared; reported to (main)
Note: origin/feat/server-edition has a0929b2 (D6) not yet in the stack top; the next merge brings it.
