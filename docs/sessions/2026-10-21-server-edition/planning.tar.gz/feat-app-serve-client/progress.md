# progress — feat/app-serve-client

2026-10-20
- 73183d8 feat(serve): --owner app; open_docs_viewer → Engine row (+ no-bundle refusal test)
- 4b19e6f feat(app): engine.rs find-or-start (decide/observe/probe/spawn/adopt/replace), lib.rs client-only; checks
- aee051b feat(app): engineDoor routing + state, ready, EngineGate, gen in pane keys, raise_window; transport/engine-route checks
- fadb2ce docs: CHANGELOG, AGENTS.md, docs/engine-client-manual-checks.md, sandbox.sh beforeDevCommand + WORKTREES_SERVE_BIN
- Drive (no clicks, isolated tmux /tmp/claude-501/wtsbx): start → adopt after SIGTERM'd app → replace 0.42.0-mm → use unowned. 0 panics.
  Logs: ~/.cache/worktrees/worktrees/feat-app-serve-client/drive-{app,serve}.log
- Manual (hands): typing in dock, a note, Reconnect after kill -9, clean ⌘Q owned/unowned — docs/engine-client-manual-checks.md
