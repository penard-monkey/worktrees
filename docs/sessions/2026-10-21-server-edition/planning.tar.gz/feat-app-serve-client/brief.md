# The desktop app becomes a client of `worktrees serve` (Server Edition, Phase 1, last slice)

You are a lane. `(main)` coordinates you through the worktrees MCP `report` / `messages` tools. Do NOT push.

## Where this sits

This lane stacks on four open PRs, none merged yet:

| PR | Branch | What it adds |
|---|---|---|
| #508 | `feat/server-edition` | the `worktrees-api` extraction: 150 commands, `Ctx`, `host::boot`/`start`/`stop` |
| #516 | `feat/worktrees-serve` | `worktrees serve`: loopback WebSocket, handshake v1, `serve.json`, the dispatch/exposure table, one engine per host |
| #515 | `feat/serve-transport`, **your base** at `f9dc344` | the frontend's one door (`app/src/ipc.ts`) and a DEV-ONLY socket client (`app/src/ipcws.ts`, `pnpm dev:serve`) |
| #513 | `feat/sidecar-bundle` | **NOT in your base.** The CLI is bundled privately inside the app; on Linux, AppImage and `.deb` |

Read these first:
- `docs/proposals/server-edition.md`: decisions 1, 2, 5 and 6, §III.7 Transport (reconnection), §III.9 Phase 1 and Appendix B;
- the crate doc of `crates/worktrees-api/src/lib.rs`;
- `crates/worktrees-cli/src/serve/{mod,servefile,dispatch,policy,wire}.rs`;
- `app/src/ipc.ts`, `app/src/ipcws.ts` and `app/src/main.tsx`;
- `app/src-tauri/src/lib.rs` `run()`.

## The goal

**One engine per host.** Today the app links the engine in-process: `host::boot`/`start` in `run()`, its own `Ctx`, the nav-dot poll, dock PTYs and the docs server. After this lane, the shipped desktop app holds only:
- the window;
- the client-local commands;
- the job of FINDING OR STARTING a local `worktrees serve`, then talking to it over the socket.

Everything else goes through serve.

Phase 1's exit criterion applies, in the REAL app rather than Chrome: `list_workspace`, a mutation, a terminal attach and a dock shell all work through serve.

## What has to exist

1. **Find or start.** The shim (Rust) reads `<app config dir>/serve.json` (`{port, token, pid, version}`, mode 0600). A serve counts as usable only when ALL of these hold:
   - the pid is alive;
   - the port accepts a connection;
   - the handshake's server proof verifies;
   - the version equals the app's.

   Anything less means stale, an impostor or a mismatch. Start one from the private CLI with `worktrees serve --config-dir <app config dir>`. Where that binary lives, as measured by the sidecar lane:
   - macOS: `current_exe().parent()/worktrees` (`Contents/MacOS/worktrees`);
   - Linux `.deb`: `/usr/lib/worktrees/worktrees`;
   - AppImage: `$APPDIR/usr/lib/worktrees/worktrees`;
   - BOTH Linux layouts are `app.path().resource_dir()/worktrees`;
   - DEV: `resource_dir` is `target/debug`, which may hold a debug CLI, so "found there" does NOT mean the bundle.

   Give dev an explicit path, e.g. a `WORKTREES_SERVE_BIN` env override, else the workspace's `target/{debug,release}/worktrees`, and say which was used in app.log.

   Put the decision (use / replace / start / refuse) in a PURE function over the observed state, and unit-test every branch:
   - no file;
   - an unparsable file;
   - a dead pid;
   - a live pid with a closed port;
   - a port held by something that fails the proof;
   - a live serve on the same version;
   - a live serve on another version.

   Spawn only AFTER `fixup_gui_path()`, so serve inherits the fixed PATH. Pass through whatever env the sandbox relies on: `sandbox.sh --app` sets its own identifier, and the tmux prefix must reach serve.
2. **Lifetime. Default below; tell (main) if you find a reason against it.**
   - Starting a serve: the app owns it, and SIGTERMs it on a clean quit. That keeps today's behaviour, where quitting ends dock shells and serve's `host::stop` flushes the rings.
   - Finding one already running (the CLI, `pnpm dev:serve`, or a crash leftover on the same version): the app uses it and does NOT stop it on quit.
   - If the app crashes, serve survives, and the next launch finds it.
   - Version mismatch: replace the old serve. Prove it is a real serve on that config dir first (proof verified, pid from its file), SIGTERM it, wait for its file to go, then start ours. Never kill a pid that failed the proof.
3. **The door in production.** Today `main.tsx` installs the socket only under `import.meta.env.DEV && VITE_SERVE`. Make the shipped app use the socket for everything EXCEPT serve's `ClientLocal` rows, which stay on Tauri IPC because they act on the machine the window runs on:
   - `copy_text`, `install_app_version`, `open_editor`, `detect_editors`, `open_terminal`, `set_zoom` and `open_docs_viewer`, per `dispatch.rs` at your base.

   Route by command name in one table, and add a drift check (the shape of `dnd-check.mjs`) that pins that table against `dispatch.rs`'s `ClientLocal` rows both ways.

   The token reaches the webview only as the result of one Tauri command the shim answers. It never goes in a URL, localStorage or a log line.

   The mock harness (`pnpm dev:mock`) must keep working untouched. `transport-check.mjs` currently asserts the production bundle carries NO socket client; that assertion changes meaning, so update it to say what is now true, and keep a test that fails if the dev-only `--allow-origin` path could ship.
4. **The shim stops being an engine.** `run()` no longer builds a `Ctx` or calls `host::start`.
   - **Default: no in-process fallback.** If serve can't be started, show a clear error naming `~/.cache/worktrees/serve.log`. A silent embedded engine would make two engines.
   - Keep `api-boundary-check.mjs` meaningful: it currently counts one `.setup(` and a managed `Ctx`. Rewrite what it asserts to the new truth, and show each new guard failing first.
   - The commands registered in `generate_handler!` shrink to the client-local ones plus whatever the shim itself needs.
   - Viewer refresh wiring: check where `viewer::refresh` now runs. Serve's host poll should own it, and nothing may be left polling nothing.
5. **Disconnects.** Serve dying or the socket dropping must not look like a closed place or a blank app.
   - **Minimum:** a visible "engine disconnected" state, plus a Reconnect action that re-runs find-or-start, re-subscribes events and lets terminals re-attach through their existing remount path. The ring replay and its `── restored ──` seam already handle a re-attach.
   - **Not required:** automatic reconnection with backoff. If it falls out cleanly, say so; if not, list it as the next slice.

## Rules

- **Plan first.**
  1. Write `task_plan.md` (gitignored).
  2. REPORT the plan to (main) before rewriting `run()`: the decision table, the lifetime rules, the routing table and what each check will assert.
  3. Wait for (main)'s OK.

  Reading and measuring before then is fine.
- **Linux support is the default.** Every path you add covers Linux x86_64 and aarch64 as well as macOS, or says why not. NO Docker (the user's disk is nearly full), so Linux evidence is unit tests that run on both OSes plus CI's ubuntu jobs. List anything only Docker could show as unverified.
- **AGENTS.md traps that apply here:**
  - run gates from the REPO ROOT with `worktrees run --slot gate -- …`;
  - build `cargo build --release -p worktrees-cli` FIRST, and confirm it is newer than the sources;
  - report cargo with `grep -E "^running|^test result"`, never tail;
  - every new test must be shown failing first: break it, watch it go red, then restore by EDITING back and `touch`;
  - `sandbox.sh --app`: drive it by PID only, never by name, and read only the bytes of app.log appended after your start offset;
  - HMR is dead inside `.worktrees/`;
  - tmux probes must always use `-L <name>`;
  - never a bare `git stash`;
  - `$x:path` in zsh is a modifier trap, so write `${x}:path`.
- **Commits:** `bret@brethash.com`, SSH-signed (`%G?` = G). NO `Co-Authored-By` trailer and NO "Generated with" line. Small reviewable commits; a CHANGELOG entry under `## [Unreleased]`, counting the `###` headers.

## Done means

Gates all green with 0 warnings:
- bats;
- lint;
- core, cli and api tests;
- `app --lib`;
- tsc;
- `cargo check -p app`;
- every `app/scripts/*-check.mjs`, run from the root.

Then a REAL-APP drive with `sandbox.sh --app`, read through app.log and serve.log:
1. The app starts serve and lists the workspace.
2. Open a place's terminal; open a dock shell and type into it.
3. Make one mutation (a note, say).
4. Kill serve by PID, see the disconnected state, press Reconnect, and get the terminals back.
5. Quit, and confirm serve stopped.
6. Relaunch with a serve already running, and confirm it is used and left running on quit.
7. Make the version mismatch real (e.g. a serve from another build), and confirm it is replaced.

`[panic]` must stay at 0 throughout.

Report to (main): the tip, the commits, the gate table, the drive results with log excerpts, and everything unverified.
