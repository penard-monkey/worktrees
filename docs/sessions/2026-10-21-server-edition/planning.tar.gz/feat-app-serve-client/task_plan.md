# task_plan — the desktop app becomes a client of `worktrees serve`

Base: `feat/serve-transport` @ f9dc344 (PRs #508 → #516 → #515 stacked; #513 sidecar NOT in base).
Status: BUILT — 4 commits on f9dc344; gates running; drive done minus click steps.

## Phases

1. [x] Read: brief, proposal (decisions 1/2/5/6, §III.7, §III.9, App. B), api crate doc,
       serve/{mod,servefile,dispatch,policy,wire,conn}.rs, ipc.ts/ipcws.ts/main.tsx, lib.rs run(),
       host.rs, the four checks (api-boundary, transport, serve-dispatch, hostpolicy).
2. [x] Report plan to (main); wait for OK (viewer question Q1 needs an answer).
3. [x] Shim: `engine.rs` (observe → pure decide → act; probe; spawn; ownership) + unit tests.
4. [x] Shim: `run()` stops being an engine; handler list = client-local + shim's own.
5. [x] Frontend: routed door + engine state in ipc.ts; `ready` on SocketDoor; production boot
       in main.tsx; EngineGate (startup screen + disconnected banner + Reconnect); App: engine
       generation in terminal keys + re-pull; raise_window on app:open-doc.
6. [x] Checks: engine-route-check.mjs (new), api-boundary rewrite, serve-dispatch rewrite,
       hostpolicy rule 4 → serve, transport-check edges + router tests. Each new guard shown red.
7. [ ] Gates (from repo root, `worktrees run --slot gate`).
8. [x] Real-app drive (sandbox.sh --app, by PID) — 7 steps, logs.
9. [x] CHANGELOG, AGENTS.md, commits, report.

## Decision table (pure `decide(Seen, our_version)`)

| Seen (observed in this order, stops at first failing step) | Decision |
|---|---|
| NoFile                          | Start |
| Unparsable(file)                | Start (serve overwrites it; a real serve's file is renamed into place, never partial) |
| DeadPid(sf)                     | Start (stale: crash / reboot) |
| PortClosed(sf) — pid alive      | Start (stale: pid reused, or serve mid-stop; serve's own live_other agrees) |
| Unproven(sf, why) — port open, proof fails | Refuse — never kill, never delete the file; error names pid, port, serve.json, serve.log |
| Proven(sf, v) v == ours         | Use |
| Proven(sf, v) v != ours         | Replace: SIGTERM sf.pid, wait ≤10s for serve.json to go / pid to die, then Start; still alive → Refuse |

Start = spawn `<bin> serve --config-dir <app config dir>` (+ `--allow-origin <devUrl origin>` ONLY under
`cfg(dev)`), setsid, stdio null, after host::boot's fixup_gui_path; wait ≤20s for serve.json naming
the child pid + a passing probe; child exits first → re-observe once (another app won the race → Use),
else Err naming serve.log. Probe Origin: `tauri://localhost` in release, devUrl origin under cfg(dev).

## Lifetime
- Started by us → owned (pid of an unreaped child; a reaper thread logs its exit and clears ownership).
  Exit arm: SIGTERM owned serve, brief wait, log outcome.
- Found (Use) → not owned, never signalled on quit.
- Replace → SIGTERM only after Proven; never a pid that failed the proof.

## Routing (ipc.ts, one table)
LOCAL (→ Tauri IPC) = serve's ClientLocal rows: copy_text, install_app_version, open_editor,
detect_editors, open_terminal, set_zoom, open_docs_viewer(*Q1)  + SHIM: engine_connect, raise_window.
Everything else → the socket. dev:serve (browser): no local half — everything to the socket as today.

## (main)'s rulings (2026-10-20, msg 1792529096357)
- Q1 = B: open_docs_viewer → Engine row (ClientLocal = 6). Update Appendix B (ISSUED/registrations),
  proposal ClientLocal list, dispatch.rs comments. CLI-started serve w/o WORKTREES_VIEWER_JS → clear
  error, no panic, TEST pins it. Queued bullet: loopback URL means nothing to a remote client.
- Crash leftover IN THIS SLICE: `serve --owner app` → optional `owner` in serve.json (serde default).
  decide(): Proven + same version + owner=app → ADOPT (owned, SIGTERM on clean quit; not our child →
  watch by pid + probe, no reaper). No owner (CLI/dev:serve) → Use, never signalled. Test both.
- Approved: Unproven→Refuse; Replace SIGTERM/10s/Refuse, never SIGKILL; token only via engine_connect;
  EngineGate; raise_window; gen in keys; checks; fix policy.rs Linux-origin comment.
- DRIVE: NO scripted UI (not even AXPress). Click steps (Reconnect, clean Quit) → docs/*-manual-checks.md.
- DISK: no release build unless df ≥ 15 GiB free; mismatch CLI = debug build sharing target deps,
  delete export after; < 5 GiB free → stop and tell (main).

## Errors encountered
| Error | Attempt | Resolution |
|---|---|---|
| owner test green w/o serde(default) | mutation | serde defaults a missing Option anyway; mutated skip_serializing_if instead |
| fake serve took observe's bare port check as its one connection | 1 | accept loop skipping non-upgrades, bounded 10s |
| mutated probe hung the suite in accept | 1 | nonblocking accept + deadline |
| transport-check exit 13 under mutation (pending await) | 1 | every engine-door await raced via settle() |
| tmux socket "File name too long" | 1 | TMUX_TMPDIR=/tmp/claude-501/wtsbx (macOS 104-byte cap) |
| screencapture -l refused | 1 | no Screen Recording grant; evidence from logs/processes |
| Chrome extension not connected; peer venv lacks playwright | 1 | mock harness not driven in a browser — listed unverified |
