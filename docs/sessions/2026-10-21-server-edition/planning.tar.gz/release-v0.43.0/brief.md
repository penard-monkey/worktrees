# Brief: cut v0.43.0, the Server Edition release

You are a lane coordinated by (main). Report on the bus with the MCP `report` tool when you're done or blocked.

## Context
main is at 8f65acd. It now carries the whole Server Edition stack as five squash commits:
- #508: Phase 0, worktrees-api;
- #516: `worktrees serve`;
- #515: the transport;
- #524: the desktop app is a client of serve, one engine per host;
- #525: auto-reconnect. #513, the CLI bundled in the app as a private sidecar, lands inside #525's commit.

It also carries the update-rehearsal fixes D1, D2, D3, D6 and D7. Before those: #521, #522 and #523 (atomic writes never follow a symlink).

The last release is v0.42.0 (tag v0.42.0, commit 7344ba9, "chore: release v0.42.0 (#498)"). Mirror that commit and v0.41.0's (6263cb9, PR #481) for shape.

## Do
1. Follow AGENTS.md "Release" steps 1–2 exactly:
   - CHANGELOG: move `## [Unreleased]` into `## [0.43.0] - 2026-10-21`, and leave a fresh empty `## [Unreleased]` above it, as the previous release commits did.
   - Bump the workspace `Cargo.toml` version to 0.43.0, and `install.sh` `SCRIPT_VERSION` to "v0.43.0".
   - Let cargo update Cargo.lock. There are now FOUR workspace crates (worktrees-api is new), so expect 8 changed lines, not 6.
   - If ROADMAP.md has a version or "current release" line like the one v0.42.0 touched, update it the same way.
2. Read the new `## [0.43.0]` section as RELEASE NOTES. release.yml publishes it, and the app shows it as "What's new".
   - Check for duplicate `### ` headers (exactly one each), entries that landed in the wrong release, and anything that clearly reads as unfinished.
   - Don't rewrite prose wholesale. Fix only real defects, and list what you changed.
   - The user explicitly said NOT to bother with the stale "the app will start serve" wording in #513's sidecar item. Leave that alone.
3. Gates (AGENTS.md "Gates", release build FIRST; report counts with grep, never tail). `test/misc.bats` asserts the binary version against Cargo.toml, so the release build must be fresh. Also run the `app/scripts/*-check.mjs` set from the repo root, including release-dryrun-check.
4. An empirical D1 check, cheap, with no app bundle and no GUI:
   - Copy the fresh `target/release/worktrees` into a scratch `X.app/Contents/MacOS/worktrees` under `$TMPDIR`.
   - Run `worktrees serve --config-dir <scratch>` from that copy, with an isolated HOME. Keep the real PATH so the installed `~/.local/bin/worktrees` still resolves, and use a private TMUX_TMPDIR.
   - Confirm that serve.log's `mcp_status` line names the PATH CLI, not the bundle copy.
   - SIGTERM it afterwards, by pid only.
   - Never touch the real `~/.claude.json`, the real app, or `~/.tauri/worktrees-updater.key`.
5. Commit on this branch with the message `chore: release v0.43.0`. Identity bret@brethash.com, SSH-signed. NO Co-Authored-By trailer and no Claude attribution anywhere.
6. Do NOT push, do NOT tag, and do NOT run `make release`. (main) handles the push and the PR after the user says go. Tagging happens from the root checkout afterwards.
7. Report to (main): the SHA, the files changed, any release-notes fixes, the gate counts, and the D1 check result. Also draft a PR title (`release: v0.43.0 — <short summary>`) and a short PR body in #481's style: a few bolded headline lines and no attribution footer.

## Rules
- No bare `git stash`.
- Stop if free disk drops below 8 GiB.
- Never script clicks or keys into any app.
- Fresh worktree: run `git submodule update --init --recursive` and `pnpm install` in `app/` (Node >= 22.13) first.
