# Progress

2026-10-21 start. disk 24Gi free, swap 821M free.
- Step 0 done: submodules, pnpm 11.5.2 / node 22.23.3, old CLI 0.42.0 on PATH.
- Step 1: merge b161a63 (1 textual + 2 semantic conflicts, sidecar-merge.md), bump d4ce51b (+ CHANGELOG [0.43.0] cut). Gates running (bg task bqxvibfdn) -> $C/gates-d4ce51b/summary.txt
- Prep: $C/renv (env -i wrapper), $R/.gitconfig, $R/.config/worktrees/config ai_cmd=none, throwaway key $R/keys/rehearse-updater.key (pw "rehearse"), $C/src-0.42.0 (git archive + pnpm install), $C/wsclient.py
- Relaunch trap answered from source: direct spawn, env inherited -> real-updater route viable (port 18743, http + dangerousInsecureTransportProtocol)
- 12:36 seeded tmux: demo repo $R/src/demo, places feat-alpha/feat-beta (v0.42.0 CLI), tmux pid 39370, stand-in 41422.
- 12:39 old bundle rebuilt with 1-line latest_release_tag patch; 12:40 update server 127.0.0.1:18743 (bg bxf6ha8n7).
- 12:41 old app run0 54412 (killed unseeded at (main)'s rename request 12:47).
- 12:49 rebuilt "Worktrees Server" 0.42.0 + 0.43.0; relaunched old app pid 79363. Batch 1 re-sent 12:50:29 -> deadline 13:35.
- 13:17 0.43.1 bundle built + staged (updates/staged-0.43.1).
- 14:32-15:23 the real run: batches 1-6 via (main); update 0.42.0->0.43.0 (real updater), 7a/7b/7c/7d done; cleanup 15:23-15:24; report.md final. Defects D1 #513, D6 #508, D7 #524, D2 #516, D3 #524, D4/D5 #513.
