# Rehearse v0.42.0 -> Server Edition update (macOS)

Brief: .planning/brief.md. Cache: ~/.cache/worktrees/worktrees/rehearse-server-edition-update
R = $C/home (HOME for every rehearsal run; TMUX_TMPDIR=$R/tmux)

## Phases
- [x] 0 Bootstrap (submodules, pnpm, old CLI 0.42.0)
- [x] 1 Merge origin/feat/sidecar-bundle; sidecar-merge.md; bump 0.43.0 (rehearsal-only commit); gates + serve_bin no-tmux
- [x] 2 Build OLD bundle v0.42.0 (rehearse identifier, no updater artifacts) -> $R/Apps/worktrees.app
- [x] 3 Build NEW bundle 0.43.0 with sidecar; check Contents/MacOS/worktrees --version
- [x] 4 Seed before-state with old app (scratch repo, places, stand-in agent, manual batch, snapshot)
- [x] 5 Update (route decided by restart impl + updater endpoint + throwaway key)
- [x] 6 First-launch checks 6.1-6.9
- [x] 7 Lifecycle (quit, crash, 0.43.1 update, downgrade)
- [x] 8 Linux AppImage (stretch) — sources only, NOT COVERED in docker
- [x] Deliverables: report.md, sidecar-merge.md, defects list, report to (main); stop all processes

## Constraints
- disk >= 8 GiB free (started 24 GiB); one build at a time (swap nearly full)
- never default identifier, never /Applications or ~/.local/bin, never by name
- no scripted clicks/keys; manual steps batched to (main)
- local commits only, no Co-Authored-By
