# Findings

## Merge (step 1)
- Only textual conflict: CHANGELOG `### Added` (both sides). Kept both, one header.
- Semantic: engine.rs:633 bare Command::new(serve) vs #513 childenv rule -> childenv::command.
- Semantic: childenv-check.mjs read serve/tests.rs (#516 layout) as non-test -> skip tests.rs declared `#[cfg(test)] mod tests;`.
- Sidecar CHANGELOG/sidecar.sh text says app "will start" serve - now it does (docs wording on retarget).

## Relaunch trap (step 5)
- tauri 2.11.5 in BOTH locks (v0.42.0 and HEAD); plugin-process 2.3.1, updater 2.10.1.
- process.rs restart(): macOS reads Contents/Info.plist CFBundleExecutable and Command::new(MacOS/<exe>).spawn() -> direct spawn, env inherited. NOT LaunchServices. (a) holds.
- JS relaunch() -> plugin-process commands::restart -> app.request_restart() -> ExitRequested(RESTART_EXIT_CODE) + Exit -> callback(Exit) runs app's Exit handler -> cleanup_before_exit -> process::restart.
- v0.42.0 Exit handler: winstate::stop, save_shell_cwds, save_shell_scrollback, kill dock shells, viewer::kill, cancel clones, viewer::cleanup. So the update path flushes the rings.
- updater 2.10.1 validate_endpoints: only endpoints need https unless dangerousInsecureTransportProtocol; download URL unchecked. (b) holds via --config.
- macOS install_inner: extract tar.gz to $TMPDIR tempdir, rename current .app into tempdir backup (deleted on drop), rename new into place, touch. Running process' bundle is deleted underneath it.
- v0.42.0 Settings -> Version "Update app" = check() -> downloadAndInstall() -> relaunch(). Don't click "Update CLI" (runs install.sh).

## Updater route (after (main)'s trap note)
- v0.42.0 "Install <tag>" = install_app_version: hardcoded github.com + api.github.com -> never clicked.
- "Update app -> vX" = plugin check() (conf endpoints) BUT renders only if check_update's `latest` set; latest_release_tag() curls github.com/releases/latest; check_update also auto-fires ~3-5 s after launch (update_auto_check default true).
- Rehearsal patch (one line) latest_release_tag URL -> http://127.0.0.1:18743/releases/latest in v0.42.0 lib.rs:1732 and 0.43.x api ops.rs:763. Diffs: $C/rehearsal-patch-*.diff
- renv: dead proxy (127.0.0.1:9) for http(s)/all, NO_PROXY loopback. Proven: claude_status curl exit 7 in old app.log.

## Old app first run (pid 54412, 12:41:18)
- config dir $R/Library/Application Support/net.casadelvalle.worktrees.rehearse (ui-state, window-state, term-history, ui-events.jsonl)
- v0.42.0 app.log lands at $R/Library/Logs/net.casadelvalle.worktrees/app.log (DEFAULT id, not .rehearse — v0.42.0 log_dir const). Isolated under $R anyway.
- check_update -> local server HEAD /releases/latest 404 at +5 s.
- tmux server pid 39370 ($R/tmux/tmux-501/default), stand-in pid 41422 (pane %2 demo-feat-alpha) -> $R/standin.log

## Rename (main's request, 12:47)
- productName + window title "Worktrees Server" via --config; identifier unchanged; CFBundleExecutable still `app`; sidecar Contents/MacOS/worktrees.
- Old app run0 (unseeded) killed 54412 -> evidence/run0-*; new old-app pid 79363 @12:49:45.
- WebKit writes REAL ~/Library/Caches/<rehearse id> and ~/Library/WebKit/<rehearse id> (NSHomeDirectory ignores $HOME). Not on the stop list.
- No screen-recording permission -> window title not machine-verifiable; user confirms.

## DEFECT candidate (source): profile::worktrees_bin() under serve = the bundle sidecar
- current_exe() named "worktrees" wins (profile.rs:1208). Under serve that's .../Contents/MacOS/worktrees.
- Callers: mcpsetup::install -> `claude mcp add -s user worktrees -- <sidecar> mcp --mutations` (user-global!), codexmcp, kimi/kimiplace mcp.json, guidance guard_bin, mcp status worktrees_bin (cli-missing never reported).
- Contradicts sidecar.sh "nothing outside the bundle points at this copy" + CHANGELOG "keep working whether the app is installed or not". Linux AppImage: path into /tmp/.mount_* per launch.
- Verify empirically: serve.log mcp_status line after update.

## Linux AppImage (step 8, sources)
- type2-runtime runtime.c: pipe(keepalive_pipe) no O_CLOEXEC; FUSE child keeps write end, writes until EPIPE -> SIGTERM self -> unmount; parent keeps read end and execv(AppRun) -> inherited by app -> serve (Rust Command closes nothing) -> tmux server (tmux server.c/proc.c no closefrom; only client_exec closefrom).
- => mount lives while ANY holder lives: app-owned serve keeps it after app crash/quit-without-stop; tmux server started by app/serve keeps it for its lifetime (pre-existing in 0.42.0 for tmux).
- Extract-and-run (APPIMAGE_EXTRACT_AND_RUN / flag; opt-in, not automatic): runtime forks app, waitpid, then rm_recursive(prefix) unless NO_CLEANUP -> extracted dir deleted under a surviving serve (exe unlinked, viewer.js gone).
- tauri-utils 2.9.3 resource_dir linux: <exe>/../lib/<productName> canonicalized, else $APPDIR/usr/lib/<name>, else /usr/lib/<name>.

## Preflight 0.43.0 in $C/home-pre (fresh install, not the update) 13:38-13:39
- serve from bundle sidecar, argv `serve --config-dir <rehearse cfg> --owner app`, no --allow-origin; serve.json 0600 owner app; env HOME/TMUX_TMPDIR/TMPDIR/proxies inherited; WORKTREES_VIEWER_JS set (path with space).
- launch 13:38:07 -> serve ready 13:38:10 (~3 s: page load ~2.5 s, serve <1 s). client 1 = shim probe, client 2 = page (tauri://localhost).
- 0.43.0 writes the startup line to Logs/net.casadelvalle.worktrees/app.log (DEFAULT id) and the rest to Logs/<rehearse id>/app.log (known: AGENTS "one line still written under the default").
- FRESH-INSTALL defect: "window state: could not save: No such file or directory" at +1 s — config dir doesn't exist until serve creates it (shim no longer creates it). (#524) Not on the update path.
- mcp_status worktrees=<bundle sidecar> CONFIRMED in serve.log.
- list_workspace (wsclient, Origin tauri://localhost) vs v0.42.0 ls --json: 0 differing shared fields; serve-only: agent_sessions, profile_name, profile_stale, unborn.
- log_info -> dir/file = $HOME/.cache/worktrees/serve.log; log_tail works.
- inbox: v0.42.0 `worktrees show README.md` -> $HOME/.cache/worktrees/inbox/<ts>.json consumed by serve within 4 s ("inbox: open …").
- kill -9 app -> serve survives (ppid 1), serve.json kept; relaunch -> "observed … proven v0.43.0" -> "adopting … this app stops it on quit".
- SIGTERM serve -> "stopping" / "stopped", serve.json removed; serve.json.lock stays.

## Preflight downgrade-after-crash (home-pre, 13:44-13:47) — 7(d) first half
- 0.43.0 serve 25482 + serve-owned dock shell zsh 26687 (opened over WS: shell_open on_bytes __CHANNEL__:1; shell_write data = int array) cwd /private/tmp -> shell-cwds.json written by serve 13:45:15.
- kill -9 app -> serve + zsh survive. Swapped v0.42.0 into same path; launched 28461 (in-process engine) beside serve.
- shell-cwds.json: 60 s sample, unchanged (v0.42.0 save_shell_cwds returns early with no live shells of its own -> never clobbers; merges when it has shells). Orphan: zsh 26687 lives under serve, invisible to v0.42.0's dock.
- Doubled polls: both engines run their 3 s host poll (inbox, tmux, viewer) + 5-min claude_status.
- INBOX race: 3 `worktrees show` -> all consumed by v0.42.0 (coin toss: first poll wins).
- DEFECT: serve drains the inbox with ZERO clients (host.rs:208 every tick): after app crash, `worktrees show` consumed in <1 s ("[25482] inbox: open") and emitted to nobody -> lost. v0.42.0 with the app down left it 30 s for the next launch. (#516)
- serve SIGTERM -> stopping/stopped, shell killed.
- claude_usage: "keychain: no Claude Code credentials" under HOME=$R -> no real credential read (good isolation sign).

## REAL UPDATE 0.42.0 -> 0.43.0 (14:36:56-14:37:03)
- 14:36:56 Check for updates (curl /releases/latest 302 v0.43.0); 14:37:01 updater GET latest.json + tarball (ua tauri-plugin-updater/2.10.1); tmpdirs tauri_current_app*/tauri_updated_app* in $R/tmp; 14:37:02.09 new app 55080 (ppid 1, pgid 33481 = old app's); serve 55127 @02.68; serve.json 0600 @02.95; client @02.99. Launch->ready < 1 s.
- app 55080 + serve env: HOME/TMUX_TMPDIR/TMPDIR/proxies kept (relaunch trap empirically clear).
- serve argv ok, no --allow-origin; owner app; host-policy copied x2; host-policy.json {ask, ask}.
- mcp_status worktrees=<bundle sidecar> on the REAL update path (D1 confirmed).
- tmux 39370 + stand-in 41422 unchanged; standin.log kept growing.
- list_workspace vs ls --json: only diff feat-alpha.declared (app path merges store; v0.42.0 in-process list_workspace did too: lib.rs:383) -> PASS.
- ui-state diff: codex_permissions + pi_project_trust DELETED (settings.ts:796-797, c25cc2a, #508, deliberate) -> brief expectation fails; downgrade reads defaults (auto-review wider than ask!). last_seen_version 0.42.0->0.43.0 (What's new shown + dismissed), update_dismissed ""->v0.43.0, usage_kimi added.
- ring: seam "restored" + REHEARSAL-1/2 + ↑ recall of echo REHEARSAL-2/1; shell-cwds unchanged {1: /private/tmp}; zsh under serve cwd /private/tmp. REHEARSAL-3 NOT in history/ring at 14:39 (user may not have typed it; ask).
- 6.8 mixed: v0.42.0 MCP (0.42.0, 16 tools) handshake/list_places/report(from feat-alpha) ok; v0.42.0 MCP set_note/set_lifecycle + CLI new feat-gamma -> serve list_workspace sees all; serve set_note/set_lifecycle/new_place feat-delta -> v0.42.0 CLI ls shows feat-delta, status feat-gamma lifecycle saved.

## 7a clean quit 0.43.0 (user ⌘Q ~14:59:43)
- serve.log 20:59:43 "serve: stopping", 20:59:44 "serve: stopped"; app.log "serve pid=55127 exited (exit status: 0)", "quitting; serve pid=55127 stopped" (Exit hook / stop_owned path).
- serve.json removed 14:59:44; ring kept (2580 B incl REHEARSAL-4, last dirty tick 14:59:23, nothing dirty at exit); shell-cwds unchanged; dock zsh 56476 gone; tmux 39370 + stand-in alive.
- 6.9 user: notes.md shown in dock Files tab AND the viewer open with "# Notes / line 1".
- REHEARSAL-3: ring shows batch-2 ↑/↓ recalls ending on a cleared line, no Enter/^C; REHEARSAL-3 arrived only at 14:58 as a bracketed paste. Not lost — never entered in batch 2. History appended REHEARSAL-3/4 after update (INC_APPEND works).
- Artefact: my serve new_place(provider null) launched claude in feat-delta (same as v0.42.0 lib.rs:1491: provider None -> default harness, ai_cmd ignored). Ran 14:40-15:00 at onboarding under HOME=$R; tmux server env predates proxy vars. Killed 72659. Wrote only $R/.claude*, nothing in real ~/.claude/sessions.

## 7b real bundle (15:01-15:02)
- relaunch 0.43.0 by me 15:01:39: page did not open the dock shell by itself within 20 s (window not focused?) -> I opened feat-alpha tab 1 over WS (seam "restored · 14:59:23", CRASH-PRE). kill -9 app 25335 @15:02:22 -> serve 25439 ppid 1 + zsh 27148 + serve.json survive. Relaunch 28298 @15:02:30 -> "observed … proven v0.43.0" -> "adopting … this app stops it on quit". User: no third seam (shell re-attached).
## 7c 0.43.0 -> 0.43.1 (15:07:52)
- set_codex_permissions full @15:07:33 (host-policy.json full; ui-state none).
- updater GET latest.json + tarball 15:07:52; old app Exit hook: "quitting; serve pid=25439 stopped" (adopted serve, SIGTERM, serve stopping/stopped). New app 73672 ppid 1: "no serve.json -> starting one" (NOT Replace). serve 73753 v0.43.1 host-policy full. dock shell respawn 76577 @15:08:01. No SIGKILL/replacing anywhere.
- ring: 3 seams (update 0.42->0.43, relaunch after ⌘Q, update ->0.43.1), none after crash. History all 8 commands. What's new 0.43.1 (user). ⌘Q 15:08:48 -> stopping/stopped exit 0.
## 7d clean downgrade
- after clean quit: host-policy full/ask; ui-state no codex/pi keys; swapped v0.42.0 at same path; launched 86299 @15:09:38. Batch 5 sent.
