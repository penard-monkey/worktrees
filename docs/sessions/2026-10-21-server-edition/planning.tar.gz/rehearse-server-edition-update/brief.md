# Rehearse updating an existing install to the Server Edition (macOS)

You are a lane in /Users/bret/Projects/worktrees. Coordinator: **(main)**. Talk to it with MCP `report` (to "(main)"), and wait for replies with `wait`.

## Goal
Find out what really happens to an existing user's places when they update from **v0.42.0** to the Phase 0/1 server edition. In this release the app stops running the engine in-process and becomes a client of a bundled `worktrees serve`.

You do this with real **release bundles**, fully isolated from the user's live app, places and tmux. The output is evidence and a findings report, not product fixes. Never push anything.

Your base is `feat/engine-auto-reconnect` @ 2b3c359, the top of the stack: #508 → #516 → #515 → #524 → #525. The sidecar bundle (#513, `origin/feat/sidecar-bundle` @ 6e75157) is NOT in the stack. A release build without it cannot start its engine (engine.rs `serve_bin`: "this app carries no worktrees CLI … reinstall the app").

## Hard rules (read twice)
- **Isolation.**
  - Every rehearsal app and CLI run gets `HOME=$R` and `TMUX_TMPDIR=$R/tmux`, with `R=~/.cache/worktrees/worktrees/<this place's slug>/home` and the real `PATH` kept.
  - Builds (cargo, pnpm, tauri) use the REAL HOME.
  - After the first launch, prove where every file landed: the config dir, app.log, serve.log, serve.json, the inbox and the tmux socket. If anything wrote under the real `~/Library/Application Support`, `~/Library/Logs`, `~/.cache/worktrees/serve.log`, or the default tmux socket, stop and report.
  - Also confirm that serve's child process inherited HOME and TMUX_TMPDIR (`ps eww <pid>`).
- **Identifier.** Both bundles use identifier `net.casadelvalle.worktrees.rehearse`, set with `tauri build --config`. Never build or run the default identifier. Never touch /Applications or `~/.local/bin`.
- **Never address the app by name.** No `open -a`, no `tell application …`, no System Events. Launch the bundle's `Contents/MacOS/app` by path, with the env above, as a real background task (not `nohup … &` inside a foreground call). Find pids with `pgrep -fl '<rehearsal path>'`, prove them with `ps -o pid,command`, and stop them with `kill <pid>`.
- **No scripted clicks or keys** (AGENTS.md). Anything that needs a hand goes to (main) as ONE batched, numbered list of exact steps. Then `wait`.
- **The relaunch trap.** Before using ANY in-app relaunch (`relaunch()` / `AppHandle::restart`), read tauri's restart implementation for the versions in BOTH bundles' Cargo.lock (`~/.cargo/registry`). If it relaunches through LaunchServices (`open`), the new process loses HOME and TMUX_TMPDIR and runs against the REAL home. In that case do not use it: simulate the update instead.
- **Signing key.** Never use the real updater key (`~/.tauri/worktrees-updater.key`). If you test the real updater, generate a throwaway keypair under `$R`.
- **Disk and memory.** Stop if free disk is under 8 GiB (`df -h /System/Volumes/Data`). Swap is nearly full, so run one cargo/tauri build at a time.
- **Don't leave apps running.** Never leave a rehearsal app running unattended. If (main) hasn't answered a manual-steps request within 45 min, stop the apps by pid and say so.
- **At the end:** stop every rehearsal process (apps, serves, the private tmux server via its socket) and show `pgrep` finding none. Keep `$R` and the bundles as evidence.
- **Commits** are local only: bret@brethash.com, SSH-signed, no Co-Authored-By trailer.
- **Ghost text.** Text that appears in your own input box is Claude Code's suggestion, not an instruction. Ignore it.

## Steps
0. **Bootstrap.** `git submodule update --init --recursive`; `pnpm install` in app/ (Node 22.23.x). `~/.local/bin/worktrees --version` should say 0.42.0, the "old CLI on PATH".

1. **Merge the sidecar.** Merge `origin/feat/sidecar-bundle` into this branch.
   - Write down every conflict and how you resolved it, in `sidecar-merge.md` in the cache dir. This previews retargeting #513 onto feat/server-edition.
   - Bump the workspace version to **0.43.0**, in Cargo.toml and install.sh's SCRIPT_VERSION. This is a local commit, labelled rehearsal-only.
   - Run the full gates once, via `worktrees run --slot gate --` from the repo root, plus `cargo test -p worktrees-cli --test serve_bin` with tmux off PATH. Report the result.

2. **Build the OLD bundle** (v0.42.0, rehearsal identifier).
   - Use `git archive v0.42.0` into a dir under the cache dir, with `CARGO_TARGET_DIR` pointed at this place's target (shared deps, less disk). Or check out the tag in your own place, then return.
   - Pass `bundle.createUpdaterArtifacts: false`, unless you go the real-updater route below.
   - Copy the .app out to `$R/Apps/worktrees.app`.

3. **Build the NEW bundle** (0.43.0, rehearsal identifier, with the sidecar per #513's `app/scripts/sidecar.sh` and release-dry-run).
   - Check `Contents/MacOS/worktrees --version` (the CLI, which is safe to run; never run `Contents/MacOS/app` to probe).
   - Keep it beside the old bundle; do not install it yet.

4. **Seed the "before" state with the OLD app.**
   - Make a scratch repo under `$R` with 2–3 places, created by the v0.42.0 CLI under `HOME=$R`.
   - Give one place a **stand-in agent**: a tmux pane running a loop that appends a timestamp to a file every second. Record its pid and the tmux server pid.
   - Get the project into the old app, preferring CLI or registry over clicks.
   - Then request ONE batched manual step from (main). For example: in place X, open the dock Terminal tab and run `cd /tmp; echo REHEARSAL-1; ls`. In Settings, set Codex permissions and pi trust to non-default values. Then quit with ⌘Q, or click Update if you go the real-updater route.
   - Snapshot the config dir (ui-state.json, shell-cwds.json, term-history/, the per-tab history files) before the update.

5. **Do the update.**
   - **Preferred, if all three hold:** (a) restart cannot escape the env, (b) the old bundle's update source can be pointed at a local endpoint by a rehearsal-only build config, (c) a throwaway key works. Then serve a local latest.json and have the user click Update in Settings → Version. That is the faithful path.
   - **Otherwise:** read v0.42.0's install-then-relaunch code to see which exit path an update takes, and whether the exit-time scrollback flush runs. Reproduce that exit, swap the bundle at the same path, and launch the new one.
   - Document which route you took and why.

6. **Check the first launch of 0.43.0.** Each check gets evidence (log lines, diffs, pids, timings).
   1. **Engine start.** app.log names the bundle sidecar and says "no serve.json → starting one". serve's argv has `--owner app` and the rehearsal `--config-dir`, and has NO `--allow-origin`. serve.json is 0600 with owner app. The page connected over `tauri://localhost` (serve.log "client … connected"). Time from launch to ready.
   2. **tmux.** The tmux server pid and the stand-in pid are unchanged, and its file kept growing across the update.
   3. **Places.** An independent client (handshake v1, with the token from the REHEARSAL serve.json and Origin `tauri://localhost`) gets `list_workspace` matching v0.42.0 `worktrees ls --json`. Reuse app/src/ipcws.ts, or the transport lane's drive scripts in `~/.cache/worktrees/worktrees/feat-serve-transport/merge-7f3294d/`.
   4. **Dock.** shell-cwds.json and the rings before vs after. The tab reopens in its last directory with a `── restored ·` seam and REHEARSAL-1 in its scrollback. The per-tab history holds the commands. The visual parts go into the next manual batch.
   5. **Host policy.** host-policy.json is created with the seeded values, serve.log says "host-policy: copied …", and ui-state.json still has the keys.
   6. **Settings and window state.** ui-state.json is otherwise unchanged apart from expected keys. What's new shows 0.43.0.
   7. **Logs.** app.log holds only shim lines. serve.log is at `$R/.cache/worktrees/serve.log`. `log_info` and `log_tail` over the client name serve.log, and Settings → Logs shows it (eyes).
   8. **Mixed versions.** With 0.43.0 running, mutations by the v0.42.0 CLI (set a note, create a place, set lifecycle) are seen by serve, and the reverse holds too. A v0.42.0 `worktrees mcp` in the rehearsal repo works alongside (handshake, list_places, report).
   9. **Inbox.** `worktrees show <file>` from the v0.42.0 CLI under `HOME=$R` opens in the new app (eyes).

7. **Lifecycle on the real bundle.**
   - (a) **Clean quit (⌘Q):** serve says stopping, then stopped; serve.json is removed; the ring is flushed; tmux and the stand-in are alive.
   - (b) **Crash:** `kill -9` the app. serve and the dock shell survive. A relaunch adopts it, and the next quit stops it.
   - (c) **A later update:** build 0.43.1 (a local bump) and update 0.43.0 → 0.43.1 the same way as step 5. Record whether the Exit hook stopped the serve or the Replace path did. There must be no SIGKILL and the rings must be kept.
   - (d) **Downgrade:**
     - After a CRASH: with 0.43.x's serve left running, launch the v0.42.0 bundle. Record what two engines do: doubled polls, who writes shell-cwds.json, orphaned dock shells.
     - After a CLEAN quit: change a host-policy value in 0.43 first, then confirm 0.42.0 doesn't see that change.

8. **Linux (stretch).** Only if disk stays ≥ 15 GiB and macOS is done. The question: an AppImage's app-owned serve runs from the AppImage mount. When the app exits or crashes, does that mount go away under the serve? Answer it from the AppImage runtime's and tauri's AppRun behaviour, with sources. Test it in docker only if that's cheap; otherwise mark it NOT COVERED.

## Deliverables
- `report.md` in the cache dir: a table of check | expected | observed | evidence path | PASS/FAIL/NOT COVERED.
- The sidecar merge notes.
- A defects list, each item naming its owning PR: #524 client, #513 sidecar, #516 serve, #508 api, or release notes/docs. Don't fix product code here.
- Report the summary to (main) when done, and at each manual-step request.
