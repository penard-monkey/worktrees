# Bring main's Kimi harness into PR #508's extraction

Based on `feat/server-edition` at `c04243d`: PR #508, Server Edition Phase 0. The user wants #508 mergeable. Right now GitHub reports it `DIRTY` (it conflicts with main), so GitHub builds no merge ref and runs **no CI at all** (AGENTS.md: "A CONFLICTED PR gets no CI").

## What happened

#508 branched from main at `6da42aa`. Since then main gained:
- `3efa209` feat: Kimi Code as a fourth harness: core, CLI, MCP, the dot poll (#509)
- `32ec1b8` feat(app): Settings → Kimi, and the kimi-mcp offer (#510)

#508 moved all 143 `#[tauri::command]` bodies out of `app/src-tauri/src/lib.rs` (11,288 → ~2,100 lines) into `crates/worktrees-api`, behind a `Ctx`. Main's Kimi work added about 360 lines to the OLD lib.rs. So this is not a text conflict to pick sides on. Kimi has to be ported INTO the extraction:
- five new commands: `kimi_status`, `kimi_version`, `set_kimi_allowed`, `kimi_mcp_status`, `kimi_mcp_set`
- the dot-poll pieces: `kimi_watch_set`, `kimi_tick`, `kimi_tick_in`
- `kimi_paste_refusal`
- their tests

Other files both sides touched:
- `AGENTS.md`
- `CHANGELOG.md`
- `app/src/App.tsx`
- `app/src/SettingsSheet.tsx`
- `app/src/mock/install.ts`
- `crates/worktrees-cli/src/mcp.rs`
- core `lib.rs`, `ops.rs`, `projcfg.rs`, `trust.rs`

## How

**MERGE `origin/main` into this branch. Do not rebase.** #508 has 26 commits, many of them rewriting lib.rs, and a merge needs no force-push of an open PR. The PR is squash-merged at the end anyway.

Port Kimi the way #508 ported its siblings. Pi is the closest twin for every piece. Find where #508 put each pi piece and mirror it:
- `pi_status`, `set_pi_allowed`, `pi_mcp_status`/`set` → their `worktrees-api` module
- pi's watch and tick → `worktrees-api/src/watch.rs` and the poll in lib.rs
- pi's paste refusal → wherever #508 put it

Rules #508 relies on:
- **Every command in lib.rs is a thin wrapper that delegates to `worktrees-api`.** `app/scripts/api-boundary-check.mjs` enforces it, along with no `tauri` in the api crate's tree, exactly one `.setup(`, and no `state::<T>` except Ctx and Tracker.
- **Registries live on the `Ctx`** (`watch`, `terminals`, `shells`, `viewer`, `docnames`). Kimi's watch registry, if it has one, goes onto `watch::Watch` beside codex and pi, NOT into a new `static`. (`docs/proposals/server-edition.md` Appendix B rules every process-global; a new one needs a ruling.) `KIMI_TAIL` in core is a host-fact cache like `CODEX_TAIL`/`PI_TAIL`, so it is fine where it is.
- **`worktrees-api` reaches any core `cmd_*` only through `argv::Argv::call`** (R3, commit 72fce61). Main's ops.rs/mcp.rs Kimi changes must keep the `--` discipline and the shared `safe_arg`/`branch_arg` validators. If main added a `cmd_*` call or a git call carrying a client value, route it the same way. The unit test that fails on a stray `cmd_*` reference will tell you.
- **Host policy (commit c25cc2a):** Codex permissions and pi trust live in `host-policy.json` and are set only from a Settings click (`app/scripts/hostpolicy-check.mjs`).
  - Check that main's Kimi Settings work adds no setter pushed from a `useEffect` or on load. If it does, report it rather than copying the pattern.
  - `set_kimi_allowed` writes the persisted allowance like `set_pi_allowed`, which is fine.
- **The mock harness must track every command in lib.rs** (AGENTS.md), and main already added Kimi to it. Merge it with #508's mock changes (host policy).
- **CHANGELOG:** after the merge there must be ONE `## [Unreleased]` and one each of `###` Added/Changed/Fixed. Main's Kimi bullets and #508's bullets both belong under it. Count the headers (AGENTS.md describes the "keep both" trap). If main CUT A RELEASE in between, the section boundaries moved, so check which section each bullet landed in.
- **Version:** if main bumped the workspace version, keep main's.

## Verify

1. The full gate set from AGENTS.md:
   - release build FIRST, and confirm it is newer than the sources
   - `make test` redirected to a file, with the plan line, ok count and not-ok count
   - `make lint`
   - `cargo test` for core, cli, api, and `-p app --lib`
   - `tsc --noEmit`
   - `cargo check -p app`
   - every `app/scripts/*-check.mjs` from the REPO ROOT

   Report cargo with `grep -E "^running|^test result"`, and count `^warning` lines (expect 0).
2. **Kimi's own tests**, the ones main added in lib.rs's `mod tests`, must still exist and pass wherever they now live. List them by name before and after; none may silently vanish in the move.
3. **A real-app run, because CI never starts the app.** #508 shipped green once while every command panicked; see AGENTS.md's "`Builder::setup` REPLACES" note.
   - Run `app/scripts/sandbox.sh --app`.
   - Wait about 60s.
   - Grep the SANDBOX app.log (`~/Library/Logs/net.casadelvalle.worktrees.sbx/app.log`) for `[panic]` and `[error]`, and quote the counts.
   - Kill it by PID: `pgrep -fl 'server-edition-sync-main/target/'`, confirm with `ps`, then kill. Never address it by name.
   - Port 1420 must be free first and afterwards. If it is busy, find out who holds it; do not kill someone else's process.
4. `git merge-tree --write-tree origin/main HEAD` (or a fresh test merge) shows that main merges into the result cleanly.

## Rules

- Commit the merge, plus any follow-up fix commits, SSH-signed as `bret@brethash.com`. Use NO `Co-Authored-By` or any attribution trailer. Do not push.
- **Grep trap:** inside Claude Code, `grep` skips files containing a NUL byte. Use `git grep` or `/usr/bin/grep` for anything a conclusion rests on.
- Do not edit other places' trees. `feat-worktrees-serve` is mid-work and will rebase onto your result later.

`report` to (main) with:
- the merge commit and any follow-ups
- where each Kimi piece landed
- the Kimi test names, before and after
- gate counts
- the sandbox panic and error counts
- anything in main's Kimi work that conflicts with #508's rules (host policy, R3, statics)
