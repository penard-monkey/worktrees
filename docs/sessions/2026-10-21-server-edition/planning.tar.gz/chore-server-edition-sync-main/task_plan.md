# Merge origin/main (Kimi #509/#510) into #508's extraction

## Goal
Branch chore/server-edition-sync-main (= feat/server-edition c04243d) + merge origin/main 32ec1b8, Kimi ported into worktrees-api. No push.

## Phases
- [x] 1. Inventory kimi pieces on main + test names (before)
- [x] 2. git merge origin/main (uncommitted, in progress), conflicts resolved
- [x] 3. Port lib.rs kimi pieces into worktrees-api (mirror pi)
- [x] 4. Check R3 / host policy / statics in main's kimi work
- [x] 5. CHANGELOG headers, version (0.42.0 both sides, no release cut)
- [x] 6. Gates: all green
- [x] 7. Sandbox app run: 0 panic, 0 error
- [x] 8. merge-tree clean; commits fecee55 (merge), 9b97a62 (R3), cd0e60c (docs); report sent

## Kimi tests in main's lib.rs mod tests (BEFORE)
- agent_sessions_match_the_two_provider_rule_they_replaced (modified: kimi row)
- kimi_lanes_feed_busy_waiting_and_done_through_the_tick (new)
- a_kimi_paste_needs_an_empty_composer_and_no_prompt_open (new)
## AFTER
- workspace.rs: agent_sessions_match_the_two_provider_rule_they_replaced
- watch.rs: kimi_lanes_feed_busy_waiting_and_done_through_the_tick
- files.rs: a_kimi_paste_needs_an_empty_composer_and_no_prompt_open

## Where kimi landed
- kimi_status/KimiStatus, kimi_version, set_kimi_allowed -> api project.rs (kimi_version wrapper keeps spawn_blocking)
- kimi_mcp_status/kimi_mcp_set -> api config.rs
- KimiWatched/kimi_watch_set/kimi_tick/kimi_tick_in -> api watch.rs, registry on Watch.kimi (KIMI_WATCH static gone)
- harness_feed/watch_lane/live_model kimi arms -> watch.rs
- kimi_paste_refusal + KIMI_OPENER_PENDING + plan_prompt/plan_ask_main/ask_main_refusal arms -> api files.rs

## Findings
- R3: main's `doctor --kimi` scan read raw args (`doctor -- --kimi` = flag). Fixed via split_options; R3 test extended, shown red first.
- Host policy: kimi setters click-only. OK.
- Statics: KIMI_TAIL only (host fact). Appendix B row added; also hostpolicy::tests SERIAL (test-only, #508's own) was missing.
- set_pi_allowed: main added warn log on not-in-git; ported into api.
- docs/adding-a-harness.md pointed dot poll at lib.rs; repointed to watch.rs.
- CHANGELOG "143 commands" -> 148 (verified names+client args vs main).
