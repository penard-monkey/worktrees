# Fix the flaky Kimi usage test on main (lane D)

You are a lane. `(main)` coordinates you through the worktrees MCP `report` / `messages` tools. Do NOT push.

## The failure

`crates/worktrees-core/src/kimi_usage.rs`, test `kimi_usage::tests::a_probe_reads_usage_and_leaves_no_kimi_running`.
- **Where it failed:** ONCE, on CI, macOS rust job, run 39438923287, 2026-10-20.
- **The panic:** `the server was never sent SIGTERM` at the `assert!(d.join("term").exists(), …)` line. The `wait_dead` assertion just before it PASSED: the fake `kimi` process was gone, but its SIGTERM marker file was missing.
- **History:** it came in with #511 (Kimi plan usage). It passed on every other run, including #508's and main's.
- **Locally:** 55 runs passed, 15 of them alongside two full core test runs.

The fake (`fn fake`) is a `/bin/sh` script with `trap 'touch "<dir>/term"; exit 0' TERM`, then `sleep 60 &` and `wait`. The probe's `Server` drop (`impl Drop for Server`):
1. SIGTERMs the process GROUP;
2. polls `try_wait` every 20 ms for 2 s;
3. SIGKILLs the group, either when the leader is gone or when the grace runs out.

## What to find out FIRST, before fixing

Name the actual cause, with evidence. Two candidates to check against the code, and add any you find:
1. **The grace ran out.** The 2 s grace expired on a loaded runner before the trap's `touch` (an external command, so a fork and exec) finished. The SIGKILL then took the shell before the marker existed. If this is it, ask whether the PRODUCT has the same problem: does a real `kimi web` that takes over 2 s to handle SIGTERM get SIGKILLed and leave its stale instance record? That's the thing the SIGTERM exists to avoid; see the module doc.
2. **A shell or signal race.** A `wait`/trap race in /bin/sh (bash 3.2 in sh mode on macOS) when SIGTERM goes to the whole group, so `sleep` dies first.

Try to reproduce:
- under CPU stress (e.g. `yes > /dev/null` × the core count) with `--test-threads` high;
- with the fake's `touch` slowed;
- with `RUST_TEST_THREADS` varied.

Record the reproduction rate before and after.

## Fix

- **Test-only cause:** AGENTS.md's rule applies ("A test that races two sleeps asserts the scheduler, not the rule"). Prefer a seam: make the grace injectable, or have the test drive the Drop's timing, so it asserts the RULE (SIGTERM is sent before any SIGKILL) and not the scheduler. Use a shell builtin rather than `touch` if that removes the fork, but explain why it's sufficient.
- **Real product cause:** fix the product too, e.g. a grace sized to what kimi needs. Say what you measured to choose it.

Either way, the new or changed test must be shown FAILING first against the unfixed code under your reproduction conditions. Restore by editing back, then `touch` the file.

## Gates

From the REPO ROOT via `worktrees run --slot gate -- …`:
- `cargo build --release -p worktrees-cli` FIRST, confirmed fresh;
- `make test`: redirect it, then count the plan line and `not ok`;
- `make lint`;
- `cargo test -p worktrees-core`, `-p worktrees-cli` and `-p app --lib`;
- tsc;
- `cargo check -p app`;
- every `app/scripts/*-check.mjs`.

Report cargo with `grep -E "^running|^test result"`; 0 warnings. Then run the fixed test 200× under your stress setup and report the count.

## Rules

- Commits are `bret@brethash.com`, SSH-signed (`%G?` = G), with NO `Co-Authored-By` and NO "Generated with". Add a CHANGELOG bullet under `## [Unreleased]` ### Fixed only if product behaviour changed; a test-only fix needs none. Count the headers.
- Disk is shared and limited. Stop and report if `df -h /` shows under 8 GiB free.
- Linux support is the default: the fix must hold on Linux too, where CI's ubuntu job runs this test. Docker is allowed but not needed; prefer reasoning plus CI.
- Report to (main): the cause with evidence, the fix, the fail-first evidence, the 200× result, the gates, and the commit list. Don't push.
