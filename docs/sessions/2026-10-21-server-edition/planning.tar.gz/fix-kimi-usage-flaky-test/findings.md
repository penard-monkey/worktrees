# Findings — flaky kimi_usage SIGTERM test

## CI evidence (run 39438923287, rust macos-latest)
- `a_failed_refresh…` (sorts just before `a_probe_reads…`) finished 14:25:48.272;
  libtest dispatches in sorted order, so `a_probe_reads…` started ≤ ~48.272.
- `a_probe_reads…` reported FAILED at 14:25:50.341 → it ran ≥ 2.07 s.
- A passing probe takes ~0.1 s (local p50 0.13 s incl. binary start). 2.07 s =
  the 2 s kill grace + ~70 ms. A lost trap (candidate 2) would fail FAST
  (leader exits at once, Drop returns, wait_dead immediate) — not seen.

## Local reproduction (original code)
- Unloaded, 30 runs: 0 fail, p50 0.131 s.
- 14 `yes` hogs + 16 parallel loops, 400 runs: 0 fail, p99 0.237 s, max 0.255 s
  (macOS demotes the hogs; plain CPU stress does not reach 2 s here).
- Same + tests under `taskpolicy -b` (background QoS, starved): 400 runs,
  17 × "the server was never sent SIGTERM" (exact CI assertion), 135 × budget
  timeout at line 640 (different assertion: the 5 s probe budget).

## kimi itself
- Not installed on this machine; SIGTERM→exit time of real `kimi web` cannot be
  measured here. Archived findings: "SIGTERM exits and removes its instance
  record; SIGKILL leaves a stale record, which the next start prunes."

## Classified (temporary XXX-PROBE instrumentation in Drop)
- Slowed `touch` (PATH shim sleeping before exec), original test, 4×5 runs each:
  1.5 s → 20/20 pass; 2.5 s → 20/20 FAIL "never sent SIGTERM", 2.10–2.18 s per
  run, Drop = GRACE-EXPIRED after 2.00 s, leader status signal 9. CI: ≥2.07 s.
- Background QoS + 14 hogs, 16×10 capped 150 s: 64 runs, 10 × SIGTERM assert —
  ALL GRACE-EXPIRED (2.25–3.01 s in Drop, status 9); 0 leader-gone failures;
  52 × budget timeout (separate 5 s startup bound, only under this starvation).
- Candidate 2 (lost trap at script EOF): never observed — 0 fast failures in
  400 CPU-stress runs and 0 leader-gone failures in any classified run.
- The 82-min run (2026-10-20 17:29) was lost: machine slept, driver printed only
  at the end. Driver now appends per run and stops at a cap.

## Cause
The test asserted that the fake's SIGTERM handler (a fork+exec `touch`)
FINISHES inside the product's 2 s grace — a wall-clock race. On a stalled
runner the grace expired, Drop SIGKILLed the group before `touch` ran.

## Fix (f986c71)
- Product: `GRACE` const (2 s, unchanged) carried by `Server { child, grace }`;
  `probe(binary, cwd, budget, grace)`; `read()` passes `GRACE`. No behaviour change.
- Test: `PATIENT` = 60 s for the SIGTERM-marker test; others pass `GRACE`.
  `fake_with(dir, on_term, body)`: child forked + recorded BEFORE body;
  `wait_dead` = leader AND child gone; `alive` treats a zombie (ps stat Z) as gone.
  New `a_server_deaf_to_sigterm_is_killed_with_its_group_after_the_grace` (100 ms).
- Kept `touch` (not a builtin): with the seam the handler's cost no longer
  matters; a builtin alone still races 2 s against the shell being scheduled
  (not measured separately); `touch` keeps the slowed-touch repro usable.

## Before / after (same setups)
- Slowed touch 2.5 s + 14 hogs + 8 parallel, ×200: original 200/200 FAIL
  (2.08–2.39 s, all SIGTERM assert); fixed 200/200 PASS (2.60–2.75 s).
- Slowed touch, kimi_usage module ×5 at RUST_TEST_THREADS 1/4/32: original 5/5
  fail each; fixed 0/5 each.
- Background QoS + hogs: original 10/64 SIGTERM-assert (all GRACE-EXPIRED);
  fixed 0/29 SIGTERM-assert (stopped early, load ~300), all drops leader-gone
  ≤1.64 s; 13/29 hit the separate 5 s startup budget (pre-existing, not CI's).
- Mutants: A PATIENT=GRACE → 20/20 red under slowed touch; B SIGKILL instead
  of SIGTERM → a_probe red; C no group SIGKILL on expiry → deaf test red only.
