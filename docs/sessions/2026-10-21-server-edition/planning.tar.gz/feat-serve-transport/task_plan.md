# Frontend transport seam — task plan

Brief: `.planning/brief.md`. Stacked on `feat/worktrees-serve` @ 495df95.

## Goal
One module is the frontend's only door to the backend: Tauri IPC (default,
unchanged) and a dev-only WebSocket client for `worktrees serve`.

## Phases
- [x] 0. Read: brief, AGENTS.md, serve/{mod,wire,policy,conn,dispatch,servefile}.rs,
      server-stack.sh, serve lane's .planning, plan §III.1/§III.7. Bootstraps.
      Baseline all 42 checks (all rc=0) → scratchpad/baseline.txt.
- [x] 1. Choose mechanism (ipc module vs WS-backed `__TAURI_INTERNALS__`) → findings.
- [x] 2. `app/src/ipc.ts` (the door) + `app/src/ipcws.ts` (pure WS client, no imports).
- [x] 3. Migrate the 25 files (import swap). Diff the 42 checks vs baseline.
- [x] 4. Version: `__WT_VERSION__` from the workspace Cargo.toml via vite `define`.
- [x] 5. Selection: `pnpm dev:serve` (VITE_SERVE=1, DEV only) + vite plugin endpoint
      serving {port, token, version} same-origin only. main.tsx boot; App registers fail().
- [x] 6. `app/scripts/transport-check.mjs` — behaviour on a virtual clock + wire.rs pins
      + the one-door guard + prod-bundle grep. Show it failing several ways.
- [x] 7. Drive it: server-stack.sh + vite dev:serve + Chrome. Screenshots → cache dir.
- [x] 8. Docs: CHANGELOG (existing [Unreleased] headers; count), AGENTS.md note.
- [x] 9. Gates: tsc, all checks from root, cargo check -p app, cargo test -p app --lib.
- [x] 10. Commit (signed, bret@brethash.com, no trailer), report to (main).

## Decisions
- Mechanism: the ipc module (findings §1).
- Byte vs typed channel: by the ARG KEY (`onBytes`), pinned against dispatch.rs.
- `err` passes through unchanged (string or CloneError object).
- Version: exact string equality; frontend's from the workspace Cargo.toml at build.

## Errors encountered
- zsh does not word-split `$files` → the first sed migration was a no-op; redone in Python.
- A first Python pass died on an assertion AFTER writing AgentSetup.tsx → 24+1 = 25.
- `new h.door.channel()` in the check: `channel` is a factory, not a constructor.
- M2/M4/M5 first exited 13 (unsettled top-level await) with no failure printed → settle() deadline.
- `vite build --mode development` left DEV false → used NODE_ENV=development for the negative build.
- "could not connect … is the stack running?" was wrong for an Origin refusal → names both.
- Chrome extension stopped answering after closing the mock tab (likely a beforeunload prompt).

## H1 — handshake v1, client half (from (main), 2026-10-18; approved by the user)
Spec: ~/.cache/worktrees/worktrees/owasp-serve/handshake-v1.md. Report: …/owasp-serve/report.md H1.
- [x] 11. Fail-first: new transport-check §2 (handshake from SPEC, proofs by node:crypto) run
      against aee08f9's ipcws.ts → 69 failures (cache dir h1-red-vs-aee08f9.txt).
- [x] 12. ipcws.ts: hello/challenge/auth/ok+proof, subtle.verify, version only after proof,
      nothing sent (requests, events held) until verified, SERVE_HOST literal, no-subtle guard.
- [x] 13. Mutations M15–M23 (+ M1/M5 retargeted): 23/23 fail by name.
- [x] 14. crypto.subtle on tauri://localhost: measured in a standalone WKWebView (findings §7).
- [x] 15. Docs: AGENTS.md door bullet + trap 4; CHANGELOG bullet (no new headers). Gates.
- [x] 16. Commit (new commit, not an amend) → report to (main) #1. (2e20cf5)
- [x] 17. Wait for (main): feat/worktrees-serve's handshake + end-of-channel commits. GO 2026-10-20 @ 60b21b0.
- [x] 18. Restack ONLY on (main)'s word (the serve lane will itself rebase feat/worktrees-serve onto
      feat/server-edition, bbfed64's double-.setup() fix, so its SHAs change — a moved ref alone is
      NOT the word). Exactly: `git rebase --onto feat/worktrees-serve 495df95 feat/serve-transport`
      (replays only aee08f9, 2e20cf5 and later; NEVER a plain `git rebase feat/worktrees-serve`).
      Then pin handshake keys/labels against the Rust, and run api-boundary-check.mjs with the rest
      (new guards: exactly one `.setup(`, no `state::<T>` but Ctx/Tracker). sandbox.sh --app now
      logs to the sbx identifier.
- [x] 19. Consume end-of-channel: drop the channel handler + what it closes over.
- [x] 20. Live drive: server-stack.sh + impostor on the port (adapt probes/impostor.py) → refused,
      nothing sent. Gates. Commit. Report to (main) #2.

### (main)'s GO, 2026-10-20 — serve @ 60b21b0 (batch 1+2, gates green)
Wire as built: handshake exactly v1; cn/sn/proofs 64 LOWERCASE hex (upper REFUSED, not folded);
each handshake frame exactly ONE key; AUTH_DEADLINE 3s whole exchange.
End of channel: {"channel": id, "seq": n, "end": true} — no data, seq = one past last data frame,
same per-connection queue (never overtakes data). An `err` reply to the request that named a channel
ALSO finishes it; an end frame precedes the err only if a sink had been made. Sent on shell_detach,
re-attach, term_close, shell exit (end PRECEDES shell:exit), clone_project/sync_apply return (end
precedes reply). Docs: serve/wire.rs + serve-dispatch-check.mjs header.
Limits: ≤512 bytes before proof verifies; ≤16 MiB/message after (larger ends conn); 5s HTTP phase.
Do: 1) `git rebase --onto 60b21b0 495df95 feat/serve-transport`; 2) pin SPEC↔wire.rs/policy.rs,
check lowercase-only + one-key frames vs client; 3) end-of-channel + err rule + transport-check
cases red-first; 4) live drive: real handshake, fast typing in order, dock shell exit/detach releases
channel, impostor (adapt owasp-serve/probes/impostor.py) refused, nothing sent.
NEXT restack (when serve rebases onto new feat/server-edition, #508 Kimi): 
`git rebase --onto <new serve tip> 60b21b0 feat/serve-transport` + gate rerun. Drive now regardless.

- [x] 21. Commit (new) → report #2 DONE (859a15a). REMAINING: Final restack `--onto <new serve tip> 60b21b0` on (main)'s word (serve now be5bb71) + gate rerun incl. the new api-boundary guards.
  (main), after report #2: WAIT — be5bb71 is not final until serve's gates + sandbox check report;
  (main) will message the FINAL tip. Then exactly `git rebase --onto <final tip> 60b21b0 feat/serve-transport`
  with the trialled resolution (PiPanel: keep the new imports, invoke from ./ipc; KimiPanel.tsx →
  `import { invoke } from "./ipc"`), rerun gates (tsc, all checks from root incl. api-boundary +
  hostpolicy, cargo check -p app, cargo test -p app --lib, pnpm build + bundle assertion), report,
  then `git branch -D tmp/restack-trial-be5bb71` (local only).
  2026-10-20 (main) GO (msg 1792504897262-1e52-00000000): final tip IS be5bb71. ADOPT the trial as-is,
  keeping SHAs — `git reset --hard tmp/restack-trial-be5bb71` (no rewrite/amend; stop and ask if
  anything needs changing). Done: range-diff 3/3 (2,3 '='; 1 = PiPanel+KimiPanel ./ipc only),
  all 3 signed G bret@brethash.com, no trailers; feat/serve-transport = f9dc344. Then verify from
  root: transport-check (156), tsc, cargo check -p app, make test-frontend, every *-check.mjs;
  delete the trial branch; report tip + results. NO push — (main) force-pushes with a lease.
  DONE 2026-10-20: gates on f9dc344 all green (transport 156/0, tsc 0, cargo check 0, cargo test --lib 8,
  test-frontend 44/0, 44 checks rc=0 incl. api-boundary's 3 new guards + hostpolicy, build + bundle 4 absent,
  dist removed). Trial branch deleted. Reported to (main) as 1792505068407-5788-00000005. Not pushed.
- [x] 22. (main) msg 1792552796805-1e52-00000019: `git merge` feat/worktrees-serve 0ba880e (pushed #516 tip) into
  feat/serve-transport (#515) — signed merge, no trailers, CHANGELOG conflict only, keep all bullets, 1/1/1.
  Done 5bbfe67 (ff from origin f9dc344). term_open now errs for a missing session — client relied on nothing
  else (TerminalPane gates on id; ipcws err rule). Full gates green, 0 warnings; live drive 22/22.
  Reported 1792553405127-5788-00000006. Not pushed. Local serve ref is at 4bb5ce9 (2 commits past 0ba880e; not merged).
- [x] 23. (main) msgs …0021 / …0022: merge serve b46b6bb → bc47966 (CHANGELOG conflict: serve's bullet +1
  sentence, frontend bullet whole after it; 1/1/1). Gates on bc47966: transport-check RED 3 — its Rust cut
  `split("\n#[cfg(test)]")` stopped at dispatch.rs's new test-only TEST_PANIC above the table. Fix: cut at the
  cfg(test) heading `mod tests` (shipped()). Slice mutations 12/12 as expected (old cut red on real files;
  no-cut control red), M1–M41 41/41 red. Committed alone: 0fe3493. Then merged 7f3294d (fe31ee3 + 7f3294d),
  clean → 084d694, ff of origin 5bbfe67. ipcws vs `{id, err:"internal error"}`: generic err path; scratch probe
  (transport-check copy + 4 cases) green. Gates on 084d694 running (+ serve_bin with tmux off PATH, 11/11 wanted).
  Known gap, not fixed: rustFn's body regex needs a column-0 `}` — a one-line duplicate fn is swallowed, not counted.
  DONE: 084d694 (ff of origin 5bbfe67). Gates all green 0 warn (bats 538, core 871, cli 126, api 192, app 12,
  transport 156/0, 44 checks, build+bundle), serve_bin tmux-off-PATH 11/11, probe 4/4, live drive 22/22.
  Reported 1792564714310-5788-00000007. Not pushed.
- [x] 24. (main) msg …0036: merge origin/feat/worktrees-serve 901e941 (D2 9fb1127: show waits for a client;
  D6 a0929b2: downgrade copy of host policy) → a919a64 (signed; CHANGELOG conflict, serve's sentence then the
  transport bullet; 1/1/1, one [Unreleased]; line check: only serve's own two rewrites differ). Gates once.
  Note for (main), unmeasured: D2 releases a held show as soon as ANY authed connection exists; in dev:serve the
  socket authenticates during `await import("./App")`, before App's `app:open-doc` listener — ipcws drops an
  event with no listener, so a held show released in that gap is lost (dev only; Tauri has a similar boot gap).
  DONE: a919a64 (ff of origin 084d694). Gates once, all green 0 warn: bats 538, core 872, cli 127, api 192, app 12,
  tsc 0, transport 156/0, 44 checks, test-frontend 44/0, build+bundle, serve_bin tmux-off-PATH 12/12. No push.
- [x] 25. (main) msg …003e: re-cascade — merge LOCAL feat/worktrees-serve 3950a58 (901e941 + ed65ed1 = #508's
  merge of origin/main 498306f, #521–#523: fsx::write_atomic + guard no_source_builds_its_own_temp_name) → 0348f99
  (signed; NO conflicts; CHANGELOG 1/1/1, one [Unreleased]; line check: no side's additions lost in CHANGELOG or
  AGENTS.md). This branch adds no .rs files (guard scans crates/*/src + app/src-tauri/src only). servefile.rs's
  write → fsx; hex32 (read by transport-check) unchanged. Gates once → merge-3950a58/gates-0348f99/.
  DONE: 0348f99. Gates once, all green 0 warn: bats 538, core 886 (fsx guard ok), cli 127, api 193, app 12, tsc 0,
  transport 156/0 (no dist), 44 checks, test-frontend 44/0, build+bundle, serve_bin tmux-off-PATH 12/12. No push.
