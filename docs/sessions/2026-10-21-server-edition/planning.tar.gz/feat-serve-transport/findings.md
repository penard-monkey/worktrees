# findings — frontend transport seam

## 1. Mechanism: an ipc module, not a WS-backed `__TAURI_INTERNALS__` (decided)

(main) asked to weigh plan §III.1's route — install a WS client as
`window.__TAURI_INTERNALS__`, the way `mock/install.ts` installs fixtures, with
zero call-site changes — against an explicit module. Chosen: **the module**
(`app/src/ipc.ts`), for the NEXT lane's sake, where the shipped Tauri app becomes
a client and keeps its plugins:

- **In a real Tauri webview the internals route has to WRAP the real object, not
  replace it.** Every plugin (`plugin:opener|…`, `plugin:dialog|…`,
  `plugin:updater|…`, `plugin:process|…`, `api/window`) and `plugin:event|listen`
  itself go through `__TAURI_INTERNALS__.invoke` + `transformCallback` +
  `unregisterCallback`. So the shipped app would run every plugin call through
  our interceptor: route `plugin:*` to the saved original, route the rest to the
  socket, intercept `transformCallback` to learn channel callbacks, map
  `plugin:event|listen` onto event frames while still forwarding `tauri://` window
  events to Tauri. That is a man-in-the-middle on an undocumented, per-version
  object in the production app; a Tauri bump that reshapes it (2.x already moved
  IPC to a custom protocol and changed `transformCallback`'s signature) breaks
  plugins AND the backend at once, and nothing type-checks it.
- **The module route never touches plugin traffic.** Plugins keep importing
  `@tauri-apps/plugin-*` directly and keep the real internals; only app commands
  go through the door. In Tauri mode the door IS `@tauri-apps/api/core`'s
  `invoke`/`Channel` and `api/event`'s `listen` — same objects, same args — so
  "unchanged under Tauri" is true by construction, and the mock (which sits BELOW
  `@tauri-apps/api/core`) keeps working untouched.
- **Channel order is ours, not Tauri's.** The internals route would feed
  `{index, message}` into Tauri's index-buffered `Channel` — reusing good code, but
  through its raw message shape, which is undocumented. The module owns a small
  seq buffer that the drift check drives directly.
- **Cost of the module route:** 25 import lines change once, and a new file
  could import `@tauri-apps/api/core` directly and bypass the door. The check
  guards that (one-door rule: only `ipc.ts` and `mock/` may import core/event).
- The two seams coexist: the mock still installs fake internals for fixtures,
  under the door's Tauri implementation.

## 2. Measured
- 25 non-mock files import core/event (brief's count holds). `mock/install.ts:872`
  is a template-string fixture, not an import.
- Tauri 2.11.1 `Channel` constructor calls `__TAURI_INTERNALS__.transformCallback`
  → constructing one in a plain browser THROWS. So the WS path needs its own
  Channel; `new Channel<T>()` at call sites must resolve to the door's.
- Tauri's `Channel` has `#private` fields → nominal in TS; the door exports its
  own structural `Channel<T>` interface (`onmessage`, `toJSON`).
- Channel kind (bytes vs typed) cannot be read off the frame: `data` is a base64
  string for a ByteSink and a JSON value for progress, and a JSON value COULD be a
  string. dispatch.rs is the convention: `frames.bytes(a.channel("on_bytes"))`
  vs `frames.typed(a.channel("on_progress"))`. So kind = arg key `onBytes`;
  pinned against dispatch.rs. (CloneProgress / SyncProgress are objects today.)
- serve answers requests CONCURRENTLY (spawn_blocking per frame) — replies can
  come back out of request order; routing by id is required, not defensive.
- serve's `shell_open` pushes the replay through the sink BEFORE returning, and
  the reply is queued after it on the one outbox → over the socket the replay is
  deterministically the channel's first frame AND arrives before the reply.
  TerminalPane's "first message before `open` resolves → presumed replay" path
  is the one that runs.
- No end-of-channel frame exists in the protocol (Tauri sends one when the Rust
  `Channel` drops). The client must hold every channel's handler for the page's
  life — a disposed terminal's closure is retained. Dev-only now; a protocol gap
  for the next lane → reported to feat-worktrees-serve.
- `fail()` is App-local state (`setErr`). A handshake failure happens before App
  mounts → the door buffers transport errors and replays them to the first
  subscriber (App registers `fail`).
- client-local call sites: `open_editor` ×3 and `open_terminal` → `.catch(fail)`
  (visible); `copy_text` → falls back to `navigator.clipboard` (works in a
  browser); `detect_editors`, `set_zoom` → swallowed by design; `open_docs_viewer`,
  `install_app_version` → awaited in try blocks.

## 3. vite 7.3.6 dev server — what protects a token endpoint (measured in source)
- `server.cors` default = `{ origin: /^https?:\/\/(?:(?:[^:]+\.)?localhost|127\.0\.0\.1|\[::1\])(?::\d+)?$/ }`
  (`config.js:25780`). So ANY page on ANY localhost port gets
  `Access-Control-Allow-Origin` on the dev server's responses — another dev
  server's page, a docs page, anything served from loopback. Same-origin does NOT
  protect a token served by vite under defaults.
- Middleware order (`config.js:25671–25705`): rejectInvalidRequest → **cors** →
  hostValidation (allowedHosts) → `configureServer` hooks → transform/static.
  cors runs BEFORE a plugin middleware, so its ACAO header is already set on the
  response when ours runs.
- hostValidation (DNS rebinding) runs before plugins; skipped when https or
  `allowedHosts: true`.

## 4. Plugins / window APIs that break on a non-Tauri client (out of scope; listed)
Every one goes through `window.__TAURI_INTERNALS__`, absent in a browser. The plugin
functions are `async`, so each REJECTS (TypeError) rather than throwing; what the user
sees is whatever the call site's catch does.
- `feedback.ts:99` `getCurrentWindow()` — SEEN: with `.env.development`'s Orfis key the
  config is non-null, so this throws → "Feedback is unavailable in this build." toast on
  every WS load + `ui: Feedback initialization failed` in serve.log.
- `plugin-dialog` `open()` — App.tsx:5411 (Add project), :5468 (New project), :5523
  (Clone); ProfilesPanel.tsx:197 (skill dir). All in try → `fail()`. **Add/New/Clone
  project cannot be done from a browser at all** — a remote client needs a typed path or
  a server-side picker. (The drive registered its project via the CLI instead.)
- `plugin-opener` `openUrl` — AgentSetup:271, CodexMcpPanel:63, DocsPane:438, App:71,
  :2785, :5843, :8227, :8244, :9475, PlanPane:416, FilesPane:909, PrsPane:62, :118, :204,
  SettingsSheet:64 (`.catch(() => {})` — SILENT). A browser could `window.open` instead.
- `plugin-opener` `revealItemInDir` / `openPath` — DocsPane:257, App:5849, FilesPane:1038,
  :1323, :1324, ProfilesPanel:520, TerminalPane:902, SettingsSheet:224, :690, :749, :752,
  :780. Host-filesystem acts: meaningless on a remote client, should be hidden there.
- `plugin-updater` `check` (SettingsSheet:606), `plugin-process` `relaunch` (:614, :665)
  — the app bundle's own lifecycle; client-local by nature.

## 5. The drive (server-stack.sh + `pnpm dev:serve` + Chrome), 2026-10-17
Scratch project `demo-repo` in the scratchpad, registered via the stack's XDG registry
(`worktrees projects add`); place sessions created by hand as plain shells
(`open_place` and `worktrees new` both launch an agent pane). Screenshots:
`~/.cache/worktrees/worktrees/feat-serve-transport/01..10`.
- Workspace: nav lists demo-repo/(main); Home "1 live"; usage bars are serve's real
  claude_usage. ✔
- Place terminal (`term_open` → tmux): attached, typed `echo over-the-socket-$((6*7));
  git log --oneline` → `over-the-socket-42` + the commit; `tmux capture-pane` agrees. ✔
- Event: subscribed via the page's own `/src/ipc.ts` (same module instance), added a
  worktree + tmux session at 03:08:58 → `places:changed` at 03:08:59; nav grew `demo-b`
  under ACTIVE and (main) an amber dirty dot. App has no timer that re-lists, so only the
  event can have done it. ✔ (No claude busy dot: that needs a real claude probe file.)
- Client-local: place menu → Open in editor → banner `client-local`; console names
  `open_editor`; serve.log `ui: client-local` (fail() → log_event). ✔
- Close: stack stopped under the page → banner "the connection to worktrees serve
  closed". Reload with no stack → banner "the dev server could not say where worktrees
  serve is: cannot read …serve.json: ENOENT … is the stack running?" (pre-mount failure
  replayed into fail()). ✔
- Origin refusal: stack restarted WITHOUT `--allow-origin :1430` → serve.log "refused a
  connection: origin"; the page first said "is the stack running?" — misleading, a
  browser cannot tell a refused upgrade from a dead port → message now names both.
- Token rotation: restart with the origin → plain reload reconnects (endpoint reads
  serve.json per request; no vite restart). ✔
- termreplay LIVE: dock shell `printf 'Q:\033[>c\n'` → live DA2 answered (`0;276;0c` on
  the prompt, correct). Switched to demo-b and back → dock re-attached, full scrollback
  replayed, prompt clean. Outgoing frames recorded (patched WebSocket.prototype.send):
  10 writes after, ALL `term_write` (tmux attach bursts — must be answered), ZERO
  `shell_write`. ✔
- ✘ SERVER BUG: keystrokes reordered. Page sent `echo 0123456789abcdefghij\r` as 26
  frames, ascending ids, in order; zsh got `0124356789…`. Also `dock`→`dcok`,
  `echo abc`→`ech oabc`. conn.rs: one `spawn_blocking` per frame. Reported to
  feat-worktrees-serve + (main). Not worked around client-side (would hide it from the
  phone client).
- xterm `Cannot read properties of undefined (reading 'dimensions')` in
  `Viewport.syncScrollArea` on every terminal mount/unmount — ALSO in `pnpm dev:mock`
  (unchanged Tauri door, no socket) → not the transport; xterm 5.5 + dev StrictMode
  disposal timing. Not compared against main (would mean running vite in (main)'s tree).
- `term_resize` with no `.catch` (TerminalPane:86 tmuxTransport.resize) → one
  "Uncaught (in promise)" after the stack stopped. Same under Tauri on any failure;
  call sites left alone (import-swap-only migration).
- Not driven live: version mismatch (needs a second serve binary of another version) and
  a wrong-token refusal — both covered by transport-check on the virtual clock.

## 6. Other server-side findings (reported to feat-worktrees-serve)
- No end-of-channel frame → the client holds every channel handler for the page's life.
- serve.log lines tear under concurrency (`writeln!` = several write(2)s).
- `set_codex_permissions` / `set_pi_trust` run on every page load; in-memory process-global
  overrides (checked: no disk write), so the LAST client to load decides for all clients.

## 7. Handshake v1 (OWASP H1), client side — 2026-10-18
- Built to (main)'s spec exactly; no divergence. The check carries its OWN copy of the spec
  (SPEC: keys, labels, host) and computes both proofs with node:crypto, so it is independent of
  ipcws.ts. Before the serve lane lands, WIRE is pinned to SPEC only — the Rust has no v1 yet;
  after the rebase, SPEC must also be pinned to wire.rs/policy.rs.
- States: connecting → hello → proving → verifying → ready. Each async step sets the next state
  BEFORE its first await, so a frame behind it meets the right state. Frames that arrive while
  serve's proof is being verified (serve adds a client to its broadcast set at ok, so an event can
  follow at once) are held in `inbox` and handled only once it verifies; dropped if it does not.
- What an impostor sees from the new client: `{"hello": cn}` and, if it sends a well-formed
  challenge, `{"auth": HMAC(token, client|cn|sn)}`. Neither reveals the token; the client proof
  is bound to cn (ours) and to a sn the impostor chose, and the label split means it cannot be
  reflected as a server proof (tested). Not defended at this layer, and not claimed: a relay to a
  live serve with the same token — impossible here, because that serve would hold the port.
- Fail-first against aee08f9's ipcws.ts: 69 failures. Right reason for (a) (the review's
  stand-in got the token, list_workspace and term_write "my-sudo-password"), (b) (token in the
  first frame), (d) (version-mismatch error from an unproven server). (c)/(e) fail there only
  because the old client cannot speak v1 at all — their right-reason reds are mutations M15–M22.
- A broken client's fire-and-forget `void invoke()` rejected unhandled and CRASHED the check
  before it printed anything after (b) → every such call goes through settle().
- crypto.subtle where it runs:
  - dev: Chrome on http://localhost:1430 — a secure context (localhost is potentially
    trustworthy). A LAN address would not be; the client then opens NO socket and says so.
  - shipped app (next lane): tauri 2.11.5 serves macOS from `tauri://localhost`
    (manager/mod.rs:338) through wry 0.55.1's `setURLSchemeHandler:forURLScheme:`
    (wkwebview/mod.rs:284). Measured in a STANDALONE WKWebView registered the same way
    (macOS 27.0, 26A428; probe in the cache dir, wkwebview-probe/): isSecureContext=true,
    crypto.subtle=object, HMAC-SHA256 matches node byte for byte, verify rejects a flipped
    byte; and `new WebSocket("ws://127.0.0.1:P/")` from that page OPENS (not mixed-content
    blocked), sending `Origin: tauri://localhost`. tauri.conf.json `csp: null`, so no
    connect-src stands in the way either. NOT measured in the shipped app itself (AGENTS.md:
    never drive the installed app); wry may set other WKWebView preferences.

## 8. End of channel, the err rule, serve's limits (2026-10-20, serve @ 60b21b0)
- Restacked `--onto 60b21b0 495df95` → 7e00bc1, 3255cf0 (CHANGELOG conflict: serve's bullet
  continuation vs mine — kept both as separate items; headers stay 1/1/1). Signed, no trailer.
- v0 pins went red on the new Rust exactly as they should (auth_ok gone, auth_reply 3 keys).
  §1 now pins: hello/auth via policy `hex32_field`, challenge_frame (1 key), auth_reply
  {ok:true, version, proof}, CLIENT/SERVER_LABEL consts, the one-key rule, is_hex32 lowercase
  only, `{x:02x}` in servefile hex32 + server_proof, mac() update order + token key, labels per
  direction, handshake_v1 call order in conn.rs, end_frame {channel, seq, end:true}, both Drop
  impls' seq+1, PREAUTH_BYTES, MAX_MESSAGE. rustFn now refuses >1 definition (first-match trap).
- RED vs 3255cf0 (eoc/red-vs-3255cf0.txt): 17 failures; right-reason ones: a byte channel's end
  frame goes to atob → InvalidCharacterError THROWN out of onmessage (every detach would throw);
  a progress handler gets `null` for the end frame (clone dialog would read null.phase); a 16 MiB
  request is sent (serve ends the connection). New THROWN recorder in the harness (cb()).
- Client: WIRE.end; Stream.end ordered like data (Tauri's messageEndIndex shape); release() =
  streams.delete; err to a request releases the channels it named; shut() clears streams;
  MAX_MESSAGE guard counted in UTF-8 (fast path len*3 <= MAX); openChannels() on SocketDoor.
- 41 mutations, all red by name (eoc/mutations.txt).
- LIVE (serve pid 83528 :56182): Node driver 20/20 (eoc/node-live-run.txt) — 163 pre-proof bytes;
  48 shell_write + 53 term_write back to back stay in order (capture-pane agrees); detach → end
  then ok; re-attach ends the old attach's channel; exit → end BEFORE shell:exit, 0 held at the
  event; err with no sink (no repo) → no end, released; clone_project from a missing source →
  end ch#1 BEFORE the CloneError err (sink made then failed); term_open on a missing session is
  NOT an err (id returned, attach dies, channel ends itself); 17 MiB write_file refused, conn up.
  Same with the M29 (no guard) client: serve ENDS the connection (node-live-run-without-size-guard).
  NB: shell_open does not validate the slug (a shell for "no-such-place" spawns) — engine
  behaviour, same under Tauri; and a dock tab whose shell exited re-attaches as its ring with no
  shell behind it until "Restart shell".
- Chrome: UI typing in order (place terminal + dock shell), dock exit card; page's own
  bootSocket() in Chrome (chrome-bootsocket-run.json): secure context, subtle, detach end→ok,
  exit end→shell:exit with 0 held, err rule.
- Impostor (serve SIGKILLed, serve.json left naming :56182): stand-in → browser + node each sent
  only `hello`, VERDICT request_frames=0 token_seen=False; challenge → hello+auth only, same
  verdict, banner "its proof does not verify". Remedy followed: server-stack.sh → :57453,
  reload reconnects (17-…jpg).
- feat/worktrees-serve moved to be5bb71 during this (rebased onto server-edition with bbfed64,
  + "load host policy at boot"). The new api-boundary guards are NOT at 60b21b0.
