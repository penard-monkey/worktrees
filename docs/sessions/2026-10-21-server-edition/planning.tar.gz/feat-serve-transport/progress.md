# progress — frontend transport seam

## 2026-10-17
- Read brief, AGENTS.md, serve/*.rs, server-stack.sh, serve lane .planning, plan §III.1/§III.7.
- Bootstraps: submodules; `corepack pnpm install` (pnpm 11.5.2, node 22.23.3).
- Baseline: 42 `app/scripts/*-check.mjs` from repo root, all rc=0 (scratchpad/baseline.txt + .d/ logs).
- (main) asked: weigh WS-backed `__TAURI_INTERNALS__` vs a module → chose the module; findings §1.
- (main): `err` passes through unchanged (CloneError object) → covered in transport-check 2b.
- Wrote `app/src/ipc.ts` (door), `app/src/ipcws.ts` (pure WS client), `app/vite.serve-door.ts`
  (dev token endpoint), `__WT_VERSION__` define in vite.config.ts, `dev:serve` script,
  main.tsx DEV-gated boot, App registers `onTransportError(fail)`.
- Migrated 25 files (import swap; App.tsx's two lines merged into one). tsc rc=0.
- Checks after migration vs baseline: diff-check (counts the working-tree diff: 50→80
  files, still bad=0) and viewer-boundary (68→70 files) differ benignly; feedback-check
  BROKE as the brief predicted (stubs `@tauri-apps/api/core` by name) → now stubs `./ipc`.
- `transport-check.mjs`: 59 assertions green. Shown failing 14 distinct ways on scratch
  copies via TRANSPORT_* overrides (scratchpad/mutate.py, mutations.txt): requests before
  auth (3), replies by arrival (6), frames in arrival order (4), version unchecked (8),
  refused handshake swallowed (2), err stringified (1), Rust `seq`→`n` (6), Rust
  `on_bytes`→`on_data` (1), Rust auth key (2), DEV gate dropped (1), token door trusts
  same-site (2), CORS headers kept (1), Tauri door adds options (2), bytes as strings (5).
  First run of M2/M4/M5 exited 13 (unsettled top-level await) with NO failure printed —
  a hung call ended the check silently; `settle()` now races a 1s deadline → `{hung}`.
- Bundle: `pnpm build` → the 3 ipcws markers absent. `NODE_ENV=development VITE_SERVE=1
  vite build` → emits `ipcws-*.js`, check fails on it. NOTE `vite build --mode development`
  does NOT flip DEV (NODE_ENV stays production) — measured, the boot fn had both dev blocks gone.
- Drive (findings §5): workspace ✔, place terminal + input ✔ (capture-pane agrees), places:changed
  event ✔, client-local banner ✔, close / no-stack / origin-refusal banners ✔, token rotation ✔,
  termreplay live ✔ (0 shell_write on re-attach). ✘ serve reorders keystrokes → reported.
- Reported to feat-worktrees-serve (4 items) and (main) (heads-up on the reorder).
- Gates: `pnpm build` rc=0; tsc rc=0; 43/43 checks rc=0 (42 baseline + transport-check, statuses
  otherwise identical; transport-check 76 ok / 0 not ok incl. the bundle assertion on a fresh
  build); cargo check -p app rc=0; cargo test -p app --lib: 8 passed. Mutations re-run on final
  code: 14/14 fail.
- Committed aee08f9 (signed, bret@brethash.com, no trailer). Cleaned: vite stopped, stack
  --clean (2 sbx sessions gone), app/dist removed. Screenshots in
  ~/.cache/worktrees/worktrees/feat-serve-transport/.

## 2026-10-18 — H1 client half (handshake v1)
- (main): build the client half of OWASP H1 to handshake-v1.md; fail-first (a)–(e); WKWebView subtle.
- New transport-check §2 written first; vs aee08f9's ipcws.ts: rc=1, 57 ok / 69 not ok, no crash
  (after routing fire-and-forget calls through settle()). Saved h1-red-vs-aee08f9.txt.
- ipcws.ts v1 → 124 ok / 0 not ok. 23 mutations (M1–M23), 23 fail by name (h1-mutations.txt).
- WKWebView probe (standalone, tauri:// scheme like wry): secure, subtle ok, ws://127.0.0.1 opens.
- Gates: tsc 0; 43/43 *-check.mjs rc=0 from root (same set); cargo check -p app 0; cargo test -p app
  --lib 8 passed; pnpm build 0 + bundle assertion (4 markers absent); dist removed.
- 2026-10-19: watcher fired on a ref move only — feat/worktrees-serve 495df95 → ecf6851 (serve.log
  one-write-per-line fix), NO message from (main). Not rebased, per (main). Re-armed a message-only
  watcher (bqzdit3v6) on *.<hex(feat-serve-transport)>.json; (main) may also SendMessage directly.
- 2026-10-20: (main) GO @ 60b21b0. Restacked (CHANGELOG conflict resolved, headers 1/1/1). Pins →
  v1 + end frame + limits; §2 2l/2m/2n + upper-case impostors + THROWN; red vs 3255cf0 (17);
  client end-of-channel/err rule/size guard → 156 ok; 41/41 mutations red. Live drive (Node 20/20,
  Chrome UI + bootSocket, impostor both modes, remedy). Gates: tsc 0; 43/43 checks rc=0 (same set);
  cargo check -p app 0; cargo test -p app --lib 8 passed; pnpm build 0 + bundle assertion; dist rm.
- Committed 859a15a (signed, no trailer). Trial restack onto be5bb71 on tmp/restack-trial-be5bb71
  (PiPanel import conflict; KimiPanel.tsx new direct import migrated → 26 files); gates green there
  incl. both new api-boundary guards. Report #2 sent to (main) (id 1792475090421-5788-00000004).
  Waiting for (main)'s word on the final restack. Stack --clean'd, vite stopped, tab closed.

## 2026-10-20 — final restack
- (main) GO: final serve tip is be5bb71; adopt tmp/restack-trial-be5bb71 as-is. Range-diff checked (2,3 '=';
  1 = PiPanel/KimiPanel ./ipc only), signatures G, no trailers → `git reset --hard` → f9dc344.
- Gates (worktrees run --slot gate): transport-check 156/0; tsc 0; cargo check -p app 0; cargo test -p app --lib
  8 passed; make test-frontend 44/0; 44 *-check.mjs rc=0; pnpm build 0 + bundle 4 markers absent; dist removed.
- tmp/restack-trial-be5bb71 deleted. Reported (1792505068407-5788-00000005). No push.
  Evidence: ~/.cache/worktrees/worktrees/feat-serve-transport/restack-be5bb71/.

## 2026-10-20 — merge of serve 0ba880e
- Merged 0ba880e → 5bbfe67 (signed, parents f9dc344 + 0ba880e). CHANGELOG conflict: serve's bullet keeps its new
  sentences, frontend bullet whole after it; 1 Changed/Added/Fixed. Line check: nothing of either side lost.
- Gates (gate slot): release 0 warn; bats 538/538; lint clean; core 871, cli 123, api 191, app --lib 11, all 0 failed
  0 warn; tsc 0; cargo check -p app 0 warn; transport 156/0; 44 checks rc 0; test-frontend 44/0; build + bundle ok.
- Live: drive-eoc updated for the new refusals (missing session, prefix of a live session, unknown slug — each end
  frame then err, released once). 22/22 against a stack from 5bbfe67. Stack cleaned. Reported. No push.
  Evidence: ~/.cache/worktrees/worktrees/feat-serve-transport/merge-0ba880e/.

## 2026-10-21 — merges of serve b46b6bb and 7f3294d
- bc47966 = merge b46b6bb (CHANGELOG conflict, kept both). Gates: transport-check red 3 — the first-#[cfg(test)]
  cut stopped at dispatch.rs's new TEST_PANIC. 0fe3493 fixes the cut (mod tests); slice mutations 12/12,
  M1–M41 41/41 red. 084d694 = merge 7f3294d, clean. Full gates green, serve_bin without tmux 11/11, live 22/22.
  Evidence: ~/.cache/worktrees/worktrees/feat-serve-transport/merge-7f3294d/. Reported; no push.

## 2026-10-21 — merge of serve 901e941 (D2 + D6)
- a919a64 = merge 901e941 (CHANGELOG conflict, kept both; 1/1/1). Merged diff vs 084d694 = serve's 12 files exactly.
  Gates (gate slot), once, all green 0 warn: release; bats 538/538; lint; core 872, cli 127, api 192, app 12; tsc 0;
  cargo check; transport 156/0; 44 checks; test-frontend 44/0; build + bundle (no socket client); serve_bin
  without tmux 12/12. codex_usage: no failure (only the always-ignored live test). Evidence → ~/.cache/worktrees/worktrees/feat-serve-transport/merge-901e941/gates-a919a64/.

## 2026-10-21 — re-cascade: merge of LOCAL serve 3950a58 (main through #523)
- 0348f99 = merge 3950a58 (901e941 + ed65ed1, #508's merge of origin/main 498306f). No conflicts; CHANGELOG 1/1/1.
  No own .rs → fsx guard has nothing of ours; it passes. Gates once, all green 0 warn: bats 538; core 886, cli 127,
  api 193, app 12; tsc 0; transport 156/0 (no dist); 44 checks; test-frontend 44/0; build + bundle; serve_bin without
  tmux 12/12. Evidence: ~/.cache/worktrees/worktrees/feat-serve-transport/merge-3950a58/. Reported; no push.
