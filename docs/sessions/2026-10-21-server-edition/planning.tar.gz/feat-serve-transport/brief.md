# Frontend transport seam — the client half of Server Edition Phase 1

## Where you are

Stacked on `feat/worktrees-serve` (local only, not pushed), which is stacked on `feat/server-edition` (PR #508). #508 moved all 143 Tauri command bodies into `crates/worktrees-api`. `feat/worktrees-serve` added `worktrees serve`, which hosts them behind an authenticated loopback WebSocket.

Read first:
- `crates/worktrees-api/src/lib.rs` crate doc (one engine process per host, decided 2026-10-17).
- `crates/worktrees-cli/src/serve/` — `mod.rs`, then `wire.rs` (every frame shape), `policy.rs` (handshake rules), `conn.rs`, `dispatch.rs` (the 143-row exposure table).
- `app/scripts/server-stack.sh` — the dev stack you will drive.
- The serve lane's `.planning/` in `/Users/bret/Projects/worktrees/.worktrees/feat-worktrees-serve` may help. Read it; never edit that tree.

If `feat/worktrees-serve` is rewritten under you (review fixups), `git rebase --onto feat/worktrees-serve <old base sha>`.

Rules of the road: AGENTS.md — read all of it. Especially the Tauri-app section, Gates, "A new test must be shown to FAIL first", the mock-harness notes (it answers instantly; HMR is dead inside `.worktrees/` so restart vite with `--force` after edits and content-check what it serves; keep vite out of a foreground process group), and the termreplay / channel-order notes.

Bootstraps (both fail confusingly without): `git submodule update --init --recursive`, then in `app/`: `nvm use && corepack pnpm install`.

## Goal

One module becomes the frontend's only door to the backend, with two implementations behind it: Tauri IPC (today's behaviour, unchanged, the default) and a WebSocket client speaking `worktrees serve`'s protocol.

Exit: the real frontend, served by vite in a browser, drives a real `worktrees serve` started by `server-stack.sh`. The workspace renders, a terminal opens and takes input, events arrive, and a client-local command fails visibly rather than silently.

## Facts already measured (verify if anything contradicts; the code wins over this brief)

- 25 non-mock files under `app/src` import `@tauri-apps/api/core` (invoke, Channel) or `@tauri-apps/api/event` (listen). No wrapper exists today.
- Plugins (`plugin-opener` ×10, `plugin-dialog` ×2, `plugin-updater`, `plugin-process`, `api/window`) are client-local by nature. OUT of scope: leave those imports alone, and list in findings which call sites would break on a non-Tauri client.
- The mock harness (`app/src/mock/install.ts`) installs a fake `window.__TAURI_INTERNALS__`. If the Tauri implementation keeps calling `@tauri-apps/api/core`, the mock keeps working untouched. `pnpm dev:mock` must behave identically afterwards.
- Wire, per the serve lane's `wire.rs`: request `{id, cmd, args}` → `{id, ok}` or `{id, err}`. Channel frame `{channel, seq, data}`: data is base64 for a ByteSink stream (terminal, dock shell) and a JSON value for a typed progress callback. Event frame `{event, payload}`. A `Channel` argument is serialized `__CHANNEL__:<id>` (Tauri 2's own form). Argument keys are camelCase, as Tauri sends them.
- Handshake: first frame `{"auth": "<token>"}` within `policy::AUTH_DEADLINE` (3s) → `{"ok": true, "version": "<x.y.z>"}`. Any refusal closes the socket with nothing said. Client-local commands answer `err: "client-local"`.
- `server-stack.sh` keeps the token in its own config dir's `serve.json` (mode 0600) and never prints it. `http://localhost:1420` is always an allowed Origin and `--allow-origin` adds others. Port 1420 is also `tauri dev`'s; serve your browser frontend wherever you like and pass `--allow-origin` for it.
- Check scripts load real sources. `feedback-check.mjs` names `@tauri-apps/api/core` and `/window` explicitly. `zoom-check.mjs` loads `settings.ts` as a `data:` URL module and CANNOT follow a new relative import (AGENTS.md explains). Others slice sources by text. Moving an import can break a check, or make it pass vacuously, which is worse. Run every `app/scripts/*-check.mjs` from the REPO ROOT before and after your change and diff the results.

## Deliverables

1. **The seam** (`app/src/ipc.ts`, or a name you prefer): `invoke`, `Channel` and `listen` with the signatures the call sites use, so migrating a file is an import swap. Migrate all 25. Under Tauri, behaviour must be exactly what it was: same command names and args, same Channel semantics.
2. **The WebSocket implementation.** Auth first; request ids; reply routing; channels delivered per channel in `seq` order, with an ArrayBuffer for byte streams (what TerminalPane gets from Tauri today) and the JSON value for typed ones; `listen` over event frames with a working unlisten. A close or a refused handshake surfaces through the existing `fail()` path, never swallowed. The termreplay contract must hold over the socket (the replay is a channel's FIRST message; `onData` stays muted while it parses) — read `termreplay-check.mjs` and `TerminalPane.tsx` before writing the channel code.
3. **Version.** The auth reply carries the server version; refuse a mismatch with a visible message. Work out where the frontend's own version should come from (the workspace `Cargo.toml` is the one version source) and write the choice down.
4. **Selection.** Tauri stays the default and the only path in a production build. The WS path is DEV-ONLY in this lane; the next lane makes the shipped app a client. Constraints on getting the endpoint and token into a browser frontend: the token never goes in a URL (page or socket), never into localStorage, and never into a production bundle. vite is ^7 — check what its dev server's CORS default actually is before relying on same-origin to protect anything you serve, and record the threat you considered in findings.
5. **A drift check**, `app/scripts/transport-check.mjs` (the `api-boundary-check.mjs` family). Evaluate the real ipc module under stubs on a virtual clock: auth before any request, reply routing by id, per-channel seq order including a reordered arrival, a version mismatch refused, a refused handshake surfaced. Also pin the frame keys against the serve lane's `wire.rs`, so a Rust-side rename fails it. Show it failing first, several distinct ways.
6. **Drive it end to end** against `server-stack.sh` in a real browser (Playwright MCP or the Chrome tools): workspace list, open a place's terminal and type into it, an event (a nav dot) arriving, one client-local command refused and shown. Record what you saw. Screenshots go to `~/.cache/worktrees/worktrees/feat-serve-transport/`.
7. **Docs.** CHANGELOG entries under the EXISTING `[Unreleased]` headers, then count them (one `### Added` and one `### Changed` at most). An AGENTS.md note on the seam (the one door; plugins stay direct) if it earns one.

## Out of scope

The shim becoming a client (find-or-start serve, reading `serve.json` from Rust, switching the shipped app to WS); reconnect and backoff beyond surfacing the close; TLS or remote; iOS; the sidecar packaging (a sibling lane); any change under `crates/`. If the server's protocol is wrong or missing something you need, do NOT patch it here. `report` it to `feat-worktrees-serve` and to (main), and carry on with what you can.

## Gates

`cd app && ./node_modules/.bin/tsc --noEmit`; every `app/scripts/*-check.mjs` from the repo root; `cargo check -p app`; `cargo test -p app --lib`. You change no Rust, so bats and the core suites are not yours to run, but do `cargo build --release -p worktrees-cli` before driving the stack, because `server-stack.sh` runs `target/release/worktrees`. Report cargo results with a grep, not a tail.

## Working rules

- Commit identity `bret@brethash.com`, SSH-signed; confirm with `git log --show-signature -1`. NO `Co-Authored-By: Claude` trailer and no "Generated with Claude Code" footer, ever.
- No push and no PR. Commit locally.
- Never edit another place's tree (`feat-worktrees-serve`, `feat-server-edition`, `feat-sidecar-bundle`, `(main)`, or any other).
- Keep `.planning/task_plan.md`, `findings.md` and `progress.md` current.
- When done or blocked, `report` to (main): what shipped, gate results with numbers, what you drove and saw, and anything out of scope you noticed. If you are blocked, report instead of waiting.
