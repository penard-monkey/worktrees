# task_plan — `worktrees serve` (Server Edition Phase 1, slice 1)

Brief: `.planning/brief.md`. Base: `feat/server-edition` (PR #508, not on main).

## Goal
`worktrees serve`: hosts `worktrees-api` behind an authenticated WebSocket on
127.0.0.1, speaking `{id, cmd, args}` → `{id, ok}|{id, err}`, with byte/typed
channel frames and `{event, payload}` broadcasts. Server half only.

## Phases
- [x] 1. Orient: read brief, AGENTS.md, api crate doc, shim run(), docserver, boundary check.
- [ ] 2. Deps: cli links worktrees-api + tokio + hyper (workspace) + ONE ws crate
      (`tokio-tungstenite`, handshake only, pinned, justified in Cargo.toml).
- [ ] 3. `worktrees_api::host`: `boot(sink)` (log sink → panic hook → PATH/locale →
      core logsink → startup line), `start(ctx, hooks)` (cleanup, import,
      cold-start, the 3s poll thread incl. ring flush), `stop(&ctx)` (exit
      sequence). `hostenv::default_config_dir()` + `APP_IDENT`. Shim: mechanical
      edit to call all three. Extend `api-boundary-check.mjs`.
- [ ] 4. `serve/`: policy (host_ok reuse, origin allowlist, missing Origin refused),
      listener (hyper upgrade → tungstenite frames; refusal = close, nothing said),
      auth frame (3s deadline, const-time compare, reply `{ok, version}`),
      `serve.json` (0600, flock + temp + rename, pid liveness refusal), log file
      at `~/.cache/worktrees/serve.log` with a version start line.
- [ ] 5. Dispatcher: ONE macro = exposure table + arms (143 rows). Args by key,
      camelCase or snake_case. Channels: `__CHANNEL__:<n>` → `{channel, seq, data}`.
      Per-connection writer mpsc = order. Requests dispatched concurrently
      (spawn_blocking). Disconnect closes that connection's term attaches.
- [ ] 6. Tests, each shown to FAIL first (evidence in progress.md):
      connect-witness ×4 (served first), serve.json 0600/rotation, version,
      headless RPC round trip (`list_workspace`), drift check both directions.
      Platform named on every OS assertion.
- [ ] 7. `app/scripts/serve-dispatch-check.mjs` (+ `make test-frontend`).
- [ ] 8. Gates (AGENTS.md), zero warnings. CHANGELOG under [Unreleased].
- [ ] 9. Stretch: `app/scripts/server-stack.sh`.
- [ ] 10. Commit locally (project identity, no Claude attribution). `report`.

## Decisions (see findings.md for the why)
- Listener in `worktrees-cli` (api doc: the caller owns the transport).
- hyper parses HTTP → refusal returns Err from the service → hyper closes with
  no bytes (VERIFY by test). tungstenite = frames only (`from_raw_socket`).
- `err` carries what the Tauri `Err` serializes to: a string for 142 commands,
  the `CloneError` object for `clone_project` (frontend branches on `kind`).
- Second `serve` on a config dir whose serve.json names a LIVE pid that still
  listens → refuse (one engine per host). Dead pid/port → stale, overwrite.
