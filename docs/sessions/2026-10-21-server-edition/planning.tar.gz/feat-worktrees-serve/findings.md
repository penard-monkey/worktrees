# findings — worktrees serve

- `crates/worktrees-api/Cargo.toml` says the api owns NO command socket
  ("`worktrees serve` will bring its own") → listener lives in worktrees-cli.
- Frontend sends camelCase arg keys (`delBranch`, `onProgress`, `onBytes`),
  Tauri 2 default. A `Channel` serializes as `__CHANNEL__:<id>`.
- `worktrees_api::files::b64_encode` exists (RFC 4648) — no base64 crate needed.
- tungstenite's own `accept_hdr_async` WRITES an error response on refusal →
  cannot satisfy "nothing said"; hyper service `Err` is the path to a silent close.
- cargo reaches crates.io (tokio-tungstenite 0.30.0 is current). Lock has no
  sha1/rand/data-encoding/utf-8/tungstenite → those arrive transitively.
- The shim's poll has ONE window-only step: raising the window when
  `drain_inbox > 0`. Everything else ports verbatim → `host::start(ctx, hooks)`
  takes an optional `raise_window` hook.
- The CLI has no log today; its cache convention is `~/.cache/worktrees/<thing>`
  (inbox, codex-usage, plan-hook, the retired mcp-debug.log) → `serve.log` there.
- Tauri's `app_config_dir()` = `dirs::config_dir()/identifier`: macOS
  `~/Library/Application Support/<id>`, Linux `$XDG_CONFIG_HOME|~/.config/<id>`.
- ~~`projcfg::USER_ONLY_KEYS` is cited in four comments but no const by that name~~ WRONG, struck 2026-10-18: it exists at crates/worktrees-core/src/projcfg.rs:51 (used at :504). The shell's `grep` is a function around Claude's bundled ugrep with `-I`, which skips any file holding a NUL byte; projcfg.rs has one literal NUL in a comment, so `grep -r` listed every citer and not the definer. `git grep`, `command grep` and `/usr/bin/grep` all find it. A 'not found' that carries a conclusion needs a second witness from one of those. Nothing committed acted on the wrong version; (main) is recording the trap in AGENTS.md on feat/server-edition.
- hyper 1.x really writes NOTHING when the service returns Err: the witness
  test reads zero bytes before EOF on every refusal (measured on macOS 27.0 in
  the unit test AND through the release binary with a raw-socket client on
  2026-10-18; Linux is NOT measured here — CI's ubuntu runner runs the witness).
  A malformed request hyper cannot PARSE still gets its
  own `400` — that is hyper's, before any policy of ours, same as the docs server.
- tungstenite 0.30's `Message::text` takes `Into<Utf8Bytes>`; a `.into()` on a
  `&str` argument is ambiguous (Bytes vs Utf8Bytes) — pass the `&str`.
- `cargo test -p worktrees-cli` compiles the integration test against the
  debug binary (`CARGO_BIN_EXE_worktrees`), so the subprocess test always runs
  the code under test — no stale-release trap there, unlike bats.
