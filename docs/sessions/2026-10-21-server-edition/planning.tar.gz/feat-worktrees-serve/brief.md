# `worktrees serve` — the loopback server (Server Edition, Phase 1, slice 1)

## Where you are

This place is stacked on `feat/server-edition` (PR #508, Phase 0 of the Server
Edition), which is NOT yet on `main`. That branch extracted all 143 Tauri
command bodies into `crates/worktrees-api`, leaving thin wrappers in
`app/src-tauri/src/lib.rs`. Read `crates/worktrees-api/src/lib.rs`'s crate doc
first — it records the design and three decisions made on 2026-10-17:

1. **One engine process per host.** The desktop app will become a CLIENT of a
   local `worktrees serve`, the same way a second desktop or a phone is one.
   Everything that owns a registry (`Ctx`) runs in exactly one process per
   machine. Your server is that process.
2. **The CLI ships inside the app as a private sidecar** used only to start
   `serve` (packaging is a LATER lane, not yours). `install.sh` keeps putting
   the CLI on `PATH`.
3. **The loopback listener has its own rule set** (below). TLS, remote bind,
   device enrollment, the phone: all later. You bind `127.0.0.1` and nothing
   else.

Rules of the road: AGENTS.md (read all of it; the Gates section and every
"shown to FAIL first" note apply). Do NOT edit `.worktrees/feat-server-edition`
or `(main)`. When #508 merges, rebase this branch onto `origin/main`. If
`project::tests::a_forced_ask_queued_behind_a_fetch_shares_it` fails ONCE on
your base, it is a known wall-clock flake being fixed on `feat/server-edition`
— re-run, do not touch it.

Fresh-worktree bootstraps (both fail confusingly without): `git submodule
update --init --recursive`, then in `app/`: `nvm use && corepack pnpm install`.

## Goal

`worktrees serve`: a subcommand of `worktrees-cli` that hosts `worktrees-api`
behind an authenticated WebSocket on loopback, speaking the same
`{id, cmd, args}` shape `__TAURI_INTERNALS__.invoke` does, so the frontend can
later be pointed at it unchanged. The plan's Phase 1 exit is "drive the real
app against a real engine over a socket"; your slice is the SERVER half, with
the frontend transport and the Tauri shim becoming a client left to the next
lane.

## Deliverables

1. **`worktrees-cli` links `worktrees-api`; `worktrees serve` exists.** Flags:
   `--config-dir DIR` (default: the app's config dir — `~/Library/Application
   Support/net.casadelvalle.worktrees` on macOS, `$XDG_CONFIG_HOME/…` on Linux;
   the shim gets it from Tauri's `app_config_dir()`, you compute it), `--port`
   (default ephemeral), `--allow-origin ORIGIN` (repeatable, DEV ONLY — a flag,
   never a config key, so a dev entry cannot ship).

2. **The listener.** `127.0.0.1` only. HTTP/1.1 upgrade to WebSocket on one
   well-tested stack — `worktrees-api` already carries hyper 1.x + tokio for the
   docs server (`docserver.rs`), so prefer building on those; if you add a WS
   crate, pin it, keep features minimal, and justify it in `Cargo.toml` the way
   the hyper comment does. Report before adding more than one crate.

3. **The loopback rule set** — each refusal closes the socket with NOTHING
   said (no body, no reason, no capability hint; the docs server's "nothing
   says otherwise" discipline):
   - `Host` must be loopback (`127.0.0.1[:port]`, `localhost[:port]`,
     `[::1]`). On plaintext loopback this is what stops DNS rebinding; nothing
     else does.
   - `Origin` ALLOWLIST: `tauri://localhost`, `http://tauri.localhost`, plus
     `--allow-origin` entries. A MISSING `Origin` is refused — every planned
     client is a webview or a browser, and browsers always send one on a WS
     handshake. This deliberately diverges from `docserver::origin_ok(None,…)`,
     which allows a missing Origin for a same-origin GET of a document; write
     that divergence down in a comment so nobody "aligns" them. No CORS header,
     ever.
   - **First frame must be `{"auth": "<token>"}`.** Anything else — wrong
     token, any other frame, a timeout of a few seconds — closes the socket.
     The token is never in the URL.
   - The token: 256 bits from `getrandom` (already a dep), rotated every launch.
     `serve` writes `<config_dir>/serve.json` — `{port, token, pid, version}` —
     mode `0600`, under the same lock-and-rename discipline `registry.rs` uses.
     The app will read this file; so will the dev stack.
   - The auth reply carries `{"ok": true, "version": "<cargo version>"}`. The
     app will refuse a mismatch; after an upgrade "app is new, server is old"
     is the DEFAULT state, not a corner (AGENTS.md's stale-MCP-server notes).

4. **RPC.** Request `{id, cmd, args}` → `{id, ok: <value>}` or `{id, err:
   "<string>"}`. A dispatcher over the 143 commands into `worktrees_api::*`
   with serde_json argument deserialization. **Every command gets an
   `Exposure` row in an exhaustive table in code** — `Engine` (remote, the
   point), `ClientLocal` (`copy_text`, `open_editor`, `open_terminal`,
   `detect_editors`, `open_docs_viewer`, `set_zoom`, `install_app_version`:
   refused over the socket with `err: "client-local"`, never silently run on
   the host — `copy_text` would write the SERVER's clipboard), `HostAdmin`
   (`update_cli`, `*_mcp_*`, `add/remove/clone_project`, `init_repo`,
   `save/delete_profile`…: allowed on loopback for now, tagged so Phase 2 can
   gate them), `Stream` (`term_*`, `shell_*`). The precedent is
   `projcfg::USER_ONLY_KEYS`: a missing row is a hard error, not a default.
   Add `app/scripts/serve-dispatch-check.mjs` in the `api-boundary-check.mjs`
   family: parse `generate_handler!` in the shim and the dispatcher's table,
   fail on any name in one and not the other.

5. **Streams and events.** `ByteSink` → frames `{channel: <id>, seq, data:
   <base64>}`, order preserved per channel (AGENTS.md: a replay answered as
   input came from an out-of-order payload; order is the contract). The
   `FnMut(T)` progress callbacks → typed channel frames the same way.
   `Host::emit` → `{event, payload}` broadcast to every AUTHENTICATED socket.

6. **Host wiring.** The shim's `run()` does, in order: install the log sink →
   panic hook → `hostenv::fixup_gui_path()` + `fixup_gui_locale()` → core
   `logsink::install` → `Ctx::new` → `viewer::cleanup` → `import_app_projects`
   → the nav-dot poll thread (`watch::*`, `term::forget_vanished_places`,
   `sweep_term_history`, the ring-flush tick) → on exit `viewer::kill` and the
   ring flush. `serve` needs ALL of it. Prefer moving the poll thread and the
   flush tick INTO `worktrees-api` as one `host::start(ctx)` that both the
   shim and `serve` call, so there is one copy — a mechanical edit to the
   shim, nothing more — and extend `api-boundary-check.mjs` to assert the shim
   calls it. The pi nav-dot lesson in AGENTS.md is exactly a host forgetting
   one wiring step; the checklist should be code.
   The log: `serve` logs to a file in the CLI's log location, stamps its
   version on the first line (AGENTS.md: a long-lived server outlives an
   upgrade, and the start line is what makes that diagnosable).

7. **Tests, each shown to fail first.**
   - The connect-witness over a RAW loopback socket, four directions, the
     served case FIRST so a dead server cannot pass: good Host + allowed Origin
     + token → served; foreign Origin → closed; missing Origin → closed;
     `Host: attacker.example` → closed. Shape: `docserver::tests::
     a_forged_host_is_refused_and_a_loopback_one_is_served`.
   - `serve.json` is `0600`, rewritten on each launch, and the token changes.
   - The auth reply's version equals `env!("CARGO_PKG_VERSION")`.
   - A headless RPC round trip: `list_workspace` through the socket from a
     test, against a temp config dir — the same position
     `tests/headless.rs` takes.
   - The dispatch drift check fails when a name is removed from either side.
   - Every assertion that touches OS behaviour says WHICH platform you measured
     it on. CI runs ubuntu and macOS; you have macOS.

8. **Stretch, if 1–7 are green:** `app/scripts/server-stack.sh` — a dev
   stack with its own config dir, tmux prefix and port that runs `serve` and
   prints the `serve.json` path. The next lane needs it.

## Out of scope — do not start these

The frontend WS transport; the Tauri shim becoming a client; `externalBin` /
sidecar packaging; TLS, any bind other than `127.0.0.1`, device enrollment,
revocation, rate limits, the audit log (Phase 2); iOS. Per-object authorization
(the plan's R1) is NOT yours; a loopback caller is the local user.

## How to work and when to stop

- Gates from AGENTS.md before every commit; `cargo test -p worktrees-api` and
  `cargo test -p worktrees-cli` especially; `make test-frontend` for the new
  check script. Zero warnings.
- Commit locally with the project identity. **Do not push. Do not open a PR.**
  Never attribute commits to Claude.
- Stop and `report` (the worktrees MCP tool) when deliverables 1–7 are green
  locally, or when you are blocked on a decision — report, do not guess. In
  particular: if the WS stack needs more than one new crate, or if moving the
  poll thread into the api turns out to be more than a mechanical shim edit,
  stop and say so with what you found.
