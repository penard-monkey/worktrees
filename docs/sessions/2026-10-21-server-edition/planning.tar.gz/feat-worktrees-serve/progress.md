# progress — worktrees serve

## 2026-10-17
- Oriented. Plan written. Starting deps + host module.
- Deps: cli links worktrees-api; ONE ws crate (tokio-tungstenite 0.30, handshake only)
  + futures-util as a trait import (already in lock). Lock +13 crates (listed in Cargo.toml).
- `worktrees_api::host` written (boot/start/stop); shim edited mechanically (-307 lines);
  `cargo check -p app` clean. api-boundary-check extended — FAILS FIRST on the old shim
  (13 failures), green on the new.
- serve/: policy, servefile, wire, dispatch (143 rows, one macro), conn, mod; main.rs route.
  `cargo test -p worktrees-cli`: 94 unit + 1 + 3 subprocess, all green.
- serve-dispatch-check.mjs: FAILS FIRST with a row removed (A), a handler removed (B),
  a row retagged ClientLocal (C); green restored (files byte-identical).
- Rust fail-first mutations M1–M12 run via scratchpad/mutate.sh (results below).
- CHANGELOG: entries merged into the EXISTING `### Added` / `### Changed` under
  [Unreleased] (first attempt had created duplicate headers — the AGENTS.md hazard — fixed).
- Pre-existing warning on the base: `viewer::claim` never used (feat/server-edition's).
- Fail-first, Rust (mutate.sh, each restored by cp+touch, residue grep clean):
  M1 host check removed → witness FAILED · M2 origin check removed → witness FAILED ·
  M3 any first frame authenticates → auth test FAILED · M4 version "0.0.0" → 2 version
  tests FAILED · M5 serve.json 0644 → mode test FAILED · M6 token constant → rotation
  FAILED · M7 reply id dropped → rpc test FAILED · M8 client-local string → FAILED ·
  M9 camelCase fallback removed → args test FAILED · M10 serve.json never removed →
  subprocess life test FAILED.
  M11 (second serve never detected) HUNG the subprocess test instead of failing it:
  `.output()` on a second serve that does not refuse waits forever. Test fixed to a
  bounded spawn/poll/kill; M11 + M12 re-run (mutate2.log).
- mutate2: M11 (bounded now) → subprocess life test FAILED in 20.6s at the "kept
  running" expect; M12 broadcast to first client only → event test FAILED. 12/12 red.
- Gates running: gates.sh → gates-summary.log (cli, api, core, app --lib, release
  build, bats, cargo check -p app).

## 2026-10-18 — gates green, committed, rebased, stack driven

- Full gate run (pre-rebase): cli 94+1+3, api 159+7, core 799 (2 ignored),
  app --lib 8, release build newer than core sources, lint, tsc,
  test-frontend 42 ok, bats 518/518 (plan 1..518, 0 not ok), check -p app.
- Found before committing: two comments and the commit draft claimed
  "measured on macOS 15 and ubuntu-latest" — neither was true (this machine
  is macOS 27.0; no Linux measurement had been run). Measured for real:
  macOS 27.0 and Linux 6.12 (Alpine 3.24 musl + Debian 12 glibc containers),
  umask 022/077/000 → mode 0600 everywhere; kill(2e9,0) ESRCH on all;
  container pid_max was 99999, not the 4194304 the comment guessed.
  `pid_alive` now refuses a pid outside pid_t instead of casting it negative
  (a pgid probe); the dead-pid test uses an in-range pid and adds the wide one.
- Commits (project identity, SSH-signed, no attribution): 24f9aa3 refactor(api)
  host::boot/start/stop; 8ae3c9a→amended feat(cli) worktrees serve.
- Rebased onto origin/feat/server-edition @ 1da695e: clean, no conflicts.
  CHANGELOG has one Added/Changed/Fixed each under [Unreleased].
- Re-gated on the rebased tree: cli/api/app --lib/check -p app/boundary/
  dispatch all rc=0, ZERO warnings (the base's two commits removed the three
  pre-existing ones).
- server-stack.sh driven end to end against the release binary: ephemeral
  port, serve.json 0600 {port,pid,version,token}, process detached (ppid 1,
  own pgid), listener 127.0.0.1 only; raw-socket client: 101 with no CORS
  header, auth → {ok,version 0.42.0}, list_workspace → projects [],
  copy_text → err "client-local", unknown cmd → err; foreign Origin,
  missing Origin → 0 bytes; wrong token → closed silently. --stop: process
  gone, serve.json + pidfile removed, log "serve: stopped". --clean removes
  serve-config (the sandbox root with serve.out stays).
- The script's "every log line carries the pid, grep <pid>" was false (only
  the startup line embedded it). ServeLog now writes `[pid]` on every line;
  cli tests re-run green; commit 2 amended.
- Nothing pushed, no PR. PR #508 still OPEN (CLEAN); origin/main unmoved.

## 2026-10-19/20 — batch 1 (transport findings 1–3) and batch 2 (OWASP H1 + M1)

Resumed after a ~12 h stall on a model-switch prompt; (main) relayed the
user's restart. All commits NEW on 495df95, signed, no trailers, NOT pushed.
- ecf6851 serve.log: one write(2) per line (tearing).
- bb57695 per-stream serial lanes (`dispatch::lane`) — keystroke order.
- 3e4ccea end-of-channel `{channel, seq, end: true}`.
- 5193acd dock-shell reader survives its client's disconnect (found here).
- 9b9968d handshake v1 (hello/challenge/auth/ok+proof), token never on wire.
- 60b21b0 M1: caps 64/16, 512 B pre-auth Budget, 16 MiB post-auth,
  5 s HTTP phase, RLIMIT_NOFILE soft → min(hard, 10240).
Gates on 5193acd and on 60b21b0: all green, zero warnings (bats 518/518).
Evidence + probes in the session scratchpad (flood-*.txt, flood3.txt,
impostor2.txt, typing-*.txt, *failfirst*.log, mut-*.log).

HOLDING the rebase (main, 2026-10-20): feat/server-edition is being synced
with main (Kimi Code, #509/#510). When (main) sends the target:
1. lib.rs: ONE .setup (IDENT, config_dir, hostpolicy::boot, manage Ctx,
   winstate attach, then host::start); host::boot replaces the preamble
   (incl. core logsink); host::stop in the Exit arm. My tip still has TWO
   .setup — the bug bbfed64 fixed on the base.
2. api-boundary-check.mjs: keep base's checks 4 (one .setup) and 5
   (state::<Ctx|Tracker> only) + mine (host::boot/start/stop).
3. dispatch: set_codex_permissions/set_pi_trust take &Ctx (HostAdmin);
   get_codex_permissions = Engine; Kimi rows mirroring pi (kimi_status Engine,
   kimi_version Engine, set_kimi_allowed / kimi_mcp_status / kimi_mcp_set
   HostAdmin like pi's); Kimi tick in host.rs poll.
4. NEW commit: serve calls hostpolicy::boot(&config_dir) before host::start,
   fail-first serve_bin test via get_codex_permissions.
5. Gates, api-boundary-check + hostpolicy-check from repo root, then
   sandbox.sh --app ~1 min, grep its app.log for [panic] (expect 0), kill by
   PID only.

## 2026-10-20 — rebased onto feat/server-edition 4799b42; tip be5bb71

- 8 commits rebased + NEW be5bb71 (serve calls hostpolicy::boot; fail-first
  serve_bin test). lib.rs: one .setup (IDENT, config_dir, hostpolicy::boot,
  manage Ctx, winstate, then host::start); host::boot before the builder;
  host::stop on exit. api-boundary-check: base's checks 4/5 kept + new
  "host::start after manage" (shown failing). dispatch: 150 rows (Kimi ×6 +
  get_codex_permissions). Two messages reworded via commit-tree (trees equal).
- Gates on be5bb71: all green, zero warnings (bats 538/538, core 865, cli
  110+1+5, api 170+9+7, app 8, tsc, check, 43 frontend checks).
- Sandbox app (sbx identifier) ran 65 s: 0 [panic] lines; killed by PID.
- server-stack.sh: handshake v1 verified, 9/9 typed lines in order.
- Reported to (main). NOT pushed: origin/feat/worktrees-serve is 60b21b0, so
  the push needs a force — the user's call via (main).
- Flagged to (main): base CHANGELOG says "149 app commands"; 150 registered.

## 2026-10-20 — lane A: L1 log fixes + two engine checks (on be5bb71)

(main) pushed be5bb71 (force-with-lease from 60b21b0, user's call). New task
as NEW commits, no rewrite, no push:
- 1f0b3fb log_event: `ui_line` escapes C0/C1, U+2028/9, bidi controls; cap
  4000 AFTER cleaning on a char boundary. Old `truncate(4000)` PANICKED off a
  boundary (3999 ASCII + é). Red: 3 unit tests + serve_bin forged-line test
  (CR, ESC, NUL in serve.log; forged `2026-01-01 … host-admin` line its own).
- dbcbff5 serve.log 0600: mode at create, fchmod through the handle every
  write, serve.log.1 tightened after rename. Red: 3 append_line tests (644)
  + serve_bin new/inherited (inherited half red alone by mutation).
- fe1f199 shell_open: safe_arg up front; place_session_cwd checks
  place_index ("no such place: x"). Red: `--all` was given a shell.
- 0aad024 term_open: session_exists (exact) first, attach `-t =name`.
  Frontend read first: TerminalPane mounts only when ls says up; open error
  written into the pane; ipcws ends the channel on err — nothing relies on ok.
  Red (private tmux via TMUX env): `{"ok":1}` for a missing session, and a
  PREFIX `wtsb` attached `wtsb-lane`.
- Live probe on the release binary (l1probe/): all four as intended.
- db308b5 test(serve): rest() tolerates EINVAL from set_read_timeout on a
  socket the peer RESET (macOS, measured). The handshake-deadline test flaked
  once in the gate run; forced race red 3/3 → green 3/3.
- Gates (0aad024; cli re-run on db308b5): all green, 0 warnings. bats
  538/538, core 865, cli 113+1+9, api 175+9+7, app 8, tsc, check, 43 checks.
- Reported to (main) (msg 1792544084593-…-05). NOT pushed; tip db308b5,
  fast-forward of 5 over origin be5bb71. Flagged: app.log is 0644 too;
  core tune_session's target is still a prefix.

## 2026-10-20 — (main)'s three follow-ups (on db308b5)

- 942c9aa fix(app): app.log 0600 — sink body → `append_line` in lib.rs,
  serve.log's shape; the tighten helper is now ONE fn,
  `worktrees_api::log::owner_only`, used by both sinks. Red 3/3 (umask 022).
- 33d216f fix(core): tune_session `-t =<session>:`. Test re-execs the core
  test binary as a child with TMUX = a private socket (no in-process env
  change). Red: tuning `wtt` set aggressive-resize on wtt-lane.
  make test-real-tmux 5/5.
- 0ba880e merge origin/feat/server-edition eb0f72e (#520) — git merge, not a
  rebase; one CHANGELOG conflict, all 16 bullets kept (#520's first);
  Changed/Added/Fixed = 1/1/1. Fast-forward from origin be5bb71.
- Next: full gates on 0ba880e, then sandbox.sh --app (sbx app.log is 0644
  now — must come out 0600; grep [panic]).
- Gates on 0ba880e (run after the merge commit): all rc=0, 0 warnings. bats
  538/538, core 871 (2 ign), cli 113+1+9, api 175+9+7, app 11, tsc, check,
  43 checks, 3 stream reruns green.
- Sandbox app ran (pid 24048): sbx app.log 0644 → 0600, 11 new lines,
  0 [panic]. Killed by PID; tauri dev + vite gone, :1420 free. (The 65 s
  wait used `ps -o etimes`, which macOS lacks — it never ended; 2 h up.)
- Reported to (main) (msg 1792552095563-…-06). NOT pushed.

## 2026-10-20 — queued batch (msg 1792544270819): on 0ba880e
1. serve off-loopback CONNECT witness (LAN addr on serve's port refused,
   loopback connect FIRST succeeds); macOS + Linux; red with 0.0.0.0 bind.
2. catch_unwind around each dispatch body → {id, err:"internal error"},
   panic to serve.log, connection + server live. Test-only panicking arm.
- cd26b8e test(serve): LAN witness in serve_bin.rs
  (`serve_can_be_reached_on_loopback_and_not_off_it`). Loopback connect first,
  then connect to own LAN IPv4 (UDP-route trick) must fail. CI with no LAN
  address fails instead of skipping.
  - Measured with lanprobe.py, macOS 27.0 and Linux 6.12 (docker
    python:3.12-slim): LAN connect refused vs 127.0.0.1, accepted vs 0.0.0.0.
  - Red with conn.rs bound to UNSPECIFIED: "192.168.0.40:50706 answered".
  - conn.rs restored byte-identical.
- 4bb5ce9 fix(serve): answer() catch_unwind → {id, err:"internal error"}.
  - Error line `serve: <cmd> panicked: <{:?}, ≤500 chars>; answered …`.
  - Seam: #[cfg(test)] dispatch::TEST_PANIC (on lane term:<id> when given).
  - Red on old answer(): no frame in 5 s (os error 35). Raw-text mutation:
    red at "escaped onto one line". CHANGELOG sentence in serve's Added bullet.
  - Flag, unfixed: host::boot's panic hook logs `info.to_string()`, which is
    TWO lines ("panicked at f:l:c:" + raw message), in both app.log and
    serve.log.
- Gates on 4bb5ce9: all rc=0, 0 warnings. bats 538/538, core 871, cli
  114+1+10, api 175+9+7, app 11, tsc, check, 43 checks, reruns green x3.
- Reported to (main) (msg 1792552921627-…-07). NOT pushed; tip 4bb5ce9,
  ff of origin be5bb71. Waiting for (main).

## 2026-10-21 — (main): CI fix on #516, then the panic hook + app sink
- #516 on origin is 0ba880e (pushed by (main)). New commits on 4bb5ce9:
- 7e3768e test(serve): PrivateTmux Drop → try_run (the macOS rust CI job
  has no tmux; serve_bin.rs:330 expect panicked). Red with tmux off PATH
  (PATH=~/.cargo/bin:/usr/bin:/bin:/usr/sbin:/sbin) = CI's panic exactly.
  The core tune test's Drop hardened the same way (it skips without tmux).
- b46b6bb fix(serve): signals() installed before start()/serve.json. The
  full no-tmux serve_bin turned up 2 tests with exit None: a SIGTERM hit
  before the handler was installed. New test (10 launch+SIGTERM rounds,
  launch polls every 5 ms): red 6/6 both PATHs, green 3/3 each.
- Gates on b46b6bb green (+ no-tmux serve_bin 11/11, tune both ways).
  Reported (msg 1792559493425-…-08).
- fe31ee3 fix(api): panic hook → one line `panicked at f:l:c: "<{:?} ≤500>"`;
  log::panic_text shared with serve's answer(). Child re-exec test, red on
  the old hook. AGENTS.md (.setup passage) + CHANGELOG L1 bullet.
- 7f3294d fix(app): app.log one write_all per line. Red 3/3 (torn), green 3/3.
- Gates on 7f3294d: all rc=0, 0 warnings (api 176, app 12, no-tmux serve_bin
  11/11). Reported (msg 1792560066704-…-09). NOT pushed by me; (main) pushes.

## D2 (rehearsal): serve drained the inbox with no client — 2026-10-21
- Task from (main), bus 1792618806627-1e52-00000030. Evidence: ~/.cache/worktrees/worktrees/rehearse-server-edition-update/evidence/{check-07-downgrade-crash,preflight-downgrade}/inbox.txt.
- The client count is serve's own `conn::Clients` (this branch, #516), not #515's transport, so there was no need to touch another PR.
- v0.42.0 semantics: inbox.rs is byte-identical to v0.42.0 (MAX_AGE_SECS 30, expired deleted unshown). Matched, not changed.
- Fix 9fb1127:
  - `Host::has_audience` (default true; Broadcast = map non-empty).
  - `drain_inbox` -> `Inbox::{Opened,Held}`; with no audience it calls `inbox::sweep` (keeps fresh, deletes expired/unparseable).
  - The poll logs "inbox: N request(s) held until a client connects" when N moves.
  - CHANGELOG: one sentence on the serve Added bullet; headers are 1/1/1.
- Red first: serve_bin `a_show_with_no_client_connected_waits_for_the_next_client` panicked at "the request was taken off the inbox with no client connected" after 3.69 s (one tick). Green 3/3, about 6.7 s each.
- Mutations:
  - has_audience=false: red, "the held request never reached the client" (30.7 s).
  - sweep not deleting expired: core test red, "the expired one must be deleted".
  - Both files restored by cp+touch and checked with cmp.
- Gates on 9fb1127: all rc=0, 0 warnings. bats 538/538, core 872+2 ign, cli 114+1+12, api 176+9+7, app 12, tsc, check -p app, frontend 43/43, reruns 3x green, no-tmux serve_bin 12/12. Reported to (main). NOT pushed.
- Cascade (bus 1792621614760-1e52-00000035): merged origin/feat/server-edition a0929b2 (D6) -> 901e941, signed, no conflicts.
  - The D6 CHANGELOG line extends the host-policy bullet under [Unreleased] ### Fixed; headers are 1/1/1.
  - The first merge message wrongly said ### Changed; amended before anything was pushed (2f39b1a -> 901e941).
  - Gates once on 901e941: all rc=0, 0 warnings. bats 538/538, core 872+2, cli 114+1+12, api 176+9+7, app 12, tsc, check, frontend 43/43 (hostpolicy-check ok), no-tmux serve_bin 12/12.
  - Reported. NOT pushed.
- Re-cascade (bus 1792625704717-1e52-0000003d): merged LOCAL feat/server-edition ed65ed1 (main through #523) -> 3950a58, signed, no trailers.
  - One conflict, CHANGELOG ### Fixed tail: all bullets kept, #523 first after #520, then this branch's two. Headers 1/1/1, one [Unreleased]; released sections identical to both parents.
  - The fsx guard flagged 6 lines on this branch. servefile.rs serve.json temp -> fsx::write_atomic(0600). OWN_TEMP_NAMES rows added for the serve/mod.rs log line (pid, not a path) and for serve/tests.rs (cfg(test) file a line scan can't see).
  - Gates once on 3950a58: all rc=0, 0 warnings. bats 538/538, core 886+2, cli 114+1+12, api 177+9+7, app 12, tsc, check, frontend 43/43, fsx 8/8, servefile 4/4, no-tmux serve_bin 12/12.
  - Reported. NOT pushed.
