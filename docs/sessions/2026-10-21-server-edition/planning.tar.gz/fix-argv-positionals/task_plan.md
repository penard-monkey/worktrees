# R3 — client values never read as flags (OWASP M3)

Base: f308062 (feat/server-edition). Branch fix/argv-positionals. Do not push.

## Findings that shape the fix
- cmd_switch's parser REFUSES a dash-led base today ("Unknown flag"), and
  do_switch then runs `git fetch --quiet origin <base>` with NO `--`.
  Measured: `git fetch --quiet origin --upload-pack=touch X` RUNS touch.
  So adding `--` to the parser alone would OPEN local command execution.
  `--` before origin, or `--end-of-options`, turns it into "invalid refspec".
- Single-positional parsers (open/close/rm/status/provision) eat a dash-led
  slug as a flag and then fail "needs a worktree" — confusion, no effect.
  Two-positional ones (new, switch) and relink/provision (`--all`) DO change
  behaviour: base `--no-fetch`/`-r`/`--force`/`--brief=..`/`--no-tmux`,
  relink slug `--all` (+force) widens one place to every place.
- MCP already has `safe_arg` (cli/src/mcp.rs) for branch/base/slug — move it
  to core and share it; do not write a second.
- No ref validator exists in core. Write `valid_branch` mirroring
  `git check-ref-format --branch` (no expansion) + oracle test vs real git.
- UI: a thrown Err from new_place loses the dialog's input (runCmd -> null);
  a failed CmdResult restores the form. Refuse with a failed CmdResult.

## Phases
1. [x] fail-first tests (api: each changed fn; core: `--` positional) — red on base
2. [x] core: `argv` module (split at `--`, safe_arg, valid_branch); parsers honour `--`
3. [x] core: `--` on git calls carrying client positionals (fetch base, switch, worktree add)
4. [x] api: helper builds argv (static flags, glued values, `--`, positionals) + boundary validation
5. [x] MCP uses the core safe_arg (+ valid_branch?)
6. [x] drift guard: every cmd_* call in api goes through the helper; show it failing on a planted call
7. [x] bats test for `worktrees new -- …` if harness can express it
8. [x] Command::new table (subagent first pass, verify)
9. [x] AGENTS.md note + doc comment; CHANGELOG if CLI-visible
10. [x] gates; commit signed; report to (main) with invariant text (72fce61 on ad09f5d)
