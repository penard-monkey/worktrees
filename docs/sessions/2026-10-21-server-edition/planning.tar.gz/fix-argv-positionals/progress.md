# Progress — R3

- Fail-first evidence logs: ~/.cache/worktrees/worktrees/fix-argv-positionals/
  - base-core.log (3 core tests red on base; upload-pack test RAN touch)
  - base-api.log (9 api tests red on base, one per function)
  - mid-core.log (parser `--` without git `--`: worktree add took --lock as an option)
  - drift-before.log (drift check lists exactly the 10 direct calls)
  - drift-planted.log / drift-planted2.log (direct call, held fn, second Argv)
  - bats-old.log (4 new bats tests red on installed v0.42.0: "Unknown flag: --")
- Subagent audit merged; extra fix from it: branch_arg validates the post-strip_origin name.
- Outside R3, to report (not fixed): write_file can overwrite .git/config (core.fsmonitor);
  save_profile model unvalidated + mcp_servers/hooks; term_open.session unanchored -t;
  sync.rs rsync local_root from hub manifest has no `--`/absolute check; sanitize_prefix
  allows a leading '-'.
- Gates: all green on 72fce61 (rebased onto local feat/server-edition ad09f5d). Reported to (main).
