# R3: client-supplied values must never be read as flags (OWASP review M3)

Based on `feat/server-edition` (PR #508, Server Edition Phase 0) at `f308062`. The user approved this fix.

## Why

PR #508 moved the 143 Tauri command bodies into `crates/worktrees-api`. `worktrees serve` (branch `feat/worktrees-serve`, not on this base) now exposes them over an authenticated loopback WebSocket. Any authenticated client, not only the app's own dialogs, can therefore put arbitrary strings into these functions.

An OWASP review of serve found finding **M3**, Medium. The full report is at `~/.cache/worktrees/worktrees/owasp-serve/report.md`; read the M3 section. In summary:
- `worktrees-api` builds a `Vec<String>` argv from client values and hands it to core's CLI-style parsers.
- Those parsers tell flags from positionals by a leading `-`, and none of them honours `--`.
- So `new_place` with `branch: "--force"` or `base: "-r"` is parsed as the FLAG.
- The final git and tmux calls do use `--` (clone.rs:560, sync.rs:1687, tmux.rs:699), so this confuses flags in our own parser; it is not confirmed injection into git options.
- The proposal (`docs/proposals/server-edition.md`, "Queued, not yet in a phase") records that R3, the argument-injection invariant, has no phase and must land no later than Phase 2. The user wants it closed now.

## Scope

1. **Every `worktrees-api` call into a core `cmd_*` parser.** Found so far:
   - `ops.rs`: `cmd_new` :614, `cmd_switch` :635, `cmd_open` :730, `cmd_close` :1003
   - `prefs.rs`: `cmd_rm` :142
   - `config.rs`: `cmd_doctor` :303, `cmd_status` :358, `cmd_relink` :588, `cmd_provision` :598
   - `project.rs`: `cmd_init` :363

   Re-derive the list yourself with `git grep -n -E 'cmd_[a-z_]+\(' -- crates/worktrees-api/src`. For each call, trace which argv elements come from the client.
2. **Core parsers.** Teach each parser reached above to honour `--`: everything after it is positional. That fixes the CLI too (`worktrees new -- -weird`).
   - Then make `worktrees-api` put `--` before every client-supplied positional.
   - Watch `cmd_new`'s value-taking flags (`--name`, `--ai`, `--model`, `--brief`): `ops.rs` ~line 803 already treats a `-`-led value specially when a value is expected. Keep a value that starts with `-` from turning into a flag there too, or refuse it with a clear message. Decide which, and say why.
3. **Validation at the boundary, as a second layer.** A branch or base name must be a valid ref that does not start with `-`, the same rule `git check-ref-format --branch` applies. A slug or place name must pass the existing slug rules.
   - Refuse in `worktrees-api` with a message the UI can show.
   - Reuse core's existing validators if they exist (`git grep -n -E 'fn valid_|check_ref|fn is_valid'`); do not write a second one that can drift from them.
4. **Every `Command::new` reachable from `worktrees-api` with a client-supplied value** (git, tmux, gh, editors, anything). Make a table: call site, which argument is client-supplied, and how it is guarded (`--`, validated, or not reachable). Fix any unguarded one.
   - `open_editor` and `open_terminal` build `/bin/sh -c` from user config. They are ClientLocal, and serve refuses them (report I6), so note them and leave them.
   - This table is the R3 invariant's evidence. Put it in your report.
5. **State the invariant where the next contributor will trip over it.** Add a short note to AGENTS.md, in the same voice as its other notes, plus a doc comment on the helper you add.
   - Do NOT edit `docs/proposals/server-edition.md`: another lane (`docs/statics-audit`) is editing it. Send (main) the invariant text and (main) will fold it into the proposal.

## Tests: fail first

AGENTS.md: "A new test must be shown to FAIL first."
- For each api function you change, write a unit test where a client value like `--force`, `-r` or `--no-fetch` would have toggled a flag. Assert that it is refused, or treated as a literal name, and that the flag did NOT take effect. Show each one red on the base commit before the fix.
- For the core parsers, add a test that `--` makes the next arg positional, and a bats test for the CLI form (`worktrees new -- …`) if the bats harness can express it.
- Consider a guard in the `app/scripts/*-check.mjs` family or a Rust test that fails if a new `cmd_*` call appears in `worktrees-api` without passing through your helper. Use the drift-check shape AGENTS.md describes: slice off `mod tests`, and fail if more than one thing claims to be the emitter. Add it only if you can make it able to fail; show it failing on a planted bad call.

## Rules

- Gates, all of them, per AGENTS.md: release build FIRST, `make test`, `make lint`, `cargo test -p worktrees-core`, `-p worktrees-cli`, `-p worktrees-api`, `-p app --lib`, tsc and `cargo check -p app`. Report cargo with `grep -E "^running|^test result"`, not tail.
- If a change alters CLI behaviour a user could notice (a name that used to work is now refused), add a CHANGELOG bullet under the existing `## [Unreleased]`, then count the `###` headers so there are no duplicates.
- Commit locally:
  - SSH-signed as `bret@brethash.com`, with NO `Co-Authored-By` or any attribution trailer
  - do not push
- **Grep trap:** inside Claude Code, `grep` is a function that skips files containing a NUL byte. Use `git grep` or `/usr/bin/grep` for anything a conclusion rests on.
- Do not edit other places' trees: `.worktrees/feat-worktrees-serve`, `feat-serve-transport`, `docs-statics-audit`, `fix-host-policy`.

`report` to (main) when done:
- commits
- each fail-first test's before and after
- the `Command::new` table
- the invariant text for the proposal
- gate counts
- anything that changes what a CLI user can type
