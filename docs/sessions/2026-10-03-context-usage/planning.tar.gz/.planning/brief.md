# Brief: research how to show each agent session's CONTEXT usage

(Reconstructed at close-out from the session transcript; the worktree that held it was removed.)

## Goal
David wants each place's agent session to show how full its context window is ("62% of 200K", or similar). **This is research and planning only. Build nothing.** Use the planning-with-files skill (task_plan.md / findings.md / progress.md). Deliver `docs/proposals/context-usage.md` in a docs-only PR. Report the PR number to the orchestrator in (main), and do not merge.

## Questions to answer, for EACH harness: Claude, Codex, pi
1. Where does the number live? (Claude transcript usage / session probe / statusline; Codex rollout token_count; pi session files.) Measure on REAL files; sample many sessions.
2. What is the numerator? The LAST turn's prompt size, checked against each CLI's own display.
3. What is the denominator (the window)? Claude 200K vs [1m]; Codex model_context_window; pi models.json contextWindow. Unknown case?
4. Compaction / clear / resume: does the number drop, which record says so?
5. Freshness and cost: content not mtime; ride the existing poll without new spawns; tail reads.
6. Model switches mid-session (/model).
7. Surfaces: nav row, place header / status chip, dock, MCP place_status, ls --json. ONE primary surface; ASCII for %, bar, tokens.
8. Thresholds: warn level; each CLI's auto-compact point.

## Output: docs/proposals/context-usage.md
Per-harness table; real redacted samples; what's impossible/unreliable; recommended design and phases; open questions for David. Follow docs/adding-a-harness.md's by-surface thinking.

## Rules
- READ ONLY on ~/.claude, ~/.codex, ~/.pi. Never read ~/.pi/agent/auth.json or credentials. Redact prompt content.
- Never write ~/.claude.json, ~/.codex or ~/.pi config. Don't drive David's app. Don't touch other places' sessions.
- Throwaway CLI sessions: tiny; `tmux -L <unique>` on EVERY call; scratch in a `worktrees new --ai none --no-attach` place or ~/.cache/worktrees/worktrees/context-usage/; no `git worktree add`; answer no config-writing trust prompts, report if one writes anyway.
- Co-Authored-By, no session trailers/URLs. Docs-only PR.
