# Findings

(Reconstructed at close-out: the original gitignored file was lost when the
context-usage worktree was removed before close-out. Content is the same
notes; the full evidence is in docs/proposals/context-usage.md.)

## Code surfaces
- Claude model: agent::transcript_model + model_switch; app cached_model 256KiB tail keyed by len. Probe has no model/tokens.
- Codex: codex::rollout_model, activity::codex_tail (256KiB, CODEX_TAIL), latest_rollout.
- pi: pi::session_model, tail_info (PI_TAIL); pimodels.rs reads models.json baseUrl+ids only.
- Poll 3s; models_moved → places:changed → snapshot re-pull. Nothing parses token usage today.

## Claude (251 transcripts / 14d)
- usage on every assistant line; numerator input+cache_creation+cache_read (binary RIe/vvn).
- model ids never carry [1m]; opus/fable families exceed 200K routinely → 1M default.
- window logic vv(): [1m] → 1M; beta+support; capability table; env; else 200K; credits latch.
- compact_boundary {trigger, preTokens, postTokens}; 13/14 autos since 2.1.269 at 967–971K.
- first assistant after compact may be synthetic zero usage; first real 54–127K.
- last usage ≤154KB from end in 40 largest files.

## Codex (180 rollouts / 30d)
- token_count info {total_token_usage, last_token_usage, model_context_window=258400}; null only in Codex Desktop placeholders.
- after `compacted`: token_count input 0, total = estimate 18–25K. auto at 231–245K.
- /status % left = (W−T)/(W−12000).

## pi (27 sessions)
- usage {input, output, cacheRead, cacheWrite, totalTokens}; compaction {tokensBefore}; tree via parentId.
- footer: last post-compaction usage + trailing estimate; "?" after compaction; >70 warn, >90 error; auto at window−16384; custom-model default 128K.

## Live probe
- Claude haiku 63,859 == /context 63.9k/200k (32%); opus /context 1m, buffer 33k.
- /model saves default to ~/.claude/settings.json (restored).
- /clear: new sessionId in probe immediately.
- Codex 30,888/258,400 == /status 92% left.
