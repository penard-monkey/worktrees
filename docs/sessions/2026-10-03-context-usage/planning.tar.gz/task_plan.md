# Task plan: context-usage research (docs-only)

## Goal
Deliver docs/proposals/context-usage.md (research + design, build nothing) in a docs-only PR; report PR # to (main); do not merge.

## Phases
- [x] 1. Map code surfaces (model readers, poll, MCP place_status, ls --json, frontend)
- [x] 2. Claude: measure real transcripts — usage fields, numerator, model/[1m], compaction, sizes/tail cost; probe file; statusline
- [x] 3. Codex: rollout token_count events, model_context_window, compaction
- [x] 4. pi: session files, usage fields, models.json contextWindow, compaction
- [x] 5. Cross-check against each CLI's own display (/context, footer)
- [x] 6. Write proposal (tables, samples, impossibles, design, phases, open questions)
- [x] 7. docs-only PR (#427), report to (main)

## Errors
- /model in a probe wrote ~/.claude/settings.json (restored via /model opus).
