# kimi as a fourth harness

## Goal
Kimi Code (`kimi` 2.2.0) gets every harness surface claude/codex/pi have. Phase A proposal is OK'd (proposal.md in cache dir; decisions a/b/c accepted).

## Decisions (approved 2026-10-19 by David via worktrees-(main))
- (a) Deferred opener: never into a non-empty composer or over a modal; bounded and logged; confirmed by wire `turn.prompt`; the gives-up path is tested.
- (b) Per-place `<place>/.kimi-code/mcp.json`: owned by worktrees, excluded in the COMMON dir's info/exclude (covers every place), refused when tracked or not ours, removed with the place.
- (c) Catalog from config.toml `[models.*]` only. Every other table is dropped unread, and its contents never reach applog, errors or test output; a parse error says "config.toml unreadable". Synthetic fixtures only.
- Trust: default `ask`, with a `worktrees trust kimi` allowance (env KIMI_CODE_TRUST_WORKSPACE=1).
- Never pass --yolo/--auto.
- /model record: measure via the session-only path only if config.toml is not written; otherwise list it as unmeasured.

## Phases
### PR1 core + CLI + MCP + app backend + frontend registration — #509, CI running
- [ ] provider row + adapter skeleton
- [ ] kimi.rs: workspace dir, wire reader (activity, model, session discovery)
- [ ] kimimodels.rs: catalog
- [ ] trust kimi
- [ ] per-place mcp.json
- [ ] deferred opener
- [ ] send
- [ ] guidance delivery
- [ ] doctor
- [ ] fixtures + tests (shown RED first) + bats
- [ ] CHANGELOG
### PR2 app + mock — pending
### PR3 docs (kimi-manual-checks, checklist) — pending
### PR-usage (after PR1): kimi usage meter via `kimi web` GET /api/v1/oauth/usage
Pins from main (2026-10-19):
1. Loopback-only bind, verified with lsof (-nP -iTCP:<p> -sTCP:LISTEN); if it is LAN-reachable, stop and report.
2. The stdout token is never logged, and is redacted from errors.
3. Own process group; kill the group on success, timeout and error, then reap; test that no kimi web survives a timed-out probe.
4. Single-instance lock (server/instances): measure the effect on a user's own `kimi web` and on an interactive kimi.
5. Port 0 if kimi accepts it and prints the bound port; otherwise pick a free port, and treat a bind failure as unavailable and retry next tick.
6. TTL and failure floor: at most one probe per 120s, failures included.
