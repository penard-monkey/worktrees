# Progress
- 2026-10-19: Phase A done, approved. Phase B started.
- 2026-10-19: PR1 core written: kimi.rs, kimimodels.rs, kimiplace.rs, the Kimi adapter, trust kimi, the opener helper (`worktrees kimi-opener`), guidance delivery as place files.
- Mutation pass: 16 mutants, all RED (screen order, open interactions, models_only, opener-in-argv, the opener's non-empty composer / took-over / start grace, foreign/tracked place files, protect-ours ×2, place-born filter). Lesson: a restore that writes back by replacing new->old corrupts the file when new is ""; restore from the saved original text.
- 2026-10-19: PR1 opened as #509 (core + CLI + MCP + app backend poll + frontend registration). Local gates all green (bats 532/532, core 837, cli 68+1, app 165, lint, tsc, check, test-frontend, real-tmux, test-mcp). CI run 39361542329 is being watched.
- Next: PR2, Settings → Kimi (binary/version, trust allowance, MCP toggle, default model) plus offers; then PR3, the usage meter via `kimi web` (pins in task_plan).
- 2026-10-19: #509 review fixes pushed (head f780f59), CI green on all 9 jobs: exact-text opener, one derivation (`lane_state`), trust computed after the files, excludes with a header / hidden-file warning / pruning, plus the nits. Waiting for main to merge; PR2 (Settings → Kimi) is next.
- 2026-10-19: #510 merged (32ec1b8). PR3 is #511 (the usage meter + the launch gate + doctor), CI green on all 9 jobs (run 39367891843). It also has the pi/kimi status-swallow fix. Waiting for review.
- Owed by David: manual-checks §9b's last box and §10 (one lane end to end in the real app).
- 2026-10-19: #511 review fixes pushed (head 9f56627); CI green on all 9 jobs. Waiting for merge. Then close-out.
