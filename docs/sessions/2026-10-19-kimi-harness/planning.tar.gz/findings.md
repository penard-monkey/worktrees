# Findings (kimi 2.2.0)
See ~/.cache/worktrees/worktrees/kimi-harness/proposal.md for the Phase A survey.
- kimi binary is a bundled JS app; its strings dump is in the session scratchpad (kimi.strings).
- wire.jsonl events: agent.turn.started{turnId}, turn.prompt{promptId,turnId}, interaction.request{id,kind}, interaction.resolved{id}, agent.turn.ended{outcome}, turn.ended{reason}, turn.cancel, prompt.completed/aborted, profile.bind{modelAlias}, llm.request{modelAlias}.
- workspace dir: wd_<basename>_<sha256(root)[:12]>; root = place dir.
- Trust: workspace-trust/<wd id>; env KIMI_CODE_TRUST_WORKSPACE=1 trusts the launch only and writes nothing.
- MCP: user ~/.kimi-code/mcp.json; <gitroot>/.mcp.json; <cwd>/.kimi-code/mcp.json (last wins); project layers are trust-gated.
- No positional prompt in interactive mode.
- /model picker: Enter PERSISTS default_model to config.toml; Alt+S = session-only (verified: config.toml mtime unchanged). A switch writes `config.update {modelAlias}` immediately.
- Busy send: kimi queues; screen shows `❯ <text>` + `↑ to edit · ctrl-s to steer immediately` above the composer, and the composer clears; the wire gets turn.prompt only when it starts.
- Question modal: interaction.request kind=question; screen footer `↑↓ select  1-3 / ↵ choose  ←/→/tab switch  esc cancel`. Every modal replaces the composer box (╭ … ╰).
- `-S <bad id>`: "error: failed to start shell: Session … not found.", exit 1, creates nothing.
- Guidance: kimi reads <dir>/.kimi-code/AGENTS.md (in addition to AGENTS.md) and <proj>/.kimi-code/skills; --skills-dir REPLACES discovery.
- kimi never calls MCP getInstructions.

## kimi web (usage route), measured 2026-10-19 on 2.2.0
- `kimi web --no-open --port 0` binds 127.0.0.1 only (lsof: `127.0.0.1:<p> (LISTEN)`, "Network: off") and prints the bound port in `Local: http://127.0.0.1:<p>/#token=…`. Ready in ~0.9s.
- GET /api/v1/oauth/usage with `Authorization: Bearer <token>` answers in ~1s: {kind:"ok", quota:{usages:{limit5h?, limit7d?, monthTotal?, monthCode?: {usedRatio, resetAt?}}, extraUsage}} or {kind:"error", message, status?}.
- The token is PERSISTENT: equal to ~/.kimi-code/server.token and shared by every `kimi web`, a user's own included. Never log it; never read that file.
- No single-instance lock: two servers on two ports coexist and both answer. server/instances/<id>.json holds server_id, pid, host, port, started_at, heartbeat_at, host_version (no token).
- No child processes. SIGTERM exits and removes its instance record; SIGKILL leaves a stale record, which the next `kimi web` start prunes.
