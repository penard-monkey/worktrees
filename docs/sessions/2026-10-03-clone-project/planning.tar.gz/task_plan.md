# Task plan — "Clone from URL…" (branch clone-project)

Goal: paste a git URL → clone into a remembered parent folder → added + selected.
Design: findings.md.

## Slices (each a main-quality commit)
- [x] 1. Design: findings.md settled (gitignored); draft PR opened after slice 2.
- [x] 2. core `clone.rs`: parse/name derivation, destination guard, env
      (no prompts), streaming progress, cancel + cleanup-only-what-we-made,
      error classification. Tests vs local bare repos (`file://`), fail-first.
- [x] 3. CLI `worktrees clone` + bats.
- [x] 4. App backend: `clone_project` (Channel progress, add_project) +
      `clone_cancel`; lib tests.
- [x] 5. Frontend: `clone.ts` mirror, `CloneDialog`, menu item, `projects_parent`
      setting shared with New project; mock cases; `clone-check.mjs`.
- [x] 6. Harness verification (elementFromPoint, themes), CHANGELOG, docs,
      gates, CI, mark ready, report to (main).

## Decisions
See findings.md §Design decisions.

## Errors
| Error | Attempt | Resolution |
|---|---|---|
