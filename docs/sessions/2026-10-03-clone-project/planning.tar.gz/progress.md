# Progress

## 2026-10-03
- Read brief, AGENTS.md, add/new-project/import paths, sync progress Channel,
  settings.ts. Wrote findings.md design + task_plan.md slices.
- Bootstrap (submodules, pnpm) started.
- Slice 2 core `clone.rs`: 10 tests green. Fail-first by mutation (each red, then restored):
  - drop `.process_group(0)` → cancel test FAILED (ran >60s, grandchild ssh alive)
  - skip `remove_dir_all` on failure → a_failed_clone_removes… FAILED
  - `create_dir` → `create_dir_all` → late-target test FAILED (it deleted the other party's file)
  - drop the `/.git` segment pop → name_cases FAILED
  - drop GIT_TERMINAL_PROMPT → env test FAILED
- Slice 3 CLI `worktrees clone` + test/clone.bats (6). Fail-first: dispatch removed → 6/6 red;
  registry::add stubbed → test 1 red. Manual Ctrl-C probe with a hanging fake ssh:
  exit 130, "Clone cancelled.", dest/slow removed, ssh grandchild dead.
- Slice 4 app backend `clone_project` / `clone_cancel` + `CloneJobs`; 2 lib tests.
  Fail-first: guard Drop not removing → cancel test red; enum without snake_case → serialize test red.
- ADR 0001 audit of the add path: nothing repo-supplied runs (findings.md).
- Slice 5 frontend: clone.ts mirror, CloneDialog, menu item, `projects_parent` (shared with
  New project), mock clone_project/clone_cancel, clone-check.mjs (37 assertions).
  Fail-first for clone-check: drop TS `.git` pop → red; add a Rust kind → red; mock kind drift → red.
  Harness (Playwright, chromium + webkit, ~/.cache/.../pw/drive.mjs): autofocus no scroll; hit-tests
  true for Clone/Cancel/Change…/URL; preview; 4 failure kinds; progress; Esc+scrim inert while
  running; cancel note; success closes + selects (main); remembered parent shared with New project;
  exists refused; 6 themes screenshotted (WebKit).
- Slice 6: probes, CHANGELOG, gates all green, CI run 37152081111 green (9 jobs), PR #428 ready.
- Follow-up #432 (review nice-to-haves 1–6), CI green; close-out archive.
