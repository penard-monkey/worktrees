# Findings — Clone from URL…

## Where it plugs in (read 2026-10-03)
- Add menu: App.tsx ~8402 (`ctx?.kind === "add"`): New project… / Add existing… / Import from hub….
- `addProject` (App.tsx 5011): native picker → `probe_dir` → `add_project`.
- `NewProjectDialog` (App.tsx 3046, module scope) + `create_project` (lib.rs 607).
  **There is NO remembered parent today.** `defaultLocation` (App.tsx 5066) is
  DERIVED: the most common parent dir of the workspace's projects, else
  `~/workspace`. So the "one remembered answer" is new: a `Settings` key
  `projects_parent` that BOTH dialogs read (`projects_parent || derived`) and
  BOTH write on success (create writes its location, clone writes its parent).
- `add_project` (lib.rs 524) = `Project::discover` + `registry::add` +
  `list_workspace`. Import calls it after the transfer (lib.rs ~4086) — clone does
  the same.
- Progress precedent: `sync_apply` takes `on_progress: Channel<SyncProgress>`;
  core's `apply_streaming` reads the pipe, throttles (`PROGRESS_MIN_GAP`),
  always sends the final sample, and drains stderr on its own thread.
- No cancel precedent anywhere in lib.rs → new: a registry of running clones
  keyed by a frontend-chosen id + `clone_cancel(id)`.
- `expand_home` + absolute-path rule exist in lib.rs for create_project; the
  clone reuses the same rules (core gets its own copy, or lib.rs's moves to core).
- Mock: no generic "every command is mocked" check exists. `create_project`
  mock models the exists-refusal.

## ADR 0001 audit (add path for a fresh clone)
- `git clone` copies no hooks (hooks are never transferred; templates are the
  USER's). No `--recurse-submodules` → no repo-supplied URLs fetched.
- `add_project` → `Project::discover` + `registry::add` + snapshot. To verify in
  the build slice: snapshot only READS `.worktrees.toml` (projcfg refuses
  argv keys as parse errors); install_cmd / `[[file]]` / compose run at place
  CREATION, never at add. (Verify by grep before claiming in the PR.)

## Design decisions
1. **URLs.** Any git URL: `https://…`, `http://…`, `ssh://…`, `git://…`,
   `file://…`, scp-style `user@host:path`. `owner/repo` shorthand (exactly two
   segments of `[A-Za-z0-9._-]`, no scheme, no colon) → `https://github.com/owner/repo.git`.
   Refused: empty, leading `-` (argv injection; also passed after `--`),
   `ext::`/any `<transport>::` remote-helper syntax, whitespace/control chars,
   bare local paths (use Add existing…).
   Name = last path segment, minus `.git`, minus trailing `/`. Must pass the
   same `valid_project_name` rules (no leading dot, etc.) else refuse with a
   message.
2. **Destination.** `<parent>/<name>`; existing target is REFUSED (same as
   create_project: "already a git repo → Add existing…" vs "exists"). No
   auto-suffixing — a second copy of a repo is unusual and a silent `-2` hides
   that you already have it. Name is not editable in v1? → Decided: an optional
   "Folder name" field prefilled from the URL (cheap, and the only way out of a
   collision without moving the parent).
   Parent: native picker defaulting to remembered `projects_parent`; missing
   parent dirs are created (`~/workspace` on a fresh Mac).
3. **Auth/hangs.** stdin null; `GIT_TERMINAL_PROMPT=0`;
   `GIT_SSH_COMMAND = <user's GIT_SSH_COMMAND | core.sshCommand | ssh> -o BatchMode=yes -o ConnectTimeout=20`
   so the user's ssh config/agent/keychain still apply. Credential helpers
   (osxkeychain) still run — non-interactive. Errors classified from stderr:
   auth / not_found / host_key / network / exists / other, each with a readable
   message plus git's last line.
4. **Progress/cancel.** `git clone --progress` (stderr, `\r`-separated).
   Parse "Receiving objects: 45% (…), 1.2 MiB | 3 MiB/s" → {phase, percent, rate}.
   Throttled like sync. Cancel: AtomicBool checked by the wait loop; git runs in
   its own process group (`process_group(0)`) so kill reaches
   git-remote-https/index-pack; then remove the target — which the clone itself
   created with `create_dir` (atomic claim: fails if it exists), so cleanup
   removes ONLY a dir this clone made. Same cleanup on any failure.
5. **Submodules:** not recursed (each is a repo-supplied URL = more auth
   prompts + hang surface; matches a plain `git clone`). If `.gitmodules`
   exists, the result says so with the command to run. Default branch = the
   remote HEAD (plain clone).
6. **After:** `add_project`, select the project, save the parent. Nothing else
   runs (ADR 0001).

**CLI:** yes — `worktrees clone <url> [--into <parent>] [--name <dir>]`, ahead
of the git guard, one core impl (`worktrees_core::clone`), progress passes
straight through to the terminal. Cheap and gives bats + the real-git tests a
non-GUI driver.

## Frontend mirror
Live preview needs the name derivation in TS (`app/src/clone.ts`). Core is the
authority; `clone-check.mjs` runs the TS function over the SAME table core's
unit test uses (parsed from clone.rs), and checks the mock's failure kinds ⊆
core's `CloneErrorKind`.

## ADR 0001 audit — verified 2026-10-03
`clone_project` → core `clone_repo` (plain `git clone`, no `--recurse-submodules`,
no `-c` from the repo) → `add_project` = `Project::discover` (git rev-parse) +
`registry::add` (JSON) + `list_workspace` → `snapshot` = `project.ls()` (git
reads), `store::read_lenient`, profiles, tmux pane list, agent probes. The only
`.worktrees.toml` read on this path is `projcfg::project_prefix` (a string).
No spawn anywhere on the path takes a string from the repository. `.git/config`
is written by the local `git clone`, never by the remote, so no repo-supplied
`core.fsmonitor`/`core.hooksPath`/filter drivers either.
