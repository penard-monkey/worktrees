# Progress

## Session 2026-09-02 (bug-fixes worktree, model fable)
- ff-merged origin/main (5 commits: v0.19.0, v0.19.1, close-outs #181 #182).
- Read mcp.rs tool table + create_worktree handler, ops.rs launch/cmd_new,
  tmux.rs helpers, valleos .mcp.json. Wrote findings.md.
- Next: discussion with David → pick first slice.
- Web research done (cross-session messaging doc, orchestrator survey) → findings.md.
- Vocabulary + Q1 (a)+(c) + orchestrator-in-main settled with David. Phase 3 complete.
- Next: agree slice 1 scope, then implement.
- Slice 1 implemented on `bug-fixes-agent-brief`:
  core/agent.rs (probe reader moved from app), AiLaunch.opener + launch_cmd
  (--name <session> + opener, claude only), cmd_new --brief → .planning/brief.md
  (+ check-ignore nag), MCP create_worktree {brief, spare=false}, place_status
  {agent_state, agents}. README row, CHANGELOG [Unreleased].
- Gates: release build fresh; make test 333 → 1 fail (test bug: KeyError on
  optional `tmux`) → fixed; mcp+new bats 62/62; core 272; cli 7; app --lib 43;
  lint clean. Uncommitted — awaiting David's go for commit+PR.
- CdV question: repo is ALREADY on the tooling (prefix cdv, 31 places, 3 live
  sessions). Not on it: `.dmux/worktrees/dmux-…` (feature/api-default-deny-auth)
  and sibling `…-design-skills` — both outside .worktrees/, so invisible to ls.
  No .mcp.json yet.
- PR #183 (slice 1) CI green → squash-merged.
- Slice 2 on `bug-fixes-strays` (stacked): model::Stray + LsJson.strays (one
  `git worktree list` spawn, shared with registrations), Code::StrayWorktree +
  stray_findings in doctor (whole-project, not config-only, not hub copy, never
  strict-promoted), profile.worktrees_mcp_mutations → args ["mcp","--mutations"],
  app: ⊟ on project row + Project sheet section with move commands, mock fixture
  (cdv has the dmux stray), ProfilesPanel checkbox. Gates: core 274, cli 7,
  app --lib 43, tsc clean, lint clean, bats full green after two test-side
  fixes (slug rule = cmd_new's `/`→`-`; physical path; relink before --strict).
- PR #184 (slice 2) CI green → squash-merged as 802a367. Both slices on main.
