# Findings

## Repo state (2026-09-02)
- bug-fixes-next fast-forwarded to origin/main @ 3372710 (#182). Latest release
  v0.19.1; installed `~/.local/bin/worktrees` is 0.19.1 → "get latest" done.

## Current MCP surface (`crates/worktrees-cli/src/mcp.rs`)
Tools: list_places, place_status, doctor, set_note, set_pin, set_lifecycle,
create_worktree, close_session, remove_worktree (confirm:true).
- `create_worktree {branch, base?}` → `ops::cmd_new(branch [base] --no-attach)`.
  No passthrough for `--no-spare`, `--ai`, `--name`, `-r`. spare_shell defaults
  TRUE in cmd_new → every MCP-created worktree gets 2 panes (AI | spare shell,
  where deps install). App passes `--no-spare` (single pane; scratch shell in dock).
- Args go through `safe_arg` (restrictive charset) — a free-text prompt could
  NOT ride through it as-is.

## tmux layout (`crates/worktrees-core/src/tmux.rs`, `ops.rs::launch`)
- pane0 = `exec $SHELL -ic '<env assigns>; claude …'` (keeps
  pane_current_command == claude for session adoption).
- pane1 (only if spare_shell) = `<install_cmd> && echo '✓ deps ready'; <keep>`.
- Only `split-window -h`, `select-pane`, `new-session`, `kill-session` exist —
  no send-keys / capture-pane helpers in core (send-keys mangles VS16/ZWJ per
  CLAUDE.md; ASCII is fine).

## valleos orchestrator setup (as of today)
- `~/workspace/valleos/.mcp.json`: `worktrees mcp --mutations` (stdio).
- Three places: communications, messaging-extraction, regression-locks.
- Nothing in valleos CLAUDE.md/ROADMAP/close-out documents the orchestrator
  role yet — it's informal so far.

## What the pattern is missing (gaps, not yet decisions)
1. Worker gets NO task: pane0 launches bare `claude`; orchestrator has no way
   to hand it a brief. (Options: `prompt` arg → appended to the AI cmd; or a
   brief FILE in the worktree the worker reads on start — file survives
   restart/resume and avoids argv-injection concerns.)
2. Orchestrator can't see worker state beyond `place_status` health. The app
   already probes `~/.claude/sessions/<pid>.json` (busy/idle, delegated) —
   not exposed over MCP. ROADMAP:45 already lists "health verdict into MCP
   place_status".
3. No channel back: no `send_to_session` (send-keys) / `read_session`
   (capture-pane). Claude Code's own ListAgents/SendMessage may cover
   session-to-session messaging natively — verify.
4. 2-pane default is wrong for an agent-created worker (David's complaint).
   Cheapest fix: `create_worktree` passes `--no-spare` (match the app) or
   takes `spare: bool` defaulting false.

## Prior art to survey (unverified, from memory — check before citing)
claude-squad, vibe-kanban, Tmux-Orchestrator, ccmanager, ruflo/claude-flow,
conductor. All tmux/worktree-per-agent shapes; none integrates with a
durable-places model like this one.

## BIG ONE: Claude Code already has session-to-session messaging (verified 2026-09-02)
`ListAgents` from this session lists every live local Claude session with its
tmux pane address, e.g. `regression-locks-55 · idle · tmux valleos-regression-locks:@6.%7`,
`communications-61 · tmux valleos-communications:@14.%16`. Names are
`<worktree-slug>-<2hex>`. `SendMessage({to: "regression-locks-55", …})` reaches it.
⇒ Gap 3 (channel to the worker) is mostly SOLVED natively — no send-keys tool
needed. What's missing is only the BRIDGE: the orchestrator learning which
session name belongs to which place (our tmux session name is right there in
the row: `<prefix>-<slug>`), plus the worker's idle/busy state, which the row
also shows. Worth confirming: does a worker see the message while it is busy /
does it wake an idle session?

## Research pass (2026-09-02, web)
### Claude Code cross-session messaging (official doc, code.claude.com/docs/en/cross-session-messaging)
- v2.1.224+, on by default, same machine = unix socket, no servers.
- Delivery: busy receiver reads it BETWEEN tool calls (never interrupts a tool);
  IDLE receiver → Claude Code starts a new turn with it. ⇒ a worker can be
  driven by messages alone.
- `notify_when_idle` (v2.1.236+): one-shot "tell me when that session goes
  idle/exits", carries a one-line status. ⇒ orchestrator can await workers
  without polling. Main conversation only, same machine only, 12h expiry.
- Names: `--name` flag or `/rename`; auto-named otherwise (`<cwd-basename>-<2hex>`
  is what we see). Duplicate live names get a variant. `@name` mentions in
  prompts. ⇒ launching pane0's claude with `--name <session>` makes addressing
  deterministic.
- Inbound controls: `crossSessionInbound` accept/hold/refuse. DEFAULT: a
  bypassPermissions receiver HOLDS messages for approval unless sender also
  bypasses; a prompting receiver delivers. `-p` workers need
  `--settings '{"crossSessionInbound":"accept"}'` to take messages unattended.
- Receiver is told the message is from another session; it can't approve
  prompts, change config, or run slash commands.
- Also exists natively: agent teams (Claude spawns+supervises), agent view
  (watch/steer many sessions), background sessions, channels (push CI etc. in).
- Socket path exported as CLAUDE_CODE_MESSAGING_SOCKET to hooks/Bash — a script
  (or OUR binary) could post into a session directly.

### Prior art (awesome-agent-orchestrators, andyrewlee)
Terminal/tmux/worktree-per-agent: amux, claude-squad (5.8k★), dmux, herdr
(working/blocked/idle status), tmux-ide. Desktop: agent-orchestrator,
Alethe, bb, Berd, Fletch, kandev (kanban steps), Paseo. Swarms: gastown
(coordinator agent + git issues, 20-30 agents), Orkas (commander>specialists),
paperclip (org chart, ticket queue). vibe-kanban: Bloop shut down Apr 2026,
community-maintained. Take: everyone does worktree-per-agent + per-agent
status; hierarchy (project > workstream > agent) is rare and mostly in swarm
tools. Nobody I saw builds on the durable-place model or on Claude's native
messaging — they all ship their own bus.
Sources: augmentcode.com/tools/open-source-agent-orchestrators,
github.com/andyrewlee/awesome-agent-orchestrators, amux.io blog, nimbalyst blog.

## Slice 1 design (2026-09-02)
- Probe file `~/.claude/sessions/<pid>.json` ALSO carries `name`
  (`communications-61`), `tmux` (`valleos-communications:@14.%16`), `sessionId`,
  `version`, `kind`, `messagingSocketPath`. ⇒ `place_status.agent` can report
  name + state + tmux target; match probe→place by `tmux` session prefix first,
  cwd second.
- New core module `agent.rs`: ClaudeProbe + busy_is_delegated + pid_alive +
  scan (moved from app lib.rs; app calls core). `AgentState` serializable.
- `AiLaunch.opener: Option<String>`; `pane0_body_for(keep, session)` appends
  ` --name '<session>'` and the opener positional ONLY when
  `ai_word_of(cmd) == "claude"` (excludes fake-ai in bats and the fail-closed
  printf). `-r` is followed by `--name` so its optional session-id never eats
  the opener.
- `cmd_new --brief <text>`: writes `<wt>/.planning/brief.md` after the
  worktree exists, warns if `git check-ignore` says it is not ignored, sets
  opener "Read .planning/brief.md and begin."
- MCP `create_worktree {branch, base?, brief?, spare?=false}` → args
  `[branch, base?, --no-attach, --no-spare unless spare, --brief text]`.
