# Task plan — orchestrator + worker agents via worktrees (discussion first)

**Goal:** work out, incrementally, how the `worktrees` CLI/MCP supports the
pattern David is using in valleos: an orchestrator Claude in the MAIN tree
(`.mcp.json` → `worktrees mcp --mutations`) that spins up worktrees, each
with its own Claude in the tmux AI pane. Don't over-build — small steps that
improve the actual daily workflow.

## Phases

| # | Phase | Status |
|---|-------|--------|
| 1 | Get latest (ff to origin/main, confirm installed CLI = latest release) | complete |
| 2 | Map the current MCP/tmux surface + what the orchestrator pattern is missing | complete |
| 3 | Discuss options with David, pick the first slice | complete |
| 4 | Slice 1: brief file + --name + single-pane MCP create + agent state in place_status | complete (uncommitted) |
| 5 | Gates + PR + close-out | PRs #183 + #184 merged; close-out pending |

## Decisions
- 2026-09-02 Vocabulary SETTLED: Project = repo; Place = workstream (kind of
  work, durable, parked on `<place>-next`); Agent = one Claude session with a
  BRIEF (1..n per place); Orchestrator = (main)'s Claude, driven by David.
- 2026-09-02 Parallelism stance: Q1 (a)+(c) — one agent per place at a time;
  more parallelism = more places, or the agent's own Claude-native helpers
  (agent teams / Agent isolation:worktree) which we SHOW but don't model.
  Door kept open to sub-places (`communications/<task>` worktrees) later.
- 2026-09-02 Orchestrator stays (main)'s Claude for a long while — the app
  does not host one. We do addressability + observability; Claude's native
  ListAgents/SendMessage/notify_when_idle is the bus (no bus of our own).
- 2026-09-02 An agent is "a Claude session launched against a brief file"
  (`.planning/brief.md` in the worktree) — the one hard rule.

## Errors Encountered
| Error | Attempt | Resolution |
|-------|---------|------------|
| `target/release/worktrees` absent in this fresh worktree | 1 | use `~/.local/bin/worktrees` (0.19.1) for probes; build before any gate |

## Model draft v0 (2026-09-02, under discussion)
Vocabulary (engineer metaphor):
- Project = the company/repo.
- Place = a WORKSTREAM (communications, messaging-extraction): a kind of work,
  durable, parked on `<place>-next`. Today: 1 worktree + 1 tmux session.
- Agent = an engineer: one Claude session with a BRIEF (the task). Today: the
  single pane-0 claude. Proposed: 1..n per place.
- Orchestrator = the lead in (main): creates places, briefs agents, gets
  notified, reads status. Uses `worktrees mcp` + Claude's native
  ListAgents/SendMessage/notify_when_idle (no bus of our own).
Open questions (see conversation): where do parallel agents in ONE place
live (shared worktree vs sub-worktrees)? what is "status" (git health vs
agent state vs brief progress)? where does the brief live?
- 2026-09-02 Slice 1 settled: brief at `.planning/brief.md`; agent `--name` =
  FULL tmux session name (`<prefix>-<slug>`); MCP `create_worktree` single-pane
  by default; `place_status` gains an `agent` block. Branch `bug-fixes-agent-brief`.

## Slice 2 candidates (2026-09-02, from the CdV adoption question)
- **Stray worktrees** (registered in git, outside `.worktrees/`): expose from
  `snapshot()` — it already runs `git worktree list --porcelain` and drops
  them — as `strays` in `ls --json` (zero extra spawns → app can badge the
  project at startup without breaking doctor's on-demand rule), AND a doctor
  finding `Code::StrayWorktree` (project-level, `place: None`) carrying the
  exact `git worktree move` remedy. Never auto-move (tmux/editors hold cwds);
  a later `worktrees adopt <path> [--name]` can wrap the move.
- **MCP registration is NOT a doctor item**: `worktrees mcp` discovers the
  project from cwd, so ONE user-scope `claude mcp add -s user worktrees --
  worktrees mcp --mutations` covers every repo. Gap found: a profile's injected
  `worktrees` server (`worktrees_mcp: true`, profile.rs:808) is READ-ONLY
  (`args: ["mcp"]`) — an orchestrator under a profile cannot create places.
  Needs a profile knob for `--mutations`.
- CdV done today: `.dmux/worktrees/dmux-1781998195357` → `.worktrees/
  api-default-deny-auth` (git worktree move; `ls` sees it). Left alone:
  sibling `casa-del-valle-monorepo-design-skills`, two unregistered leftover
  dirs in `.dmux/worktrees/` (not git worktrees; rm is David's call).
  Other projects scanned (valleos, worktrees, drone-testing, general-stuff,
  ctw): no strays.
