# Brief: FIX — rendered markdown views jump to the top when they refresh (critical)

Ian (a user), verbatim: "the rendered markdown views refresh periodically and the view port for the pane
resets to the top of the document instead of keeping place so while working on things i have to
constantly go over to the document and scroll back down to where i was looking - this is definitely
happening in the files view but maybe others". He ranks it above the nav "+" button.

## Do
1. Reproduce first, in the mock harness (off port 1420; HMR is dead in `.worktrees/` — restart vite with
   `--force` after edits; check served content, not the port). Find every surface that renders markdown
   or a file and re-fetches it: Files pane (`FilesPane.tsx`, `CodeView.tsx`, `markdown.tsx`), Docs
   (`DocsPane.tsx`), Plan (`PlanPane.tsx`), PRs (`PrsPane.tsx`), the status sheet, anything else using
   `markdown.tsx`. For each: what triggers the refresh (poll interval, fs watch, place switch, list_workspace
   re-render, a key change remounting the scroller), and does scroll survive it. Report the table.
2. Root-cause it: likely a remount (changing `key`, conditional render through a loading state, content
   replaced wholesale) or a scroller that resets on new content. Fix at the cause: an unchanged document
   must not re-render at all (compare content), and a CHANGED document keeps the viewport (preserve
   scrollTop, or better anchor to the top-visible block/heading so an edit above doesn't shift what you
   read). Also: switching tab/place and back should restore position if that's cheap (per place+path;
   don't write it into `ui-state.json` unless it's clearly worth it — that file is whole-blob).
3. Guard it: a `app/scripts/*-check.mjs` (same slice-the-real-source shape as race-check/termreplay-check)
   or harness test that fails on today's code and passes after — SHOW IT RED FIRST. Wire it into
   `make test-frontend`.
4. Verify by hand in the harness: scroll a long doc, let several refresh cycles pass (and force a content
   change), position holds; each surface in your table.

## Rules
- Read AGENTS.md first (Tauri rules: components at module scope, mock-instant timing caveat, etc.).
- Gates: all of AGENTS.md's, `cargo build --release -p worktrees-cli` FIRST; `make test-frontend` from repo root.
- CHANGELOG: one bullet under `### Fixed` in `## [Unreleased]` (create it only if absent; count headers).
- Never drive David's running app; sandbox by pid only, no scripted input. Any tmux use: `tmux -L <unique>`
  on EVERY call. Never `git worktree add`. Scratch → `~/.cache/worktrees/worktrees/md-scroll-keep/`.
- No session URLs / Claude-Session trailers; keep Co-Authored-By.
- Open a PR, SendMessage `worktrees-(main)` with the number, the surface table, root cause, gates. Don't
  merge — a fable review runs first.
