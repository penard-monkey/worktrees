# Progress

## Session 1 — 2026-08-11

- Branch `ui-next`, worktree `.worktrees/ui-tweaks`, clean at `403393d`.
- Request: persist the WORKING DIRECTORY of terminals (not history) so a
  reopened terminal lands where it was.
- Mapped the terminal stack (Explore agent + direct reads of
  `app/src-tauri/src/lib.rs`, `app/src/App.tsx`, `app/src/settings.ts`,
  `crates/worktrees-core/src/tmux.rs`). Written up in findings.md.
- Key discovery: two terminal kinds with different failure modes — dock shells
  reset on EVERY app restart (app-owned PTYs), the main tmux terminal only
  resets when tmux dies.
- Key constraint: `ui-state.json` is written whole-blob by the frontend, so the
  cwd record needs its own backend-owned file.
- Phase 0 — user chose **dock shell tabs only**, restore **any still-existing
  dir** (no place-subtree restriction). Main tmux terminal explicitly out.
- Phases 1–3 implemented, all in `app/src-tauri/src/lib.rs`:
  - `proc_cwd(pid)` — libproc on macOS, `/proc/<pid>/cwd` on Linux, `None`
    elsewhere. No new crate (`libc` was already a dep), no subprocess.
  - `shell-cwds.json` in the app config dir; `CwdMap = "repo|slug" → index →
    path`; `read_cwds_at` / `edit_cwds_at` (lock + read-modify-write, skips the
    write when nothing changed), `merge_cwds` (merge, never replace).
  - Capture: every 5th tick (~15s) of the existing 3s poll thread, plus once in
    `RunEvent::Exit` BEFORE the shell sweep.
  - Restore: `shell_open`'s spawn branch only, via `pick_start_dir`.
  - Forget: `close_shell_session` drops the tab; `remove_place` drops the place.
- Phase 4 — mock harness needs NO change: no new Tauri command, and the two
  changed signatures only gained an `AppHandle` (injected, not sent by the
  frontend). tsc clean.
- Tests: 7 added, each shown FAILING first under a deliberate mutation, then
  green (25/25 in `cargo test -p app --lib`). Includes a REAL pty test —
  `/bin/sh` spawned on a pty, told to `cd`, cwd read back by pid — because the
  other proc_cwd test would pass even if it could not follow a child.
- Gates: release CLI build (nothing in its tree changed, freshness re-checked
  against core/cli sources), `make test` exit 0 with 0 `not ok`, `make lint`
  exit 0, core 208 passed, cli 6 passed, `tsc --noEmit` clean, `cargo check -p
  app` clean.
- CHANGELOG `[Unreleased]` entry added.
- REMAINING: the real-app run (`app/scripts/sandbox.sh --app`) — GUI, needs a
  human to cd in a tab, quit, reopen. Nothing else outstanding.

### Real-app run (sandbox, `net.casadelvalle.worktrees.sbx`)

- First launch died on the documented Node trap: plain `node` here is v22.12.0,
  pnpm demands >= 22.13. Relaunched under `nvm use 22.23.2`.
- App instance pid 81800 started 23:21:07; `shell-cwds.json` written 23:21:29 —
  ~22s later, i.e. the ~15s sampler firing on a live shell, from the running
  instance. Content:
  `{"/Users/davidpena/workspace/worktrees|ui-tweaks": {"1": "/Users/davidpena"}}`
- ⇒ CAPTURE verified on the real app (isolated config dir, not the mock).
- NOT yet verified: RESTORE. Needs a quit + relaunch and a look at where tab 1
  opens. Expect `/Users/davidpena`.
- Worth a glance while testing: the recorded path is HOME, not the worktree. If
  that was not a deliberate `cd ~`, a login-shell rc is cd'ing to home and the
  memory is faithfully recording it — in which case every tab would reopen at
  home, correct by the rule but surprising.

### Review round (2026-08-12)

- 5-lens adversarial review, 19 raw findings, 1 survived two refuters:
  the reaped-pid hazard. Fixed with `live_pid()` (try_wait before sampling).
- Two dismissed findings fixed anyway — each was raised independently by 4–5
  lenses, and both are cheap:
  - "Restart shell" wiped the tab's directory (restart routes through
    `close_shell_session`). Now `forget: Option<bool>`; restart passes false.
  - `shell_open` reads the file without the writer's lock, so a plain
    `fs::write` could hand it half a document. Write is now tmp + rename.
- Test-quality findings acted on: `forget_tab` / `remembered_dir` extracted so
  tests exercise the production predicates instead of copies; unique temp dirs
  with cleanup; a test for the composition `shell_open` actually performs.
- Two self-inflicted test bugs found and fixed in the process — a pty deadlock
  (no drain) and a cleanup-before-assert. Both are written up in findings.md.
- Gates re-run after all of it: bats exit 0 / 0 `not ok`, lint 0, core 208,
  cli 6, `cargo check -p app` clean, tsc clean, `cargo test -p app --lib` 27/27
  green three consecutive runs. Both new tests shown failing under mutation.

### Fable review + follow-ups, and the active-tab feature (2026-08-12)

- Fable review of PR #122. Biggest catch was infrastructure, not the feature:
  CI never ran the app crate's tests (`build`/`check` don't compile `mod
  tests`). Added `cargo test -p app --lib` to ci.yml + the CLAUDE.md gates;
  confirmed the step ran on ubuntu, which executes the Linux `/proc` branch of
  `proc_cwd` for the first time anywhere.
- Also fixed from that review: swallowed write error in `edit_cwds`; a sampler
  race that could resurrect a just-forgotten tab; a startup sweep for places
  removed via the CLI; `forget: Option<bool>` (absent = true) renamed to
  `keep_cwd` (absent = false) with the mock asserting the key; CHANGELOG
  wording; `CWD_FILE` → `CWD_FILE_LOCK`. Two new tests, shown failing first.
- PR #122: commits 59bc83c + 893d7b1, CI green on both runners.
- NEW: active-tab memory (PR #123, branch `ui-terminal-active-tab`, stacked on
  #122 because it edits the same component). `term_tab_active` keyed
  `repo|slug`; NOT a `place_panels` field (`panelsFor` spreads into `Settings`,
  so a per-place key there needs a global, which would seed across places).
  `dropPanels` now sweeps every per-place map — `term_tab_names` had been
  leaking entries for removed places since it was added.
- Verified in the mock harness with Playwright (this feature IS expressible
  there, unlike the cwd one): add / select / leave-and-return / reload / close
  the active tab, asserting DOM and persisted settings at each step.
- Harness artifacts moved to ~/.cache/worktrees/worktrees/ui-tweaks/; vite on
  5199 stopped and the port confirmed free (two listeners had to be killed).

### Tab strip persistence (2026-08-12, folded into PR #123)

- `term_tabs`: the strip per place, keyed `repo|slug`. Restore unions it with
  live shells; names still unioned for installs predating the record.
- Only add/close write (`commitIds`); the restore never does — otherwise
  visiting a place whose session is down would persist the empty strip it
  correctly renders and lose the tabs permanently.
- Harness: three tabs with NO names, reload, all three return with the right
  one in front; closing one drops it from the record. Before: a single `sh 1`.
- PR #123 retitled — it now covers both the active tab and the strip.

### Merge (2026-08-13)

- PR #122 squash-merged as 756e567 on main.
- The stack needed a manual fix-up: `gh pr merge --squash` with the branch KEPT
  means GitHub does NOT retarget the stacked PR, and #123's history still
  carried the pre-squash commits. Rebased with
  `git rebase --onto origin/main 893d7b1 ui-terminal-active-tab`, force-pushed
  with --force-with-lease, retargeted #123 to main by hand. Diff vs main is now
  only the tab-strip work (3 files, +127/-25).
- Fable review of #123 running.

### Fable review of #123 (2026-08-13)

- HIGH, confirmed and fixed: the "restore never writes" invariant protected the
  record only until the first deliberate edit. A session-down place shows no
  tabs by design, so `commitIds` writing the VISIBLE strip meant the first
  "+ new terminal" recorded [1] over [1,2,3] — named tabs survived via the
  names union, unnamed ones (the point of the feature) did not.
  `commitIds(shown, remembered)` now separates the two; add unions, close is
  the one shrink.
- Also fixed: down→up never re-ran the restore (mount-only effect + component
  keyed on the place), so Close → Enter left an empty strip until you switched
  places. `upToken` bumps on that transition.
- MEDIUM (mostly carried by the above): those paths dropped tabs from
  `term_tabs` without telling the backend to forget the directories, so a later
  tab at a recycled index could inherit one.
- LOW: doc comment sat on the wrong function; moved.
- Verified clean by the reviewer: ref-mirroring/useCallback deps, no write on
  any restore path incl. `.catch`, settings shape, and the skipped
  SETTINGS_REV bump (new keys, no changed default — `{...DEFAULTS, ...raw}`).
- Harness now covers the session-down paths (close_place/open_place ARE
  modelled): 42e7436 on the branch.

### Four-lens review + fix (2026-08-14)

- Workflow: 4 lenses (state machine / index-as-identity / React lifecycle /
  what the mock cannot see), 19 raw findings, 1 survived two refuters.
- CONFIRMED: my `dropPanels` widening broke `removeProject`. Untracking is
  reversible and the backend keeps each tab's DIRECTORY, so sweeping the
  terminal maps destroyed half a tab's identity — losing names (a regression
  vs main) and letting a post-re-add "+" land on an index whose cwd the backend
  still had. `dropPanels` now takes the fields to sweep; only removeProject
  narrows to place_panels. Fixed by fable, verified in the harness.
- Harness lesson: the project-remove button is a TWO-CLICK arm with a 4s
  timeout, and its title CHANGES when armed — selecting on the unarmed title
  clicked a different project, and separate browser_evaluate round-trips
  exceeded the timeout. Both clicks must go in ONE evaluate with a delay
  between them; state is read in a later call.

### Merged (2026-08-14)

- PR #123 squash-merged as 1081926. Both features are on main:
  756e567 (directory memory) + 1081926 (tab strip + active tab).
- Worktree returned to `ui-next` at origin/main, clean.
- STILL UNVERIFIED IN THE REAL APP: the two features together. The mock models
  neither shells nor directories, so "a restored unnamed tab spawns in the
  directory the backend remembers for that index" has never actually run.
  `app/scripts/sandbox.sh --app` (node 22.23.2), a place with a few tabs,
  cd around, quit, relaunch.

### Release v0.13.0 (2026-08-14)

- User confirmed the real-app sandbox run before shipping — the one check the
  mock cannot express — and authorized the release.
- PR #126: CHANGELOG [Unreleased] → [0.13.0] - 2026-08-14, workspace version
  0.12.1 → 0.13.0. Gates green on the release commit (bats 0 not-ok, lint,
  core 208, cli 6, app 29, cargo check -p app, tsc).
- `make release` only tags (it verifies Cargo.toml matches and the tree is
  clean); the push is manual. Tag MUST be cut from the repo root worktree
  /Users/davidpena/workspace/worktrees, which owns `main`.

### Shipped (2026-08-14)

- PR #126 merged as 959595b; tag v0.13.0 cut from the ROOT worktree
  (/Users/davidpena/workspace/worktrees) after fast-forwarding it, and pushed.
- release.yml run 31765080192: success. All 7 jobs green — CLI x4 targets,
  signed app bundles x2 (aarch64 + x86_64 macOS), release.
- Published assets: 4 CLI binaries, 2 .app.tar.gz + their .sig, checksums.txt,
  latest.json. Not a draft, not a prerelease — the in-app updater will see it.
- Worktree back on `ui-next` at origin/main, clean.
- NOTE: the locally installed CLI is still 0.12.1 (install.sh COPIES; it does
  not follow the repo). Update via the app's Settings → Version or by
  re-running install.sh.
