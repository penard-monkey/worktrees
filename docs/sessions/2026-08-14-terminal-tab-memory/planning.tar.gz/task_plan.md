# Task plan — persist terminal working directory

## Goal

A DOCK SHELL TAB reopens in the directory it was last in, not the place root.
History NOT persisted. Main tmux terminal is OUT of scope (decided Phase 0) —
tmux already keeps its pane cwd while the server lives, and changing
`new-session -c` would mean a core change shared with the CLI.

## Context (verified 2026-08-11, see findings.md for file:line)

Two kinds of terminal in the app:

| Terminal | Backend | Survives app restart? | cwd today |
|---|---|---|---|
| Main place terminal | PTY wrapping `tmux attach` | YES (tmux server owns it) | fixed at `new-session -c <place_dir>`; tmux keeps it while the server lives |
| Dock shell tabs (Terminal tab, ⌘⇧T) | app-owned PTY, login shell | NO — die with the app | `cmd.cwd(place_dir)` on every spawn |

So the everyday loss is the DOCK SHELLS: every app restart resets each tab to
the place root. The main terminal only resets when tmux itself goes away
(reboot, `Close` → `Enter`).

Nothing in the repo records a per-terminal cwd today.

## Phases

### Phase 0 — scope + shape decisions — `complete`
- [x] Map the terminal stack (done, findings.md)
- [x] Ask: dock shells only, or main tmux session too? → **dock shells only**
- [x] Ask: restore any existing dir, or only inside the place? → **any existing dir**
- Decided: separate backend-owned `shell-cwds.json`, NOT ui-state.json
  (frontend writes that file whole-blob; a backend write would be clobbered).

### Phase 1 — read a live shell's cwd — `complete`
- [x] `fn proc_cwd(pid: u32) -> Option<PathBuf>`
  - macOS: `libc::proc_pidinfo(PROC_PIDVNODEPATHINFO)` → `pvi_cdir.vip_path`
    (`libc` is ALREADY a dep — no new crate). Verify the struct/const are
    exposed by libc 0.2 for apple before committing to it.
  - Linux: `std::fs::read_link("/proc/<pid>/cwd")`
  - other: `None`
- [x] Unit test: cwd of our own process ⇒ matches `std::env::current_dir`

### Phase 2 — capture + persist — `complete`
- [x] `shell-cwds.json` in app config dir: `{ "<repo>|<slug>": { "<index>": "/abs/path" } }`
- [x] Background ticker (~20s): sample every live shell, write only on change
- [x] Also sample+write in `RunEvent::Exit`, BEFORE the existing `kill_shell` sweep
- [x] `close_shell_session` prunes that tab's entry (mirrors how a closed tab
      drops its name)

### Phase 3 — restore — `complete`
- [x] `shell_open` (spawn branch only, not re-attach): saved path → use if it
      still exists and is a dir; else fall back to `place_dir`. No subtree
      restriction — a saved `~/` is restored as `~/`.
- [x] NOT doing: main tmux session / `new-session -c`. Out of scope.

### Phase 4 — mock + tests — `complete`
- [x] Mock needs NO change — no new command; `close_shell_session`/`remove_place`
      only gained an injected `AppHandle`, invisible to the frontend's invoke
- [x] Rust tests: 7 added, incl. a REAL pty `cd` and file round-trip/prune/corrupt
- [x] Each shown FAILING first under a deliberate mutation, then reverted

### Phase 5 — gates + real-app verification — `complete`
- [x] All green: release build (deps unchanged, freshness re-checked), `make test`
      exit 0 / 0 `not ok`, `make lint` exit 0, core 208, cli 6, tsc clean,
      `cargo check -p app` clean, `cargo test -p app --lib` 25/25
- [x] REAL app run (sandbox): capture verified from the log+file timing, restore
      confirmed by the user on 2026-08-11.
- [x] CHANGELOG `[Unreleased]`

## Errors encountered

| Error | Attempt | Resolution |
|---|---|---|
| — | — | — |

### Phase 6 — review + land — `complete` (#122 merged as 756e567)
- [x] Adversarial review: 1 confirmed defect fixed (reaped pid), 2 near-misses
      fixed anyway (restart forgetting, non-atomic write), test quality raised
- [x] Commit + PR #122 (branch `ui-terminal-cwd`, rebased onto origin/main
      after #121 landed; gates re-run post-rebase, all green)
- [ ] Tear down the sandbox (`app/scripts/sandbox.sh --clean`) once done with it

### Phase 7 — terminal tab strip + active tab memory — `complete` (merged)
- [x] `term_tab_active` in ui-state.json, keyed `repo|slug`
- [x] Restore honours it; falls back to the first tab without overwriting
- [x] `dropPanels` sweeps every per-place map (fixes a `term_tab_names` leak)
- [x] Playwright harness run over all five paths
- [x] `term_tabs` — the strip survives a restart whether or not tabs are named
- [x] Merged as 1081926 after four review rounds
