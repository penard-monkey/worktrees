# Findings — terminal cwd persistence

Verified 2026-08-11 by reading the files (agent map + direct reads).

## Where terminals live

### Main place terminal (tmux)
- Created ONCE: `crates/worktrees-core/src/tmux.rs:220-232`
  `new-session -d -s <session> -c <wt> -P -F '#{pane_id}' <pane0>` — `-c wt` is
  the only cwd tmux is ever told, and `wt = p.place_dir(slug)`.
- Called from the single site `crates/worktrees-core/src/ops.rs:211` inside
  `launch()` (`ops.rs:153-273`).
- App attaches via PTY: `app/src-tauri/src/lib.rs:2780-2782`
  (`tmux -u attach-session -t <session>`) — attach cannot set a cwd.
- Frontend: `<TerminalPane key={selected.tmux_session.name} …>` `App.tsx:2980`.
- ⇒ cwd already survives app restarts (tmux server holds the pane). Lost only
  when tmux dies (reboot) or the place is Closed and re-Entered.

### Dock shell tabs (the everyday case)
- `shell_open` `lib.rs:2927-3028`. Spawn block `lib.rs:2970-2977`:
  `SHELL -l`, `cmd.cwd(&cwd)`, `TERM=xterm-256color`.
- `cwd` from `place_session_cwd(repo, slug)` `lib.rs:2673-2681` → `place_dir`.
  The webview NEVER supplies a path (deliberate, documented there) — so a
  restored cwd must be resolved backend-side, not passed in from React.
- Registry `Shells(Mutex<HashMap<(repo,slug,index), Shell>>)` `lib.rs:2888-2891`;
  `Shell.child` `lib.rs:2871` is the login shell ⇒ its pid is the cwd to read.
- Re-attach branch `lib.rs:2940-2955` replays the ring, bumps `gen` — must NOT
  touch cwd (process already running).
- Death sweep on quit: `RunEvent::Exit` at `lib.rs:3318-3327` kills every shell.
  This is the natural last-chance capture point.
- `list_shell_sessions` `lib.rs:2695-2705` → `ShellTab {index, dead}`.
- `close_shell_session` `lib.rs:2708-2712` → `kill_shell`.
- Frontend `TerminalTabs` `App.tsx:684-830`: tabs only, no splits; only the
  ACTIVE tab is mounted (`App.tsx:817-818`), inactive shells keep running.

## What is persisted today
- `ui-state.json` (app config dir) — `lib.rs:471-475`, `get_settings`
  `lib.rs:491-498`, `set_settings` `lib.rs:500-505`. **Free-form JSON, written
  WHOLE-BLOB by the frontend.** Any backend write into it is clobbered by the
  next frontend save ⇒ cwd must live in its own file.
- `term_tab_names: Record<"repo|slug", Record<number, string>>` `settings.ts:97-101`
  — the precedent: only the NAME outlives the process, "closing a tab drops its
  name" (`closeTab` `App.tsx:777-784`).
- `.worktrees.places.json` (`crates/worktrees-core/src/store.rs`) — per-place
  declared state (lifecycle/pin/note/title/epochs/profile + `extra` flatten).
  Per-tab cwd does NOT belong here: it is app-UI state, not place lifecycle,
  and the CLI has no dock shells.

## Nothing records a cwd today
- `pane_current_path` appears exactly once: `tmux.rs:144`, the `list-panes -a -F`
  format used for ADOPTION matching (`session_in` `tmux.rs:178-206`).
- `display-message -p '#{pane_current_path}'` — absent from the repo.

## Reading a process cwd
- `libc = "0.2"` is ALREADY an app dep (`app/src-tauri/Cargo.toml`, added for
  `kill(pid,0)` liveness probes). No new crate needed if
  `proc_pidinfo`/`PROC_PIDVNODEPATHINFO`/`proc_vnodepathinfo` are exposed for
  apple — VERIFY before building on it.
- Rejected: `lsof -a -d cwd -p <pid>` — a subprocess per sample, ~100ms, and
  this repo counts spawns deliberately (`spawn-count.sh`).
- Rejected: OSC 7 shell integration — macOS `/etc/zshrc` only emits it when
  `TERM_PROGRAM == Apple_Terminal`; making it fire would mean lying about
  `TERM_PROGRAM` or editing the user's rc files.

## Risks
- **Main-terminal restore changes what "Enter" means.** Today Enter always puts
  you at the place root. Feeding a recorded cwd into `new-session -c` makes a
  fresh session inherit a stale location — and `launch()` is CORE, shared with
  the CLI, so the CLI would need the same record or the two diverge.
- Stale/deleted dirs: always stat before use, fall back to `place_dir`.
- The mock harness answers instantly and models no cwd — per CLAUDE.md, three
  v0.12.x bugs lived exactly in what the mock cannot express. Real-app run is
  mandatory here.

## Post-review discoveries (2026-08-12)

- **`Child::kill()` in portable-pty sends SIGHUP, not SIGKILL**
  (`portable-pty-0.9.0/src/lib.rs:347`). An interactive `/bin/sh` on a pty whose
  master is still open survives it. The app is fine — `kill_shell` drops the
  `Shell`, which closes the master, and the EOF finishes the job — but any test
  that holds the master open and then waits will hang forever.
- **A pty test MUST drain the master.** Without a reader the shell's output
  fills the pty buffer and the child WEDGES MID-EXIT: `ps` shows state `E`,
  it is never reaped, and even SIGKILL + `wait()` blocks (observed: `wait4`
  stuck >10 min). Production never hits this because `shell_open` always spawns
  a reader thread. Tests now call a `drain()` helper.
- **`Child::process_id()` keeps returning a reaped pid.** portable-pty's impl
  for `std::process::Child` is `Some(self.id())`, unconditional. Since
  `list_shell_sessions` calls `try_wait()` (which reaps) on every dock mount,
  sampling by pid alone would eventually read an unrelated process's cwd after
  pid wraparound. Hence `live_pid()`.
