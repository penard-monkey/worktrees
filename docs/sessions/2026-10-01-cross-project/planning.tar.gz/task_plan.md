# Task plan — cross-project reach (proposal only)

## Goal
Write `docs/proposals/cross-project.md` + a row in `docs/proposals/index.md`: how an agent
reaches places in OTHER projects (see, message, mutate, drag-drop reference). ONE docs-only
PR, then STOP for a fable review. No implementation, no merge.

## Phases
### Phase 1 — map the restriction — complete
- [x] mcp.rs: pin at startup, caller_place, known_slug, place_index, instructions, managed
- [x] messages: per git-common-dir log, file name carries hex(to)
- [x] app: projects.json (plain array of main roots), list_workspace fan-out
- [x] drag-drop: App.tsx resolveDrop rejects foreign repo; drop_reference + mention.rs token
- [x] probe: release binary 0.34.1, two scratch repos — foreign slug = "no such place"

### Phase 2 — remaining evidence — complete
- [x] CLI main.rs git guard (does any command run outside a repo?)
- [x] tmux session-name collisions across projects (prefix = basename by default)
- [x] Claude SendMessage across projects (ListAgents scope) — source/observation
- [ ] resources/templates in Claude Code @-menu — NOT verified; deferred to P4
- [x] cost: time `worktrees ls --json` on a few real projects (read only)
- [x] trust/protect-ours, hub-copy refusal per target project

### Phase 3 — write the proposal — complete
- [x] Sections: answer-in-one-screen, map, registry, addressing, messaging, safety,
      drag & drop (user asked 2026-10-01), guidance+UI, cost, phased plan, open questions
- [x] Public-docs scrub: no home paths, usernames, real project names

### Phase 4 — PR — complete (#395)
- [x] index row, branch `cross-project-proposal`, commit (Co-Authored-By, no session URL)
- [x] push, open PR, confirm docs-only (no CI by design), STOP

## Decisions
- Drag & drop is an explicit section + its own phase item (user request).

## Errors
(none yet)

## BUILD phases (2026-10-01, David: build P0–P4)
- [x] P0 registry — PR #397 merged
- [x] P1a — PR #402 merged
      + mcp.rs managed(): a repo in the registry is managed (§2.2; review of #397 item 7)
- [x] P1b — PR #404 merged — Settings/private UI + offers card + drag-drop (Claude/Codex/pi, waiting refusal)
      + SKILL.md 'Across projects' section (§9) — deferred from P1a: it bumps guidance VERSION → offer
      + app doctor sweep: name `nested-project` (and `prefix-collision`) in remedies() like stray-worktree, not `manual` (review of #397 item 6)
- [x] P2 — PR #405 merged — cross-project messages (reply_to vs sender log; Codex write guarded; manual check doc)
- [x] P3 — PR #406 merged — opt-in mutations (remove_worktree NEVER)
- [x] P4 — PR #407 — @-mentions + P3 follow-ups
Rule: fresh branch off origin/main after previous merges; never stack. Coordinate with #358 (quota gate).
