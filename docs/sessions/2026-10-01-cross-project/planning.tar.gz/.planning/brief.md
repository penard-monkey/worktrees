# Research + plan: let an agent reach places in OTHER projects (remove the one-project restriction)

## What David wants (2026-10-01)
Today a session can only reference worktrees/places of its OWN project: the `worktrees mcp`
server (crates/worktrees-cli/src/mcp.rs) discovers ONE project from its cwd
(`Project::discover(&root)` ~mcp.rs:673) and every tool — list_places, place_status, send,
report/messages/wait, create_worktree, remove_worktree, set_*, run_automation — is scoped to it.
David wants to REMOVE that restriction: e.g. the orchestrator in worktrees' `(main)` should be able
to see and talk to a lane in `valleos`, and lanes across projects should be able to message each
other. This lane INVESTIGATES and PLANS — a proposal, then stop. No implementation.

## Deliverable
`docs/proposals/cross-project.md` + a row in `docs/proposals/index.md`, ONE docs-only PR, then
STOP (a fable review precedes any build). House style: `docs/proposals/pi-harness.md`,
`agent-guidance.md` — mark [observed]/[source]/[inferred], end with a phased plan and crisp open
questions for David. docs/ is public (GitHub Pages): no usernames, home paths, private hosts, real
project names from his machine beyond generic examples.

## Questions to answer (with evidence)
1. **Where the restriction lives.** Map every place the single project is assumed: mcp.rs (discover,
   `caller_place`, `place_index`, the place-aware instructions from #385, the managed check), core
   (`worktrees_core::messages` log lives in each repo's GIT COMMON DIR — so messages are per-repo
   by storage), activity/place_status readers, `send`'s ownership checks, the CLI (`worktrees`
   commands run in a repo), the app (it already holds MANY projects: `projects.json` in the app
   config dir, `list_workspace` in app/src-tauri/src/lib.rs ~447-468 — what can core/CLI see of
   that list today?). Note which pieces are "one project by design" vs by accident.
2. **The project registry.** How would the CLI/MCP know the set of projects? Options: read the app's
   `projects.json` (owned by the app — read-only rule like ui-state.json?), a new user-scope registry
   in `~/.config/worktrees/`, discovery from places' git common dirs, or explicit `project` args only.
   Which is the single source of truth, and how does it stay in sync with the app?
3. **Addressing.** How a tool names a place in another project (`project:slug`? a project id? a
   path?), backwards compatibility (a bare `slug` keeps meaning "my project"), ambiguity, and what
   `list_places` returns (all projects? opt-in?). Tool descriptions are FROZEN in some clients at
   connect time (AGENTS.md: Claude keeps old tool definitions across /mcp reconnect) — design so new
   capability arrives via new params/tools or results, not silently changed old ones.
4. **Messaging across projects.** The message log is per git common dir. Cross-project
   report/messages/wait needs either a shared log (user-scope?) or routing to the target repo's log.
   `from` identity must stay server-derived (never caller-supplied) — say how a cross-project `from`
   is expressed. Claude↔Claude can already use Claude's own SendMessage across sessions — how does
   that interact?
5. **Safety / permissions.** Today `--mutations` gates destructive tools per server. Cross-project
   reach widens blast radius: should mutations across projects (create/remove/send into another
   repo's lane) need a separate opt-in, a per-project allowance, or `confirm: true` + naming the
   project? ADR 0001 (a repo never supplies argv) — any new path where repo A's content influences
   actions in repo B? Trust (pi trust, protect-ours) per target project. Private repos: is listing
   another project's place names/branches a leak to an agent working in a different client's repo?
   Propose a default (likely: read-only cross-project visibility on, mutations opt-in) and justify.
6. **Agent guidance + UI.** What the MCP instructions/skill (#385/#393) must say about other
   projects; whether the app needs anything (e.g. showing cross-project messages, a setting).
7. **Cost.** A workspace-wide `list_places` = git/tmux fan-out over every project (the app's
   `list_workspace` takes seconds) — caching, lazy per-project, or summary-only.
8. **Phased plan** (e.g. P1 read-only visibility + addressing, P2 cross-project messaging, P3
   cross-project mutations behind opt-in), each with the files it touches and tests (bats with
   two scratch repos), and how it is verified end to end in the real app (docs/adding-a-harness.md's
   lesson: "core reports it" ≠ "the user sees it").

## How to investigate
- Read the code; run the real release binary's `worktrees mcp` over stdio in THROWAWAY repos to
  observe behaviour (two scratch repos to show the restriction). For any scratch checkout of THIS
  repo use a worktrees place (`worktrees new <name> --no-spare --no-attach`, then `worktrees rm` +
  delete its branch) — NEVER `git worktree add` into /tmp. Scratch files in
  ~/.cache/worktrees/worktrees/<this worktree>/.
- READ the app's projects.json / ui-state.json if needed, never write them. Never write
  ~/.claude.json, ~/.codex, ~/.pi config. Do not drive David's running app.
- Codex is out of tokens — no Codex sessions.
- Do not merge. Keep Co-Authored-By; NO session URLs or Claude-Session trailers.
