# Progress

## 2026-10-01
- Read brief; branch cross-project at origin/main (17c240a), 0/0.
- Mapped mcp.rs, messages.rs, app projects.json/list_workspace, drag-drop path.
- Probe with release 0.34.1 in ~/.cache/worktrees/worktrees/cross-project/probe (alpha/beta):
  restriction confirmed.
- User asked mid-session: include drag and drop in the plan; use planning-with-files.
- Cost measured: 9 projects / 101 places, full ls 2.2s serial, worktree list ~130ms total.
- ListAgents observed: Claude sessions across 4 projects visible (names not reproduced).
- Wrote docs/proposals/cross-project.md (+ index row), incl. §6 drag and drop.
- Branch cross-project-proposal, PR #395 opened (docs-only). STOP for fable review.
- Fable review (via worktrees-(main)): applied M1–M3 + nice-to-haves, recorded David's decisions
  (reach off by default + offer; private bare row; core registry union-merge; drop in all 3
  harnesses). Pushed b4ae5e3 to #395, replied to reviewer. Not merged. STOP.

## 2026-10-01 — BUILD (P0..P4, one PR per phase, wait for review between)
- #395 merged (98a9203). P0 on branch cross-project-p0-registry → PR #397, CI run 36939608937.
  registry.rs + `worktrees projects` + app via core + nested-project doctor + cross_project user-only.
  Red-first: bats 9/9 red on 0.34.1; lock test red without lock; import test red without seen-check.
  Gates green; ls --json identical. Real-app migration NOT run (sandbox window would steal focus).
- #397 merged. P1a on cross-project-p1a-resolver → PR #402, CI run 36944386875.
  Session was interrupted (another lane killed the tmux server; gate run died 137); resumed,
  rebased on #401, re-ran all gates green. New rule: throwaway tmux = `tmux -L <name>` always.
- #402 review: fixed stale nested root resolving into enclosing (private) project; no paths below
  full (strip_paths by value); wait echoes address; doctor names without roots/private. fd60cfa,
  CI 36946657935 green. Reported; waiting for merge → P1b.
- #402 merged. P1b on cross-project-p1b-ui → PR #404, CI run 36949468711. Settings section, offer,
  SKILL+VERSION 3, plan_drop/mentionPlan + drop-check, drop into Codex/pi (waiting refused),
  drop_reference reads RECEIVING sidecar, remedies registry bucket, manual-check doc.
  Mock driven in Chromium + WebKit (pw/drive.mjs in cache) — all good.
  Slip: a python slice with reversed bounds inserted the new drop_reference at the top of lib.rs;
  caught by cargo check (duplicate fn), repaired before any commit.
- #404 merged. P2 on cross-project-p2-messages → PR #405, CI run 36952168051. report to
  <project>:<slug> at read; post_into (reply_to vs sender log; red on old check, bats+unit);
  hub-copy per target; named sandbox refusal; Q8 in manual-check doc; P1b nits 1-7 folded in.
- #405 merged. P3 on cross-project-p3-mutations → PR #406, CI run 36955334301. mutable_target
  gate (full + --mutations, hub copy per target), send/close/set_*/create(project)/show_doc;
  remove never. Found + fixed pre-existing MCP stdout pollution by git output (red on 0.34.1).
- #406 merged. P4 on cross-project-p4-mentions → PR #407, CI run 36957541931. P3 follow-ups:
  brief provenance header, private re-read per write, Proj::Here borrow, other_project wording,
  send/in-run/pi-trust tests, hermetic send unit. P4: foreign resources list/read/templates,
  watcher roots; drag keeps address (ROADMAP).
- #407 review: foreign_project() = one fresh-consent resolution for all foreign paths (report/reads
  included); connect 11→5 git spawns, list 20→12, read 23→13. 29b9600 CI green. Reported. P0–P4 done
  pending the last merge. Owed: real-app checks in docs/cross-project-manual-checks.md.
