# Findings

## Where the one-project assumption lives [source @17c240a]
- mcp.rs module note: "The repo is pinned at startup ... No tool takes a repo path" — BY DESIGN (safety).
- cmd_mcp (~657): root = CLAUDE_PROJECT_DIR (claude only, trusts_claude_project_dir) or cwd;
  Project::discover once; Server.project: Option<Project>.
- caller_place (~1909): deepest place of THE project containing `here` → `from`.
- known_slug (~2118): slug must be in self.proj().ls() — full ls fan-out per call (cost!).
- place_status: ls() then find; report/messages/wait/send: messages::dir(project.git_common).
- show_doc: canonical path must be under project main_root ("outside this repository").
- resources/list: uri_map(place_index) → `place://<slug>`; watcher polls ONE wt_root + sidecar.
- instructions: role_line names `{root}`; MESSAGE_NOTE says "another place of this project".
- managed(): guidance::is_managed — `.worktrees.toml` or registered place; comment says
  "the app's project list is not readable from here".
- send: tmux session = project.session_name(slug) = `<prefix>-<slug>`; ownership check is
  "sessions this project owns".
- HIDDEN_IN_RUN gates send/remove inside automation runs.
- hub_copy_refusal keyed on self project's main_root — would need TARGET project.

## Messages [source messages.rs]
- `<git-common>/worktrees-messages/<id>.<hex(to)>.json`, read markers `.read/<hex(to)>/<id>`.
- from/to are bare slugs; MAX_COUNT 500 per project, 7d age; prune on write.
- No $HOME needed (sandboxed agents reach it) — a user-scope shared log would lose that.

## App [source lib.rs]
- projects.json in app config dir: JSON array of canonical main roots, order = nav order.
  Written by add_project/remove_project/reorder. Core/CLI never read it.
- list_workspace: snapshot() per project, chunks of 4 in parallel.
- core user config lives in $XDG_CONFIG_HOME/worktrees (~/.config/worktrees): config.toml,
  profiles.json, skills.json — precedent for a user-scope registry the CLI owns.

## Drag & drop [source App.tsx ~5445-5600, lib.rs drop_reference, mention.rs]
- Dropping a place onto the terminal = `mention` target, Claude panes only
  (TerminalPane drop={provider==="claude" ? "mention" : undefined}).
- Foreign project → reject with hint "a session can only reference worktrees from its own
  project" — comment cites the pinned MCP server: token would be dead text.
- drop_reference: Project::discover(repo of DRAGGED place), uri_for(places, slug),
  server_name_for(repo, into_slug, ~/.claude.json) — NOTE uses the dragged repo for the
  profile stamp of the TARGET slug; fine today only because repo==sel.repo. Must split
  into source repo / target repo for cross-project.
- token = `@<server>:place://<slug>`; client matches by exact uri in cached resources/list.
- Tier zone drop across projects: "a worktree belongs to its project" — stays (moving a
  worktree between repos is meaningless).

## Probe [observed, worktrees 0.34.1, scratch repos alpha/beta]
- list_places in alpha lane: ["(main)","alpha-lane"] only.
- place_status beta-lane / report to beta-lane from alpha: "no such place: beta-lane".
- abs path of beta as slug: "no such place: <path>".
- report to (main) lands in alpha/.git/worktrees-messages only; beta's log empty.

## Identity
- session name `<prefix>-<slug>`, prefix default = basename(main_root) (resolve_prefix):
  two projects with the same basename collide in tmux & claude --name.
