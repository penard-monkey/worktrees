# Progress
- 2026-10-06: fix written (launch_watched), tests red on old shape (3/4; long-runner passes both ways by design), green after. Committed on in-app-editor-cmd-errors (2620514).
- Proposal written: docs/proposals/in-app-editor.md + index row. Uncommitted, goes on in-app-editor-proposal off origin/main.
- Gates running (logs in ~/.cache/worktrees/worktrees/in-app-editor/*.log).
- PRs: #443 (fix + editor picker added at (main)'s request; CI green on 7573a77), #444 (proposal). Reported to (main). Terminal picker skipped (reasons in PR).
- CI flake seen: core codex_usage fake_cli_auth_... on ubuntu, first run only.
- #443 squash-merged as 3d48e06 by (main). #444 open, waiting for David's §9 answers via (main); not closing out.
