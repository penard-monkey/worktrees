# Findings

## Editor button
- open_editor/open_terminal spawned sh and reaped blind; `code` missing → exit 127, silent.
- Fixed with `launch_watched` (1.5s grace; non-zero exit inside it → Err; 127/126 special-cased).

## Existing editor (already in FilesPane, #56 / #306)
- Markdown Source view only = `<textarea>` (SourceEditor), ⌘S, md toolbar via execCommand (keeps undo).
- Drafts in a module store (survive unmount/place switch, NOT reload). `base` mtime → write_file CAS.
- Save refused → "save refused" tag + Discard + Overwrite (force).
- write_file: guard_under_projects (ANY registered project, not the place), file must exist, tmp `.{base}.wt-tmp` (fixed name, no pid), perms copied, rename onto CANONICAL target (writes through symlinks).
- read_file: 1 MiB cap, NUL → binary, `from_utf8_lossy` (non-UTF-8 would be corrupted on save).
- textarea normalises CRLF→LF (measured in WebKit) → existing md editor rewrites CRLF files to LF on save. Latent bug.
- places:changed fires on tmux fingerprint change or every 30s → the only re-read trigger. No fs watcher crate.
- CodeBlock renders every line (no virtualisation).
- Tree right-click: rows only (no empty space), CtxMenu; Reveal/Open/Copy path.

## Measurements (esbuild --minify, ESM, scratch ~/.cache/.../bundle)
- CM6 minimal (state+view+commands: line numbers, history, keymaps): 289 KB / 94 KB gz
- + search + language (StreamLanguage, HighlightStyle, folding): 324 KB / 105 KB gz
- + 6 lezer langs (md, js/ts, rust, python, css, json): 684 KB / 238 KB gz
- basicSetup + 7 langs: 741 KB / 256 KB gz
- Monaco 0.57 core API, no languages: 2.72 MB JS + 91 KB CSS (701 KB gz) + editor worker 307 KB. node_modules 102 MB.
- CM6 6.43 MIT; Monaco MIT.
- CM6 in Playwright WebKit 2359 + Chromium: 3.66 MB / 60k-line doc mounts 22 ms, 67 DOM lines; typing, Tab (indent), undo OK.
- highlight.ts tokenizeLines 1 MB: 38–76 ms (ts, rust). ~3.6 KB gz.
