# Task plan: in-app editor (investigation) + editor-command error fix

## Goal
1. Small code PR: surface a failed `open_editor` / `open_terminal` command.
2. Docs PR: `docs/proposals/in-app-editor.md` — editor design, new-file from tree, phases, open questions.
3. Report both PR numbers to (main) via SendMessage. Do not merge.

## Phases
- [x] 1. Read open_editor/open_terminal, design the failure rule
- [x] 2. Implement fix + failing-first test + CHANGELOG
- [x] 3. Gates, PR #1
- [x] 4. Investigate FilesPane / tree / highlight / keyboard / security
- [x] 5. Bundle-size measurements (CM6, Monaco) in ~/.cache scratch
- [x] 6. Proposal PR #444
- [x] 7. Report to orchestrator

## Errors
