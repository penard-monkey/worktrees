# Findings

Orfis handoff/source pinned initially to 1614c67f9780f65cd1bcaeb9ff2e2b3cdb084e61.
SDK lacks device override, lifecycle hooks, and truthful memory-only queue copy.
Outbox write can shed new entry then return true (false queued); reported to main.
Need upstream fixes, not edits to Orfis from this Place. Production key/URL and
packaged origin absent; no real report or production provisioning authorized.
Node pin 22.23 unavailable locally (22.22.3 installed); pnpm 11.5.2 installed lockfile.
