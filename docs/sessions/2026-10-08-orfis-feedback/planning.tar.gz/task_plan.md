# Orfis integration

- [x] Read brief, handoff, SDK/widget/outbox/schema, repository rules and ADR.
- [ ] Pin SDK bundle with regeneration/provenance; report upstream safety gaps.
- [ ] Implement startup singleton, offline mock, Settings action, Escape/focus/theme bridge.
- [ ] Add behavioral regression checks and prove failures with mutations.
- [ ] Run required gates and browser checks; attempt isolated native validation.
- [ ] Document shipping dependencies and report reviewable result to main.

Working assumptions: Settings > Data & Logs; no diagnostic capture/log attachments;
build-time public routing configuration; no automatic identifiers or work content;
main-window startup retries; production configuration absent means disabled.
