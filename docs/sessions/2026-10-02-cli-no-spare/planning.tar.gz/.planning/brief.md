# Brief: the CLI stops opening a spare shell pane by default

## Why
`worktrees new` and `worktrees open` split the tmux session into an AI pane plus a "spare shell" pane (pane 1) unless `--no-spare` is passed. The app passes `--no-spare`, the MCP `create_worktree` tool defaults to it, and David says he barely uses the spare pane. It bit today: mac-utilities' orchestrator ran `worktrees new gif-stickers main --ai codex --model … --brief …` through the CLI, and the Codex lane opened with an idle zsh taking half the width. Our own skill (`crates/worktrees-core/src/guidance/SKILL.md:29`) tells agents to run exactly that command with no `--no-spare`.

**Decision (David): single pane is the CLI default.**

## What to change
1. **`crates/worktrees-core/src/ops.rs`**
   - `cmd_new` (~line 591) and `cmd_open` (~line 975): change the default to `spare_shell = false`.
   - Add a `--spare` flag that opts IN.
   - Keep `--no-spare` accepted as a no-op, because the app, scripts, briefs and older docs pass it. If both flags are given, the last one wins.
   - Update the comments that say "Default keeps the CLI's spare shell".
2. **The install command.** Today it only ever runs in the spare pane. With no spare it is echoed as `then: <install_cmd>` (~line 856), and that stays the behaviour: the default now prints the hint, and `--spare` runs it in pane 1 as before. Check the `--no-install` and `--no-tmux` interplay still reads right. Make sure the message is clear for a person who used to get auto-install.
3. **MCP `create_worktree`** (`crates/worktrees-cli/src/mcp.rs` ~1845):
   - `spare: true` must now push `--spare`. Today it pushes nothing and relies on the old default, so this would SILENTLY break.
   - Absent and `false` both stay single-pane. Pushing nothing is fine, but keep it explicit if that reads better.
   - Do NOT change the tool's schema or description beyond what's true. The client tool definitions are frozen; only add optional params, never change existing ones.
   - Check the cross-project create path too.
4. **The app** (`app/src-tauri/src/lib.rs` ~1200, ~1296) can keep passing `--no-spare`. It's harmless; leave it unless removing it is cleaner. Make sure nothing in the app relied on the old default.
5. **CLI help/usage text, README.md, docs** that describe the spare shell or `--no-spare`: update them to describe `--spare`.
6. **The skill** (`crates/worktrees-core/src/guidance/SKILL.md`): make the CLI lane line read correctly under the new default. Add `--no-attach` where an agent launches a lane, since an agent should never attach.
   - Check what #411's editable-guidance machinery needs when the bundled SKILL.md changes: the `SKILL.base.json` / VERSION mechanism in `guidance.rs`.
   - Bump whatever must be bumped so users with an edited copy get the "default changed" diff, and so the tests pass. Read `guidance.rs` first.
   - Also check `guidance.rs:35`/`:845` (the MCP instructions head is capped at 244 chars; don't push it over).
7. **Tests.**
   - `test/new.bats`, `test/open.bats`, `test/mcp.bats`, `test/close.bats` and `test/pi.bats` assert spare behaviour. Update them to the new default.
   - Add cases for: the default is single-pane; `--spare` splits and runs the install command in pane 1; `--no-spare` is still accepted; MCP `spare: true` splits.
   - Show at least the MCP `spare: true` case FAILS before your mcp.rs fix (AGENTS.md "a new test must be shown to fail first").
8. **CHANGELOG**: under `## [Unreleased]`, add a `### Changed` entry. v0.36.0 was just released, so `[Unreleased]` is likely empty; open the subsection. Count headings afterwards: one `[Unreleased]`, and one of each `###`.

## Gates (AGENTS.md; run from the place root with `make -C`)
1. `git submodule update --init --recursive`, then `cargo build --release -p worktrees-cli` FIRST.
2. Run `make test` and check the plan line and the `not ok` count. Then run `make lint` and `cargo test` for each of `-p worktrees-core`, `-p worktrees-cli` and `-p app --lib`; report the cargo runs with a grep, not a tail.
3. For the frontend: `nvm use`, then `corepack pnpm install` in app/. Then run tsc and `make -C <root> test-frontend`.
4. Run `ls --json` and check it is byte-identical to `~/.local/bin/worktrees` (this change shouldn't move it).
5. **End-to-end with the release binary in a SCRATCH repo:** `new` with no flag → 1 pane; `--spare` → 2 panes; `open` likewise.
   - This needs real tmux, so use **`tmux -L <unique-name>` on EVERY call, including kill-server. NEVER run a bare `tmux kill-server`.** `TMUX_TMPDIR` is not isolation inside a lane. On 2026-10-01 a lane killed David's whole tmux server that way.
   - If the binary talks to tmux without `-L`, run it with `env -u TMUX` plus a dedicated `TMUX_TMPDIR` socket dir. Verify with `tmux -L`/`-S` that you are inspecting YOUR server, never the user's.
   - For the scratch repo, use a `worktrees new <name> --ai none --no-spare --no-attach` place, or a plain dir under your cache dir (`~/.cache/worktrees/worktrees/cli-no-spare/`). Never use `git worktree add`.

## Finish
- Open a PR. Its body explains the default change, `--spare` and the compat for `--no-spare`. Commits keep a Co-Authored-By line, with no Claude-Session trailers or session URLs.
- Watch CI with `gh run watch <id> --exit-status`.
- Report to the orchestrator in (main) with the PR number, the gate results and the fail-first evidence. Do NOT merge.

## Don't
- Don't touch existing tmux sessions of David's, including `mac-utilities-gif-stickers~agent~codex`.
- Don't drive the running app.
- Don't write to `~/.claude.json`, `~/.codex` or `~/.pi`.
