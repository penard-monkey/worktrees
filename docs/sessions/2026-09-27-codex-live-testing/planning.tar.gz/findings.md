# Findings

The reports used MCP processes started before v0.32.1. No verdict until verified against this checkout's release binary.

Live user lanes must receive no input. Reproductions use owned scratch repos and tmux sessions.

## Baseline on 3514559 (v0.32.1), macOS, codex-cli 0.157.1
- Scratch root and session metadata: `/tmp/wt-codex-probe.json`; raw captures and MCP responses are under the recorded temporary base.
- Fresh release MCP: sleep-300 lane returned `event: timeout`, `state: busy`; escalation for `pwd` returned `event: waiting`, `state: waiting`; plan-mode request_user_input modal also returned waiting. Bug A's reported states do not reproduce in these cases.
- Sending into sleep-300 returned delivered true with confirmed-submitted note. Pending-question banner still to reproduce.
- `/plan` request_user_input opens a modal; Shift-Left leaves it unchanged, Escape aborts the turn. Need asynchronous question layout.

- Reproduced the exact collapsed question layout using request_user_input_async: `? 1 question` / `shift+← to answer` immediately above the composer. While typing, the model/path status is replaced by `tab to queue message · Plan mode`.
- Bug B: fixed by #352, evidence: release MCP sent a long body with this banner present, returned delivered true / confirmed submitted; post-send capture shows the full attributed message in history and a fresh empty composer. Short preview capture confirms occupied composer was recognizable despite banner.
- Bug A: reported mid-turn/approval false idle is already fixed on current main (the activity reader predates #351; #351 retains it). Approval send correctly refuses input. Collapsed async question remains busy while independent work runs; it is not a blocking modal.

- Completion witness: after the async-question lane finished its sleep and final answer, release `wait` returned idle with `last_done:1790532432`, rather than a null completion date.
- Full core suite: 505 passed; CLI: 33 passed; TypeScript passed. Remaining gates still running.

- The long-task lane finished naturally after 5m 5s, answered DONE / RECEIVED, and release wait returned idle with last_done 1790532501.
- Git history identifies the shared activity implementation as #348, retained by #351; evidence does not justify attributing Bug A specifically to #351. Verdict is already fixed on current main, with the stale-server explanation consistent with the supplied report.

## Final validation
All required gates passed (382 Bats, 505 core, 33 CLI, 161 app with one existing ignored; lint, TypeScript, app check and release build). All three new tests were demonstrated failing under deliberate production mutations before the restored implementation passed.
