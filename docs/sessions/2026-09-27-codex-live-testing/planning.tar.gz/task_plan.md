# Codex send/wait verification

## Goal
Verify both reports on current code using scratch codex-cli 0.157.1 sessions, fix remaining bugs, open a PR and report to main without merging.

## Phases
- [x] Build release and bootstrap; inspect activity/send implementation.
- [x] Reproduce mid-turn, approval, and question-banner states; capture evidence.
- [x] Add regression tests, prove failures, implement fixes.
- [x] Run all repository gates and update changelog/findings.
- [x] Commit, open PR, report verdicts to main, clean up owned scratch sessions.

## Errors
None yet.
