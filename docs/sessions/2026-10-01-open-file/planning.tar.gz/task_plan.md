# open-file — terminal path links + show_doc line support

Brief: .planning/brief.md

## Decisions
- Activation: ⌘-click (plain click = focus/select/mouse-report to claude). Hover underline+pointer + tooltip.
- ⌘-click on a link: stop the mousedown at .xterm-screen (target phase, after linkifier) so it never
  reaches xterm's el listeners → no mouse report to claude, no selection start.
- Links only for EXISTING regular files that pass guard_under_projects (what the viewer can read).
  Outside → no link (viewer can't read them; Finder-reveal would make arbitrary text a fs probe).
- Resolution in backend `resolve_term_paths`: relative against dock shell's live cwd (proc_cwd) then
  place root; `~/`; `a/`/`b/` diff prefixes. Stat only, no spawn. Frontend caches per candidate (TTL).
- Viewer: `at` (line/col) override renders the plain source with the line marked, regardless of
  preview/diff, until the user picks a view. Persisted per place as `files_open_at`.
- show_doc: optional line/col; Request gains optional fields (serde default, skip None). Stays in
  --mutations tier (drives the screen; read-only profiles shouldn't steer the user's window).

## Phases
1. [x] PR1 core/CLI/MCP: inbox Request line/col, cmd_show --line, show_doc line/col + description, guidance line + VERSION, tests red-first
2. [x] PR2 app: lib.rs OpenDoc line + resolve_term_paths; termlinks.ts; TerminalPane provider; viewer line; mock; check script
3. [x] (PRs #399, #400 open; CI watching) Gates, mock Chromium + WebKit, CHANGELOG, PRs, CI watch
