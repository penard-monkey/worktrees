# Findings — side-by-side diff for the Files tab

## What already exists (read from source, 2026-08-17)

### `changed_files` — `app/src-tauri/src/lib.rs:2431`
- THREE git spawns per refresh, once for the whole tree.
- Committed half: `git diff --name-status -z <cand>...HEAD` with candidate
  precedence `origin/main → origin/master → main → master`. **Three dots** —
  the merge base, so a moved base branch doesn't light up unrelated files.
- Uncommitted half: `git status --porcelain -z --untracked-files=all`, applied
  SECOND so it wins on collision.
- Returns `{ root (canonical repo top), files: [{path (absolute), status}] }`.
- `ChangeKind` = `modified | added | untracked | deleted`. A rename is reported
  as added + deleted (both halves), which is why the tree can draw a ghost row.
- **Implication:** the base the tree's marks are computed against is
  `merge-base(origin/main, HEAD)` — a diff view that used `HEAD` as its base
  would disagree with the very marks that led the user to click the file.

### `FilesPane.tsx` (760 lines)
- `FileTree` owns `changes` state (built by `buildChanges`). `FileView` does
  **not** receive it — it only gets `path`. Adding a Diff toggle that appears
  only for changed files means lifting `changes` into `FilesPane` (or passing
  the one status down). Real, small refactor.
- `FileView.renderBody()` already branches per kind: image → `ImageView`,
  binary → placeholder, markdown+!mdSource → `Markdown`, else
  `<div class="scroll"><CodeBlock …></div>`. A diff view is a fifth branch.
- Header already hosts a `seg` segmented control (Preview | Source) shown for
  markdown and SVG only, plus Wrap / Expand / Editor buttons. Natural home.
- `reloadToken` re-reads from disk on every places:changed + dock Refresh —
  a diff view gets live updates for free by keying off it.
- Layout thresholds precedent: `SPLIT_AT = 620`, `SPLIT_FLOOR = 420`, with
  `orientationFor()` resolving `auto`. Same shape works for
  "side-by-side diff vs unified diff" at narrow dock widths.

### `CodeView.tsx` (39 lines) + `highlight.ts` (311)
- `tokenize(src, lang) → Tok[]` is a flat list; **tokens may contain newlines**
  (block comments, template strings). `CodeBlock` gets away with it because the
  line-number gutter is a SEPARATE column sharing line-height.
- **This is the single biggest technical constraint.** A side-by-side diff needs
  one DOM row per line pair; you cannot have a token spanning rows. Needs a
  `tokenizeLines(src, lang): Tok[][]` that runs the existing tokenizer over the
  whole file (so block-comment/string context is right) and then splits tokens
  at `\n`. ~15 lines, no change to the scanner.
- Tokenizing a diff hunk's lines INDIVIDUALLY (the cheap route) mis-colours
  anything whose context starts outside the hunk — an unterminated string, the
  inside of a `/* */`, a Python docstring.
- `highlight.ts:162 diffTokens()` already colours *unified diff text* per line
  (`+` → str, `-` → kw, `@@`/`+++` → attr), and `filekind.ts:42` maps
  `.diff`/`.patch` → that grammar. So a UNIFIED diff already renders today if
  something hands it diff-flavoured text. Side-by-side is the new work.
- No UI deps in `app/package.json` beyond xterm, marked, react. Confirms the
  "no UI libraries" rule is live.

### Roadmap adjacency — `ROADMAP.md:586`
- "A 'changes only' view of the Files tab, and auto-expand to changed files" is
  already parked, deliberately deferred so the marker slice stayed clean.
  A diff viewer is the natural companion; worth mentioning both belong to the
  same "the tree knows the branch's diff" family.
- `ROADMAP.md:600` — the nav's dirty count (uncommitted only) vs the tree's
  badge (uncommitted + committed-on-branch) already disagree and nothing on
  screen says so. A diff view with a base selector would be the first surface
  that could make that distinction *visible* rather than confusing.

## Option space

### Axis 1 — where the diff is computed

**1A. Backend `git diff -U3`, frontend parses unified text into rows.**
- Small payload even for a huge file. git owns rename/binary/EOL/submodule.
- Cons: only 3 lines of context (needs an "expand" round-trip); highlighting
  has no whole-file context; parsing unified diff correctly is fiddly
  (`\ No newline at end of file`, multi-hunk, `+++ /dev/null`).

**1B. Backend hands both full texts; frontend runs its own line LCS/Myers.**
- `git show <base>:<rel>` + read the working file. Whole-file tokenize on both
  sides is free and correct. Full context, collapse-unchanged is a render
  choice. Cons: we own the diff algorithm (~100 lines) and rename detection.

**1C. Hybrid — backend runs `git diff --unified=<huge>` (full-file context) and
returns the raw text; the frontend derives old text, new text AND the alignment
from that one payload.**
- git does the diffing (no JS algorithm), the frontend still gets both COMPLETE
  files, so `tokenize()` runs with full context. One spawn.
- Cons: payload ≈ 2× file size, so it needs the same 1 MiB cap `read_file` has.
- Untracked files need a separate arm (`git diff --no-index /dev/null <file>`,
  or just "everything is added").

**1D. Backend parses git's diff into `Vec<DiffRow>` in Rust** — frontend renders
a ready-made row list. Moves the fiddly parsing to the typed side and keeps the
payload structured. Same highlighting problem as 1A unless full context is used.

**1E. Punt — shell out to `git difftool` / open in the external editor.** Near
zero work, near zero value; the whole point of the tab is not leaving the app.

### Axis 2 — what "before" means

- **merge-base** (`origin/main...HEAD` semantics, working tree included):
  matches the marks the user clicked. `git diff <merge-base>` — note TWO dots
  against the working tree, i.e. `git diff $(git merge-base origin/main HEAD)`.
- **HEAD**: "what have I not committed yet" — the more familiar `git diff`.
- **index**: staged vs unstaged; a third column's worth of nuance.
- These are genuinely different questions and the tree can't answer both with
  one tint. Cheapest honest answer: a two-way segmented control
  `vs base | vs HEAD`, defaulting to base so the diff agrees with the marks.

### Axis 3 — layout

- **CSS grid, 4 columns** (old gutter, old text, new gutter, new text), one grid
  ROW per aligned line pair. Alignment survives line WRAPPING for free — the
  grid row takes the max height of its cells. This is the reason to prefer grid
  over two independently scrolling `<pre>` columns (which desync on wrap and
  need scroll-sync JS).
- **Unified** fallback below a dock-width floor, same shape as `orientationFor`.
- **Collapse unchanged runs** — `⋯ 42 unchanged lines` expander. Needed once
  full-file context is on the table (option 1B/1C), otherwise a one-line change
  in a 3000-line file scrolls forever.
- Intra-line (word-level) highlight is a separate, later slice — either
  `git --word-diff` or a JS char-diff over paired rows.

### Axis 4 — highlighting
See the `tokenizeLines` note above. Whole-file tokenize + split at `\n`.

### Axis 5 — entry point
- Header `seg` grows a third state for a changed file: `Source | Diff`
  (and `Preview | Source | Diff` for markdown). Requires `changes` in `FileView`.
- Alternative: a separate keystroke/toggle that applies to whatever is open, and
  reads "no changes" when the file is clean. Fewer moving parts, less discoverable.

## Base agreement — verified empirically (2026-08-18)

`scratchpad/base-agree.sh` replays BOTH command sequences from lib.rs against
eight synthetic repos. Result: **all eight agree**, including that the two
candidate loops always settle on the same ref — even though `changed_files`
breaks on the first candidate whose `git diff <cand>...HEAD` SUCCEEDS while
`file_diff` breaks on the first whose `git merge-base` succeeds. Shapes covered:
committed-only, uncommitted-only, base moved on, no origin, no main/master at
all, unrelated histories, rename.

**One genuine user-visible contradiction, by design (case 3).** A file changed in
a commit on the branch and then changed BACK in the working tree:
- `changed_files` still marks it (the working tree differs from HEAD), so the
  tree tints the row.
- `file_diff` vs base correctly reports no difference, so the viewer says
  *no changes vs origin/main*.

Both are true — the branch touched the file, and its current content equals the
base — but the row and the viewer contradict each other on screen, which is
exactly the confusion the shared `BASE_CANDS` was meant to prevent. The
Base/HEAD toggle does reveal the revert. Candidate fixes, cheapest first:
1. When the base patch is empty, say so more specifically ("identical to
   origin/main — this branch changed it and changed it back"), which needs the
   backend to also ask whether it differs from HEAD. One extra git spawn, and
   ONLY in the already-empty case.
2. Leave it and document.

### Probe traps hit while writing that script (both cost real time)
- **`git -C "" …` runs against the CURRENT repo.** The first version let a repo
  path come back empty (bash expands every assignment on a `local a=1 b="$a"`
  line before binding any of them), so `branch -M main` and `push origin main`
  were aimed at the real worktree. Git refused both — the worktree guard for the
  rename, non-fast-forward for the push — and `origin/main`, local `main` and
  HEAD were all verified unchanged afterwards. The script now routes every git
  call through a `g()` that hard-exits unless the directory is non-empty and
  under `$TMP`.
- **`… | grep -q X` under `set -o pipefail` reports FAILURE on a match.** `-q`
  exits at the first hit, the upstream `sort` takes SIGPIPE, and pipefail
  promotes that to the pipeline's status — so a found file read as "not found"
  and two cases looked like product bugs. Same family as the `grep -c` trap
  already in CLAUDE.md. Write to a file, then grep the file.

## Open questions for the user
1. Base semantics — default to merge-base (agrees with the tree) or HEAD?
2. Full-file diff with collapsible context, or hunks-only?
3. Is word-level intra-line highlight in the first slice or later?
