# Progress

## Session 2026-08-17/18 — side-by-side diff in the Files tab — **MERGED**

Merged as `68300a2` (PR #159), squashed. Worktree parked on `ui-next`, level
with `origin/main`, clean. Branch deleted locally and on the remote.

Rebased **four** times during the session (main moved 21, then 2, then 2 more).
Conflicts each time in `FilesPane.tsx` (main's new `CtxMenu`), `lib.rs` (both
sides appended tests) and `CHANGELOG.md` (both added `[Unreleased]`).

### Fable review — verdict FIX-FIRST, all 12 findings addressed
Three MAJOR, each reproduced before fixing:
1. **A genuine git failure rendered as "no changes".** `git_out` → `None` was
   collapsed to an empty patch, and empty means "identical to base". Reachable:
   an unborn HEAD with a STAGED file — tracked, so the untracked arm misses it;
   every `merge-base` fails; the `HEAD` fallback exits 128. Fixed with an
   explicit `has_commits` guard (all-added) plus `ok_or_else` so a real failure
   surfaces through `fail()`.
2. **"nothing changed on this branch" before the change set had loaded**, and
   permanently after a failure (markers are additive, so `NO_CHANGES` sticks).
   Gated on `changes.root !== ""`. The mock cannot show this — it answers in a
   microtask; exactly CLAUDE.md's documented bug class.
3. **Sticky gutters were ~86% transparent on changed rows only.** `.dg.del`
   (0,2,1) overrode `.dg`'s opaque `--bg-tree` (0,1,1), and that column is
   `position: sticky` in a `max-content` grid — code slid under the pinned line
   numbers on exactly the rows being read. Gutter tints now mix over
   `--bg-tree`; the hatch gets an opaque layer under it.
4. **`wordDiff` contradicted its own docstring** (promised no marks for lines
   sharing nothing, marked the whole line). Fixed — and my first fix was WRONG
   in the dangerous direction: testing "LCS kept nothing" killed the marks on
   `const foo` → `const bar`. `diff-check.mjs` caught it. Correct predicate is
   "no common prefix AND no common suffix AND LCS kept nothing".

Plus: word-diff memo bounded by `MAX_ROWS`; dead `against` comment corrected in
both languages; `BASE_CANDS` comment no longer overstates agreement; CHANGELOG
glyph polarity fixed; empty-label and rows-vs-lines wording; mock now errors on
a non-file and orders `untracked` before `binary` like the backend; screen
readers get a `.vh` "added/removed" prefix; multi-file patch guard.

### Verified, not assumed
- `diff-check.mjs` — 12/12 round-trips byte-for-byte; shown to fail when
  `flush()` is corrupted.
- Base agreement across 8 repo shapes — both loops always pick the same
  candidate. One genuine by-design contradiction found and documented (committed
  then reverted in the worktree).
- Sticky opacity, grid alignment, `.vh` invisibility measured with
  `getComputedStyle` in BOTH layouts (the `add` gutter is sticky only in
  unified, so the fix mattered there specifically).
- 4 new Rust tests, each shown to fail before its fix. The `ok_or_else` arm is
  belt-and-braces and is NOT independently covered — the one reachable instance
  is now caught earlier by `has_commits`.
- CI: all 9 checks green before merge.

### Mistakes made and corrected
| What | Resolution |
|------|------------|
| Probe let a repo path go empty → `git -C ""` ran `branch -M main` and `push` against the REAL repo | git refused both (worktree guard, non-fast-forward); verified remote main, local main, HEAD, worktree all unchanged; probe now refuses any dir outside `$TMP` |
| `grep -q` under `pipefail` read a match as a failure (SIGPIPE) | write to a file, grep the file — two "product bugs" evaporated |
| First `wordDiff` fix removed working highlights | corrected predicate; case pinned in `diff-check.mjs` |
| First colour measurement parsed `color(srgb 0-1)` as 0-255 | re-measured with a syntax-aware parser |
| UTF-8 test passed with its guard removed | fixture rebuilt to straddle + asserts that it does |
| Started vite with `nohup … &` | relaunched as a tracked background task |

### Still open (in ROADMAP.md)
- No manual side-by-side/unified pin for the diff.
- Add/del edge under 3:1 on two light themes; and `--syn-com` is already under
  4.5:1 on all four dark themes, which `tokens.css` claims otherwise.
- **Never run against the real app.** Everything was the mock harness plus
  direct git probes. `sandbox.sh --app` execs a GUI that cannot be driven from
  here, so a human pass on a real repo is still worth doing.
