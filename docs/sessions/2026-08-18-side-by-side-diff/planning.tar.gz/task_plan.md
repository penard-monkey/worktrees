# Task plan — side-by-side diff in the Files tab

## Goal

The dock's Files tab already marks changed files (tint + directory counts, from
`changed_files`). It can only show the file's CURRENT content. Add a way to see
what actually changed — ideally a SIDE-BY-SIDE diff — for a file the tree has
marked.

Right now this is a **design/options** task: enumerate viable approaches, pick
one with the user, then build.

## Phases

| # | Phase | Status |
|---|-------|--------|
| 1 | Map the existing surface (FilesPane, CodeView, highlight, `changed_files`) | complete |
| 2 | Enumerate options across the 5 decision axes, with costs | complete |
| 3 | User picks direction | complete |
| 4 | `diff.ts` — unified parser, row model, word-level diff | complete |
| 5 | `tokenizeLines` in highlight.ts | complete |
| 6 | `DiffView.tsx` — grid renderer, side/unified auto | complete |
| 7 | Backend `file_diff` + mock harness parity | complete |
| 8 | Settings: per-place diff toggle + changed-only filter | complete |
| 9 | Wire FilesPane / App / CSS | complete |
| 10 | Gates (all green) + harness verification | complete |
| 11 | Rebase onto origin/main (done twice — 21 then 2 commits) | complete |
| 12 | Real-app run via `app/scripts/sandbox.sh --app` | **pending** |
| 13 | Push + PR | **pending — user's call** |

## Decisions (2026-08-17, user)

1. **Compute — option C.** Backend runs `git diff --unified=<huge>` for full-file
   context; the frontend derives old text, new text and the row alignment from
   that one payload. No JS diff algorithm for LINES.
2. **Base — merge-base by default, with a `vs base | vs HEAD` toggle.** Base
   candidates must follow `changed_files`' precedence exactly
   (`origin/main → origin/master → main → master`) or the diff disagrees with
   the tint that made the user click.
3. **Context — full file, nothing collapsed.** No expander state at all.
4. **First slice — all four:** side-by-side + unified fallback, word-level
   intra-line highlight, per-place persistence of the toggle, and the
   "changes only" tree filter (`ROADMAP.md:586`).

## Constraints carried in from CLAUDE.md

- No UI/component libraries. A pure parser/algorithm is the `marked` precedent.
- Commands must be `async fn`.
- The mock harness (`app/src/mock/install.ts`) must track every new command.
- Module-scope components only.
- A `place_panels` field whose global twin is a SEED must be **optional**, and
  `updatePanels` must carry the STORED value rather than filling from `cur`.
- Rebuild the release binary before believing `make test`.

## Constraints carried in from CLAUDE.md

- No UI/component libraries. A pure parser/algorithm is the `marked` precedent.
- Commands must be `async fn`.
- The mock harness (`app/src/mock/install.ts`) must track every new command.
- Module-scope components only.
- Rebuild the release binary before believing `make test`.

## Errors encountered

| Error | Attempt | Resolution |
|-------|---------|------------|
| `grep --include=*.rs` under zsh → "no matches found" | 1 | zsh globbed the flag; passed dirs instead of `--include` |
