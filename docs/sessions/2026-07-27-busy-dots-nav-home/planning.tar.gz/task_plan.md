# Task Plan — nav redesign, meaningful dots, system theme

## Goal
1. Green dot = only "session churning" (live activity), purple AI dot removed,
   red/dirty indicator kept. No UI lag.
2. Sidebar restyled: Mux-inspired nesting/left padding, folder icon on project
   rows, Home entry (logo + open-new-project button).
3. macOS system light/dark: already shipped ("System (match macOS)" in
   Settings) — enhance so user picks which light/dark theme pair it flips.

## Phases

### Phase 1 — busy ("churning") signal  [complete]
- [x] `worktrees-core/src/tmux.rs`: `session_activity()` → Vec<(name, activity_epoch)>
      via `tmux list-sessions -F "#{session_name}\t#{session_activity}"`.
- [x] `app/src-tauri/src/lib.rs` poll thread (already ticks every 3s): compute
      busy set = sessions with activity < BUSY_WINDOW (10s) ago; emit
      `sessions:busy` event (string[] payload) only when the set changes.
- [x] Frontend: listen once in App, keep `busy: Set<string>` state.
- [x] Mock harness: event emitter support + simulated busy cycling so the dot
      is exercisable in `pnpm dev:mock`.
- No new invoke round-trips, no schema change to `ls --json` (bats untouched).

### Phase 2 — dot semantics cleanup  [complete]
- [x] PlaceRow: status-dot rendered ONLY when its tmux session is busy
      (green + breathe). No more lifecycle-colored always-on dots.
- [x] Remove purple ✦ AI glyph from row glyphs + topbar status-cluster + the
      AI chip in briefing/Home. Keep statusbar "pane0 claude" fact line.
- [x] Project rollup dot: green only when a child session is busy; else no dot.
- [x] Keep dirty ● glyph (the "red circle" user likes) + ahead/behind/detached.

### Phase 3 — sidebar restyle (Mux-inspired, not a copy)  [complete]
- [x] "Home" top-level nav row (house icon) above projects; click → clear
      selection (shows Home view).
- [x] Project header: chevron + folder SVG icon + name (+count); busy dot
      overlays/trails when children busy. Mini buttons stay on hover.
- [x] Generous left padding / indent steps (bump --ind & row padding); session
      rows nested deeper, plain text, right-aligned meta (glyphs + age).
- [x] Selected row: full-width rounded pill highlight.
- [x] Age column (declared.last_opened_epoch → `2d` style) right-aligned dim.

### Phase 4 — Home view  [complete]
- [x] Replace "Welcome back" briefing: app logo (icons/128x128@2x.png copied to
      src/assets), app name, primary "Open a project" button (addProject).
- [x] Keep resume list + live/dirty chips under it (drop AI chip).

### Phase 5 — system theme pair choice  [complete]
- [x] Settings: `theme_light` / `theme_dark` (defaults tokyo-day/tokyo-night).
- [x] `resolveTheme("system")` uses those instead of hardcoded tokyo pair.
- [x] SettingsSheet: when theme=system, show two selects (light pair, dark pair).

### Phase 6 — gates + visual verify  [complete]
- [x] `cd app && ./node_modules/.bin/tsc --noEmit && cargo check -p app`
- [x] `cargo test -p worktrees-core` (n/a — no unit tests in crate; bats covers)
- [x] `cargo build --release -p worktrees-cli` + `make test` (134/134 pass;
      needed `git submodule update --init` in this worktree first)
- [x] `make lint` (pass)
- [x] Screenshots via mock harness (port 1421) — saved to scratch dir

## Decisions
| Decision | Choice | Why |
|---|---|---|
| Busy transport | piggyback existing 3s fingerprint thread, event push | zero extra polls, no invoke churn, no lag |
| Busy window | 10s since last tmux `session_activity` | poll is 3s; 10s absorbs jitter, decays fast |
| Schema | untouched (`ls --json` v1 byte-stable) | bats + CLI compat |
| Rail | keep | holds lenses/⌘B/settings; Mux borrow is nav-column only |
| "Red circle" | interpreted as dirty ● glyph | only red-ish circular mark in nav; kept regardless |
| Home content | logo + open button + resume list | user asked logo+button; resume list too useful to drop |

## Errors Encountered
| Error | Attempt | Resolution |
|-------|---------|------------|
| tsc: unused `DOT_COLOR`/`isLive` after dot cleanup | 1 | removed both (lifecycle colors no longer drive dots) |
