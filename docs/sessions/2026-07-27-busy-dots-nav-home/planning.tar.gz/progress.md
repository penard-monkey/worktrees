# Progress

## Session 2026-07-27 (started)
- Read reference image `_tmp/side-bar.jpeg` → findings.md.
- Explored App.tsx / settings.ts / SettingsSheet.tsx / tokens.css / App.css /
  core tmux.rs / model.rs / project.rs / lib.rs poll thread / mock install.ts.
- Key: system theme ALREADY exists; dots driven by lifecycle_effective +
  claude_session_present (why green/purple everywhere).
- Wrote task_plan.md (6 phases).

## Session 2026-07-27 (implementation — all phases done)
- Phase 1: `session_activity()` in core tmux.rs; lib.rs poll thread emits
  `sessions:busy` (10s window, only on change); App listens (`busySessions`
  Set); mock harness got a real event emitter + simulated busy cycle.
- Phase 2: row dot = busy-only (green breathe, fixed slot → no shift); purple
  ✦ removed everywhere (glyphs/topbar/chips); dirty/ahead/behind/detached kept.
- Phase 3: Home nav item; folder SVG icon + busy corner-badge on project rows;
  --ind 10→14px; --dotcol recentred for 16px icon; row age column.
- Phase 4: Home view = logo (icons/128x128@2x → src/assets/logo.png) + name +
  tagline + "Open a project" + live/dirty chips + resume list.
- Phase 5: theme_light/theme_dark settings + normalizePair; resolveTheme(s)
  signature change; SettingsSheet pair selects (system only).
- Phase 6 gates: tsc ✓, cargo check app+core ✓, release CLI build ✓,
  bats 134/134 ✓ (after `git submodule update --init`), make lint ✓.
- Visual verify (mock harness :1421 + Playwright): dark + light (system→
  tokyo-day) screenshots → ~/.cache/worktrees/worktrees/ui-changes/.
  NOTE: settings-sheet screenshot shows nav dark = scrim overlay, not a bug
  (computed styles verified light).
- User follow-up: tagline → "a place for every work stream"; README intro
  reframed (durable places / work streams); CHANGELOG [Unreleased] filled;
  GitHub repo description updated via `gh repo edit`.
- Committed on `next` (ff5bb24), PR #38, all 8 CI checks green,
  squash-MERGED to main 2026-07-27. Worktree still on merged `next` branch —
  run /close-out before starting the next stream here.
