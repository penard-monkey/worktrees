# Findings

## Reference image: _tmp/side-bar.jpeg (Mux v4.0.6 sidebar)

Observed structure (dark theme):
- **Top-level nav items** (icon + label, generous vertical spacing):
  Home, New agent, Search, GitHub, Automations, Customize (has small orange
  notification dot on its icon).
- **"Workspace" section header** — small/dim label with filter-ish icon left,
  `+` button on right edge.
- **Project groups**: chevron (collapse) + folder icon + project name
  (e.g. `general-cbcode`, `mux`, `cloudflare`). Bold-ish, brighter than
  section header.
- **Sessions nested under project**: indented (~2 levels of left padding, no
  icon), plain text names. Active session = full-width rounded highlight
  (light pill, dark text).
- **Trailing metadata right-aligned per session**: diff stats (`+324` green,
  `-2` red) and relative age (`2d`, `4d`, `10d`) in dim text.
- Bottom bar: version string left, small icon buttons right (settings etc).

What user wants from it (per request):
- Nesting + left padding style
- Icon on the project row
- Home concept (our Home = logo + "open new project" button)
- NOT an exact copy

## User asks (from prompt)

1. **macOS auto light/dark**: option to follow system appearance (in addition
   to explicit theme choice).
2. **Red circle on left nav**: user LIKES it — keep.
3. **Green dot**: shows on ~everything → meaningless. Only show while session
   is "churning" (active/busy). No UI lag added. Otherwise remove.
4. **Purple AI session dot**: on everything, meaningless → remove.
5. **Sidebar rework**: nesting/padding like reference, project icon, Home
   entry (logo + new-project button).

## Codebase

- **System theme EXISTS**: `settings.ts` `theme: "system"` + `resolveTheme()`
  (hardcodes tokyo-night/tokyo-day pair); App.tsx:313 matchMedia listener;
  SettingsSheet has "System (match macOS)" option. User ask #1 = mostly done;
  enhancement = configurable pair.
- **Dots today** (App.tsx):
  - Row `status-dot`: colored by `DOT_COLOR[lifecycle_effective]` (active →
    `--ok` green — most places are active ⇒ green everywhere). `.live` class
    (breathe anim) when `isLive()` = tmux up OR claude_session_present.
  - Purple ✦ = `g-ai` glyph when `claude_session_present` (a .claude session
    dir exists ⇒ ~always true). Also topbar `✦ ai`, briefing AI chip.
  - Dirty = `g-dirty` `●N` colored `--dirty` (amber/red-ish) — the liked one.
  - Project header `rollup` dot: green `.on` when any child tmux up.
- **Live refresh**: lib.rs:880 thread polls `session_fingerprint()` every 3s,
  emits `places:changed` on change or every ~30s. Perfect piggyback spot for a
  busy-set event (`#{session_activity}` from same list-sessions call).
- **model.rs schema v1**: byte-stable `ls --json` (bats asserts) — do NOT add
  fields; keep busy signal app-side only.
- **Mock harness** (`mock/install.ts`): `plugin:event|listen` resolves 0, no
  emitter — must add event wiring + simulated busy to exercise the dot.
- **tokens.css**: `--ind: 10px` indent step (tight); `--dotcol` aligns main-row
  dot with project rollup; breathe keyframes exist. Nav layout classes in
  App.css (`.project-h`, `.row`, `.kids`, `.group-h`).
- **Logo for Home**: `app/src-tauri/icons/128x128@2x.png` (commit-node tree
  icon, PR #33). Copy into `app/src/assets/` for Vite import.
- **Settings plumbing**: every visual setting = CSS var via `applySettings`;
  new settings need DEFAULTS + type + (optionally) normalize on load.
