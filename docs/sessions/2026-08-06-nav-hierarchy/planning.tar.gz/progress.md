# Progress log

## Session 2026-08-06 — left-nav hierarchy (projects up, dormant down)

Branch `ui-next-usage`, worktree `ui-tweaks`.

### What happened

1. Read `_tmp/Screenshot 2026-08-06 at 17.16.55.png`, sampled its pixels
   (`#181825` nav = catppuccin-mocha, `#11111b` dormant band = `--bg-abyss`)
   and cropped/upscaled the dormant region to see the band's hard edge.
2. Diagnosed the real cause of "hard to see the project": `.pname` was
   `--fs-label` (13px) while `.row-name` is `--fs-row` (15px) — the project
   header was SMALLER than its own children. Nothing else separated projects.
3. Asked the user for the treatment; both recommendations taken —
   sticky + strong type, and dormant fades instead of banding.
4. Implemented in `app/src/App.css` (4 rule blocks) + `app/src/App.tsx`
   (dormant caret → shared SVG chevron).
5. Verified in the mock harness on port 1421 (`--force`, per the `.worktrees/`
   HMR trap) with `getComputedStyle` assertions + a real scroll/hit-test —
   full table in `findings.md`.

### Gates

| gate | result |
|---|---|
| `tsc --noEmit` | pass |
| `cargo check -p app` | pass |
| `make test` / `make lint` / `cargo test -p worktrees-core` | not run — untouched by a CSS/TSX-only change; run before the PR |

### Artifacts

- `~/.cache/worktrees/worktrees/ui-tweaks/after-nav-top.png`
- `~/.cache/worktrees/worktrees/ui-tweaks/after-nav-scrolled.png` (stuck header)
- `~/.cache/worktrees/worktrees/ui-tweaks/crop-dormant.png` (the "before" evidence)
- `~/.cache/worktrees/worktrees/ui-tweaks/vite.log`

### Ship

Base had moved: `origin/main` was 1 commit AHEAD of the worktree's HEAD — PR #72
(AI profiles) merged after #83, out of PR-number order. Stashed, branched
`ui-nav-hierarchy` off `origin/main`, popped (CHANGELOG/App.css/App.tsx all
auto-merged; #72 touched neither `.project*` nor `.group.dormant`). Re-ran the
gates and the whole harness assertion set on the new base — all still hold.

Full gates: `cargo build --release -p worktrees-cli`, `make test` 249/249,
`make lint`, `cargo test -p worktrees-core` 143 passed, `tsc --noEmit`,
`cargo check -p app`.

CHANGELOG: new `### Changed` block under `[Unreleased]`.

- commit `3601e7a`
- **PR #84 — MERGED** (squash, 2026-08-06). CI green on all 9 checks (app/test/
  rust/install ×2 OSes + lint). Landed on main as `29b2aea`.
- Branch `ui-nav-hierarchy` deleted local + remote; worktree back on
  `ui-next-usage`, hard-reset to the merged `origin/main`.

### Still open

- Mock harness left running on **port 1421** — `lsof -ti:1421 | xargs kill` to stop.
- Work stream is DONE. Next step when the session ends: `/close-out`.
