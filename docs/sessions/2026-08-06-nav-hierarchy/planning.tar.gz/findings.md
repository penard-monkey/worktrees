# Findings — left nav hierarchy

## Diagnosis (from screenshot + App.css)

**The project header is typographically SMALLER than its own children.**

| element | selector | size | weight | colour |
|---|---|---|---|---|
| project name | `.pname` (App.css:214) | `--fs-label` 0.8125rem | bold | `--txt-hi` |
| place slug | `.row-name` (App.css:339) | `--fs-row` 0.9375rem | med | `--txt-hi` |

Same colour, child is 2px larger. Nothing else separates a project from the
places under it — no rule above, no band, no sticky. With one project open the
position alone carried it; with three, the eye finds `★ bug-fixes` before it
finds `casa-del-valle-monorepo`.

## Dormant reads as emphasis, not recession

`App.css:315` — `.group.dormant { background: var(--bg-abyss); border-radius: var(--r-md); }`

Theme in the screenshot is **catppuccin-mocha** (sampled nav bg = `#181825`
= `--bg-tree`; dormant band = `#11111b` = `--bg-abyss`). So it IS darker, as
designed — but a hard-edged full-bleed rectangle is a *figure*, not a
*ground*. It cuts the tree horizontally and, sitting last in a project, it
doubles as a false separator competing with the next project header.

Also: the dormant header uses ASCII `▾`/`▸` (App.tsx:2079) while every other
group header uses `Icons.ChevronDown/Right` SVG — an inconsistency that adds
one more visual difference to a row that should be quieter, not louder.

## Structure notes

- `.nav-scroll` (App.css:132) is `overflow-y: auto` → sticky works, no DOM change.
- Indent ladder + plumb rails key off `--gx1/--gx2/--gx3` and
  `--s3 + depth*--ind`. The dormant band is full-bleed *because* the rail x-math
  needs a left edge at 0 — so removing the background is safe, but any padding
  added to `.group.dormant` would shift the rails.
- `.project-h` holds hover-only `.mini` buttons (`opacity: 0` until
  `.project-h:hover`) — a sticky header must not trap pointer events over rows.

## Verification — run in the mock harness (port 1421, tokyo-night, 3 projects)

Asserted with `getComputedStyle` per CLAUDE.md ("don't eyeball it"). Served CSS
checked against disk first (`curl localhost:1421/src/App.css`) — the
`.worktrees/` HMR trap.

| check | result |
|---|---|
| `.pname` font-size | `14.0625px` @ weight 600 — was 13px-equivalent |
| `.row-name` font-size | `14.0625px` @ weight 500 → header wins on weight, ties on size |
| `.project-h` | `position: sticky`, `top: 0px`, `z-index: 2`, bg `rgb(22,22,30)` = `.nav` bg (opaque) |
| `.project + .project` | `border-top: 1px rgb(37,40,56)`, `margin-top: 12px` |
| `.group.dormant` | `background-color: rgba(0,0,0,0)`, `opacity: 0.62`, `border-radius: 0px` |
| dormant caret | `svg` present (ASCII gone) |
| hover restore | hovered group `opacity: 1`, sibling stays `0.62` |
| rules parsed | `.group.dormant:hover, :focus-within, :has(.row.sel)` all in `cssRules` |
| rails unmoved | `.subgroup > .places .row` padding-left `47px` (= s3 + ind×2.5); `::before` left `42px` (= `--gx3`) |

Sticky proven behaviourally, not just declared: with `.nav-scroll` scrolled 203px,
header tops = `[0, 313, 648]`; a `.row` rect overlaps the stuck header, and
`elementFromPoint` at the header's centre returns `.pname` — the header is on
top and opaque, rows pass *under* it.

Screenshots: `~/.cache/worktrees/worktrees/ui-tweaks/after-nav-{top,scrolled}.png`

## Known tradeoff

`--fs-row` on `.pname` truncates long repo names sooner at narrow nav widths
(`casa-del-valle-mo…`). The `title={pv.root}` tooltip already covers it, and the
nav is user-resizable.
