# Task plan — left-nav legibility: projects up, dormant down

## Goal

With several projects open, the left nav must make the PROJECT the strongest
landmark in the tree, and must stop letting the DORMANT group read as an
emphasis band. Two user complaints, one hierarchy fix.

Source of the complaint: `_tmp/Screenshot 2026-08-06 at 17.16.55.png`
(3 projects visible, catppuccin-mocha theme).

## Phases

| # | Phase | Status |
|---|-------|--------|
| 1 | Diagnose from screenshot + CSS | complete |
| 2 | Pick treatment (ask user) | complete |
| 3 | Implement CSS/TSX in `app/src` | complete |
| 4 | Verify in mock harness (computed styles, screenshots) | complete |
| 5 | Gates (tsc, cargo check) + report | complete |

## Decisions

- Sticky project headers: **yes** (user picked "Sticky + strong type").
  `.nav-scroll` is already the scroll container, so `position: sticky; top: 0`
  on `.project-h` needed no DOM change.
- Project name to `--fs-row` + bold + hairline between projects: the header was
  literally smaller type than its own children (see findings.md).
- Dormant band: remove `--bg-abyss` full-bleed; recede via opacity + mute
  instead. Darker-is-deader failed because a hard-edged rectangle reads as a
  divider, not as depth.
- A sticky header must be opaque (`--bg-tree`) so rows don't bleed through.
- Dormant caret switched from ASCII `▾`/`▸` to the shared SVG chevron.

## Changed files

- `app/src/App.css` — `.project + .project`, `.project-h` (sticky/opaque),
  `.pname` (size/weight/tracking), `.group.dormant` (fade replaces band)
- `app/src/App.tsx` — dormant header caret → `Icons.ChevronDown/Right`

## Gates

`tsc --noEmit` OK · `cargo check -p app` OK. Not run (untouched by this change):
`make test`, `make lint`, `cargo test -p worktrees-core` — run before the PR.

## Errors encountered

| Error | Attempt | Resolution |
|-------|---------|------------|
| Bare `sed -n` on App.tsx from repo root failed (cwd was `app/src`) | 1 | Used absolute/relative paths consistently |
| Harness first paint had 1 project (fixtures default) | 1 | Screenshot proved 3 projects render; enough for the check |
