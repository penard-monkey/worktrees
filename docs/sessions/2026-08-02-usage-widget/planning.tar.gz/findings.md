# Findings: Claude usage widget research

## Reference screenshot (_tmp/Screenshot 2026-08-01 at 22.36.37.png)
Claude Code /usage panel, Max (20x) plan:
- **Current session**: 35% used, resets in 54 min (5h rolling window)
- **Weekly limits — All models**: 59% used, resets Tue 12:00 AM
- **Weekly limits — Fable**: 76% used, resets Tue 12:00 AM (separate bar for Fable/top-tier model — so yes, Fable has its own tracked limit)
- **Usage credits** section below (extra paid credits)
- "Last updated: less than a minute ago" + manual refresh → data comes from server endpoint, near-real-time

## Data sources

### 1. Claude Code statusline `rate_limits` (LOCAL, already wired!)
- `~/.claude/settings.json` statusLine → `~/.claude/widgets/save_rate_limits.sh` ("Token Usage for Claude" widget, installed 27 Jul).
- Every statusline refresh, Claude Code pipes JSON to the script; it extracts `rate_limits` → saves atomically to `~/.claude/widgets/rate_limits.json`.
- Current shape: `{"five_hour":{"used_percentage":46,"resets_at":1785641400},"seven_day":{"used_percentage":61,"resets_at":1785816000}}` (resets_at = unix epoch secs).
- **Covers session (5h) + weekly all-models. NO Fable/Opus bucket in statusline payload** (whole rate_limits object is saved; only those two keys present on CC 2.1.220).
- Freshness: only updates while a Claude Code session is running/statusline fires. File mtime = staleness signal.
- Zero-auth, zero-network — app can just watch this file. Simplest source.

### 2. OAuth usage endpoint (what /usage panel uses) — VERIFIED LIVE 2026-08-01
- `GET https://api.anthropic.com/api/oauth/usage`
- Headers: `Authorization: Bearer <accessToken>`, `anthropic-beta: oauth-2025-04-20`, `User-Agent: claude-code/2.1.220` (load-bearing — wrong UA → aggressive 429 bucket), `Content-Type: application/json`.
- Token: macOS Keychain `security find-generic-password -s "Claude Code-credentials" -w` → JSON `.claudeAiOauth.accessToken` (+ refreshToken, expiresAt epoch-ms). Rotates ~hourly; Claude Code refreshes it — re-read Keychain on 401.
- **Response (live, my account):** legacy top-level `five_hour`/`seven_day` ({utilization, resets_at ISO}) — but the authoritative modern field is **`limits[]`**:
  - `{kind: "session", group: "session", percent: 47, severity: "normal", resets_at, is_active: false}`
  - `{kind: "weekly_all", group: "weekly", percent: 62, ...}`
  - `{kind: "weekly_scoped", group: "weekly", percent: 80, severity: "warning", scope: {model: {display_name: "Fable"}}, is_active: true}` ← **Fable bar IS here** (NOT in `seven_day_opus`, which is null)
- `severity` (normal/warning/...) + `is_active` = free UI signals. `spend` object = usage credits (disabled for me). Many null experimental buckets (`tangelo`, `nimbus_quill`, ...) — ignore unknown keys.
- Undocumented/unversioned; has broken before (429 incident). Poll ≥180s. Free GET — consumes no quota.

### 2b. Statusline stdin JSON (docs: code.claude.com/docs/en/statusline)
- `rate_limits.{five_hour,seven_day}.{used_percentage,resets_at(epoch-secs)}` — Pro/Max only, only after first API response in session. No model-scoped bucket, no credits.
- Also `context_window.used_percentage`, `cost.total_cost_usd`, etc. No `claude usage` CLI command exists; /usage is TUI-only.
- Unified rate-limit headers on /v1/messages responses (`anthropic-ratelimit-unified-*`) = third option, but costs quota. Not needed.

### 3. Local JSONL accounting (ccusage-style)
- `~/.claude/projects/**.jsonl` transcripts have per-message token usage; `stats-cache.json` has daily message/session/tool counts (v4, computed by CC itself).
- Gives tokens/cost estimates but NOT official limit percentages — Anthropic's limit math isn't public. Community monitors estimate; error-prone. Not recommended as primary.

## App context (where widget goes)
- Left rail = `nav.rail` in `App.tsx` (~line 2060); rail has `rail-spacer` then bottom icon cluster (toggle nav / add project / settings). Nav column has `.nav-scroll`; a status bar exists at `App.css:119` (`position: fixed; left: calc(var(--rail-w)...); bottom: var(--s3)`).
- Widget candidates: bottom of nav column (above rail-only collapse) or the fixed status strip.
- Backend: Tauri command (async fn) reading `~/.claude/widgets/rate_limits.json` + mtime; mock harness must mirror it (`app/src/mock/install.ts`).
