# Task Plan: Claude usage widget research

## Goal
Research what's possible for a bottom-left usage widget in the worktrees app showing Claude usage layers (session 5h, weekly all-models, weekly Fable/Opus), like Claude Code's /usage panel. Deliverable: findings + recommendation. No implementation yet.

## Phases
1. **Capture reference** — screenshot read (session 35%, weekly all-models 59%, weekly Fable 76%, reset times, usage credits). ✅ complete
2. **Local inspection** — ✅ complete. Jackpot: statusline hook already saves `rate_limits` (5h + 7d %) to `~/.claude/widgets/rate_limits.json`. No Fable bucket there.
3. **External research** — ✅ complete (agent report merged into findings.md).
4. **Feasibility test** — ✅ complete. Live GET to api/oauth/usage worked; `limits[]` carries session 47% / weekly_all 62% / weekly_scoped **Fable 80% (warning, active)** — all three screenshot layers + credits.
5. **Synthesize** — ✅ complete. Recommendation: Tauri backend polls oauth/usage (Keychain token) every ~3 min, statusline file as fallback; render 3 mini-bars in nav-column footer. See findings.md + final chat summary.

6. **Build** — ✅ complete. Opus agent implemented (378 lines, 4 files); fable reviewed diff (clean — fail is useCallback-stable, ISO parser correct); all gates passed; PR #74 open on ui-next. Pending: manual smoke test of Keychain→endpoint path in built app (first run = one Keychain prompt).

## Errors Encountered
| Error | Attempt | Resolution |
| push rejected: remote ui-next stale (old PR #56 branch, already squash-merged) | 1 | verified merged, force-pushed with lease |
