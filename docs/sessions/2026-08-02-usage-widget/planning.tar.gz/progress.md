# Progress

## Session 2026-08-01 (late evening)
- Started research task: usage widget for app bottom-left corner.
- Read reference screenshot, created planning files.
- Local inspection: found existing statusline hook saving rate_limits.json (5h+7d only).
- Web research agent: documented api/oauth/usage endpoint, headers, community tools.
- Live-tested endpoint from Keychain token: SUCCESS — `limits[]` has all 3 bars incl. Fable (80%, warning). Findings.md fully updated.
- Research phase DONE. Then built: Opus agent implemented, fable reviewed, gates green, PR #74.
- Release v0.7.0: CHANGELOG section + Cargo.toml bump on ui-next, gates re-run (bats asserts new version), squash-merged #74 → main 30e5088, tagged v0.7.0, tag pushed. release.yml run 30731413039 in progress (CLI ×4 + signed app bundles + latest.json).
- Release run failed once (transient artifact-upload ETIMEDOUT on aarch64 CLI job); rerun-failed → SUCCESS. v0.7.0 published: 4 CLI binaries, 2 signed app bundles + sigs, latest.json, checksums.
- Worktree now sitting on main (post-merge); fresh branch at /close-out.
- Remaining: manual smoke test — launch v0.7.0 app, approve one Keychain prompt, confirm live bars.
